    
  Open Watcom Debugger WDW

  1. About

  This version of the Open Watcom Windows debugger WDW ( "NT" platforms
  only, won't run on Win9x or ME ) may debug Win32, Win16 and DOS
  applications locally, with full support for symbolic debugging.


  2. Installation

  WDW doesn't need an installation procedure. If you don't want to
  enter WDW's full path to start it, you'll have to add the directory
  where WDW was installed to your PATH environment variable.


  3. Prepare for Debugging

  The assembly source that is to be debugged has to be assembled with 
  JWasm's or Masm's -Zi option. Example:

  JWasm -coff -Zi test.asm

  On the link step, one has to tell Wlink or JWlink that a) codeview
  debug info is to be generated and b) that the linker is to run
  the CVPACK utility. Examples:

  Win32: JWlink debug c op cvpack format win pe file test.obj
  Win16: JWlink debug c op cvpack format win file test.obj
  DOS:   JWlink debug c op cvpack format dos file test.obj

  Note that for Win32 the linker must be Open Watcom's Wlink or JWlink; 
  MS link or PoLink can't be used, because they store the debug info in a 
  format unknown to WDW. 
   For Win16 or DOS, the old MS OMF linker may be used alternately:
   
  Win16: link /CO test.obj,,,libw.lib,test.def
  DOS:   link /CO test.obj;


  4. Hints

  a). The default setting of the debugger is to search for symbol main or 
      WinMain and stop there. Since an assembly program does not necessarily
      have such labels, the result may be that the debugger is unable to 
      halt the debuggee. To avoid this, there's an alternate config file, 
      WDASM.DBG; to use it, the debugger must be launched with commandline
      option /I=wdasm.dbg. WDW will stop at the program's entry point.

  b). For DOS programs, it is "sometimes" necessary to add OPTION SYMFILE 
      to enable symbolic debugging.

  c). To debug a running process, one has to start the debugger with a numeric
      argument that is supposed to be the process id. The id is assumed to be
      in decimal, unless it is preceded by a # - then the number is assumed to
      be hexadecimal.

  d)  To make the debugger stop at the initial breakpoint ( when dlls have
      been loaded, but aren't initialized yet ), add "/tr=std;i" to the 
      debugger's commandline.

  e)  To prevent the debuggee's console window to be closed when the program
      has terminated, add "/tr=std;w" to the debugger's commandline.


  5. Known Bugs
  
  a)  In assembly programs, if a procedure starts at offset 0, the contents
      of local variables won't be shown.


  6. Modifications

  This is a modified OW 1.9 version of WDW. The modified files in the 
  package are:

  - wdw.exe:
    + no annoying MessageBox if an exception occured, just a text in the
      status line is displayed.
    + won't loose control of debuggee in assembly mode if a call opcode
      caused the debugger to insert a break instead of setting the trace
      flag.
    + will search for .dbg, .prs and .hlp files in the directory where the
      debugger binary is stored. No need to add this directory to the PATH
      variable.

  - std.dll:
    + allows local debugging of VDM ( Win16 and DOS ) applications.
    + process id is supposed to be in decimal.
    + changed default behavior: first stop won't be at initial breakpoint,
      but at the application's entry point. 
    + debugger optionally waits when a process has terminated.

  - codeview.dll: 
    + bug 1118 (OW Bugzilla) fixed ( missing CodeView symbol types S_BLOCK16
      and S_BLOCK32 ).

  - default.dbg: 
    + register window is visible on default (on the upper right corner ).


  japheth

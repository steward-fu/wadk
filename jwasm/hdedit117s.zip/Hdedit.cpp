
// simple disk editor for DOS & Windows

#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>
#include <assert.h>
#include <io.h>
#include <sys\stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <fcntl.h>
#include <share.h>
#include <largeint.h>

#include "txtcua32.h"
#include "readdisk.h"
#include "hdedit.h"
#include "resource.h"

#define FOREGROUND_WHITE FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED
#define FOREGROUND_BLACK 0
#define FOREGROUND_YELLOW FOREGROUND_GREEN | FOREGROUND_RED
#define BACKGROUND_WHITE BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED
#define BACKGROUND_BLACK 0
#define BACKGROUND_CYAN  0x00030

#define BEGSUFFIX 9 + 16 * 3 
#define FIND_FILES  DDL_READONLY  | DDL_HIDDEN | DDL_SYSTEM
#define FIND_SUBDIR DDL_DIRECTORY | DDL_DRIVES | DDL_EXCLUSIVE | DDL_READONLY | DDL_HIDDEN | DDL_SYSTEM

// global variables
int g_iDrive = 0x80;
__int64 g_uCurrSec = 0;

HANDLE hScreen   = 0 ; // video output handle
HANDLE hKbd      = 0 ; // kbd input handle
HANDLE hSave     = 0 ; // original video state handle
HTWND  hWndMain  = 0 ; // hWnd main window
HTWND  hWndStat  = 0 ; // hWnd status line
HTWND  hWndSector = 0; // hWnd sector input
HTXTMENU hMenu   = 0 ; // main menu
char * pVideo    = 0 ; // pointer to screen buffer
int    columns   = 0 ; // number of screen columns
int    rows      = 0 ; // number of screen rows

int    fHex      = 1 ; // hex mode?
int    fEdit     = 0 ; // view/edit?
int    fDispCR   = 0 ; // display CR?
int    fLineWrap = 0 ; // line wrap? (not used, but needed by pager.asm)
int    fAnsi     = 0 ; // OEM/Ansi? (not used)
int    fMono     = 0 ; // force mono colors
int    fModified = 0 ; //
int    g_fInt13Ext = FALSE; // if TRUE, int 13 extensions available
int    fExtEnabled = TRUE; // if TRUE, use int 13 extensions

int    statatr   =   TW1ATTR ; // status line Color
int    sectoratr =   TW1ATTRX ; // sector edit Control Color
int    prefatr   =   TW4ATTR ; // line prefix (hexmode)

int    scrnatrv  =   TW2ATTRV ; // view mode screen Color
int    scrnatre  =   TW2ATTRE ; // edit mode screen Color
int    suffatrv  =   TW5ATTRV ; // suffix (=text)
int    suffatre  =   TW5ATTRE ; // suffix (=text)

// Variables for buffer and file handling

char *  pStaBuf = 0 ;       // ^ start sector buffer
char *  pEndBuf  = 0 ;      // ^ end sector buffer
char *  pClipBoard = 0;
int     iBufPos  = 0 ;      // position in work area (offset in pStaBuf)
int     linenum  = 1 ;
int     bufsize  = 0x200 ;  // buffer size
int     dwTabExt = 4 ;      // needed by pager.asm

char    * g_pFileName = 0;
char    * g_pExePath = 0;
int    lerror      = 0;
DPPACKET dpp = {sizeof(DPPACKET)};

// char   tPRN[4]      = {"PRN"};

// function prototypes

void static upk(void);
void static downk(void);
void static leftk(void);
void static rightk(void);
void static homek(void);
void static pgupk(void);
void static endk(void);
void static pgdnk(void);
void static pgupk2(void);
void static pgdnk2(void);
void static esck(void);
void static tabk(void);
void static returnk(void);

int _stdcall SetStandardStatusLine(void);
int checkmodified(HTWND);
int readnewsector(int iNewDrive,__int64 uNewSector, char * pBuffer);
int InitApp(void);

typedef void (*LPKEYFUNC)(void);

typedef struct tKEYFUNC {
	BYTE key;
	LPKEYFUNC kproc;
} KEYFUNC;

// key table

KEYFUNC keytable[] = {
	VK_UP,     upk     ,
	VK_DOWN,   downk   ,
	VK_PRIOR,       pgupk   ,
	VK_NEXT,     pgdnk   ,
	VK_ESCAPE,   esck    ,
	VK_TAB,      tabk    ,
	VK_LEFT,     leftk   ,
	VK_RIGHT,    rightk  ,
	VK_RETURN,   returnk ,
	0xFF};

KEYFUNC keytable_ctrl[] = {
	VK_PRIOR, homek   ,
	VK_NEXT,  endk    ,
	VK_UP,    pgupk2  ,
	VK_DOWN,  pgdnk2,
	0xFF};

void _cdecl SetModifiedFlag(void)
{
	fModified = TRUE;
}

// key commands

void static esck(void) {
	TextSendMessage(hWndMain,WM_COMMAND,ID_EXIT,0);
	return;
}
void static homek(void) {
	iBufPos = 0;	     // HOME - set position to 0
	linenum = 1;
	updateview(0);
	return;
}
void static upk(void) {		       // UP - scroll back 1 line
	updateview(-1);
	return;
}
void static pgupk(void) {
				   // PGUP - Page back
	updateview(~rows);
	return;
}
void static pgupk2(void) {
	updateview(~rows / 2);
	return;
}
void static endk(void) {
	iBufPos = bufsize;
	linenum = -1;	    // Set illegal line number as flag
	updateview(~(rows-1));
	return;
}
void static downk(void) {		     // DOWN - scroll forward 1 line
	updateview(1);
	return;
}
void static pgdnk(void) {
				   // PGDN - page forward
	updateview(rows);
	return;
}
void static pgdnk2(void) {
	updateview(rows/2);
	return;
}
void static leftk(void) {
	if (g_uCurrSec)
		readnewsector(g_iDrive, g_uCurrSec - 1, pStaBuf);
}
void static rightk(void) {
	readnewsector(g_iDrive,g_uCurrSec + 1, pStaBuf);
}

int ReadDiskEx(int iDrive,__int64 uStartSec,char * pStaBuf,int NumSecs)
{
	if (g_fInt13Ext)
		return ReadDisk(iDrive,uStartSec,pStaBuf,NumSecs);
	else
		return ReadDiskCHS(iDrive,(int)uStartSec,pStaBuf,NumSecs);
}

int WriteDiskEx(int iDrive,__int64 uStartSec,char * pStaBuf,int NumSecs)
{
	if (g_fInt13Ext)
		return WriteDisk(iDrive,uStartSec,pStaBuf,NumSecs);
	else
		return WriteDiskCHS(iDrive,(int)uStartSec,pStaBuf,NumSecs);
}

int SwitchWindow()
{
	HTWND htWnd;
	char szStr[20];
	char szRest[20];
	__int64 uNewSec;
	int i = 0;

	htWnd = TextGetFocus();
	if (htWnd == hWndMain) {
		TextEnableMenuItem(hMenu,ID_SECEDT,TM_BYCOMMAND | TM_DISABLED);
		TextSetFocus(hWndSector);
		TextSetWindowColor(hWndSector,sectoratr);
		TextSendMessage(hWndSector,WM_NCPAINT,0,0);	// Attribute update
	} else {
		if (TextGetWindowText(hWndSector,szStr,sizeof(szStr)))
			i = sscanf(szStr," %I64u %s",&uNewSec,szRest);
		if (i == 1) {
			if (readnewsector(g_iDrive,uNewSec, pStaBuf)) {
				TextSetWindowColor(hWndSector,statatr);
				TextEnableMenuItem(hMenu,ID_SECEDT,TM_BYCOMMAND | TM_ENABLED);
				TextSendMessage(hWndSector,WM_NCPAINT,0,0);
				TextSetFocus(hWndMain);
			} else {
				sprintf(szStr,"%I64u",g_uCurrSec);
				TextSetWindowText(hWndSector,szStr);
				updateview(0);
				return 0;
			}
		} else {
			TextMessageBeep();
			return 0;
		}
	}
	return 1;
}

void static tabk(void) {
	SwitchWindow();
}

void static returnk(void) {
	if (TextGetFocus() == hWndSector)
		tabk();
}

void _stdcall updateview(int iScroll) {
	_pager(iScroll);
	TextUpdateWindow(hWndMain);
	SetStandardStatusLine();
	return;
}

int ExtensionsAvailable(int iNewDrive)
{
	if (fExtEnabled)
		if (GetInt13Extensions(iNewDrive))
			return GDP_USEINT13EXT;
	return 0;
	
}

long CALLBACK sectorscallback(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	long rc = 0;
	char szStr[80];
	int i;

	switch (message) {
	case WM_INITDIALOG:
		sprintf(szStr,"%u",lParam);
		TextSetDlgItemText(hWnd, IDC_SECTORS, szStr);
		break;
	case  WM_DESTROY:
		break;
	case  WM_COMMAND:
		switch (wParam) {
		case IDCANCEL:
			TextEndDialog(hWnd,0);
			break;
		case IDOK:
			if (TextGetWindowText(TextGetDlgItem(hWnd, IDC_SECTORS), szStr, sizeof(szStr))) {
				if (sscanf(szStr,"%u",&i))
					TextEndDialog(hWnd,i);
				else
					TextMessageBeep();
			};
			break;
		}
	}
	return rc;
}


// read a new sector and set global vars

int readnewsector(int iNewDrive,__int64 uNewSector, char * pStaBuf)
{
	int i,fTmpInt13Ext;
	DPPACKET tmpdpp;
	void * pTmp;
	char szStr[260];

	if ((g_iDrive != iNewDrive) || (uNewSector != g_uCurrSec)) {
		if (!checkmodified(hWndMain))
			return 0;
		if (g_iDrive != iNewDrive) {
			fTmpInt13Ext = ExtensionsAvailable(iNewDrive);
			tmpdpp.wSize = sizeof(DPPACKET);
			if ( GetDriveParameters( iNewDrive, &tmpdpp, fTmpInt13Ext ) )
				if (tmpdpp.wBytSec > bufsize) {
					if (pTmp = (char *)malloc(tmpdpp.wBytSec)) {
						free(pStaBuf);
						pStaBuf = (char *)pTmp;
						pEndBuf = pStaBuf + tmpdpp.wBytSec;
					} else
						return 0;
				}
		} else
			fTmpInt13Ext = g_fInt13Ext;

		if (fTmpInt13Ext)
			i  = ReadDisk(iNewDrive, uNewSector, pStaBuf, 1);
		else 
			if ((uNewSector / (dpp.dwHeads * dpp.dwSecs) > 1023)) {
				sprintf(szStr,szOverflowErr,uNewSector,dpp.dwCyls,dpp.dwHeads,dpp.dwSecs);
				TextMessageBox(hWndMain,5,5,szStr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR1);
				return 0;	
			} else
				i = ReadDiskCHS(iNewDrive, (int)uNewSector, pStaBuf, 1);

		if (i == 0) {
			sprintf(szStr,szReadError,uNewSector);
			TextMessageBox(hWndMain,5,5,szStr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR1);
			return 0;
		}
		if (g_iDrive != iNewDrive) {
			memcpy(&dpp,&tmpdpp,sizeof(DPPACKET));
			g_fInt13Ext = fTmpInt13Ext;
			g_iDrive = iNewDrive;
			if (bufsize < tmpdpp.wBytSec) {
				bufsize = tmpdpp.wBytSec;
			}
			if (g_iDrive < 0x80)
				TextEnableMenuItem(hMenu,ID_PARTITION,TM_BYCOMMAND | TM_DISABLED);
			else
				TextEnableMenuItem(hMenu,ID_PARTITION,TM_BYCOMMAND | TM_ENABLED);
		}
		g_uCurrSec = uNewSector;
		sprintf(szStr,"%I64u",g_uCurrSec);
		TextSetWindowText(hWndSector,szStr);
		updateview(0);
		return 1;
	}
	return 1;
}

// rewrite a sector

int rewritesector()
{
	if (!WriteDiskEx(g_iDrive, g_uCurrSec, pStaBuf,1)) {
		TextMessageBox(hWndMain,8,8,szWriteError,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR2);
		return 0;
	} else
		fModified = FALSE;
	return 1;
}

// read a file and write it to disk

int MyReadFile(HTWND hWnd, PSTR pName)
{
	int iFsize;
	int rc = 1;
	int nSectors = 1;
	char szStr[80];
	int handle;
	int rEAX;
	char * pTmpBuffer;
	
	assert(hWnd);

	handle = _sopen(pName,_O_RDONLY | _O_BINARY,_SH_DENYNO);
	if (handle == -1) {
		TextMessageBox(hWnd,6,6,openreaderr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR2);
		return 0;
	}

	iFsize = _filelength(handle);
	nSectors = TextDialogBoxIndirectParam( 0, &loadsectorsdlgtemp, hWnd, sectorscallback, iFsize/512);
	if ((!nSectors) || (nSectors > iFsize/512)) {
		_close(handle);
		return 0;
	}

	pTmpBuffer = (char *)malloc(bufsize);
	if (!pTmpBuffer) {
		_close(handle);
		TextMessageBox(hWnd,6,6,szMemError,errstr,TMB_OK | TMB_BEEP);
		return 0;
	}

	rc = 1;
	for (;nSectors;nSectors--) {
		rEAX = _read(handle,pTmpBuffer,bufsize);
		if (rEAX != bufsize) {
			TextMessageBox(hWnd,6,6,readerr,errstr,TMB_OK | TMB_BEEP);
			rc = 0;
			break;
		}
		memcpy(pStaBuf,pTmpBuffer,bufsize);
		fModified = TRUE;
		if (nSectors > 1) {
			rewritesector();
			g_uCurrSec++;
		}
	}
	free(pTmpBuffer);
	_close(handle);
	sprintf(szStr,"%I64u",g_uCurrSec);
	TextSetWindowText(hWndSector,szStr);
	updateview(0);
	return rc;
}

// save sectors to a file

BOOL SaveFile(HTWND hWnd, PSTR pName, int nSectors)
{
	char szStr[_MAX_PATH+40];
	int handle;
	int i,k;
	_int64 j;
	char * pTmp;
	BOOL rc = TRUE;

	handle = _open(pName,_O_CREAT | _O_TRUNC | _O_BINARY | _O_WRONLY,_S_IREAD | _S_IWRITE);
	if (handle == -1) {
		sprintf(szStr,createrr,pName);
		TextMessageBox(hWnd,6,6,szStr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR2);
		rc = FALSE;
	} else {
		i = _write(handle,pStaBuf,bufsize);
		if (nSectors > 1) {
			if (pTmp = (char *)malloc(bufsize)) {
				for (j = g_uCurrSec+1;nSectors > 1; nSectors--,j++) {
					if (ReadDiskEx(g_iDrive, j, pTmp, 1)) {
						k = _write(handle,pTmp,bufsize);
						if (k != bufsize)
							break;
					} else
						break;
				}
				free(pTmp);
			}
		}
		_close(handle);
		if (i != bufsize) {
			sprintf(szStr,writerr,pName);
			TextMessageBox(hWnd,6,6,szStr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR2);
			rc = FALSE;
		}
	}
	return rc;
}

PSTR finderrorstr(int error)
{
BYTE c;
ERRELEM * pErr;

	c = (BYTE)error;
	for (pErr = errstrgs;pErr->errno != -1;pErr++) {
		if (pErr->errno == c)
			break;
	}
	return pErr->pErrstr;
}

// fill a line in the "drive select" listbox

int filldrivelb(int drive, HTWND hWndLB)
{
	int j;
	int fTmpInt13Ext = 0;
	DPPACKET tmpdpp;
	char szStr[80];
	char szExt[12];

	j = GetInt13Extensions( drive );
	if (j)
		fTmpInt13Ext = GDP_USEINT13EXT;
	tmpdpp.wSize = sizeof( DPPACKET );
	if ( GetDriveParameters( drive, &tmpdpp, fTmpInt13Ext ) ) {
		if (j)
			sprintf(szExt,"%2u.%u/%u",(j >> 12) & 0xF,(j >> 8) & 0xF,j & 0xFF);
		else
			strcpy( szExt, strNo );
		sprintf( szStr,"%2X  %5u/%4u/%3u   %10I64u %6u    %s",
				drive,
				tmpdpp.dwCyls,
				tmpdpp.dwHeads,
				tmpdpp.dwSecs,
				tmpdpp.qwNumSecs,
				(int)(tmpdpp.qwNumSecs/2048),
				szExt
				);
		j = TextListBoxAddString( hWndLB, szStr );
		TextListBoxSetItemData( hWndLB, j, drive);
		if ( drive == g_iDrive )
			TextListBoxSetSelItem( hWndLB, j );
	}
	return 1;
}

// change drive dialog proc

long CALLBACK changedrivedlgcallback(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	long rc = 0;
	int uNewDrive = -1;
	HTWND hWndLB;
	int i;
	static int uNumHDs = 0;
	static int uNumFDs = 0;

	switch (message) {
	case WM_INITDIALOG:
		uNumHDs = GetDriveCnt( FALSE );
		uNumFDs = GetDriveCnt( TRUE );
		hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX3);
		if ( uNumFDs + uNumHDs > 4 )
			TextListBoxSetFlags(hWndLB, TextListBoxGetFlags(hWndLB) | LBS_VSCROLL);
		for ( i = 0;i < uNumFDs;i++ ) {
			filldrivelb( i, hWndLB );
		}
		for ( i = 0;i < uNumHDs;i++ ) {
			filldrivelb( i+0x80, hWndLB );
		}
		break;
	case WM_CLOSE:
		TextEndDialog(hWnd,TextGetDialogData(hWnd));
		break;
	case WM_COMMAND:
		switch (wParam) {
		case IDCANCEL:
			TextSetDialogData(hWnd,g_iDrive);
			TextSendMessage(hWnd,WM_CLOSE,0,0);
			break;
		case IDOK:
			if (hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX3)) {
				i = TextListBoxGetSelItem(hWndLB);
				uNewDrive = TextListBoxGetItemData(hWndLB,i);
				if (((uNewDrive < 0x80) && (uNewDrive < uNumFDs)) || ((uNewDrive >= 0x80) && (uNewDrive < uNumHDs+0x80))) {
					TextSetDialogData(hWnd,uNewDrive);
					TextSendMessage(hWnd,WM_CLOSE,0,0);
				} else
					TextMessageBeep();
			}
			break;
		}
	}
	return rc;
}

// open "change drive" dialog

int ChangeDriveDialog(HTWND hWnd)
{
	int uNewDrive;
	
	uNewDrive = TextDialogBoxIndirect(0,&changedrivedlgtemp,hWnd,changedrivedlgcallback);
	if (uNewDrive != g_iDrive) {
		if (readnewsector(uNewDrive, 0, pStaBuf)) {
			TextSendMessage(hWndStat,WM_NCPAINT,0,0);
			TextSendMessage(hWndSector,WM_NCPAINT,0,0);
		}
	}
	return 1;
}

// "readme" dialog proc

long CALLBACK readmedlgcallback(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	char *pStr;
	char *pBuffer;
	int hFile;
	int i;
	HTWND hWndLB;
	long rc = 0;
	char szBuffer[128];
	char szPath[_MAX_PATH];
	char szStr[80];

	switch (message) {
	case WM_INITDIALOG:
		if (!(hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX1)))
			break;
		sprintf(szPath,"%s%s",g_pExePath,"hdedit.txt");
		if (-1 != (hFile = _open(szPath,_O_RDONLY | _O_TEXT))) {
			pStr = szStr;
			while (i = _read(hFile,szBuffer,sizeof(szBuffer))) {
				for (pBuffer = szBuffer;i;i--,pBuffer++) {
					if (*pBuffer == '\n') {
						*pStr = 0;
						TextListBoxAddString(hWndLB,szStr);
						pStr = szStr;
					} else {
						if ((pStr - szStr) < sizeof(szStr))
							*pStr++ = *pBuffer;
					}
				};
			}
			_close(hFile);
		} else {
			strcat(szPath, " not found");
			TextListBoxAddString(hWndLB, szPath);
		}
		break;
	case WM_CLOSE:
		TextEndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		switch (wParam) {
		case IDCANCEL:
		case IDOK:
			TextSendMessage(hWnd,WM_CLOSE,0,0);
			break;
		}
	}
	return rc;
}

// open "readme" dialog

int ReadmeDialog(HTWND hWnd)
{
	TextDialogBoxIndirect(0,&readmedlgtemp,hWnd,readmedlgcallback);

	return 1;
}

// open "saveas" dialog

int SaveFileDlg(HTWND hWnd, int nSectors)
{
	OPENFILEDLG ofd;
	static char szFind[_MAX_PATH] = {"*.*"};
	char szFName[_MAX_FNAME];
	char szDir[_MAX_DIR];
	char szExt[_MAX_EXT];
	char szDrive[_MAX_DRIVE];
	char szStr[300];

	if (!g_pFileName) {
		if (g_pFileName = (char *)malloc(_MAX_PATH))
			*g_pFileName = 0;
	}

	if (g_pFileName) {
		_splitpath(g_pFileName,szDrive,szDir,szFName,szExt);
		strcat(szFName,szExt);
		strcpy(szStr,szDrive);
		strcat(szStr,szDir);
	}

	ofd.hWnd = hWnd;
	ofd.pszFind = szFind;
	ofd.lszFind = sizeof(szFind);
	ofd.pszFileName = szFName;
	ofd.lszFileName = sizeof(szFName);
	ofd.fFiles  = FIND_FILES;
	ofd.fSubDir = FIND_SUBDIR;
	ofd.pszStartDir = szStr;
	ofd.pszResource = 0;
	ofd.flags = TOFN_OVERWRITEPROMPT;
	if (TextGetSaveFileName(&ofd)) {
		if (SaveFile(hWnd,ofd.pszFileName, nSectors)) {
			if (g_pFileName)
				strcpy(g_pFileName,szFName);
			sprintf(szStr,writehint,ofd.pszFileName);
			TextMessageBox(hWnd,8,8,szStr,hintstr,TMB_OK);
		}
	}
	return 1;
}

// open "load" dialog

int OpenFileDlg(HTWND hWnd)
{
	OPENFILEDLG ofd;
	static char szFind[_MAX_PATH] = {"*.*"};
	char szStr[_MAX_PATH];

	ofd.hWnd = hWnd;
	ofd.pszFind = szFind;
	ofd.lszFind = sizeof(szFind);
	ofd.pszFileName = szStr;
	ofd.lszFileName = sizeof(szStr);
	ofd.fFiles  = FIND_FILES;
	ofd.fSubDir = FIND_SUBDIR;
	ofd.pszStartDir = 0;
	ofd.pszResource = 0;
	ofd.flags = TOFN_FILEMUSTEXIST;
	if (!TextGetOpenFileName(&ofd))
		return 0;
	return MyReadFile(hWnd,ofd.pszFileName);
}

// get partition type

void GetPartitionType(BYTE bType,char * szType)
{
	PTYPE * pt;

	for (pt = partab;pt->type != 0xFF;pt++)
		if (pt->type == bType) {
			strcpy(szType,pt->szType);
			return;
		}
	*szType = 0;
	return;
}

// "edit partition" dialog proc

long CALLBACK parteditcallback(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	char szStr[80];
	char szCtrl[20];
	char * pStr;
	unsigned int dwCyl1,dwCyl2;
	PARENTRY *pPart;
	int i,j;
	unsigned int utab[10];
	BOOL fError = FALSE;
	long rc = 0;
	int itab[] = {2,IDC_BI,2,IDC_TYP,4,IDC_BEGCYL,3,IDC_BEGHEAD,2,IDC_BEGSEC,
		4,IDC_ENDCYL,3,IDC_ENDHEAD,2,IDC_ENDSEC,12,IDC_LBASTASEC,12,IDC_LBANUMSEC,0};

	switch (message) {
	case WM_INITDIALOG:
		TextSetDialogData(hWnd,lParam);
		pPart = (PARENTRY *)lParam;
		dwCyl1 = (pPart->wBegCyl >> 8) + ((pPart->wBegCyl & 0xC0) << 2);
		dwCyl2 = (pPart->wEndCyl >> 8) + ((pPart->wEndCyl & 0xC0) << 2);
		sprintf(szStr,"%02X %02X %4u %3u %2u %4u %3u %2u %12u %12u",
						pPart->bFlags,
						pPart->bType,
						dwCyl1,
						pPart->bBegHead,
						pPart->wBegCyl & 0x3F,
						dwCyl2,
						pPart->bEndHead,
						pPart->wEndCyl & 0x3F,
						pPart->dwBegSec,
						pPart->dwNumSec);

//----------------------------- set all controls
		pStr = szStr;
		for (j=0,pStr = szStr;itab[j];j = j + 2) {
			i = itab[j];
			while (*pStr == ' ') {
				pStr++;
				i--;
			}
			memcpy(szCtrl,pStr,i); 
			szCtrl[i] = 0;
			TextSetWindowText(TextGetDlgItem(hWnd,itab[j+1]),szCtrl);
			pStr = pStr + i + 1;
		}
//----------------------------- if it is LBA, reset "auto" button
		if (pPart->bType == 0x0C || pPart->bType == 0x0E || pPart->bType == 0x0F) {
			lParam = (LPARAM)TextGetDlgItem(hWnd, IDC_BUTTON1);
			TextSendMessage((HTWND)lParam, BM_SETCHECK, 0, 0);
			TextSendMessage(hWnd, WM_COMMAND, IDC_BUTTON1, lParam);
		}

		break;
	case  WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_BUTTON1:
			i = TextSendMessage((HTWND)lParam,BM_GETCHECK,0,0);
			if (i)
				i = 0;
			else
				i = 1;
			TextEnableWindow(TextGetDlgItem(hWnd,IDC_LBASTASEC),i);
			TextEnableWindow(TextGetDlgItem(hWnd,IDC_LBANUMSEC),i);
			break;
		case IDCANCEL:
			TextEndDialog(hWnd,0);
			break;
		case IDOK:
			szStr[0] = 0;
			for (j=0;itab[j];j = j + 2) {
				TextGetWindowText(TextGetDlgItem(hWnd,itab[j+1]),szCtrl,sizeof(szCtrl));
				strcat(szStr,szCtrl); 
				strcat(szStr," "); 
			}
			i = sscanf(szStr,"%X %X %u %u %u %u %u %u %u %u",
						&utab[0],
						&utab[1],
						&utab[2],
						&utab[3],
						&utab[4],
						&utab[5],
						&utab[6],
						&utab[7],
						&utab[8],
						&utab[9]);
			if (i != 10)
				fError = TRUE;
			if ((utab[2] > 1023) || (utab[5] > 1023))
				fError = TRUE;
			if (utab[2] > utab[5])
				fError = TRUE;
			if ((utab[3] > 255) || (utab[6] > 255))
				fError = TRUE;
//			if ((utab[4] < 1) || (utab[7] < 1))
//				fError = TRUE;
			if ((utab[4] > 63) || (utab[7] > 63))
				fError = TRUE;

			if (!fError) {
				i = TextSendMessage(TextGetDlgItem(hWnd,IDC_BUTTON1),BM_GETCHECK,0,0);
				if (i) {
					utab[8] = utab[2] * dpp.dwHeads * dpp.dwSecs +
							utab[3] * dpp.dwSecs +
							utab[4];
					if (utab[8] > 0)
						utab[8] = utab[8] - 1;
					utab[9] = utab[5] * dpp.dwHeads * dpp.dwSecs +
							utab[6] * dpp.dwSecs +
							utab[7];
					if (utab[9] > utab[8])
						utab[9] = utab[9] - utab[8];
					else
						utab[9] = 0;
				}
			}

			if (fError)
				TextMessageBeep();
			else {
				pPart = (PARENTRY *)TextGetDialogData(hWnd);
				pPart->bFlags   = utab[0];
				pPart->bType    = utab[1];
				pPart->wBegCyl  = ((utab[2] & 0xFF)<<8) | ((utab[2]>>2) & 0xC0) | utab[4];
				pPart->bBegHead = utab[3];
				pPart->wEndCyl  = ((utab[5] & 0xFF)<<8) | ((utab[5]>>2) & 0XC0) | utab[7];
				pPart->bEndHead = utab[6];
				pPart->dwBegSec = utab[8];
				pPart->dwNumSec = utab[9];
				TextEndDialog(hWnd,1);
			}
			break;
		}
	}
	return rc;
}

// "view partition" dialog proc

long CALLBACK partitioncallback(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	long rc = 0;
	static char * pTemp = 0;
	static BOOL fChanged = FALSE;
	static BOOL fReadOnly = FALSE;
	char szStr[80];
	char szType[11];
	PARENTRY *pPart;
	PARENTRY PETemp;
	HTWND hWndLB;
	unsigned int dwCyl1,dwCyl2;
	int i,j,k;

	switch (message) {
	case WM_INITDIALOG:
		sprintf(szStr, str62, g_iDrive);
		TextSetWindowText(hWnd,szStr);
		hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX2);
		TextListBoxResetContent(hWndLB);
		fReadOnly = FALSE;
		if (!pTemp) {
			pTemp = (char *)malloc(bufsize);
			if (pTemp)
				if (g_uCurrSec == 0) {
					memcpy( pTemp, pStaBuf, bufsize);
				} else {
					if (!(i = ReadDiskEx(g_iDrive,0,pTemp,1))) {
						sprintf(szStr,szReadError,0);
						TextMessageBox(hWnd,5,5,szStr,errstr,TMB_OK | TMB_BEEP | TMB_ALTCOLOR1);
						memset(pTemp,0,bufsize);
					}
				}
		}
		if (pTemp) {
			if (*(WORD *)(pTemp+0x1FE) != 0xAA55) {
//				memset(pTemp,0,bufsize);
				fReadOnly = TRUE;
			};
			pPart = (PARENTRY *)(pTemp+0x1BE);
			for (i=4;i;i--,pPart++) {
				dwCyl1 = (pPart->wBegCyl >> 8) + ((pPart->wBegCyl & 0xC0) << 2);
				dwCyl2 = (pPart->wEndCyl >> 8) + ((pPart->wEndCyl & 0xC0) << 2);
				GetPartitionType(pPart->bType,szType);
				sprintf(szStr,"%1u %02X %02X %-10s %4u/%4u/%3u  %4u/%4u/%3u  %10u %10u",
						5-i,
						pPart->bFlags,
						pPart->bType,
						szType,
						dwCyl1,
						pPart->bBegHead,
						pPart->wBegCyl & 0x3F,
						dwCyl2,
						pPart->bEndHead,
						pPart->wEndCyl & 0x3F,
						pPart->dwBegSec,
						pPart->dwNumSec
						);
				j = TextListBoxAddString(hWndLB,szStr);
				TextListBoxSetItemData(hWndLB,j,pPart->dwBegSec);
				if (!j)
					TextListBoxSetSelItem(hWndLB,j);
			}
		}
		break;
	case  WM_DESTROY:
		free(pTemp);
		pTemp = 0;
		fChanged = FALSE;
		break;
	case  WM_COMMAND:
		switch (wParam) {
		case IDCANCEL:
			i = IDYES;
			if (fChanged)
				i = TextMessageBox(hWnd,9,9,str72,warnstr,TMB_YESNO | TMB_DEFBUTTON2 | TMB_ALTCOLOR1);
			if (i == IDYES)
				TextEndDialog(hWnd,0);
			break;
		case IDOK:
			if (pTemp) {
				hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX2);
				k = TextListBoxGetSelItem(hWndLB);
				pPart = (PARENTRY *)(pTemp+0x1BE);
				pPart = pPart + k;
				memcpy(&PETemp,pPart,sizeof(PARENTRY));
				if (TextDialogBoxIndirectParam(0,&parteditdlgtemp,hWnd,parteditcallback,(long)pPart)) {
					if (memcmp(&PETemp,pPart,sizeof(PARENTRY))) {
						TextEnableWindow(TextGetDlgItem(hWnd,IDC_SAVE),1);
						fChanged = TRUE;
						TextSendMessage(hWnd,WM_INITDIALOG,0,0);
						TextListBoxSetSelItem(hWndLB,k);
						TextSendMessage(hWndLB,WM_PAINT,0,0);
					}
				}
			}
			break;
		case IDC_SAVE:
			if (pTemp && (fReadOnly == FALSE)) {
				if (i = WriteDiskEx(g_iDrive,0,pTemp,1)) {
					fChanged = FALSE;
					TextEnableWindow(TextGetDlgItem(hWnd,IDC_SAVE),0);
					if (g_uCurrSec == 0)
						memcpy(pStaBuf+0x1BE,pTemp+0x1BE,0x40);
				} else {
					TextMessageBox(hWnd,7,7,szWriteError,0,TMB_OK | TMB_BEEP | TMB_ALTCOLOR2);
				}
			}
			TextEndDialog(hWnd,1);
			break;
		case IDC_POS:
			i = IDYES;
			if (fChanged)
				i = TextMessageBox(hWnd,9,9,str72,warnstr,TMB_YESNO | TMB_DEFBUTTON2 | TMB_ALTCOLOR1);
			if (i == IDYES) {
				hWndLB = TextGetDlgItem(hWnd,IDC_LISTBOX2);
				if ((i = TextListBoxGetSelItem(hWndLB)) != -1) {
					i = TextListBoxGetItemData(hWndLB,i);
					readnewsector(g_iDrive,i, pStaBuf);
				}
				TextEndDialog(hWnd,1);
			}
			break;
		}
	}
	return rc;
}

// open "view partition" dialog

int PartitionDlg(HTWND hWnd)
{
	if (TextDialogBoxIndirect(0,&partitiondlgtemp,hWnd,partitioncallback))
		updateview(0); // refresh main window
	return 1;
}

// update status line

int _stdcall SetStatusLine(PSTR pText)
{
	if (pText)
		TextSetWindowText(hWndStat,pText);
	else
		TextSetWindowText(hWndStat,"");
	TextUpdateWindow(hWndStat);
	return 1;
}

// reset status line to default

int _stdcall SetStandardStatusLine(void)
{
	int i;
	char szStr[81];

	i = sprintf(szStr,stathelp,g_iDrive,dpp.qwNumSecs,dpp.dwCyls,dpp.dwHeads,dpp.dwSecs);
	SetStatusLine(szStr);
	TextSetWindowPos(hWndSector,i,rows+1);
	TextUpdateWindow(hWndSector);
	return 1;
}

// handle menu select msg of main menu

int handlemenuselect(int wParam)
{
	int i;
	char szStr[80];
	MENUDESC * pMD = mainmenu;

	if (wParam != -1)
	for (i = 0;i < lmainmenu;i++,pMD++) {
		if (wParam == pMD->id) {
			TextSendMessage(hWndStat,WM_NCPAINT,0,0);	// Attribute update
			strcpy(szStr+1,pMD->hlpptr);
			szStr[0] = ' ';
			SetStatusLine(szStr);
			return 1;
		}
	}
	TextSendMessage(hWndSector,WM_NCPAINT,0,0);	// Attribute update
	SetStandardStatusLine();
	return 0;
}

// start a DOS shell

void StartShell()
{
	HANDLE hTempSave;
	char szStr[_MAX_PATH];
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	if (GetEnvironmentVariable("COMSPEC",szStr,sizeof(szStr))) {
		if (hTempSave = SaveVideoState(hScreen)) {
			LoadVideoState(hScreen,hSave);
			memset(&si,0,sizeof(si));
			si.cb = sizeof(si);
			if (CreateProcess(0,szStr,0,0,0,0,0,0,&si,&pi)) {
				WaitForSingleObject(pi.hProcess, INFINITE);
				CloseHandle(pi.hThread);
				CloseHandle(pi.hProcess);
			}
			RestoreVideoState(hScreen,hTempSave);
		}
	}
}

// handle WM_COMMAND of main window

int DoCommand(HTWND hWnd,int wParam,int lParam)
{
	switch (wParam) {
	case ID_DRIVE:
		ChangeDriveDialog(hWnd);
		break;
	case ID_LOAD:
		if (OpenFileDlg(hWnd))
			updateview(0);
		break;
	case ID_SAVE:
		{
			if (int i = TextDialogBoxIndirectParam(0,&savesectorsdlgtemp, hWnd, sectorscallback, 1))
				SaveFileDlg(hWnd, i);
			break;
		}
	case ID_DOSSHELL:
		StartShell();
		break;
	case ID_EXIT:
		TextSendMessage(hWnd,WM_CLOSE,0,0);
		break;
	case ID_COPY:
		if (!pClipBoard)
			pClipBoard = (char * )malloc(bufsize);
		if (pClipBoard) {
			memcpy(pClipBoard,pStaBuf,bufsize);
			TextEnableMenuItem(hMenu,ID_PASTE,TM_BYCOMMAND | TM_ENABLED);
		}
		break;
	case ID_PASTE:
		if (pClipBoard) {
			memcpy(pStaBuf,pClipBoard,bufsize);
			fModified = TRUE;
			updateview(0);
		} else
			TextMessageBeep();
		break;
	case ID_PRVSEC:
		leftk();
		break;
	case ID_NXTSEC:
		rightk();
		break;
	case ID_SECEDT:
		SwitchWindow();
		break;
	case ID_REWR:
		rewritesector();
		break;
	case ID_VIEW:
		fEdit = FALSE;
		TextSetWindowAttr(hWnd,0,0,8,rows,prefatr);
		TextSetWindowAttr(hWnd,8,0,16*3+2,rows,scrnatrv);
		TextSetWindowAttr(hWnd,BEGSUFFIX,0,16+2,rows,suffatrv);
		SetCursorShape(hScreen,0);
		TextEnableMenuItem(hMenu,ID_REWR,TM_BYCOMMAND | TM_DISABLED);
		TextEnableMenuItem(hMenu,ID_SECEDT,TM_BYCOMMAND | TM_ENABLED);
		updateview(0);
		break;
	case ID_EDIT:
		if (TextGetFocus() == hWndSector)
			if (!SwitchWindow())
				break;
		fEdit = TRUE;
		TextSetWindowAttr(hWnd,0,0,8,rows,prefatr);
		TextSetWindowAttr(hWnd,8,0,16*3+2,rows,scrnatre);
		TextSetWindowAttr(hWnd,BEGSUFFIX,0,16+2,rows,suffatre);
		TextEnableMenuItem(hMenu,ID_REWR,TM_BYCOMMAND | TM_ENABLED);
		TextEnableMenuItem(hMenu,ID_SECEDT,TM_BYCOMMAND | TM_DISABLED);
		_edit(hWnd);
		break;
	case ID_LOWRES:
		SetScreenDimensions(hScreen,columns,25);
		InitApp();
		updateview(0);
		break;
	case ID_MIDRES:
		SetScreenDimensions(hScreen,columns,34);
		InitApp();
		updateview(0);
		break;
	case ID_HIGHRES:
		SetScreenDimensions(hScreen,columns,50);
		InitApp();
		updateview(0);
		break;
	case ID_PARTITION:
		PartitionDlg(hWnd);
		break;
	case IDC_SECTOR:
		break;
	case ID_CONTENT:
		TextMessageBox(0,7,3,helptext,helpcap,TMB_OK);
		break;
	case ID_README:
		ReadmeDialog(hWnd);
		break;
	case ID_INFO:
		TextMessageBox(0,8,5,infotext,0,TMB_OK);
		break;
	}
	return 0;
}

// if buffer has been modified, notify user and query

int checkmodified(HTWND hWnd)
{
	int rEAX;
	long rc = 1;

	if (fModified) {
		rEAX = TextMessageBox(hWnd,9,7,str71,warnstr,TMB_YESNOCANCEL | TMB_DEFBUTTON3 | TMB_ALTCOLOR1);
		switch (rEAX) {
		case IDNO:
			rc = 1;
			fModified = FALSE;
			break;
		case IDYES:
			rc = rewritesector();
			break;
		default:
			rc = 0;
			break;
		}
	}
	return rc;
}

// window proc of main window

long CALLBACK winfunc(HTWND hWnd,UINT message,UINT wParam,long lParam)
{
	long rc = 0;
	BYTE bKey;
	HTXTMENU hSubMenu;
	KEYFUNC * pKF;

	switch (message) {
	default:
		rc = TextDefWindowProc(hWnd,message,wParam,lParam);
		break;
	case WM_KEYDOWN:
		bKey = HIWORD(wParam) >> 8;

		if (lParam & (LEFT_CTRL_PRESSED | RIGHT_CTRL_PRESSED))
			pKF = keytable_ctrl;
		else
			pKF = keytable;

		for(; pKF->key != 0xFF ; pKF++) {
			if (pKF->key == bKey) {
				pKF->kproc();
				break;
			}
		}
//		if (pKF->key == 0xFF)
//			Beep(800,20);
		break;
	case WM_COMMAND:
		rc = DoCommand(hWnd,wParam,lParam);
		break;
	case WM_LBUTTONDOWN:
		if (hSubMenu = TextGetSubMenu(hMenu,1))
			TextTrackPopupMenu(hSubMenu,0,(int)LOWORD(lParam),(int)HIWORD(lParam),hWnd);
		break;
	case WM_MENUSELECT:
		handlemenuselect(wParam);
		break;
	case WM_SETFOCUS:
		SetCursorShape(hScreen,0);    // Turn off cursor
		break;
	case WM_KILLFOCUS:
		SetCursorShape(hScreen,10);   // Turn on  cursor
		break;
	case WM_CLOSE:
		if (checkmodified(hWnd))
			rc = TextDefWindowProc(hWnd,message,wParam,lParam);
		break;
	case WM_DESTROY:
		TextPostQuitMessage(0);
		break;
	}       // end switch(message)
	return rc;
}

// Adjust for current video mode

int vidcheck(void)
{
	int i;

	if (fMono) {
		statatr  = BWSTAT;      // Set B&W defaults for status line
		prefatr  = BWSCRN;      // edit mode: address prefix
		scrnatrv = BWSCRN;      // and client area view mode
		scrnatre = BWEDIT;      // edit mode: normal
		suffatrv = BWSCRN;      // and client area view mode
		suffatre = BWEDIT;      // edit mode: normal
		TextSetScreenModeColors(1);
		parteditdlgtemp.dt.color = -1;
		for (i = 0;parteditdlgtemp.di[i].dtype != DIT_NULL;i++) 
			parteditdlgtemp.di[i].color = -1;
	}
	return 1;
}

// get parameters from cmdline

void getoption(int argc,char ** argv)
{
	int iNewDrv = -1;
	int i;
	PSTR pStr;
	char c;

	argv++;
	for (i = argc;i>1;i--,argv++) {
		pStr = *argv;
		if ((*pStr == '/') || (*pStr == '-')) {
			c = *(pStr+1) | 0x20;
			switch (c) {
			case 'm':
				fMono = fMono | 1;
				break;
			case 's':
				fExtEnabled = FALSE;
				break;
			default:
				lerror = ERR_OPTION;
				return;
			}       // end switch
		} else {
			if ((iNewDrv != -1) || (!sscanf(pStr,"%X",&iNewDrv))) {
				lerror = ERR_OPTION;
				return;
			}
		}       // end if
	}       // end for
	if (iNewDrv != -1)
		g_iDrive = iNewDrv;
	return;
}

// Init application

int InitApp()
{
	int rEAX;
	char szStr[20];

	rEAX = GetScreenDimensions(hScreen);
	columns = LOWORD(rEAX);
	rows    = HIWORD(rEAX)-2;

	if (hWndMain) {
		TextSetWindowSize(hWndMain,columns,rows);
//		TextSetWindowSize(hWndStat,columns,1);
	} else {
		hWndMain = TextCreateWindow(columns,rows,0,0,winfunc);
		if (!hWndMain) {
			lerror = ERR_ALLOC1;
			return 0;
		}
		TextSetWindowColor(hWndMain,scrnatrv);
		if (!(hMenu = TextCreateMenuIndirect(mainmenu,lmainmenu)))
			return 0;
		TextSetMenu(hWndMain,hMenu);
		if (!(hWndStat = TextCreateStatic(columns,1,WF_NOSCROLL,hWndMain,0,-1)))
			return 0;
		TextSetWindowColor(hWndStat,statatr);
		if (!(hWndSector = TextCreateEdit(16,1,WF_NOSCROLL,hWndMain,0,IDC_SECTOR)))
			return 0;
		TextSetWindowColor(hWndSector,statatr);

		sprintf(szStr,"%I64u",g_uCurrSec);
		TextSetWindowText(hWndSector,szStr);
	}

	pVideo = (char *)TextGetWindowBuffer(hWndMain);
	TextShowWindow(hWndMain,0,1);
	TextDrawMenuBar(hWndMain);
	TextShowWindow(hWndStat,0,rows+1);
	TextShowWindow(hWndSector,45,rows+1);

	if (fEdit)
		TextSendMessage(hWndMain,WM_COMMAND,ID_EDIT,0);
	else
		TextSendMessage(hWndMain,WM_COMMAND,ID_VIEW,0);

	if (g_iDrive < 0x80)
		TextEnableMenuItem(hMenu,ID_PARTITION,TM_BYCOMMAND | TM_DISABLED);
	else
		TextEnableMenuItem(hMenu,ID_PARTITION,TM_BYCOMMAND | TM_ENABLED);

	return 1;
}

// main proc

int _cdecl main(int argc,char * * argv)
{
	char * pStr;
	int iolderrm;

	InitStringConstants(LANGUAGE);

	hScreen = GetStdHandle(STD_OUTPUT_HANDLE);
	SetVideoStdHandle(hScreen);

	hKbd = GetStdHandle(STD_INPUT_HANDLE);
	SetKbdStdHandle(hKbd);

//	SetConsoleMode(hKbd, ENABLE_MOUSE_INPUT);
	SetConsoleMode(hKbd, 0);
	iolderrm = SetErrorMode(SEM_FAILCRITICALERRORS);

	if (argc >= 2)
		getoption(argc,argv);
#if 1
	g_pExePath = (char *)malloc(_MAX_PATH);
	GetModuleFileName(NULL, g_pExePath, _MAX_PATH);
#else
	g_pExePath = argv[0];
#endif
	pStr = g_pExePath + strlen(g_pExePath) - 1;
	for (;(pStr > g_pExePath) && (*pStr != '\\');*pStr-- = 0);

	if (lerror == 0)
		if (g_iDrive < 0x80)
			g_fInt13Ext = TRUE; // use LBA access for drives
		else
			g_fInt13Ext = ExtensionsAvailable(g_iDrive);

	if (lerror == 0) {
		hSave = SaveVideoState(hScreen);
		vidcheck();
	}

	if (lerror == 0) {
		if ( GetDriveParameters( g_iDrive, &dpp, g_fInt13Ext ) ) {
			bufsize = dpp.wBytSec;
			if (pStaBuf = (char *)malloc(bufsize)) {
				pEndBuf = pStaBuf + bufsize;
				memset(pStaBuf, 0, bufsize);
				if (! ReadDiskEx( g_iDrive, g_uCurrSec, pStaBuf,1 ))
					lerror = ERR_READ1;
			} else
				lerror = ERR_ALLOC1;
		} else
			lerror = ERR_INVDRV;
	}

	if (lerror == 0)
		if (InitApp())
			TextSetFocus(hWndMain);

	if (lerror == 0) {
		updateview(0);
		TextSetAcceleratorTable(acctable,lacctable);
		do {
		} while (TextGetMessage(hKbd));
	}
	if (pStaBuf)
		free(pStaBuf);
	if (hSave)
		RestoreVideoState(hScreen, hSave);
	if (lerror) {
		pStr = finderrorstr(lerror);
		_write(2,pStr,strlen(pStr));  // handle 2 is stderr
	}
	SetErrorMode(iolderrm);
	return 0;
}

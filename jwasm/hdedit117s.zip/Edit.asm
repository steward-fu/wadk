
;--- the hex editor
;--- requires JWasm/Masm and Win32Inc include files

		.386
if ?FLAT
		.MODEL FLAT, stdcall
else
		.MODEL SMALL, stdcall
endif
		option casemap:none
		option proc:private

?ROWSTART     equ 8+1
?BYTESPERLINE equ 16

ID_VIEW	equ 41h
ID_EDIT	equ 42h

?NOSTACKMACRO equ 1

		.xlist
WIN32_LEAN_AND_MEAN equ 1		 
		include windows.inc
;		include crt.inc
		include txtcua32.inc
		include keyboard.inc
		.list

MAXCOL	  equ ?ROWSTART+3*?BYTESPERLINE+?BYTESPERLINE+1
BEGTXT	  equ ?ROWSTART+3*?BYTESPERLINE+1
CTRL_PRESSED equ LEFT_CTRL_PRESSED or RIGHT_CTRL_PRESSED

		.DATA

externdef c hScreen:dword

externdef c rows:dword
externdef c columns:dword
externdef c linenum:dword

externdef c pVideo:dword
externdef c pStaBuf:dword
externdef c pEndBuf:dword
externdef c iBufPos:dword
externdef c bufsize:dword


CURSOR	  struct
bRow	  db ?
bCol	  db ?
reserved  dw ?
CURSOR	  ends

mycurpos  CURSOR <0,?ROWSTART>
oldproc   dd 0

		  .CONST

; Extended key codes
exkeys	label byte
		db	  __HOME_MAKE
		db	  __CURSOR_UP
		db	  __CURSOR_LEFT
		db	  __CURSOR_RIGHT
		db	  __CURSOR_DOWN
		db	  __END_MAKE
		db	  __PAGE_UP
		db	  __PAGE_DOWN
		db	  __TAB_MAKE
lexkeys EQU	  $-exkeys				; Table of keys

extable	label dword
		dd	  homek
		dd	  upk
		dd	  leftk
		dd	  rightk
		dd	  downk
		dd	  endk
		dd	  pgupk
		dd	  pgdnk
		dd	  tabk

normkeys  DB	  "0123456789abcdef"
lnormkeys EQU	  $-normkeys

		.CODE

csr2bufposx proto stdcall csrpos:dword
updateview	proto stdcall parm1:dword
_hexwrt 	proto stdcall pBuffer:dword,line:dword
SetModifiedFlag proto c

;---

mypager proc parm:dword
		invoke  updateview, parm
@@:
		call	  csr2bufpos			; set edi to current pos
		jnc	  @F
		dec	  mycurpos.bRow
		jmp	  @B
@@:
		ret
mypager endp

WriteLine proc uses ebx				; display current line
		mov	  eax,mycurpos
		mov	  ah,?ROWSTART
		invoke  csr2bufposx,eax		; set edi to current pos
		jc	  @exit
		mov	  eax,mycurpos			; Arg 2
		mov	  ah,0
		inc	  al
		invoke  _hexwrt,edi,eax
		push  0
		mov	  ebx,esp
		mov	  eax,mycurpos
		mov	  ecx,eax
		movzx   ecx,cl
		inc	  ecx
		shl	  ecx,16
		movzx   eax,al
		inc	  eax
		mul	  columns
		add	  eax,pVideo
if 0;?FLAT          
		invoke WriteConsoleOutputCharacter, hScreen, eax, columns, ecx, ebx
else
		push ebx
		push ecx
		push columns
		push eax
		push hScreen
		call WriteConsoleOutputCharacter
endif
		pop	  eax				;clean stack
@exit:
		ret
WriteLine endp

setcursor proc
		pushad
		mov	  ecx,mycurpos
		inc	  cl			; normalize row
		movzx   eax,ch
		movzx   ecx,cl
		invoke SetConsoleCursorPos,hScreen,eax,ecx
		popad
		ret
setcursor endp

;*** handle keyboard input
;*** rc: eax=1 -> key handled

handlekeydown proc uses edi wParam:dword,lParam:dword

		mov	  edi,OFFSET exkeys 	; Load address and length of key list
		mov	  ecx,lexkeys
		mov	  eax,wParam
		mov	  edx,eax
		shr	  eax,16
		repne   scasb 				; Find position
		jnz	  @F
		mov	  eax,lParam
		sub	  edi,(OFFSET exkeys)+1 ; Point to key
		call	  extable[edi*4]		; Call procedure
		jmp	  ret1
@@:
		mov	  ah,al
		mov	  al,dl
		cmp	  mycurpos.bCol,BEGTXT
		jnc	  @F
		or	  al,20h
		mov	  edi,offset normkeys
		mov	  ecx,lnormkeys 		 ; valid hex digit entered?
		repne   scasb
		jnz	  ret0
		call	  csr2bufpos			 ; set edi to current pos
		jc	  ret0
		call	  char2buf				 ; and save character
		jmp	  hkd_1
@@:
		cmp	  al,00 				 ; ctrl key?
		jz	  ret0
		cmp	  ah,1					 ; Escape?
		jz	  ret0
		call	  csr2bufpos			 ; set edi to current pos
		jc	  ret0
		stosb
		invoke  SetModifiedFlag
hkd_1:
		call	  WriteLine
		call	  rightcursor
		jmp	  ret1
ret0:
		xor	  eax,eax				 ;key not handled
		ret
ret1:
		mov	  eax,1 				 ;key handled
		ret
handlekeydown endp

EditOff proc hWnd:dword
		invoke TextSetWindowProc, hWnd, oldproc
		ret
EditOff endp

;--- text window window proc

mywinproc proc hWnd:dword,message:dword,wParam:dword,lParam:dword

		mov	  eax,message
		cmp	  eax,WM_KEYDOWN
		jz	  mwp_1
		cmp	  eax,WM_COMMAND
		jz	  mwp_2
		cmp	  eax,WM_NCPAINT
		jz	  mwp_4
		cmp	  eax,WM_SETFOCUS
		jz	  mwp_5
		jmp	  mwp_3
mwp_5:
		call	  setcursor
		invoke SetCursorShape,hScreen,10
		jmp	  mwp_ex
mwp_4:
		push	  lParam
		push	  wParam
		push	  message
		push	  hWnd
		call	  oldproc
;		invoke SetTextWindowAttr, hWnd,0,0,?ROWSTART-1,rows,prefatr
		jmp	  mwp_ex
mwp_1:
		invoke  handlekeydown,wParam,lParam
		push	eax
		call	setcursor
		pop	  eax
		and	  eax,eax
		jz	  mwp_3
		jmp	  mwp_ex
mwp_2:
		mov	  eax,wParam
		cmp	  eax,ID_VIEW
		jz	  @F
		jmp	  mwp_3
@@:
		invoke  EditOff,hWnd
mwp_3:
		push	  lParam
		push	  wParam
		push	  message
		push	  hWnd
		call	  oldproc
mwp_ex:
		ret
mywinproc endp

EditOn	proc hWnd:dword
		invoke  TextGetWindowProc, hWnd
		cmp	  eax,offset mywinproc
		jz	  @exit
		mov	  oldproc,eax

		invoke	TextSetWindowProc, hWnd, offset mywinproc
		invoke SetCursorShape, hScreen,10
@exit:
		ret
EditOn	endp

_edit	PROC	  public uses ebx esi edi hWnd:dword

		invoke  mypager, 0

		call	  csr2bufpos
		jnc	  @F
		call	  chomek
@@:

		invoke  EditOn,hWnd

		call	  setcursor
		ret
_edit	ENDP

;*** checks if cursor is at a valid position
;*** out: C
;***	  Z

checkcolx proc
		mov	 eax,mycurpos
checkcol::
		cmp	 ah,?ROWSTART+3*?BYTESPERLINE	;in byte region?
		jnb	 checkcol1
		push	 eax
		mov	 al,ah
		sub	 al,?ROWSTART
		mov	 ah,0
		mov	 cl,3
		div	 cl
		cmp	 ah,2							;C if between nibbles
		mov	 cl,ah
		pop	 eax
		ret
checkcol1:										;in text region
		mov	 cl,0
		cmp	 ah,?ROWSTART+3*?BYTESPERLINE	;is always NC???
		ret
checkcolx endp

char2val  proc
		sub	 al,'0'
		cmp	 al,10
		jb	 char2val_ex
		sub	 al,'a'-('0'+10)
char2val_ex:
		ret
char2val  endp

char2buf  proc
		push	 eax
		call	 checkcolx			   ;???
		pop	 eax
		call	 char2val
		mov	 ah,[edi]
		cmp	 cl,1				   ;2. digit (low nibble?)
		jz	 @F
		and	 ah,0Fh
		shl	 al,4
		jmp	 c2b_1
@@:
		and	 ah,0F0h
c2b_1:
		or	 al,ah
		mov	 [edi],al
		invoke SetModifiedFlag
		ret
char2buf  endp

csr2bufposx proc uses eax ebx csrpos:dword

		mov	 ebx,csrpos
		mov	 al,?BYTESPERLINE
		mul	 bl
		xchg	 ax,bx
		mov	 al,ah
		mov	 ah,0
		cmp	 al,BEGTXT
		jc	 @F
		sub	 al,BEGTXT
		jmp	 csr2bufpos_1
@@:
		sub	 al,?ROWSTART
		mov	 cl,3
		div	 cl
csr2bufpos_1:					  ;cursor in ??
		movzx  eax,al
		add	 eax,ebx
		mov	 edi,eax
		add	 edi,iBufPos
		add	 edi,pStaBuf
		cmp	 edi,pEndBuf
		cmc					  ;C if buffer pos is too large
		ret
csr2bufposx endp

csr2bufpos proc
		  invoke csr2bufposx,dword ptr mycurpos
		  ret
csr2bufpos endp

cleftk	  proc

		call	  leftcursor
		call	  checkcolx
		cmp	  cl,0
		jz	  @exit
		call	  leftcursor
@exit:
		ret
cleftk	endp

crightk proc

		call	  rightcursor
		call	  checkcolx
		cmp	  cl,0			  ;first nibble of a byte?
		jz	  @exit
		call	  rightcursor	  ;no, go one pos to the right
@exit:
		ret
crightk endp

tabk	proc

		mov	 eax,mycurpos
		cmp	 ah,BEGTXT
		jnc	 @F
		sub	 ah,?ROWSTART
		mov	 al,ah
		mov	 ah,00
		mov	 cl,3
		div	 cl
		add	 al,BEGTXT
		mov	 byte ptr mycurpos.bCol,al
		ret
@@:
		sub	 ah,BEGTXT
		mov	 cl,ah
		add	 ah,ah
		add	 ah,cl
		add	 ah,?ROWSTART
		mov	 mycurpos,eax
		ret
tabk	endp

homek	proc

		test	al,CTRL_PRESSED
		jnz		chomek
		mov	 mycurpos.bCol,?ROWSTART
		ret
homek	endp

chomek	proc
		mov	 mycurpos.bRow,00
		mov	 mycurpos.bCol,?ROWSTART
		ret
chomek	  endp

leftcursor proc
		mov	 eax,mycurpos

		cmp	 ah,BEGTXT
		jnc	 lefttext

		cmp	 ah,?ROWSTART
		jz	 leftk1
@@:
		dec	 ah
		call	 checkcol
		jz	 @B
		invoke csr2bufposx,eax
		jc	 @B
setcp:
		mov	 mycurpos,eax
		ret
leftk1:
		mov	 [mycurpos.bCol],BEGTXT-3
scr:
		call	 upk
		ret
lefttext:
		jz	 @F
		dec	 ah
		jmp	 setcp
@@:
		mov	 mycurpos.bCol,MAXCOL-1
		jmp	 scr

leftcursor endp

leftk	proc
		test	 al,CTRL_PRESSED
		jz	 leftcursor
		jmp	 cleftk
leftk	endp

rightk	proc
		test	 al,CTRL_PRESSED
		jz	 rightcursor
		jmp	 crightk
rightk	endp

rightcursor  proc

		mov	 eax,mycurpos
@@:
		cmp	 ah,BEGTXT
		jnc	 righttext

		inc	 ah
		cmp	 ah,BEGTXT-1
		jz	 rightk_1
		call	checkcol		;cursor on valid position?
		jz	@B 					;no, increas X pos
		push edi
		invoke csr2bufposx,eax
		pop edi
;		jnc	  @F
;		cmp	  ah,BEGTXT
;		jnb	  rightk_2
;		mov	  ah,BEGTXT
		jc rightk_2
@@:
		  mov	 mycurpos,eax
rightk_2:
		  ret
righttext:
		  inc	 ah
		  push	 edi
		  invoke csr2bufposx,eax	;am Dateiende?
		  pop	 edi
		  jc	 rightk_2
		  cmp	 ah,MAXCOL
		  jnz	 @B
		  mov	 mycurpos.bCol,BEGTXT
		  jmp	 rightk_3
rightk_1:
		  call	 pos1k
rightk_3:
		  call	 downk
		  ret
rightcursor endp


pos1k	proc					;move cursor to start of line
		mov	 mycurpos.bCol,?ROWSTART
		ret
pos1k	endp

upk 	proc				 	;cursor up?
		mov	eax,mycurpos
		cmp	 al,0			 	;in first line?
		jz	 upk1
		dec	 al
		mov	 mycurpos,eax
		ret
upk1:
		call	 lineup
		ret
upk 	endp

downk	proc uses edi
		mov	 eax,mycurpos
		inc	 al
		cmp	 al,byte ptr rows	;scroll required?
		jz	 downk1
		invoke csr2bufposx,eax
		jc	 @F
		mov	 mycurpos,eax
@@:
		ret
downk1:
		call linedn
		ret
downk	endp

endk	proc
		test al,CTRL_PRESSED
		jnz	cendk
		mov	 mycurpos.bCol,MAXCOL-1
@@:
		call csr2bufpos
		jnc	 @F
		dec	 mycurpos.bCol
		jnz	 @B
@@:
		ret
endk	endp

cendk	proc
		mov	 al,byte ptr rows
		dec	 al
		mov	 ah,?ROWSTART
		mov	 mycurpos,eax
@@:
		call	 csr2bufpos
		jnc	 @F
		dec	 mycurpos.bRow
		jnz	 @B
@@:
		ret
cendk	endp

pgdnk	proc

		test	al,CTRL_PRESSED
		jnz 	@F
		invoke  mypager, rows
		ret
@@:
		call	cpgdnk
		ret
pgdnk	endp

;-- PGUP - Page back
                
pgupk	proc

		test	al,CTRL_PRESSED
		jnz 	@F
		mov		eax,rows
		neg		eax
		invoke  mypager, eax
		ret
@@:
		call	cpgupk
		ret
pgupk	endp

;-- Ctrl-PGDN

cpgdnk	proc

		mov	  eax,bufsize
		and	  al,0F0h
		mov	  iBufPos,eax			; Make it the file position
		mov	  linenum,-1			; Set illegal line number as flag
		mov	  eax,rows				; Page back
		dec	  eax
		neg	  eax
		invoke  mypager, eax
		ret
cpgdnk	endp

cpgupk	proc
		mov	  iBufPos,0 			; HOME - set position to 0
		mov	  linenum,1
		invoke  mypager, 0
		ret
cpgupk	endp

lineup	proc		; UP - scroll back 1 line
		invoke  mypager, -1
		ret
lineup	endp

linedn	proc	  	; DOWN - scroll forward 1 line
		invoke  mypager, 1
		ret
linedn	endp

		END


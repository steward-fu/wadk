
;--- viewer for both ascii and hex
;--- requires JWasm/Masm v6+ and Win32Inc include files

		.386
if ?FLAT
		.MODEL FLAT, stdcall
else
		.MODEL SMALL, stdcall
endif
		option casemap:none
		option proc:private

;?NOSTACKMACRO equ 1

		.nolist
		.nocref
WIN32_LEAN_AND_MEAN equ 1
		include windows.inc
		include txtcua32.inc
;		include ascii.inc
		.cref
		.list

CR	equ 13
LF	equ 10
TAB	equ 9
?ROWSTART     equ 8+1
?BYTESPERLINE equ 16

		.DATA

fOldHex   DB	  0

externdef c rows:dword
externdef c columns:dword
externdef c linenum:dword

externdef c pStaBuf:ptr byte
externdef c pEndBuf:ptr byte
externdef c pVideo:ptr byte
externdef c iBufPos:dword
externdef c dwTabExt:dword

externdef c fHex:byte
externdef c fLineWrap:byte
externdef c fAnsi:byte
externdef c fDispCR:byte

		.CODE

;BinToStr proto stdcall number:dword,pStr:dword
cellfill proto stdcall row:dword,rows:dword,char:dword
GoBack	 proto stdcall dwLines:dword
GoForwd  proto stdcall dwLines:dword
_cellwrt proto stdcall pBuffer:dword,line:dword
_hexwrt  proto stdcall pBuffer:dword,line:dword
_pager	 proto stdcall dwLines:dword

; Procedure Pager
; Purpose	Displays status and text lines
; Input 	Stack variable: lines to scroll (negative up, positive down)
;			Global variables: "pStaBuf", "iBufPos", "linenum"
; Output	To screen

_pager	  PROC public uses ebx edi esi dwLines:dword


		  mov	  al,fHex
		  cmp	  al,fOldHex
		  jz	  @F
		  mov	  fOldHex,al
		  mov	  linenum,-1
@@:
		  mov	  ecx,dwLines			; Get count argument
		  or	  ecx,ecx				; Argument 0?
		  jg	  forward				; If above, forward
		  neg	  ecx					; Make count positive
		  invoke  GoBack,ecx			; Adjust backward
		  jmp	  show					; Show screen
forward:
		  invoke  GoForwd,ecx			; Adjust forward
show:

		  mov	  edi,iBufPos			; file position
		  mov	  esi,edi				; Update position
		  mov	  ecx,rows				; Lines per screen
		  mov	  ebx,0
		  mov	  eax,pStaBuf
		  and	  eax,eax				; ist ein file da?
		  jz	  fillout
		  add	  esi,eax				; esi ^ jetzt auf 1. zeile am schirm
show1:
		  push	  ecx
		  mov	  ebx,rows				; Lines of text
		  sub	  ebx,ecx				; Calculate current row
		  test	  byte ptr fHex,1
		  jz	  @F
		  invoke  _hexwrt,esi,ebx		; Write line (hex)
		  jmp	  show2
@@:
		  invoke  _cellwrt,esi,ebx		; Write line (text)
show2:
		  pop	  ecx
		  mov	  esi,eax				; Get returned position

		  cmp	  eax,pEndBuf			; Beyond end of file?
		  jae	  fillout				; Yes? Fill screen with spaces
		  loop	  show1 				;	 else next line
		  jmp	  pagedone				; Get out if done
										; Fill the rest with spaces
fillout:  dec	  ecx					; Adjust
		  jecxz   pagedone
		  inc	  ebx					; starting row
		  invoke  cellfill,ebx,ecx,"�"
pagedone:
		  ret
_pager	  ENDP

cellfill  proc uses ebx edi row:dword,numrows:dword,char:dword

		  mov	  ebx,row
		  mov	  eax,columns			; Starting row
		  mul	  ebx					; Figure columns per row
		  mov	  edi,eax
		  add	  edi,[pVideo]
		  mov	  eax,columns			; Columns times remaining lines
		  mov	  ecx,numrows
		  mul	  cl
		  mov	  ecx,eax
		  mov	  eax,char
		  rep	  stosb
		  ret
cellfill  endp

;*** hexwrt(pSource,row) ***

_hexwrt   PROC public uses esi edi ebx pSource:dword,row:dword

		  mov	  esi,pSource			; Buffer position
		  cmp	  esi,pEndBuf
          jnc     hexwrt_ex
		  mov	  ecx,columns			; Cells per row
		  mov	  eax,row				; Starting row
		  mov	  ebx,ecx				; Bytes per row
		  mul	  ebx					; Figure columns per row
		  mov	  edi,eax				; Load as destination
		  add	  edi,[pVideo]
		  mov	  ecx,rows
		  dec	  ecx
		  mov	  edx,esi
		  sub	  edx,[pStaBuf]
;		   mov	   ah,byte ptr [prefatr]
		  call	  dwordout
		  mov	  al,' '
		  stosb
		  mov	  ecx,?BYTESPERLINE 	; Cells per row
		  mov	  ebx,esi
hexwrt_1:
		  cmp	  esi,pEndBuf
		  jae	  hexwrt_2
		  lodsb 						; Get character
		  call	  byteout
		  mov	  al,' '
		  stosb
		  loop	  hexwrt_1
		  jmp	  hexwrt_4
hexwrt_2:
		  mov	  al,' '
		  stosb
		  stosb
		  stosb
		  loop	  hexwrt_2
hexwrt_4:
		  stosb
		  mov	  esi,ebx
		  mov	  ecx,?BYTESPERLINE
hexwrt_3:
		  cmp	  esi,pEndBuf
		  jae	  hexwrt_5
		  lodsb
		  stosb
		  loop	  hexwrt_3
		  jmp	  hexwrt_6
hexwrt_5:
		  mov	  al,' '
		  stosb
		  loop	  hexwrt_5
hexwrt_6:
		  mov	  ecx,[columns]
		  sub	  ecx,?BYTESPERLINE*4+?ROWSTART+1
		  jc	  @F
		  mov	  al,' '
		  rep	  stosb
@@:
hexwrt_ex:
		  mov	  eax,esi				; Return position
		  ret
_hexwrt   ENDP

nibout	  proc 
		  and	  al,0Fh
		  add	  al,'0'
		  cmp	  al,'9'
		  jle	  @F
		  add	  al,07h
@@:
		  stosb
		  ret
nibout	  endp

byteout   proc
		  push	eax
		  shr	al,4
		  call	nibout
		  pop	eax
		  jmp	nibout
byteout   endp

dwordout  proc
		  push	ecx
		  mov	ecx,4
		  push	edx
		  shr	edx,8
		  push	edx
		  shr	edx,8
		  push	edx
		  shr	edx,8
		  push	edx
dwordout_1:
		  pop	edx
		  mov	al,dl
		  call	byteout
		  loop	dwordout_1
		  pop	ecx
		  ret
dwordout  endp

; Procedure _cellwrt (offset,line)
; Purpose	Writes a line to screen buffer
; Input 	Stack variables: 1 - DWORD: offset (buffer)
;							 2 - DWORD: line number (screen)
; Output	Line to screen buffer
;	eax=start next line

_cellwrt  PROC uses ebx esi edi pSource:dword,line:dword

@@:
		  mov	  ecx,columns			; Cells per row
		  mov	  ebx,ecx				; Bytes per row
		  mov	  esi,pSource			; Buffer position
		  mov	  eax,line				; Starting row
		  mul	  ebx					; Figure columns per row
		  mov	  edi,eax				; Load as destination
		  add	  edi,[pVideo]
		  mov	  ebx,edi				; Save start for tab calculation
movechar:
		  cmp	  esi,pEndBuf
		  jz	  fillspc
		  lodsb 						; Get character
		  cmp	  al,CR
		  je	  fillspc
		  cmp	  al,LF
		  je	  fillspc
		  cmp	  al,TAB
		  jne	  notab
		  call	  FillTab				; Yes? fill with spaces
		  jecxz   nextline				; If beyond limit done
		  jmp	  movechar

notab:
		  stosb
		  loop	  movechar
		  jmp	  nextline				; Done

fillspc:
		  test	  byte ptr [fDispCR],1
		  jz	  @F
		  mov	  al,20 				;0E3h
		  stosb
		  dec	  ecx
		  jecxz   space21
@@:
		  mov	  al," "				; Fill with space
space2:
		  rep	  stosb
space21:
		  cmp	  word ptr [esi-1],CR+256*LF   ;CRLF?
		  jnz	  @exit
		  inc	  esi					; Skip this LF
		  jmp	  @exit					; Done

nextline:
		  test	  byte ptr [fLineWrap],1
		  jnz	  @exit
		  mov	  al,LF 				; Search for next line feed
		  mov	  edi,esi
		  mov	  ecx,pEndBuf
		  sub	  ecx,edi
		  repnz   scasb
		  jz	  @F
		  mov	  edi,pEndBuf
@@:
		  mov	  esi,edi
@exit:
		  test	  fAnsi,1
		  jz	  @F
		  invoke  CharToOemBuff, ebx,ebx,columns
@@:
		  mov	  eax,esi				; Return position
		  ret
_cellwrt  ENDP

; Procedure FillTab
; Purpose	Writes spaces for tab to screen
; Input 	EBX points to start of line, EDI points to current position
; Output	Spaces to screen buffer

FillTab   PROC
		push	  ebx
		push	  ecx

		sub	  ebx,edi				; Get current position in line
		neg	  ebx
		mov	  ecx,dwTabExt			; Default count 8
		dec	  ecx	
		and	  ebx,ecx				; Get modulus
		inc	  ecx
		sub	  ecx,ebx				; Subtract
		mov	  ebx,ecx				; Save modulus

		test	byte ptr [fDispCR],1
		jz		normal
		cmp		ecx,1
		jbe		@F
		dec		ecx	
		mov		al,0FAh
		rep		stosb
		inc		ecx
@@:
		mov		al,1Ah
		rep		stosb
		jmp		next
normal:
		mov	  al," "				; Spaces
		rep	  stosb
next:
		pop	  ecx
		sub	  ecx,ebx				; Adjust count
		jns	  nomore				; Make negative count 0
		sub	  ecx,ecx
nomore: pop	  ebx
		ret
FillTab   ENDP

; Procedure GoBack
; Purpose	Searches backward through buffer
; Output	Updates "linenum" and "iBufPos"

GoBack	  PROC public uses edi dwLines:dword

		  mov	  edi,iBufPos
		  add	  edi,pStaBuf
		  mov	  ecx,dwLines
		  test	  byte ptr fHex,1
		  jz	  @F
		  mov	  eax,?BYTESPERLINE
		  mul	  ecx
		  sub	  edi,eax
		  cmp	  edi,pStaBuf
		  jc	  atstart1
		  mov	  edx,edi
		  sub	  edx,pStaBuf
		  shr	  edx,4
		  inc	  edx
		  mov	  linenum,edx
		  jmp	  positive
@@:
		  std							; Go backward
		  mov	  al,LF 				; Search for linefeed
		  mov	  edx,ecx				; Save a copy
		  inc	  ecx					; One extra to go up one
		  cmp	  edi,pStaBuf			; Start of file?
		  jbe	  atstart1				; If so, ignore
		  dec	  edi
findb:	  push	  ecx					;	else save count
		  mov	  ecx,edi				; Load maximum character count
		  sub	  ecx,pStaBuf
		  jecxz   atstart				; If not found, must be at start
		  repne   scasb 				; Find last previous LF
		  pop	  ecx
		  loop	  findb
		  jne	  atstart1
		  add	  edi,2 				; jump behind LF
		  cmp	  linenum,-1			; End of file flag?
		  jne	  notend				; No? Continue
		  sub	  edi,pStaBuf
		  mov	  iBufPos,edi			; Save position
		  call	  EndCount				; Count back to get line number
		  jmp	  @exit
notend:
		  sub	  linenum,edx			; Calculate line number
		  jg	  positive
		  mov	  linenum,1 			; Set to 1 if negative
positive:
		  sub	  edi,pStaBuf
		  mov	  iBufPos,edi			; Save position
		  jmp	  @exit

atstart:  pop	  ecx
atstart1:
		  sub	  edi,edi				; Load start of file
		  mov	  linenum,1 			; Line 1
		  mov	  iBufPos,edi			; Save position
		  jmp	  @exit
@exit:
		  cld
		  ret
GoBack	  ENDP

; Procedure GoForwd
; Purpose	Searches forward through a buffer
; Output	Updates "linenum" and "iBufPos"

GoForwd   PROC	  public uses edi dwLines:dword

		  mov	  ecx,dwLines
		  jecxz   atend1
		  mov	  edi,iBufPos
		  add	  edi,pStaBuf
		  test	  byte ptr fHex,1
		  jz	  gf_ascii
		  mov	  eax,?BYTESPERLINE
		  mov	  edx,rows
		  mul	  edx
@@:
		  push	  eax
		  add	  eax,edi
		  cmp	  eax,pEndBuf
		  pop	  eax
		  ja	  @F
		  add	  edi,?BYTESPERLINE
		  inc	  edx
		  loop	  @B
@@:
		  jmp	  findf1
gf_ascii:
		  cld							; Go forward
		  mov	  al,LF 				; Search for linefeed
		  mov	  edx,ecx				; Copy count
findf:	  push	  ecx					; Save count
		  mov	  ecx,pEndBuf			; Load maximum character count
		  sub	  ecx,edi
		  repne   scasb 				; Find next LF
		  jecxz   atend					; If not found, must be at end
		  cmp	  edi,pEndBuf			; Beyond end?
		  jae	  atend
		  pop	  ecx
		  loop	  findf
findf1:
		  add	  linenum,edx			; Calulate line number
		  sub	  edi,pStaBuf
		  mov	  iBufPos,edi			; Save position
		  ret

atend:	  pop	  ecx
atend1:
		  ret
GoForwd   ENDP

; Procedure EndCount
; Purpose	Counts backward to count lines in file
; Input 	EDI has buffer position
; Output	Modifies "linenum"

EndCount  PROC
		  push	  edi

		  add	  edi,pStaBuf
		  mov	  al,LF 				; Search for LF
		  mov	  linenum,0 			; Initialize

findstrt: inc	  linenum				; Adjust count
		  mov	  ecx,edi				; else search only to start
		  sub	  ecx,pStaBuf
		  repne   scasb 				; Find last previous LF
		  jecxz   found 				; If not found, must be at start
		  jmp	  findstrt

found:	  pop	  edi
		  ret
EndCount  ENDP


; Procedure BinToStr (number,address)
; Purpose	Converts integer to string
; Input 	Stack arguments: 1 - Number to convert; 2 - address for write
; Output	EAX has characters written

if 0
BinToStr  PROC uses edi esi ebx number:dword,pStr:dword

		  mov	  eax,number
		  mov	  edi,pStr
		  sub	  ecx,ecx				; Clear counter
		  mov	  ebx,10				; Divide by 10
										; Convert and save on stack backwards
@@: 	  sub	  edx,edx				; Clear top
		  div	  ebx					; Divide to get last digit as remainder
		  add	  dl,"0"				; Convert to ASCII
		  dec	  esp
		  mov	  [esp],dl				; Save on stack
		  or	  eax,eax				; Quotient 0?
		  loopnz  @B					; No? Get another
		  neg	  ecx					; Negate and save count
		  mov	  edx,ecx
		  mov	  esi,esp
		  rep	  movsb 				; Get character
		  mov	  esp,esi
		  mov	  eax,edx				; Return digit count
		  ret
BinToStr  ENDP
endif

		END


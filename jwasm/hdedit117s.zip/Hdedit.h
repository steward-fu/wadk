
// typedefs

typedef struct tPTYPE {
	BYTE type;
	char * szType;
} PTYPE;

#ifdef __cplusplus
extern "C" {
#endif
// Prototypen

void _stdcall	BinToStr(int,PSTR);
void _stdcall	_pager(int);
void _stdcall	_edit(HTWND);
void _stdcall	_cellwrt(PSTR,int);
void _stdcall	_hexwrt(PSTR,int);
void _stdcall	cellfill(int,int,int);
void _stdcall   updateview(int iScroll);

int _stdcall	SetStatusLine(PSTR);
int				vidcheck(void);
void _cdecl     SetModifiedFlag(void);

extern int linenum;
extern int rows;
extern int columns;

extern HANDLE hScreen;
extern HANDLE hKbd;

extern int fModified;
extern int fHex;	  // hex mode?
extern int fDispCR;	  // display CR?
extern int fAnsi;
extern int fLineWrap;

extern HTWND  hWndStat;
extern HTXTMENU hMenu;

extern char *  pStaBuf;	  // ^ start file buffer
extern char *  pEndBuf;	  // ^ ende file buffer
extern int bufsize;
extern int iBufPos;		  // position in work area (offset)
extern char * pVideo;	  // pointer to screen buffer
extern int dwTabExt;

#ifdef __cplusplus
}
#endif

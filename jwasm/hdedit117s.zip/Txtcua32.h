
// *** text window support library ***

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TCUAAPI
#ifdef _TXTCUA32_
#define TCUAAPI
#else
#define TCUAAPI DECLSPEC_IMPORT
#endif
#endif


// *** system independent console functions ***

typedef void *HVSTATE;

TCUAAPI int     WINAPI FillAttribute(HANDLE vpage,int attr,int laenge,int x,int y);
TCUAAPI int     WINAPI FillRectangle(HANDLE vpage,int attr,int x,int y,int dx,int dy);
TCUAAPI int     WINAPI GetScreenDimensions(HANDLE vpage);
TCUAAPI int     WINAPI SetScreenDimensions(HANDLE vpage,int cols,int rows);
TCUAAPI int     WINAPI SetConsoleCursorPos(HANDLE vpage,int col,int row);
TCUAAPI int     WINAPI GetConsoleCursorPos(HANDLE vpage);
TCUAAPI int     WINAPI SetCursorShape(HANDLE vpage,int percent);
TCUAAPI int     WINAPI SetVideoStdHandle(HANDLE vpage);
TCUAAPI HANDLE  WINAPI GetVideoStdHandle(void);
TCUAAPI HANDLE  WINAPI SetKbdStdHandle(HANDLE hkbd);
TCUAAPI HANDLE  WINAPI GetKbdStdHandle(void);
TCUAAPI int     WINAPI SetConsoleLines(HANDLE,int lines);
TCUAAPI HVSTATE WINAPI SaveVideoState(HANDLE vpage);
TCUAAPI int     WINAPI LoadVideoState(HANDLE vpage,HVSTATE handle);
TCUAAPI int     WINAPI RestoreVideoState(HANDLE vpage,HVSTATE handle);


// text windows


typedef HANDLE HTWND;

typedef long (CALLBACK *TWNDPROC)(HTWND hwnd,unsigned int message,unsigned int wparam,long lparam);

typedef struct _TEXTWINDOW {
    int xpos;
    int ypos;
    int xsize;
    int ysize;
    int flags;
    int parent;
    int hmenu;          // handle menu or id (if WF_CHILD)
    TWNDPROC winproc;   // pointer window proc
    char * pText;       // ^ window text
    int color;
    char * pBuffer;     // ^ client area
    char * buffptr;
    int menuproc;
    int user;           // user bytes
    int hVRestore;      // handle for video rectangle restore
} TEXTWINDOW;

typedef TEXTWINDOW * PTEXTWINDOW;

// *** values TEXTWINDOW.flags  ***

#define WF_FRAME        0x01      // window has frame (simple/double)
#define WF_DISPLAYED    0x02      // WM_NCPAINT is done
#define WF_NOSCROLL     0x04      // don't do AutoScroll
#define WF_SHADOW       0x08      // window has 3d effect shadow
#define WF_VISIBLE      0x10      // window is visible
#define WF_CHILD        0x20      // window is "child" - no menu possible
#define WF_SIMPLE       0x40      // frame is "simple"
#define WF_OPENED       0x80      //  ???
#define WF_MENULOOP     0x100     // window is in mode "menu"
#define WF_MENUENTERED  0x200     // window is to enter mode "menu"
#define WF_BLANK        0x400     // window frame is "blank"
#define WF_SAVEBKGND    0x800     // save/restore background automatically
#define WF_DISABLED     0x1000    // window wont receive input
#define WF_SMALLSHADOW  0x2000    // small shadow for 3d effect

// *** Messages ***

#define WM_CREATE        0x0001
#define WM_DESTROY       0x0002
#define WM_SETFOCUS      0x0007
#define WM_KILLFOCUS     0x0008
#define WM_SETTEXT       0x000C
#define WM_GETTEXT       0x000D
#define WM_GETTEXTLENGTH 0x000E
#define WM_PAINT         0x000F
#define WM_CLOSE         0x0010
#define WM_QUIT          0x0012
#define WM_ERASEBKGND    0x0014
#define WM_NCPAINT       0x0085
#define WM_KEYDOWN       0x0100
#define WM_KEYUP         0x0101
#define WM_SYSKEYDOWN    0x0104
#define WM_SYSKEYUP      0x0105
#define WM_INITDIALOG    0x0110
#define WM_COMMAND       0x0111
#define WM_MENUSELECT    0x011F
#define WM_ENTERMENULOOP 0x0211
#define WM_EXITMENULOOP  0x0212

#define WM_MOUSEMOVE     0x0200
#define WM_LBUTTONDOWN   0x0201
#define WM_LBUTTONUP     0x0202
#define WM_LBUTTONDBLCLK 0x0203
#define WM_RBUTTONDOWN   0x0204
#define WM_RBUTTONUP     0x0205
#define WM_RBUTTONDBLCLK 0x0206


#define TMB_OK           0x0000
#define TMB_OKCANCEL     0x0001
#define TMB_YESNO        0x0002
#define TMB_YESNOCANCEL  0x0003

#define TMB_BEEP         0x0010
#define TMB_ALTCOLOR1    0x0020
#define TMB_ALTCOLOR2    0x0040

#define TMB_DEFBUTTON1   0x0000
#define TMB_DEFBUTTON2   0x0100
#define TMB_DEFBUTTON3   0x0200


#define HVPAGE int  // video page

TCUAAPI HTWND WINAPI TextCreateWindow(int xlen,int ylen,int attr,int format,TWNDPROC winfunc);
TCUAAPI int   WINAPI TextDestroyWindow(HTWND hWnd);
TCUAAPI int   WINAPI TextUpdateWindow(HTWND hwnd);
TCUAAPI int   WINAPI TextShowWindow(HTWND,int xpos,int ypos);
TCUAAPI int   WINAPI TextDisplayFrame(HVPAGE vpage,int xpos,int ypos,int xlen,int ylen,int ftype);
TCUAAPI int   WINAPI TextHideWindow(HTWND hwnd);
TCUAAPI int   WINAPI TextFillWindow(HTWND hwnd,int character);
TCUAAPI int   WINAPI TextScrollWindow(HTWND hwnd);
TCUAAPI int   WINAPI TextPutStrWindow(HTWND hwnd,const char * pStr);
TCUAAPI int   WINAPI TextPutCharWindow(HTWND hwnd,char x);
TCUAAPI int   WINAPI TextGetWindowCursorPos(HTWND hwnd);
TCUAAPI int   WINAPI TextSetWindowCursorPos(HTWND hwnd,int x,int y);
TCUAAPI int   WINAPI TextGetWindowColor(HTWND hwnd);
TCUAAPI int   WINAPI TextSetWindowColor(HTWND hwnd,int color);
TCUAAPI int   WINAPI TextSetFocus(HTWND hwnd);
TCUAAPI HTWND WINAPI TextGetFocus(void);
TCUAAPI int   WINAPI TextGetMessage(HTWND hwnd);
TCUAAPI int   WINAPI TextSetParent(HTWND hwnd,HTWND hwndParent);
TCUAAPI int   WINAPI TextSetWindowProc(HTWND hwnd,TWNDPROC winproc);
TCUAAPI TWNDPROC WINAPI TextGetWindowProc(HTWND hwnd);
TCUAAPI void *  WINAPI TextGetWindowBuffer(HTWND hwnd);
TCUAAPI int   WINAPI TextSetWindowPos(HTWND hwnd,int x,int y);
TCUAAPI int   WINAPI TextSetWindowSize(HTWND hwnd,int dx,int dy);
TCUAAPI int   WINAPI TextSetAcceleratorTable(void * pacctab,int len);
TCUAAPI int   WINAPI TextSendMessage(HTWND hwnd,UINT message,UINT wParam,long lParam);
TCUAAPI int   WINAPI TextPostMessage(HTWND,UINT,UINT,long);
TCUAAPI int   WINAPI TextMessageBeep(void);
TCUAAPI int   WINAPI TextMessageBox(HTWND,int x,int y,const char * str1,const char * caption,int flags);
TCUAAPI int   WINAPI TextGetParent(HTWND hwnd);
TCUAAPI int   WINAPI TextSetWindowID(HTWND hwnd,int id);
TCUAAPI int   WINAPI TextSetWindowText(HTWND hwnd,const char * pstr);
TCUAAPI int   WINAPI TextGetWindowText(HTWND hwnd,PSTR pBuffer,int maxlen);
TCUAAPI int   WINAPI TextGetWindowTextLength(HTWND hwnd);
TCUAAPI int   WINAPI TextEnableWindow(HTWND hwnd,int flags);
TCUAAPI int   WINAPI TextPostQuitMessage(int rc);
TCUAAPI int   WINAPI TextSplitWindow(HTWND hwnd,int flag,int pos);
TCUAAPI int   WINAPI TextDefWindowProc(HTWND,int,int,int);
TCUAAPI int   WINAPI TextSetScreenModeColors(UINT);
TCUAAPI int   WINAPI TextSetWindowAttr(HTWND hwnd,int x,int y,int dx,int dy,int attr);
TCUAAPI BOOL  WINAPI TextIsWindowEnabled(HTWND);
TCUAAPI void  WINAPI InitStringConstants(DWORD);

// *** Dialoge ***

typedef struct _TDLGTEMPLATE {
 int xpos;
 int ypos;
 int xsize;
 int ysize;
 int flags;
 int color;
 char * pText;
} TDLGTEMPLATE;

typedef struct _TDLGITEM {
 int dtype   ;
 int xpos    ;
 int ypos    ;
 int xsize   ;
 int ysize   ;
 int flags   ;
 int color   ;
 char * pText;
 int xflags;
 int id    ;
 HTWND hwnd;
} TDLGITEM;

// *** Werte dtype ***

#define DIT_NULL        00
#define DIT_LISTBOX     01
#define DIT_EDIT        02
#define DIT_BUTTON      03
#define DIT_STATIC      04
#define DIT_SCROLLBAR   05

typedef struct _TDIALOG {
 int     pTemplate;
 TWNDPROC dlgproc;
 int     user;
} TDIALOG;

#define IDOK     1
#define IDCANCEL 2
#define IDYES    6
#define IDNO     7

typedef TWNDPROC TDLGPROC;

typedef struct _DLGDEF {
TDLGTEMPLATE dt;
TDLGITEM     di[];
} DLGDEF;

TCUAAPI HTWND WINAPI TextCreateDialogIndirectParam(int hInst,void * pDlgtemp,HTWND pOwner,TDLGPROC dlgproc,int lParam);
TCUAAPI HTWND WINAPI TextCreateDialogIndirect(int hInst,void * pDlgtemp,HTWND hwndOwner,TDLGPROC dlgproc);
TCUAAPI int   WINAPI TextDialogBoxIndirectParam(int hInst,void * pDlgtemp,HTWND pOwner,TDLGPROC dlgproc,int lParam);
TCUAAPI int   WINAPI TextDialogBoxIndirect(int hInst,void * pDlgtemp,HTWND hwndOwner,TDLGPROC dlgproc);
TCUAAPI int   WINAPI TextEndDialog(HTWND hwnd,int rc);
TCUAAPI HTWND WINAPI TextGetDlgItem(HTWND hwnd,int id);
TCUAAPI int   WINAPI TextSetDlgItemText(HTWND hwnd,int id, char * pszText);
TCUAAPI int   WINAPI TextIsDialogMessage(HTWND, int message,int wparam,int lparam);
TCUAAPI int   WINAPI TextGetDialogData(HTWND hwnd);
TCUAAPI int   WINAPI TextSetDialogData(HTWND hwnd,int dwData);

// *** file list macros ***

#define DDL_READWRITE  0x0000
#define DDL_READONLY   0x0001
#define DDL_HIDDEN     0x0002
#define DDL_SYSTEM     0x0004
#define DDL_DIRECTORY  0x0010
#define DDL_ARCHIVE    0x0020

#define DDL_POSTMSGS   0x2000
#define DDL_DRIVES     0x4000
#define DDL_EXCLUSIVE  0x8000

TCUAAPI int WINAPI TextDlgDirList(HTWND, PSTR,int idLB,int idSPath, int uFiletype);

// *** Farben ***

typedef struct _SYSCOLORS {
int window   ;
int shadow   ;            // window shadow
int menu     ;
int menukey  ;
int dmenu    ;
int dmenukey ;
int hmenu    ;
int hmenukey ;
int hdmenu   ;
int hdmenukey;
int button   ;
int edit     ;
int listbox  ;
int scrlbar  ;
int wincap   ;
} SYSCOLORS;

#define SC_WINDOW       BACKGROUND_WHITE | FORGROUND_BLACK
#define SC_SHADOW       0x08
#define SC_MENU         0x70  // menu text enabled           not selected
#define SC_MENUKEY      0x74  // menu text enabled  hotkey   ""
#define SC_DMENU        0x78  // menu text disabled          ""
#define SC_DMENUKEY     0x70  // menu text disabled hotkey   ""
#define SC_HMENU        0x07  // menu text enabled           selected
#define SC_HMENUKEY     0x0C  // menu text enabled  hotkey   ""
#define SC_HDMENU       0x07  // menu text disabled          ""
#define SC_HDMENUKEY    0x0F  // menu text disabled hotkey   ""
#define SC_BUTTON       BACKGROUND_WHITE | BACKGROUND_INTENSITY | FOREGROUND_BLACK
#define SC_EDIT         BACKGROUND_BLUE  | FOREGROUND_YELLOW
#define SC_LISTBOX      BACKGROUND_WHITE | FOREGROUND_BLACK
#define SC_SCRLBAR      BACKGROUND_BLACK | FOREGROUND_WHITE | FOREGROUND_INTENSITY
#define SC_WINCAP       BACKGROUND_WHITE | FOREGROUND_BLUE  | FOREGROUND_INTENSITY


// menus

typedef struct _TMENU {
 int firstitem;
 int numitems;
 int selitem;
} TMENU;

typedef struct _TMITEM {
 void * nextitem;
 int    flags;
 int    id;                // id or handle submenu
 char   itemname[1];
} TMITEM;

typedef struct _TEXTMENUITEMINFO {
 int    mask;
 int    flags;
 int    id;                // id or handle submenu
 int    cch;
 int    dwTypeData;
} TEXTMENUITEMINFO;

// flags

#define TM_SUBMENU     1
#define TM_DISABLED    2
#define TM_ENABLED     0
#define TM_CHECKED     4
#define TM_SEPARATOR   8
#define TM_BYCOMMAND   0
#define TM_SHADOW      0x10
#define TM_BYPOSITION  0x400

typedef struct _MENUDESC {
 int id;
 int flags;
 char * strptr;
 char * hlpptr;
} MENUDESC;

typedef MENUDESC * PMENUDESC;
// typedef TMENU * HTXTMENU;
typedef int HTXTMENU;

TCUAAPI HTXTMENU WINAPI TextCreateMenu(void);
TCUAAPI HTXTMENU WINAPI TextCreateMenuIndirect(void * pMenu,int lmenu);
TCUAAPI int    WINAPI TextDestroyMenu(HTXTMENU hmenu);
TCUAAPI int    WINAPI TextCloseMenu(HTXTMENU hmenu,HTWND hwnd);
TCUAAPI int    WINAPI TextAppendMenu(HTXTMENU,int flags,int id,char * string);
TCUAAPI int    WINAPI TextSetMenu(HTWND hwnd,HTXTMENU hmenu);
TCUAAPI HTXTMENU WINAPI TextGetMenu(HTWND hwnd);
TCUAAPI int    WINAPI TextGetSelMenuItem(HTXTMENU hmenu);
TCUAAPI int    WINAPI TextGetSelMenuItemPos(HTXTMENU hmenu);
TCUAAPI int    WINAPI TextEnableMenuItem(HTXTMENU hmenu,int item,int flags);
TCUAAPI int    WINAPI TextCheckMenuItem(HTXTMENU hmenu,int item,int flags);
TCUAAPI int    WINAPI TextDrawMenuBar(HTWND hwnd);
TCUAAPI int    WINAPI TextDrawPopupMenu(HTXTMENU hmenu,int xpos,int ypos);
TCUAAPI int    WINAPI TextGetMenuItemInfo(HTXTMENU hmenu, int item, int fByPos, TEXTMENUITEMINFO * pmii);
TCUAAPI int    WINAPI TextGetMenuItems(HTXTMENU hmenu);
TCUAAPI int    WINAPI TextGetMenuMaxItem(HTXTMENU hmenu);
TCUAAPI int    WINAPI SearchMenuKey(HTXTMENU hmenu,int key);
TCUAAPI HTXTMENU WINAPI TextGetSubMenu(HTXTMENU hmenu,int position);
TCUAAPI BOOL   WINAPI TextTrackPopupMenu(HTXTMENU hmenu,int flags,int x,int y,HTWND);


// static control


// *** WM_COMMAND Notifications of static to parent ***

// flags

#define SS_SEPARATOR   0x01
#define SS_TRANSPARENT 0x02

// *** functions ***

HTWND WINAPI TextCreateStatic(int xlen,int ylen,int flags,HTWND parent,int xflags,int id);


// edit control


typedef struct _TEDIT  {
int  flags    ;     // flags
PSTR pText    ;     // text
int  uTextlen ;     // size text
int  uMaxlen  ;     // max size text
int  uCursor  ;     // cursor position
} TEDIT;

typedef TEDIT * PTEDIT;

// *** flags ***

#define TES_AUTOHSCROLL    0x01
#define TES_AUTOSKIP       0x02

// *** WM_COMMAND Notifications of edit to parent ***

#define EN_SELCHANGE 0

// *** Funktionen ***

TCUAAPI HTWND WINAPI TextCreateEdit(int xlen,int ylen,int flags,HTWND parent,int xflags,int id);
TCUAAPI int   WINAPI EditSetText(HTWND,char *);
TCUAAPI int   WINAPI EditGetText(HTWND,char *,int);


// button control


typedef struct _TBUTTON {
int flags;
} TBUTTON;

typedef TEDIT *PTEDIT;

// *** flags ***

#define BT_PUSHBUTTON   0x001
#define BT_RADIOBUTTON  0x002
#define BT_CHECKBOX     0x004
#define BT_TRANSPARENT  0x040
#define BT_CHECKED      0x100


// from Parent to Button

// get/set status of CheckButtons

#define TBM_GETCHECK 0xF0
#define TBM_SETCHECK 0xF1

// get/set "Highlight" of buttons

#define TBM_GETSTATE 0xF2
#define TBM_SETSTATE 0xF3

#define BST_UNCHECKED 0x0000
#define BST_CHECKED   0x0001

// *** WM_COMMAND Notifications Button to Parent ***

#define BN_CLICKED  0

// *** functions ***

HTWND WINAPI CreateButton(int xlen,int ylen,int flags,HTWND parent,int xflags,int id);


// scoll bar control


typedef struct _TSCROLLBAR {
int flags      ;     // flags
int value      ;     // aktueller wert
int maxvalue   ;     // maximaler wert
} TSCROLLBAR;

#define SB_VERT   1

// *** WM_COMMAND Notifications ScrollBar to Parent ***

#define SB_CHANGE 0

TCUAAPI HTWND WINAPI CreateScrollBar(int laenge,int flags,HTWND parent,int maxvalue,int id);
TCUAAPI int   WINAPI TextShowScrollBar(HTWND hwnd,int xpos,int ypos);
TCUAAPI int   WINAPI ScrollBarGetValue(HTWND hwnd);
TCUAAPI int   WINAPI ScrollBarSetValue(HTWND hwnd,int value);


// listbox control


typedef struct _TLISTBOX {
void * pFirst;        // first element
int    items;         // num elements
int    flags;         // flags
int    actitem;       // currently selected element
HTWND  hWndVSB;       // hwnd vertical scrollbar
HTWND  hWndHSB;       // ditto horizontal
int    topmost;       // first visible element
} TLISTBOX;

typedef TLISTBOX *PTLISTBOX;


// *** flags ***

#define LBS_VSCROLL       0x01
#define LBS_HSCROLL       0x02
#define LBS_NOSHOWSEL     0x04 // dont highlight selected item
#define LBS_ALWAYSSHOWSEL 0x08 // always highlight selected item
#define LBS_PAINT         0x80 // internal: ???
#define LBS_UPDATE        0x40 // internal: listbox document updated
#define TLBS_SORT         0x20

// *** WM_COMMAND Notifications Listbox to Parent ***

#define LBN_SELCHANGE 1

typedef struct _TLBELEM {
void * pNext;     // next element (or 0)
int    user;      // user data
char   strng[1];  // string (min size)
} TLBELEM;

TCUAAPI HTWND WINAPI TextCreateListBox(int xlen,int ylen,int flags,HTWND parent,int xflags,int id);
TCUAAPI int   WINAPI TextListBoxAddString(HTWND hwnd,PSTR pString);
TCUAAPI int   WINAPI TextListBoxGetString(HTWND hwnd,int index,PSTR pString,int maxlen);
TCUAAPI int   WINAPI TextListBoxSetItemData(HTWND hwnd,int index,int dwData);
TCUAAPI int   WINAPI TextListBoxGetItemData(HTWND hwnd,int index);
TCUAAPI int   WINAPI TextListBoxGetSelItem(HTWND hwnd);
TCUAAPI int   WINAPI TextListBoxSetSelItem(HTWND hwnd,int index);
TCUAAPI int   WINAPI TextListBoxResetContent(HTWND hwnd);
TCUAAPI int   WINAPI TextListBoxGetFlags(HTWND hwnd);
TCUAAPI int   WINAPI TextListBoxSetFlags(HTWND hwnd,int flags);


// common dialogs


typedef struct _OPENFILEDLG {
HTWND hWnd;
PSTR  pszFind;
int   lszFind;
PSTR  pszFileName;
int   lszFileName;
int   fFiles;
int   fSubDir;
PSTR  pszStartDir;
PSTR  pszResource;
int   flags;
} OPENFILEDLG;


#define TOFN_FILEMUSTEXIST   1
#define TOFN_OVERWRITEPROMPT 2

int WINAPI TextGetOpenFileName(OPENFILEDLG *);
int WINAPI TextGetSaveFileName(OPENFILEDLG *);



#ifdef __cplusplus
}
#endif


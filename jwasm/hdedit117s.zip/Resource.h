
// color attributes

#define TW1ATTR   FOREGROUND_BLACK | BACKGROUND_WHITE // status line
#define TW1ATTRX  FOREGROUND_BLACK | BACKGROUND_CYAN
#define TW2ATTRV  FOREGROUND_BLUE | BACKGROUND_WHITE  | BACKGROUND_INTENSITY // view mode
#define TW2ATTRE  TW2ATTRV | FOREGROUND_INTENSITY // edit mode
#define TW4ATTR   FOREGROUND_BLACK | BACKGROUND_WHITE | BACKGROUND_INTENSITY // line prefix
#define TW5ATTRV  FOREGROUND_BLUE | BACKGROUND_WHITE  | BACKGROUND_INTENSITY // view mode
#define TW5ATTRE  FOREGROUND_GREEN | BACKGROUND_WHITE | BACKGROUND_INTENSITY // edit mode
#define BWSTAT    FOREGROUND_BLACK | BACKGROUND_WHITE // B&W status line
#define BWSCRN    FOREGROUND_WHITE | BACKGROUND_BLACK // B&W client
#define BWEDIT    FOREGROUND_WHITE | BACKGROUND_BLACK | FOREGROUND_INTENSITY // edit
#define LB_FRAME  WF_FRAME | WF_SIMPLE


// Control IDs

#define IDC_LISTBOX3  0x150
#define IDC_LISTBOX1  0x151
#define IDC_LISTBOX2  0x152
#define IDC_POS       0x153
#define IDC_SAVE      0x154
#define IDC_SECTOR    0x155
#define IDC_BUTTON1   0x156

#define IDC_BI        0x201
#define IDC_TYP       0x202
#define IDC_BEGCYL    0x203
#define IDC_BEGHEAD   0x204
#define IDC_BEGSEC    0x205
#define IDC_ENDCYL    0x206
#define IDC_ENDHEAD   0x207
#define IDC_ENDSEC    0x208
#define IDC_LBASTASEC 0x209
#define IDC_LBANUMSEC 0x210
#define IDC_SECTORS   0x211

// *** menu IDs ***

#define ID_DRIVE    0x11
#define ID_LOAD     0x12
#define ID_SAVE     0x13
#define ID_DOSSHELL 0x14
#define ID_EXIT     0x15

#define ID_PRVSEC   0x31
#define ID_NXTSEC   0x32
#define ID_SECEDT   0x33
#define ID_REWR     0x34
#define ID_COPY     0x35
#define ID_PASTE    0x36

#define ID_VIEW     0x41
#define ID_EDIT     0x42
#define ID_LOWRES   0x43
#define ID_HIGHRES  0x44
#define ID_PARTITION 0x45
#define ID_MIDRES   0x46

#define ID_CONTENT  0x51
#define ID_INFO     0x52
#define ID_README   0x53


#define changedrivestr  "change drive"
#define str62           "partitions drive %02X"
#define str71           "\nSector content has been changed.\n" \
                        "Rewrite now?\n\n"
#define str72           "\ndrop changes made so far?\n"

#define strOK  "OK"
#define strCan "Cancel"
#define strYes "Yes"
#define strNo  "No"

// texts

const char * errstr    = {"Error"};
const char * hintstr   = {"Hint"};
const char * warnstr   = {"Warning"};

// format status line

char stathelp[] = {" Drive: %X, Sectors: %I64u (CHS=%u/%u/%u), Sector: "};

// strings for message boxes

char * createrr     = {"\n \"%s\"\ncannot be created \n\n" };
char * writerr      = {"\n while writing on \n \"%s\" \n\n" };
char * szWriteError = {"\n Error writing sector \n\n" };
char * szReadError  = {"\n Sector %I64u cannot be read \n\n"};
char * szDriveError = {"\n Drive invalid \n\n"};
char * writehint    = {"\n Sector(s) written to file \n \"%s\". \n\n" };
char * openreaderr  = {"\n File cannot be opened \n\n" };
char * wrongsizeerr = {"\n File size must be exactly one sector (%u bytes). \n\n" };
char * readerr      = {"\n Error reading file \n\n" };
char * szMemError   = {"\n out of memory\n\n"};
char * szOverflowErr= {" CHS-translation ist active. Sector \n"
                       " %I64u would result (drive geometry is %u/%u/%u)\n"
                       " in a cylinder# > 1023."};


char * helptext = {"View- and Edit-Mode:\n"
             " Cursor Up     scroll 1 line up\n"
             " Cursor Dn     scroll 1 line down\n"
             " Page Up       scroll 1 page up\n"
             " Page Dn       scroll 1 page down\n"
             " F5            read previous sector\n"
             " F6            read next sector\n"
             "View-Mode (F7):\n"
             " Cursor Left   read previous sector\n"
             " Cursor Rechts read next sector\n"
             " Tab           switch input control\n"
             "Edit-Mode (F8):\n"
             " Cursor Keys   moves cursor\n"
             " Tab           switch Hex/Text mode\n"
          };

char * helpcap = {"Keys"};


char * infotext = {
             "           HDEDIT version 1.17 (Freeware)\n\n"
             "           Program to edit hard disks\n\n"
             "           Copyright (C) japheth 1999-2014 \n\n"
             " WARNING: this program uses low-level hard disk access.\n"
             " If used inappropriately severe data losses may occur.\n"
			 " So only experienced users should use this program.\n"
			 " In any case you should know what you are doing.\n"};


// *** dialog boxes ***

DLGDEF readmedlgtemp = {
        2,3,72,19,WF_FRAME | WF_SIMPLE | WF_SHADOW,-1,"HDEDIT.TXT",
        DIT_LISTBOX,  0, 0,70,16, 0,-1,0,LBS_VSCROLL | LBS_NOSHOWSEL,IDC_LISTBOX1,0,
        {DIT_STATIC,  0,16, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON, 28,17,10, 1,WF_SMALLSHADOW,-1,strOK,BT_PUSHBUTTON,IDOK},
        DIT_NULL
        };

DLGDEF savesectorsdlgtemp = {
        2,3,30,6,WF_FRAME | WF_SIMPLE | WF_SHADOW,-1,0,
        DIT_STATIC,  0, 1,16, 1, 0,-1,"Sectors to save",SS_TRANSPARENT,-1,0,
        {DIT_EDIT  , 16, 1, 5, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_SECTORS},
        {DIT_STATIC,  0,3, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON,  2,4,10, 1,WF_SMALLSHADOW,-1,strOK ,BT_PUSHBUTTON,IDOK},
        {DIT_BUTTON, 17,4,11, 1,WF_SMALLSHADOW,-1,strCan,BT_PUSHBUTTON,IDCANCEL},
        DIT_NULL
        };

DLGDEF loadsectorsdlgtemp = {
        2,3,30,6,WF_FRAME | WF_SIMPLE | WF_SHADOW,-1,0,
        DIT_STATIC,  0, 1,16, 1, 0,-1,"Sectors to load",SS_TRANSPARENT,-1,0,
        {DIT_EDIT  , 16, 1, 5, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_SECTORS},
        {DIT_STATIC,  0,3, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON,  2,4,10, 1,WF_SMALLSHADOW,-1,strOK ,BT_PUSHBUTTON,IDOK},
        {DIT_BUTTON, 17,4,11, 1,WF_SMALLSHADOW,-1,strCan,BT_PUSHBUTTON,IDCANCEL},
        DIT_NULL
        };

DLGDEF partitiondlgtemp = {
        2,3,72,10,WF_FRAME | WF_SIMPLE | WF_SHADOW,-1,0,
         DIT_STATIC,  0, 0,72, 2, 0,-1,
         "                        Begin           End           Begin      #\n"
         "Nr BI Typ            Cyl/Head/Sec   Cyl/Head/Sec      Sector   Sectors",
         0,-1,0,
        {DIT_STATIC,  0, 2, 0, 0, 0,-1,0,SS_SEPARATOR,-1,0},
        {DIT_LISTBOX, 0, 3,72, 4, 0,-1,0,LBS_ALWAYSSHOWSEL,IDC_LISTBOX2,0},
        {DIT_STATIC,  0, 7, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON,  5, 8,10, 1,WF_SMALLSHADOW,-1,"Change", BT_PUSHBUTTON,IDOK},
        {DIT_BUTTON, 20, 8,17, 1,WF_SMALLSHADOW | WF_DISABLED,-1,"Rewrite", BT_PUSHBUTTON,IDC_SAVE},
        {DIT_BUTTON, 42, 8, 9, 1,WF_SMALLSHADOW,-1,"Go to ",BT_PUSHBUTTON,IDC_POS},
        {DIT_BUTTON, 56, 8,11, 1,WF_SMALLSHADOW,-1,strCan,   BT_PUSHBUTTON,IDCANCEL},
        DIT_NULL
        };

DLGDEF parteditdlgtemp = {
        4,5,42,14,WF_FRAME | WF_SIMPLE | WF_SHADOW,0x17,"Change entry",
         DIT_STATIC,  0, 1,16, 1, 0,-1,"Boot Indicator",SS_TRANSPARENT,-1,0,
        {DIT_STATIC,  0, 2,16, 1, 0,-1,"Type",SS_TRANSPARENT,-1},
        {DIT_STATIC,  0, 4,16, 1, 0,-1,"Begin  C/H/S",SS_TRANSPARENT,-1},
        {DIT_STATIC,  0, 5,16, 1, 0,-1,"End    C/H/S",SS_TRANSPARENT,-1},
        {DIT_STATIC,  0, 9,16, 1, 0,-1,"Start sector",SS_TRANSPARENT,-1},
        {DIT_STATIC,  0,10,16, 1, 0,-1,"# Sectors",SS_TRANSPARENT,-1},
        {DIT_EDIT  , 16, 1, 2, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_BI},
        {DIT_EDIT  , 16, 2, 2, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_TYP},
        {DIT_EDIT  , 16, 4, 4, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_BEGCYL},
        {DIT_EDIT  , 21, 4, 3, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_BEGHEAD},
        {DIT_EDIT  , 25, 4, 2, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_BEGSEC},
        {DIT_EDIT  , 16, 5, 4, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_ENDCYL},
        {DIT_EDIT  , 21, 5, 3, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_ENDHEAD},
        {DIT_EDIT  , 25, 5, 2, 1, WF_NOSCROLL,0x9E,"",TES_AUTOSKIP,IDC_ENDSEC},
        {DIT_BUTTON,  1, 7,37, 1, WF_NOSCROLL,-1,"change following values automatically" ,BT_CHECKBOX | BT_TRANSPARENT | BT_CHECKED,IDC_BUTTON1},
        {DIT_EDIT  , 16, 9,12, 1, WF_NOSCROLL | WF_DISABLED,0x9E,"",TES_AUTOSKIP,IDC_LBASTASEC},
        {DIT_EDIT  , 16,10,12, 1, WF_NOSCROLL | WF_DISABLED,0x9E,"",TES_AUTOSKIP,IDC_LBANUMSEC},

        {DIT_STATIC,  0,11, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON,  6,12,10, 1,WF_SMALLSHADOW,-1,strOK ,BT_PUSHBUTTON,IDOK},
        {DIT_BUTTON, 21,12,11, 1,WF_SMALLSHADOW,-1,strCan,BT_PUSHBUTTON,IDCANCEL},
        DIT_NULL
        };

DLGDEF changedrivedlgtemp = {
        2,3,52, 9,WF_FRAME | WF_SIMPLE | WF_SHADOW,-1,"Drive select",
         DIT_STATIC,  1, 0,51, 1, 0,-1,"No    Cyl/Head/Sec     Sectors     MB   Extensions",0,-1,0,
         DIT_STATIC,  0, 1, 0, 0, 0,-1,0,SS_SEPARATOR,-1,0,
        {DIT_LISTBOX, 0, 2,52, 4, 0,-1,0,LBS_ALWAYSSHOWSEL,IDC_LISTBOX3,0},
        {DIT_STATIC,  0, 6, 0, 0, 0,-1,0,SS_SEPARATOR,-1},
        {DIT_BUTTON, 13, 7,10, 1,WF_SMALLSHADOW,-1,strOK,BT_PUSHBUTTON,IDOK},
        {DIT_BUTTON, 28, 7,11, 1,WF_SMALLSHADOW,-1,strCan,BT_PUSHBUTTON,IDCANCEL},
        DIT_NULL
        };


// *** main menu ***


MENUDESC mainmenu[] = {
        0,         TM_SUBMENU | TM_SHADOW,"&File" ,0,
        ID_DRIVE,   0,        "S&elect Drive   F2","select current hard disk",
        ID_LOAD,   0,         "L&oad from...","reads a file and writes content to current location",
        ID_SAVE,   0,         "&Save as...","writes sectors to a file",
        ID_DOSSHELL,0,        "&DOS-Shell","opens a DOS command shell (return to HDEDIT with \"exit\")",
        -1,        TM_SEPARATOR,0      ,0,
        ID_EXIT,   0,         "E&xit        Alt+X","terminates application",

        0,         TM_SUBMENU | TM_SHADOW, "&Edit",0,
        ID_COPY,   0,          "&Copy            Ctrl-C","copies working area to the clipboard",
        ID_PASTE,  TM_DISABLED,"&Paste           Ctrl-V","copies clipboard to working area",
        ID_PRVSEC, 0,          "P&revious sector F5",	"reads previous sector into working area",
        ID_NXTSEC, 0,          "&Next sector     F6",	"reads next sector into working area",
        ID_SECEDT, 0,          "&Enter sector#   TAB",	"opens input field to enter sector #",
        -1,        TM_SEPARATOR,0      ,0,
        ID_REWR,   TM_DISABLED,"Rewrite sector","rewrites working area to disk",

        0,         TM_SUBMENU | TM_SHADOW,"&Options" ,0,
        ID_VIEW,   0,         "&View Mode   F7","View mode - working area is read only",
        ID_EDIT,   0,         "&Edit Mode   F8","Edit mode - working area can be modified",
        ID_PARTITION,0,       "&Partitions  F4","show partitions of current drive",
        ID_LOWRES, 0,         "&25 lines    F9","switch to 25-line resolution",
        ID_MIDRES, 0,         "&34 lines   F10","switch to 34-line resolution",
        ID_HIGHRES,0,         "&50 lines   F11","switch to 50-line resolution",

        0,         TM_SUBMENU | TM_SHADOW,"&Help" ,0,
        ID_CONTENT,0,"&Key Help      F1","shows functions assigned to keys",
        ID_README, 0,"&General Info","shows file HDEDIT.TXT",
        ID_INFO,   0,"A&bout HDEDIT...","displays some copyright infos"
        };

#define lmainmenu sizeof(mainmenu)/sizeof(MENUDESC)

// *** console error texts ***

#define ERR_INVDRV   1
#define ERR_ALLOC1   2
#define ERR_READ1    3
#define ERR_NOI13EXT 4
#define ERR_OPTION   6

typedef struct _errelem {
BYTE errno;
char * pErrstr;
} ERRELEM;

ERRELEM errstrgs[] = {
                  ERR_OPTION,
                  "HDEDIT v1.17 Copyright Japheth 2001-2014\n"
                  "usage: HDEDIT [ options ] [drive]\n"
                  "  options:\n"
                  "   /m : no colors, black and white only\n"
                  "   /s : don't use Int13 extensions\n"
                  " <drive>: int 13h drive# (0|1|80|81|82...), default 80\n",
                  ERR_ALLOC1,"Not enough memory\n",
                  ERR_INVDRV,"Drive is invalid\n",
                  ERR_READ1, "Error on read\n",
                  ERR_NOI13EXT,"Program needs int13 extensions\n",
                  0xFF,      "unexpected error occured\n"
                 };

PTYPE partab[] = {
                  0x00,"<free>",
                  0x01,"FAT12",
                  0x04,"FAT16 32M",
                  0x05,"FAT16 Ext",
                  0x06,"FAT16 Pri",
                  0x07,"HPFS",
                  0x0B,"FAT32 Pri",
                  0x0C,"FAT32 LBA",
                  0x0E,"FAT16 LBA",
                  0x0F,"FAT32 Ext",
                  0x82,"Linux swp",
                  0x83,"Linux ext",
                  0xFF};

// *** accelerators ***

DWORD acctable[] = {
           VK_F4 | (LEFT_ALT_PRESSED << 16),ID_EXIT,    // Alt-F4
           VK_F1                           ,ID_CONTENT,
           VK_F2                           ,ID_DRIVE,
           VK_F4                           ,ID_PARTITION,
           VK_F5                           ,ID_PRVSEC ,
           VK_F6                           ,ID_NXTSEC ,
           VK_F7                           ,ID_VIEW   ,
           VK_F8                           ,ID_EDIT   ,
           VK_F9                           ,ID_LOWRES ,
           VK_F10                          ,ID_MIDRES ,
           VK_F11                          ,ID_HIGHRES,
           'C'   | ((LEFT_CTRL_PRESSED | RIGHT_CTRL_PRESSED) << 16)    ,ID_COPY   ,
           'V'   | ((LEFT_CTRL_PRESSED | RIGHT_CTRL_PRESSED) << 16)    ,ID_PASTE  ,
           'X'   | ( LEFT_ALT_PRESSED << 16)     ,ID_EXIT
           };
#define lacctable sizeof(acctable)/8



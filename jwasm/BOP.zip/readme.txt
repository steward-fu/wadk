
 BOP sample

 BOP is the machanism how to call Win32 code from DOS code in Windows 
 NTVDM.

 The source is to be assembled with JWasm or Masm.
 To link the DOS 16-bit binary, use MS OMF linker.
 To link the Win32 dll, one needs import library NTVDM.LIB, which
 is included because there exist some buggy versions out there.

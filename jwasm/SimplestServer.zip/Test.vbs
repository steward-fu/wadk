
' create control (use ProgID as name)

  Set object = WScript.CreateObject("SimplestServerASM")

  MsgBox "Property=" & object.Property1
	
 
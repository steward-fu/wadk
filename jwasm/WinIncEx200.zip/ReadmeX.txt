
 A. About WinIncEx

   This package contains a few include files which are rarely used. Some
   of those files are huge, they would bloat the standard WinInc package
   significantly without offering any benefit for most users.
   
   - mshtml.inc
   - mshtmlc.inc
   - dimm.inc


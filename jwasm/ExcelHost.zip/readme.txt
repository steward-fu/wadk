
 1. About ExcelHost

 This is sample which hosts an excel application by COM automation.


 2. Building the binary

 There are 2 ways to create the binary:

 a). run NMAKE (Makefile)

  Tools used:
  - JWasm v1.93+ or Masm v6.11+
  - Win32Inc include files
  - MS RC
  - MS Link

  Adjust path for Win32Inc in Makefile before running NMAKE.

 b). run MAKEM32.BAT

  Tools used:
  - Masm
  - Masm32 include files
  - MS RC
  - MS Link

  Make sure you have a valid UUID.LIB. The one supplied with Masm32 might
  miss most - or all - GUIDs, making it pretty useless.


 3. Creating Excel.inc, Excelc.inc and Office.inc
 
 The include files excel.inc, excelc.inc and office.inc are made with
 COMView. If they are to be recreated, do the following steps:

   - change to TypeLib view in COMView
   - double click line "Microsoft Office xx Object Library"
   - click button "Create ASM Include" to create office.inc. Close the
     window.
   - double click line "Microsoft Excel xx Object Library"
   - click button "Create ASM Include" to create excel.inc.
   - click button "Create Dispatch Helper" to create excelc.inc.


 4. History

 01/2003, v1.0: initial version to demonstrate COMView capabilities
 02/2004, v1.1: added buttons to add book/sheet/select cell
 01/2007, v1.2: modified source so the binary can be created with both
                Masm32 and Win32Inc.
 09/2008, v1.3: JWasm now used as default assembler. Files excel.inc, 
                excelc.inc and office.inc added.


 5. License

 ExcelHost is Public Domain.

 japheth


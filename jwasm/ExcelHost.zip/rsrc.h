//
// Used by rsrc.rc
//
#define IDD_DIALOG1                     101
#define IDC_LIST1                       1000
#define IDC_START                       1001
#define IDC_CLEAR                       1002
#define IDC_VISIBLE                     1003
#define IDC_SETCELL                     1004
#define IDC_ADDBOOK                     1005
#define IDC_GETCELL                     1006
#define IDC_QUIT                        1007
#define IDC_SHEETS                      1009


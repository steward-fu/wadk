
;--- implements event object for DWebBrowserEvents2 interface
;--- the interface declaration is found in ExDisp.inc

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include MsHtmHst.inc
	include ExDisp.inc
	include ExDispId.inc
	include MsHtmDid.inc

	include container.inc

	include macros.inc
	include debugout.inc
	.list
	.cref

CEvent struct
_IDispatch	IDispatch <>
m_RefCnt	DWORD ?
m_hwndFrame	HWND ?
CEvent ends

ifndef ?DBGEXT
?DBGEXT	equ 0	;1=log QueryInterface/AddRef/Release of event sink interface
endif

NewWindow proto :ptr WORD, :DWORD, :DWORD
OnVisible proto :HWND, :DWORD, :DWORD

	.const

;*** vtbl IDispatch

CEvent@IDispatchVtbl label IDispatchVtbl
	IUnknownVtbl {QueryInterface@CEvent, AddRef@CEvent, Release@CEvent}
	dd GetTypeInfoCount
	dd GetTypeInfo
	dd GetIDsOfNames
	dd Invoke_

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IDispatch, 0
	dd offset DIID_DWebBrowserEvents, 0
	dd offset DIID_DWebBrowserEvents2, 0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

	.code

IsInterfaceSupported proto :ptr IID, :ptr ptr IID, :dword, :ptr, :ptr LPUNKNOWN

Create@CEvent proc public uses ebx hwnd:HWND

	DebugOut "Create@CEvent enter"
	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CEvent
	.if (eax == NULL)
		return 0
	.endif
	mov ebx, eax
	mov [ebx].CEvent._IDispatch, offset CEvent@IDispatchVtbl
	mov [ebx].CEvent.m_RefCnt, 0
	mov eax, hwnd
	mov [ebx].CEvent.m_hwndFrame, eax
	return ebx
	align 4

Create@CEvent endp

Destroy@CEvent proc pThis:ptr CEvent

	DebugOut "Destroy@CEvent enter"
	invoke LocalFree, pThis
	ret
	align 4

Destroy@CEvent endp

CastOffset textequ <CEvent._IDispatch>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface@CEvent proc pThis:ptr CEvent, riid:ptr IID, ppReturn:ptr ptr

ifdef _DEBUG
local	wszIID[40]:word
endif

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn

ifdef _DEBUG
 if ?DBGEXT eq 0
	cmp eax,S_OK
	jz @F
 endif
	push eax
	invoke StringFromGUID2,riid, addr wszIID, 40
	pop eax
	DebugOut "QueryInterface@CEvent(%S)=%X", addr wszIID, eax
@@:
endif
	ret
	align 4

QueryInterface@CEvent endp

AddRef@CEvent proc pThis:ptr CEvent

	mov eax,pThis
	inc [eax].CEvent.m_RefCnt

if ?DBGEXT ;the event sink interface is AddRef/Released a lot!
	DebugOut "AddRef@CEvent: Count=%u", [eax].CEvent.m_RefCnt
endif

	mov eax, [eax].CEvent.m_RefCnt
	ret
	align 4

AddRef@CEvent endp

Release@CEvent proc pThis:ptr CEvent

	mov eax,pThis
	dec [eax].CEvent.m_RefCnt

if ?DBGEXT ;the event sink interface is AddRef/Released a lot!
	DebugOut "Release@CEvent: Count=%u", [eax].CEvent.m_RefCnt
endif

	mov eax,[eax].CEvent.m_RefCnt
	.if (eax == 0)
		invoke Destroy@CEvent, pThis
		xor eax,eax
	.endif
	ret
	align 4

Release@CEvent endp


GetTypeInfoCount proc pThis:ptr CEvent, pctinfo:ptr DWORD

	DebugOut "CEvent@IDispatch::GetTypeInfoCount"
	return E_NOTIMPL
	align 4

GetTypeInfoCount endp


GetTypeInfo proc pThis:ptr CEvent, iTInfo:DWORD, lcid:LCID, ppTInfo:ptr LPTYPEINFO

	DebugOut "CEvent@IDispatch::GetTypeInfo"
	return E_NOTIMPL
	align 4

GetTypeInfo endp


GetIDsOfNames proc uses esi edi pThis:ptr CEvent, riid:ptr IID, rgszNames:DWORD, cNames:DWORD, lcid:LCID, rgDispId:ptr DISPID

	DebugOut "CEvent@IDispatch::GetIDsOfNames(%X, %X, %X, %X, %X)", riid, rgszNames, cNames, lcid, rgDispId
	return E_NOTIMPL
	align 4

GetIDsOfNames endp


DWebBrowserEvents2@TitleChange proc pThis:ptr CEvent, bstrText:BSTR

	DebugOut "CEvent@DWebBrowserEvents::TitleChange(%X)", bstrText
	mov edx, pThis
	invoke SetWindowTextW, [edx].CEvent.m_hwndFrame, bstrText
	ret
	align 4

DWebBrowserEvents2@TitleChange endp

DWebBrowserEvents2@DocumentComplete proc uses ebx pThis:ptr CEvent, bstrURL:BSTR

	DebugOut "CEvent@DWebBrowserEvents2::DocumentComplete(%S)", bstrURL
if ADDRBAR
;--- copy the current URL into the address bar
	mov ebx, pThis
	invoke GetWindowLong, [ebx].CEvent.m_hwndFrame, WO_URLEDIT
	invoke SetWindowTextW, eax, bstrURL
endif
	ret
	align 4

DWebBrowserEvents2@DocumentComplete endp

;--- get a parameter from the VARIANTARG array found in the DISPPARAMS
;--- argument of IDispatch::Invoke().
;--- The arguments are in inverse order, the "last" one is at index 0
;--- in the array!

GetParam proc uses ebx pout:ptr VARIANT, pArray:ptr VARIANT, index:dword, cArgs:dword

	invoke VariantInit, pout
	mov ebx, pArray
	mov eax, cArgs
	sub eax, index
	dec eax
	shl eax, 4
	add ebx, eax
	invoke VariantCopy, pout, ebx
	DebugOut "CEvent@GetParam: VariantCopy(%X,%X)=%X", pout, ebx, eax
	ret
	align 4

GetParam endp

;--- the event's IDispatch::Invoke() method.
;--- the dispids will be found in ExDispId.inc

Invoke_ proc uses esi edi ebx pThis:ptr CEvent, dispIdMember:DISPID, riid:ptr IID, lcid:LCID,
	wFlags:WORD, pDispParams:ptr DISPPARAMS, pVarResult:ptr VARIANT, pExcepInfo:DWORD, puArgErr:ptr DWORD

local vt:VARIANTARG

	mov eax, dispIdMember
	mov ebx, pDispParams

	DebugOut "CEvent@IDispatch::Invoke( %d, %X [%X %X %u %u], %X)",\
		eax, ebx, [ebx].DISPPARAMS.rgvarg, [ebx].DISPPARAMS.rgdispidNamedArgs, [ebx].DISPPARAMS.cArgs, [ebx].DISPPARAMS.cNamedArgs, pVarResult

	mov esi, [ebx].DISPPARAMS.rgvarg

	.if ( eax == DISPID_TITLECHANGE)

		invoke GetParam, addr vt, esi, 0, [ebx].DISPPARAMS.cArgs
		invoke DWebBrowserEvents2@TitleChange, pThis, vt.bstrVal
		invoke VariantClear, addr vt

	.elseif ( eax == DISPID_NEWWINDOW2 )

		;--- this event is used by IE 4 and 5
		;--- I'm not sure if it works.
		DebugOut "CEvent@DWebBrowserEvents2::NewWindow2()"
		invoke NewWindow, NULL, 0, 0
		DebugOut "CEvent@DWebBrowserEvents2::NewWindow2: NewWindow()=%X", eax
		.if ( eax )
			mov edi, eax
			mov ecx, pThis
			invoke IsZoomed, [ecx].CEvent.m_hwndFrame
			mov edx, SW_SHOWMAXIMIZED
			.if ( eax == 0 )
				mov edx, SW_SHOWNORMAL
			.endif
			invoke ShowWindow, edi, edx
			invoke GetWindowLong, edi, WO_CONTAINER
			push eax
			invoke GetParam, addr vt, esi, 0, [ebx].DISPPARAMS.cArgs
			pop ebx
			invoke vf( [ebx].CContainer.m_pOleObject, IUnknown, QueryInterface ), addr IID_IDispatch, vt.byref
			DebugOut "CEvent@DWebBrowserEvents2::NewWindow2: QueryInterface()=%X", eax
			invoke VariantClear, addr vt
		.endif

	.elseif ( eax == DISPID_NEWWINDOW3 )

		DebugOut "CEvent@DWebBrowserEvents2::NewWindow3()"
		;--- this event is used since IE 6.
		;--- cancel "new window" navigation
		invoke GetParam, addr vt, esi, 1, [ebx].DISPPARAMS.cArgs
		mov ecx, vt.byref
		mov VARIANT_BOOL ptr [ecx], VARIANT_TRUE

		mov ecx, pThis
		invoke IsZoomed, [ecx].CEvent.m_hwndFrame
		mov edx, SW_SHOWMAXIMIZED
		.if ( eax == 0 )
			mov edx, SW_SHOWNORMAL
		.endif
		push edx
		;--- get the new URL
		invoke GetParam, addr vt, esi, 4, [ebx].DISPPARAMS.cArgs
		pop edx
		invoke NewWindow, vt.bstrVal, COF_VISIBLE, edx
		invoke VariantClear, addr vt

	.elseif ( eax == DISPID_ONVISIBLE )

		DebugOut "CEvent@DWebBrowserEvents2::OnVisible()"
		;--- this event may occur if app was started with -Embedding 
		invoke GetParam, addr vt, esi, 0, [ebx].DISPPARAMS.cArgs
		mov ecx, pThis
		.if ( vt.boolVal )
			mov eax, SW_SHOW
		.else
			mov eax, SW_HIDE
		.endif
		invoke OnVisible, [ecx].CEvent.m_hwndFrame, vt.boolVal, eax

	.elseif ( eax == DISPID_DOCUMENTCOMPLETE )

		invoke GetParam, addr vt, esi, 1, [ebx].DISPPARAMS.cArgs
		mov ecx, vt.byref
		invoke DWebBrowserEvents2@DocumentComplete, pThis, [ecx].VARIANT.bstrVal
		invoke VariantClear, addr vt

	.elseif ( eax == DISPID_QUIT )

		DebugOut "CEvent@DWebBrowserEvents::Quit()"
		;--- this event may occur if app was started with -Embedding 

		;not tested yet!

	.endif
	return S_OK
	align 4

Invoke_ endp

	end

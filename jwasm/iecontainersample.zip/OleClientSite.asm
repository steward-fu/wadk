
;--- IOleClientSite interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl IOleClientSite

CContainer@IOleClientSiteVtbl label IOleClientSiteVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd SaveObject
	dd GetMoniker
	dd @GetContainer
	dd ShowObject
	dd OnShowWindow
	dd RequestNewObjectLayout

	.code

; -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CastOffset textequ <CContainer._IOleClientSite>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

SaveObject proc pThis:ptr CContainer

	DebugOut "IOleClientSite::SaveObject"
;--- do nothing
	return S_OK
	align 4

SaveObject endp


GetMoniker proc pThis:ptr CContainer, dwAssign:DWORD, dwWhichMoniker:DWORD, ppmk:DWORD

	DebugOut "IOleClientSite::GetMoniker(%X,%X,%X)", dwAssign, dwWhichMoniker, ppmk
	mov ecx, ppmk
	mov dword ptr [ecx],0
	return E_NOTIMPL
	align 4

GetMoniker endp


@GetContainer: AdjustThis
GetContainer proc pThis:ptr CContainer, ppContainer:LPOLECONTAINER

	DebugOut "IOleClientSite::GetContainer(%X)", ppContainer
if ?IOC
	mov eax, pThis
	lea edx, [eax].CContainer._IOleContainer
	inc [eax].CContainer.m_RefCnt
	xor eax, eax	;=S_OK
else
	xor edx, edx
	mov eax, E_NOINTERFACE
endif
	mov ecx, ppContainer
	mov dword ptr [ecx], edx
	ret
	align 4

GetContainer endp


ShowObject proc pThis:ptr CContainer

	DebugOut "IOleClientSite::ShowObject"
	return S_OK
	align 4

ShowObject endp

;*** IOleClientSite::OnShowWindow
;*** called if object is shown in its own user window

OnShowWindow proc pThis:ptr CContainer, fShow:dword

	DebugOut "IOleClientSite::OnShowWindow(%X)", fShow
	return S_OK
	align 4

OnShowWindow endp


RequestNewObjectLayout proc pThis:ptr CContainer

	DebugOut "IOleClientSite::RequestNewObjectLayout"
	return E_NOTIMPL
	align 4

RequestNewObjectLayout endp

	end

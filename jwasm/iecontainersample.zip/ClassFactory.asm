
;--- IClassFactory implementation
;--- this is only needed if the -Embedding commandline option
;--- is to be supported.

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include unknwn.inc
	include oaidl.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include debugout.inc
	include macros.inc
	.list
	.cref

if ?IEAPP

AGGREGATION equ 0

externdef g_count:dword
NewWindow proto :ptr WORD, :dword, :dword

IsInterfaceSupported proto :ptr IID, :ptr ptr IID, :dword, :ptr, :ptr LPUNKNOWN

CClassFactory struct
_IClassFactory	IClassFactory <>
dwRefCount		dd ?
;pClass			LPOBJECTENTRY ?
CClassFactory ends

CUnknown struct
_IUnknown IUnknown <>
CUnknown ends

	.data

g_dwThreadId dd 0

	.const

CContainer@IClassFactoryVtbl IClassFactoryVtbl {QueryInterface@ClassFactory,
	AddRef@ClassFactory, Release@ClassFactory, CreateInstance, LockServer}

iftab label dword
	dd offset IID_IUnknown,0
	dd offset IID_IClassFactory,0
IFTABSIZE equ ($ - iftab)/ (2 * sizeof dword)

	.code

;--- create ClassFactory, return addr of object in eax (NULL == error)

Create@ClassFactory PROC public

	DebugOut "Create@ClassFactory"

	invoke GetCurrentThreadId
	mov g_dwThreadId, eax

	invoke LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CClassFactory
	.if (eax == NULL)
		DebugOut "Create@ClassFactory failed"
		ret
	.endif

	mov [eax].CClassFactory._IClassFactory.lpVtbl, OFFSET CContainer@IClassFactoryVtbl
	mov [eax].CClassFactory.dwRefCount, 1

	ret
	align 4

Create@ClassFactory ENDP

;------ destructor ClassFactory, return void

Destroy@ClassFactory PROC this_:ptr CClassFactory

	DebugOut "Destroy@ClassFactory"
	invoke LocalFree, this_
	ret
	align 4

Destroy@ClassFactory ENDP

;--- IClassFactory interface

QueryInterface@ClassFactory PROC this_:ptr CClassFactory,riid:ptr IID,ppReturn:ptr LPUNKNOWN

	invoke IsInterfaceSupported, riid, offset iftab, IFTABSIZE,  this_, ppReturn
	ret
	align 4

QueryInterface@ClassFactory ENDP


AddRef@ClassFactory PROC this_:ptr CClassFactory

	mov eax, this_
	inc [eax].CClassFactory.dwRefCount
	mov eax, [eax].CClassFactory.dwRefCount
	DebugOut "IClassFactory::AddRef returns %u", eax
	ret
	align 4

AddRef@ClassFactory ENDP


Release@ClassFactory PROC this_:ptr CClassFactory

	mov eax, this_
	dec [eax].CClassFactory.dwRefCount

	mov eax,[eax].CClassFactory.dwRefCount
	.if (eax == 0)
		invoke Destroy@ClassFactory, this_
		xor eax,eax
	.endif
	DebugOut "IClassFactory::Release returns %u", eax
	ret
	align 4

Release@ClassFactory ENDP


CreateInstance PROC pThis:ptr CClassFactory, pUnkOuter:LPUNKNOWN,
		riid:ptr IID, ppObject:ptr LPUNKNOWN

local pObject:LPUNKNOWN
local pWebBrowser:LPWEBBROWSER

	DebugOut "IClassFactory::CreateInstance(%X, %X, %X) enter", pUnkOuter, riid, ppObject

	mov eax, ppObject
	mov DWORD PTR [eax], NULL

if AGGREGATION
;------------- if pUnkOuter != NULL riid MUST be IID_IUnknown!
	.if (pUnkOuter != NULL)
		invoke IsEqualGUID, riid, addr IID_IUnknown
		.if (eax == FALSE)
			DebugOut "IClassFactory::CreateInstance failed (riid != IID_IUnknown)"
			return CLASS_E_NOAGGREGATION
		.endif
	.endif
else
	.if (pUnkOuter != NULL)
		DebugOut "IClassFactory::CreateInstance failed (pUnkOuter != Null)"
		return CLASS_E_NOAGGREGATION
	.endif
endif

;--- create invisible window

	invoke NewWindow, NULL, COF_AGGREGATE, 0
	.if (eax == NULL)
		DebugOut "IClassFactory::CreateInstance failed (constructor returned NULL)"
		return E_OUTOFMEMORY
	.endif

;--- get the container object
	invoke GetWindowLong, eax, 0

;--- currently the WebBrowser control is exposed directly. This isn't
;--- correct, because the InternetExplorer.Application object isn't supposed
;--- to be embeddable. Should be improved.

	mov eax,[eax].CContainer.m_pUnknown
	mov pObject,eax

	invoke vf( pObject, IUnknown, QueryInterface), riid, ppObject
	DebugOut "IClassFactory::CreateInstance: QueryInterface()=%X, [%X]", eax, ppObject

;	push eax
;	invoke vf( pObject, IUnknown, Release)
;	pop eax
	DebugOut "IClassFactory::CreateInstance exit, eax=%X", eax
	ret
	align 4

CreateInstance ENDP


LockServer PROC pThis:ptr CClassFactory, bLockServer:DWORD

	DebugOut "IClassFactory::LockServer(%X), curCnt=%u", bLockServer, g_count

	.if (bLockServer)
		inc g_count
	.else
		dec g_count
	.endif
	.if (ZERO?)
		invoke PostThreadMessage, g_dwThreadId, WM_QUIT, 0, 0
	.endif
	return S_OK
	align 4

LockServer ENDP

endif

	end

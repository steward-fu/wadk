
;*** implements IDocHostShowUI interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl IDocHostShowUI

CContainer@IDocHostShowUIVtbl label IDocHostShowUIVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd ShowHelp
	dd ShowMessage

	.code

CastOffset textequ <CContainer._IDocHostShowUI>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

ShowHelp proc pThis:ptr CContainer, hwnd:DWORD, pszHelpFile:DWORD, uCommand:DWORD, dwData:DWORD, ptMouse:POINT, pDispatchObjectHit:DWORD

	DebugOut "IDocHostShowUI::ShowHelp"
	return S_FALSE	;let the control display the help
	align 4

ShowHelp endp


ShowMessage proc pThis:ptr CContainer, hwnd:DWORD, lpstrText:DWORD, lpstrCaption:DWORD, dwType:DWORD, lpstrHelpFile:DWORD, dwHelpContext:DWORD, plResult:DWORD

	DebugOut "IDocHostShowUI::ShowMessage"
	return S_FALSE	;let the control display the message box itself
	align 4

ShowMessage endp

	end


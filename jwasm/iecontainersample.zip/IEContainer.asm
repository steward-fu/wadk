
;--- main module
;--- this module creates the window which hosts the webbrowser-control,
;--- also the address bar and status line child windows.

	.486
	.model flat, stdcall
	option casemap :none
	option proc :private

	.nolist
	.nocref
	include windows.inc
	include commctrl.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	includelib kernel32.lib
	includelib user32.lib
	includelib Comctl32.lib
	includelib ole32.lib
	includelib oleaut32.lib
	includelib shell32.lib
	includelib uuid.lib

IDC_STATUSBAR equ 2
if ADDRBAR
IDC_REBAR     equ 3
IDC_BAND1     equ 4
IDC_URLEDIT   equ 5
endif

WNDEXSPACE   equ 3*sizeof DWORD

;--- cmdline option flags
JF_EMBEDDING equ 1	;"Embedding" option found

Create@ClassFactory PROTO

	.data

g_hwndActive HWND 0
	public g_count
g_count      dd 0

ifdef _DEBUG
	.data?
	public DbgBuffer
DbgBuffer db 4096 dup (?)
endif

	.const

wszDefaultUrl dw L("http://www.google.com/"),0
;wszDefaultUrl dw L("http://www.japheth.de/JWasm.html"),0
;wszDefaultUrl dw L("file://c:\"),0
wszEmbedding dw L("Embedding"),0
szNull dw 0
szClassName db "WebBrowserClass",0

if 0
IEObj ObjectEntry { offset CLSID_InternetExplorer,
	offset LIBID_ComExeSvr, _MajorVer_ComExeSvr, _MinorVer_ComExeSvr,
	offset RegKeys_ComExeSvr,
endif

	.code

;*** set text of status line

SetSBText proc public hWnd:HWND, pszStatusText:ptr WORD

	invoke GetDlgItem, hWnd, IDC_STATUSBAR
	.if (eax)
		mov ecx, pszStatusText
		.if (!ecx)
			mov ecx, offset szNull
		.endif
		invoke SendMessageW, eax, SB_SETTEXTW, 255, ecx
	.endif
	ret
	align 4

SetSBText endp

;*** Get control area - without rebar and status bar

GetControlRect proc public hWnd:HWND, pRect:ptr RECT

local rect:RECT

	invoke GetClientRect, hWnd, pRect
if ADDRBAR
	invoke GetDlgItem, hWnd, IDC_REBAR
	.if (eax)
		lea ecx, rect
		invoke GetWindowRect, eax, ecx
		mov eax,rect.bottom
		sub eax,rect.top
		mov ecx,pRect
		add [ecx].RECT.top,eax
	.endif
endif
	invoke GetDlgItem, hWnd, IDC_STATUSBAR
	.if (eax)
		lea ecx, rect
		invoke GetWindowRect, eax, ecx
		mov eax,rect.bottom
		sub eax,rect.top
		mov ecx,pRect
		sub [ecx].RECT.bottom,eax
	.endif
	ret
	align 4

GetControlRect endp

;--- main window's WM_SIZE

OnSize proc hWnd:HWND, wParam:WPARAM, lParam:LPARAM

LOCAL rect:RECT

	mov eax,wParam
	.if (eax == SIZE_RESTORED || eax == SIZE_MAXIMIZED)
		invoke GetControlRect, hWnd, addr rect
		DebugOut "OnSize: control rect=%X %X %X %X", rect.left, rect.top, rect.right, rect.bottom
if ADDRBAR
		invoke GetDlgItem, hWnd, IDC_REBAR
		.if (eax)
			invoke SetWindowPos, eax, NULL, 0, 0,
				rect.right, rect.top, SWP_NOZORDER or SWP_NOACTIVATE
		.endif
endif
		invoke GetDlgItem, hWnd, IDC_STATUSBAR
		.if (eax)
			movzx ecx,word ptr lParam+2
			sub ecx, rect.bottom
			invoke SetWindowPos, eax, NULL, 0, rect.bottom,
				rect.right, ecx, SWP_NOZORDER or SWP_NOACTIVATE
		.endif
		invoke GetWindowLong, hWnd, WO_CONTAINER
		mov ecx, eax
		.if (ecx && [ecx].CContainer.m_pOleInPlaceObject )
			invoke vf([ecx].CContainer.m_pOleInPlaceObject, IOleInPlaceObject, SetObjectRects), addr rect, addr rect
			DebugOut "OnSize: IOleInPlaceObject::SetObjectRects()=%X", eax
		.endif
	.endif
	ret
	align 4

OnSize endp

;--- main window's WM_ACTIVATE

OnActivate proc uses ebx hwnd:HWND, wParam:WPARAM

	invoke GetWindowLong, hwnd, WO_CONTAINER
	mov ebx, eax
	movzx eax,word ptr wParam
	.if (eax == WA_INACTIVE)
		invoke GetFocus
		invoke SetWindowLong, hwnd, WO_FOCUS, eax
		.if (ebx && [ebx].CContainer.m_pOleInPlaceActiveObject)
			invoke vf([ebx].CContainer.m_pOleInPlaceActiveObject, IOleInPlaceActiveObject, OnFrameWindowActivate), 0
		.endif
		mov g_hwndActive, NULL
	.else
		mov eax, hwnd
		mov g_hwndActive, eax
		.if (ebx && [ebx].CContainer.m_pOleInPlaceActiveObject)
			invoke vf([ebx].CContainer.m_pOleInPlaceActiveObject, IOleInPlaceActiveObject, OnFrameWindowActivate), 1
		.endif
		invoke GetWindowLong, hwnd, WO_FOCUS
		.if ( eax )
			invoke SetFocus, eax
		.endif
	.endif
	ret
	align 4

OnActivate endp

;--- navigate to an URL

Navigate proc hwnd:HWND, pszUrl:ptr WORD

LOCAL bstrURL:BSTR
LOCAL vtEmpty:VARIANT 
LOCAL pWebBrowser:LPWEBBROWSER

;--- Convert the navigation URL to a BSTR
	invoke SysAllocString, pszUrl
	mov bstrURL, eax

	invoke VariantInit, addr vtEmpty

;--- Navigate to the URL
	invoke GetWindowLong, hwnd, WO_CONTAINER
	mov ecx, eax
	invoke vf( [ecx].CContainer.m_pOleObject, IUnknown, QueryInterface ), addr IID_IWebBrowser2, addr pWebBrowser
	DebugOut "Navigate: QueryInterface(IID_IWebBrowser2)=%X", eax
	.if ( eax == S_OK )
		invoke vf( pWebBrowser, IWebBrowser2, Navigate), bstrURL, addr vtEmpty, addr vtEmpty, addr vtEmpty, addr vtEmpty
		DebugOut "Navigate: IWebBrowser2::Navigate(%S)=%X", bstrURL, eax
		invoke vf( pWebBrowser, IUnknown, Release )
	.endif
	invoke SysFreeString, bstrURL
	ret
	align 4

Navigate endp

;--- main window's WM_COMMAND

OnCommand proc hWnd:HWND, wParam:WPARAM, lParam:LPARAM

local hwndEdit:HWND

	DebugOut "OnCommand(%X, %X)", wParam, lParam
	movzx eax, word ptr wParam
	.if ( eax == IDOK )
		DebugOut "OnCommand: IDOK received"
		invoke GetWindowLong, hWnd, WO_URLEDIT
		mov hwndEdit, eax
		invoke GetWindowTextLength, eax
		.if ( eax )
			inc eax
			mov ecx, eax
			shl eax, 1
			add eax, 3
			and al,0FCh
			push ebx
			mov ebx, esp
			sub esp, eax
			mov edx, esp
			invoke GetWindowTextW, hwndEdit, edx, ecx
			invoke Navigate, hWnd, esp
			mov esp, ebx
			pop ebx
		.endif

	.endif
	ret
	align 4

OnCommand endp

;*** the main window proc

WndProc proc hWnd:HWND, uMsg:DWORD, wParam:WPARAM, lParam:LPARAM

	mov eax,uMsg

	.if (eax == WM_CREATE)
		inc g_count

	.elseif (eax == WM_SIZE)
		invoke OnSize, hWnd, wParam, lParam
		xor eax,eax

	.elseif (eax == WM_ACTIVATE)
		invoke OnActivate, hWnd, wParam

	.elseif (eax == WM_DESTROY)
		invoke GetWindowLong, hWnd, WO_CONTAINER
		.if (eax)
			invoke DestroyWBContainer, eax
		.endif
		dec g_count
		DebugOut "WndProc, WM_DESTROY: g_count=%u", g_count
		.if (ZERO?)
			invoke PostQuitMessage,NULL
		.endif
		xor eax,eax

	.elseif (eax == WM_COMMAND)
		invoke OnCommand, hWnd, wParam, lParam
		xor eax, eax

	.else
		invoke DefWindowProc,hWnd,uMsg,wParam,lParam
	.endif

	ret
	align 4

WndProc endp

if ADDRBAR

;--- create a Rebar control with an edit control in it.
;--- this becomes the "address bar".
;--- possible improvement: replace edit control by a combobox.

CreateRebar proc hInstance:HINSTANCE, hWnd:HWND

local hwndRebar:HWND
local hwndEdit:HWND
LOCAL rbbi:REBARBANDINFO

	DebugOut "CreateRebar(%X, %X) enter", hInstance, hWnd
	invoke CreateWindowEx, WS_EX_CONTROLPARENT or WS_EX_TOOLWINDOW, CStr("ReBarWindow32"), NULL,
			WS_CHILD or WS_VISIBLE or WS_CLIPCHILDREN or WS_CLIPSIBLINGS or CCS_TOP or CCS_NODIVIDER or RBS_BANDBORDERS or RBS_VARHEIGHT,
			0,0,0,0, hWnd, IDC_REBAR, hInstance, NULL
	mov hwndRebar, eax

	invoke CreateWindowEx, WS_EX_CLIENTEDGE, CStr("edit"), NULL,
			WS_CHILD or WS_VISIBLE or WS_TABSTOP or ES_LEFT or ES_AUTOHSCROLL,
			0,0,0,0, hWnd, IDC_URLEDIT, hInstance, NULL
	mov hwndEdit, eax

;--- change the edit control's default font, which is too large.
	invoke SendMessage, hwndRebar, WM_GETFONT, 0, 0
	invoke SendMessage, hwndEdit, WM_SETFONT, eax, 0

	mov rbbi.cbSize,SIZEOF REBARBANDINFO
	mov rbbi.fMask,RBBIM_CHILD or RBBIM_ID or RBBIM_SIZE or RBBIM_STYLE or RBBIM_CHILDSIZE or RBBIM_TEXT
	mov rbbi.lpText, CStr("Address")
	mov eax, hwndEdit
	mov rbbi.hwndChild,eax
	mov rbbi.fStyle, RBBS_GRIPPERALWAYS + RBBS_CHILDEDGE
	mov rbbi.cx_,100
	mov rbbi.cxMinChild,100
	mov rbbi.cyChild,24
	mov rbbi.cyMinChild,24
	mov rbbi.wID,IDC_BAND1
	invoke SendMessage, hwndRebar, RB_INSERTBAND, -1, addr rbbi
	DebugOut "CreateRebar() exit"
	mov eax, hwndEdit
	ret
	align 4

CreateRebar endp

endif

OnVisible proc public hwnd:HWND, bVisible:dword, iCmdShow:DWORD

LOCAL rcClient:RECT

	.if ( bVisible )
		invoke GetControlRect, hwnd, addr rcClient
		invoke GetWindowLong, hwnd, WO_CONTAINER
		mov ecx, eax
		;--- activate the webbrowser control
		invoke vf([ecx].CContainer.m_pOleObject, IOleObject, DoVerb),
			OLEIVERB_PRIMARY, NULL, addr [ecx].CContainer._IOleClientSite, 0, hwnd, addr rcClient
		DebugOut "OnVisible: IOleObject::DoVerb(OLEIVERB_PRIMARY)=%X", eax
		.IF FAILED(eax)
			invoke MessageBox, hwnd, CStr("IOleObject::DoVerb() failed"), 0, MB_OK
		.endif
	.endif

;--- call ShowWindow AFTER the control is activated!
;--- if it is done BEFORE, the focus isn't set correctly.

	invoke ShowWindow, hwnd, iCmdShow
	ret
OnVisible endp

;--- open a browser window

NewWindow proc public uses ebx pszUrl:ptr WORD, dwFlags:DWORD, iCmdShow:dword, 

local hInst:HINSTANCE
local hwndControl:HWND
LOCAL pOleWindow:LPOLEWINDOW

	DebugOut "NewWindow(%X, %X, %X) enter", pszUrl, dwFlags, iCmdShow
	invoke GetModuleHandle, NULL
	mov hInst, eax
	invoke CreateWindowEx,WS_EX_LEFT, ADDR szClassName,
			CStr("Jie"), WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
			NULL, NULL, eax, NULL
	and eax, eax
	jz exit
	mov ebx, eax

;--- create a status line window

	invoke CreateWindowEx, 0, CStr("msctls_statusbar32"), NULL,
				WS_CHILD or WS_VISIBLE or SBARS_SIZEGRIP or CCS_BOTTOM,
				0,0,0,0, ebx, IDC_STATUSBAR, hInst, NULL

if ADDRBAR
;--- create a rebar which contains an URL edit control
	invoke CreateRebar, hInst, ebx
	invoke SetWindowLong, ebx, WO_URLEDIT, eax
endif

	invoke CreateWBContainer, ebx, dwFlags
	invoke SetWindowLong, ebx, WO_CONTAINER, eax

	.if ( dwFlags & COF_VISIBLE )
		invoke OnVisible, ebx, TRUE, iCmdShow
	.endif

	.if ( pszUrl )
		invoke Navigate, ebx, pszUrl
	.endif
	mov eax, ebx
exit:
	DebugOut "NewWindow exit, eax=%X", eax
	ret
	align 4

NewWindow endp

;--- handle cmdline options

CmdlineOption proc pszOption:ptr WORD, pflags:ptr DWORD
if ?IEAPP
	invoke lstrcmpW, pszOption, addr wszEmbedding
	.if (!eax)
		mov edx, pflags
		or byte ptr [edx], JF_EMBEDDING
	.endif
endif
	ret
	align 4

CmdlineOption endp

;--- register the window class
;--- 3 items are stored in the window extra space
;--- +0: container object
;--- +4: hwnd of IDC_URLEDIT
;--- +8: hwnd of child which has the focus

InitApp proc hInstance:HINSTANCE

local szPath[260]:BYTE
LOCAL wc:WNDCLASSEX

	invoke GetModuleHandle, CStr("shell32")
	invoke LoadIcon, eax, 14
	mov wc.hIcon, eax
	mov wc.hIconSm, eax

	invoke LoadCursor,NULL,IDC_ARROW
	mov wc.hCursor, eax

	mov wc.cbSize, sizeof WNDCLASSEX
	mov wc.style, 0
	mov wc.lpfnWndProc, offset WndProc
	mov wc.cbClsExtra, 0
	mov wc.cbWndExtra, WNDEXSPACE
	mov eax, hInstance
	mov wc.hInstance, eax
	mov wc.hbrBackground, COLOR_WINDOW + 1
	mov wc.lpszMenuName, NULL
	mov wc.lpszClassName, offset szClassName

	invoke RegisterClassEx, ADDR wc

	ret
	align 4

InitApp endp

WinMain proc hInst:HINSTANCE, hPrevInst:HINSTANCE, lpszCmdLine:LPSTR, iCmdShow:dword

local ics:INITCOMMONCONTROLSEX
local hwndMain:HWND
local argc:dword
local dwFlags:dword
local dwRegister:dword
local pUnknown:LPUNKNOWN
LOCAL msg:MSG

	xor eax, eax
	mov msg.wParam, eax
	mov dwFlags, eax

	DebugOut "WinMain: initializing"
	mov ics.dwSize,sizeof ics
	mov ics.dwICC, ICC_COOL_CLASSES or ICC_BAR_CLASSES
	invoke InitCommonControlsEx, addr ics

;--- use OleInitialize() for clipboard support
	invoke OleInitialize, NULL

	invoke InitApp, hInst

	invoke CommandLineToArgvW, lpszCmdLine, addr argc
	mov esi, eax
	mov ebx, offset wszDefaultUrl
	mov ecx, argc
	lodsd		;skip first argument
	dec ecx
	.while ( ecx )
		lodsd
		DebugOut "WinMain: cmdline argument: %S", eax
		.if word ptr [eax] != '-' && word ptr [eax] != '/'
			mov ebx, eax
			.break
		.else
			push ecx
			add eax, 2
			lea edx, dwFlags
			invoke CmdlineOption, eax, edx
			pop ecx
		.endif
		dec ecx
	.endw

if ?IEAPP
	.if ( dwFlags & JF_EMBEDDING )
		;--- register the IE application
		invoke Create@ClassFactory
		.if (eax)
			mov pUnknown, eax
			invoke CoRegisterClassObject, offset CLSID_InternetExplorer, pUnknown,
				CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE, addr dwRegister
			DebugOut "WinMain: CoRegisterClassObject()=%X", eax
			invoke vf(pUnknown, IUnknown, Release)
			mov eax, 1
		.endif
	.else
endif
		;--- create main window
		invoke NewWindow, ebx, COF_VISIBLE, iCmdShow
if ?IEAPP
	.endif
endif
	and eax, eax
	jz exit

	.while (1)
		invoke GetMessage,ADDR msg, NULL, 0, 0
		.break .if (eax == 0)
if ADDRBAR
		invoke GetWindowLong, g_hwndActive, WO_URLEDIT
		.if ( eax != msg.hwnd )
endif
			invoke GetWindowLong, g_hwndActive, WO_CONTAINER
			mov ecx, eax
			.if (ecx && [ecx].CContainer.m_pOleInPlaceActiveObject )
				invoke vf([ecx].CContainer.m_pOleInPlaceActiveObject, IOleInPlaceActiveObject, TranslateAccelerator_), addr msg
				.continue .if (eax == S_OK)
			.endif
if ADDRBAR
		.endif
endif
		invoke IsDialogMessage, g_hwndActive, ADDR msg
		.continue .if eax
		invoke TranslateMessage, ADDR msg
		invoke DispatchMessage,  ADDR msg
	.endw
exit:
	DebugOut "WinMain: terminating"
if ?IEAPP
	.if ( dwFlags & JF_EMBEDDING )
		invoke CoRevokeClassObject, dwRegister
		DebugOut "WinMain: CoRevokeClassObject()=%X", eax
	.endif
endif
	invoke OleUninitialize
	mov eax, msg.wParam
	ret
	align 4

WinMain endp


start proc public

	invoke GetModuleHandle, NULL
	push eax
	invoke GetCommandLineW
	pop ecx
	invoke WinMain, ecx, 0, eax, SW_SHOWDEFAULT

	invoke ExitProcess,eax

start endp

	end start

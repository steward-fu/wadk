
;--- IOleWindow, IOleInPlaceUIWindow and IOleInPlaceFrame implementation

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

GetControlRect proto :HWND, :ptr RECT
SetSBText proto :HWND, :ptr WORD

	.const

;*** vtbl of interface IOleInPlaceFrame

CContainer@IOleInPlaceFrameVtbl label IOleInPlaceFrameVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd @GetWindow_
	dd ContextSensitiveHelp
	dd @GetBorder
	dd RequestBorderSpace
	dd SetBorderSpace
	dd @SetActiveObject
	dd InsertMenus
	dd @SetMenu_
	dd RemoveMenus
	dd @SetStatusText
	dd EnableModeless
	dd TranslateAccelerator_

	.code

CastOffset textequ <CContainer._IOleInPlaceFrame>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

;-------------------------------------------------
;IOleWindow methods
;-------------------------------------------------

;*** IOleWindow::GetWindow

@GetWindow_:AdjustThis
GetWindow_ proc uses ebx this_:ptr CContainer, phwnd:ptr HWND

	DebugOut "IOleInPlaceFrame::GetWindow(%X)", phwnd
	mov ebx, this_
	mov eax, phwnd
	mov ecx, [ebx].CContainer.m_hwndSite
	mov [eax], ecx
	return S_OK
	align 4

GetWindow_ endp

;*** IOleWindow::ContextSensitiveHelp

ContextSensitiveHelp proc this_:ptr CContainer, fEnterMode:BYTE

	DebugOut "IOleInPlaceFrame::ContextSensitiveHelp(%X)", fEnterMode
	return E_NOTIMPL
	align 4

ContextSensitiveHelp endp

;-------------------------------------------------
;IOleInPlaceUIWindow methods
;-------------------------------------------------

@GetBorder:AdjustThis
GetBorder proc this_:ptr CContainer, lprectBorder:ptr RECT

	DebugOut "IOleInPlaceUIWindow::GetBorder(%X)", lprectBorder
	mov ecx, this_
	invoke GetControlRect, [ecx].CContainer.m_hwndSite, lprectBorder
	return S_OK
	align 4

GetBorder endp

RequestBorderSpace proc this_:ptr CContainer, pborderwidths:ptr BORDERWIDTHS

	DebugOut "IOleInPlaceUIWindow::RequestBorderSpace"
	return INPLACE_E_NOTOOLSPACE
	align 4

RequestBorderSpace endp

SetBorderSpace proc this_:ptr CContainer, pborderwidths:ptr BORDERWIDTHS

	DebugOut "IOleInPlaceUIWindow::SetBorderSpace"
	return S_OK

SetBorderSpace endp

@SetActiveObject: AdjustThis
SetActiveObject proc uses ebx this_:ptr CContainer, pActiveObject:LPOLEINPLACEACTIVEOBJECT, pszObjName:ptr WORD

	DebugOut "IOleInPlaceUIWindow::SetActiveObject(%X,%X)", pActiveObject, pszObjName
	mov ebx, this_
	.if ([ebx].CContainer.m_pOleInPlaceActiveObject )
		invoke vf( [ebx].CContainer.m_pOleInPlaceActiveObject, IUnknown, Release )
		mov [ebx].CContainer.m_pOleInPlaceActiveObject,NULL
	.endif
	mov eax, pActiveObject
	mov [ebx].CContainer.m_pOleInPlaceActiveObject, eax
	.if ( eax != NULL)
		invoke vf( eax, IUnknown, AddRef)
	.endif
	return S_OK
	align 4

SetActiveObject endp

;-------------------------------------------------
;IOleInPlaceFrame methods
;-------------------------------------------------

InsertMenus proc this_:ptr CContainer, hmenuShared:HMENU, lpMenuWidths:ptr OLEMENUGROUPWIDTHS

	DebugOut "IOleInPlaceFrame::InsertMenus(%X, %X)", hmenuShared, lpMenuWidths
	return E_NOTIMPL
	align 4

InsertMenus endp

@SetMenu_: AdjustThis
SetMenu_ proc this_:ptr CContainer, hmenuShared:HMENU, holemenu:HANDLE, hwndActiveObject:HWND

	DebugOut "IOleInPlaceFrame::SetMenu(%X, %X, %X)", hmenuShared, holemenu, hwndActiveObject
	mov ecx, this_
	mov eax, hwndActiveObject
	mov [ecx].CContainer.m_hwndObject, eax
	return S_OK
	align 4

SetMenu_ endp

RemoveMenus proc this_:ptr CContainer, hmenuShared:HMENU

	DebugOut "IOleInPlaceFrame::RemoveMenus(%X)", hmenuShared
	return E_NOTIMPL
	align 4

RemoveMenus endp

;*** IOleInPlaceFrame::SetStatusText

@SetStatusText: AdjustThis
SetStatusText proc this_:ptr CContainer, pszStatusText:ptr WORD

ifdef _DEBUG
	.if pszStatusText
		DebugOut "IOleInPlaceFrame::SetStatusText('%S')", pszStatusText
	.else
		DebugOut "IOleInPlaceFrame::SetStatusText(%X)", pszStatusText
	.endif
endif
	mov ecx, this_
	invoke SetSBText, [ecx].CContainer.m_hwndSite, pszStatusText
	return S_OK
	align 4

SetStatusText endp

EnableModeless proc this_:ptr CContainer, fEnable:DWORD

	DebugOut "IOleInPlaceFrame::EnableModeless(%u)", fEnable
	return S_OK
	align 4

EnableModeless endp

;*** IOleInPlaceFrame::TranslateAccelerator

TranslateAccelerator_ proc this_:ptr CContainer, lpmsg:ptr MSG, wID:WORD

	DebugOut "IOleInPlaceFrame::TranslateAccelerator(%X, %X)", lpmsg, wID
	return S_FALSE
	align 4

TranslateAccelerator_ endp

	end

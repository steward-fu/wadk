
;--- IOleContainer (+ ITargetContainer) interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc
	include shlguid.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

if ?IOC

	.const

;*** vtbl IOleContainer

CContainer@IOleContainerVtbl label IOleContainerVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd ParseDisplayName
	dd EnumObjects_
	dd LockContainer

	.code

; -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CastOffset textequ <CContainer._IOleContainer>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

;--- IParseDisplayName interface methods

ParseDisplayName proc this_:ptr CContainer, pbc:ptr IBindCtx, pszDisplayName:LPOLESTR, pchEaten:ptr DWORD, ppmkOut:ptr LPMONIKER

	DebugOut "IOleContainer::ParseDisplayName(%X, %S, %X, %X)", pbc, pszDisplayName, pchEaten, ppmkOut
	mov ecx, ppmkOut
	mov dword ptr [ecx],0
	return E_NOTIMPL
	align 4

ParseDisplayName endp

;--- IOleContainer interface methods

EnumObjects_ proc this_:ptr CContainer, grfFlags:DWORD, ppEnum:ptr LPENUMUNKNOWN

	DebugOut "IOleContainer::EnumObjects(%X, %X)", grfFlags, ppEnum
	mov ecx, ppEnum
	mov dword ptr [ecx],0
	return E_NOTIMPL
	align 4

EnumObjects_ endp

LockContainer proc this_:ptr CContainer, fLock:BOOL

	DebugOut "IOleContainer::LockContainer(%X)", fLock
	return S_OK
	align 4

LockContainer endp

;--- ITargetContainer interface

	.const
	
;*** vtbl ITargetContainer

CContainer@ITargetContainerVtbl label ITargetContainerVtbl
	IUnknownVtbl {QueryInterface@ITargetContainer, AddRef@ITargetContainer, Release@ITargetContainer}
	dd GetFrameUrl
	dd @GetFramesContainer

	.code

CastOffset textequ <CContainer._ITargetContainer>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface@ITargetContainer:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef@ITargetContainer:
	AdjustThis
	jmp AddRef
	align 4
Release@ITargetContainer:
	AdjustThis
	jmp Release
	align 4

GetFrameUrl proc this_:ptr CContainer, ppszFrameUrl:ptr LPWSTR

	DebugOut "ITargetContainer::GetFrameUrl(%X)", ppszFrameUrl
	return E_NOTIMPL
	align 4

GetFrameUrl endp

@GetFramesContainer: AdjustThis
GetFramesContainer proc this_:ptr CContainer, ppContainer

	DebugOut "ITargetContainer::GetFramesContainer(%X)", ppContainer
	mov eax, this_
	lea edx, [eax].CContainer._IOleContainer
	mov ecx, ppContainer
	inc [eax].CContainer.m_RefCnt
	mov dword ptr [ecx], edx
	return S_OK
	align 4

GetFramesContainer endp

endif

	end


;--- implementation of IUnknown interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

ifndef ?DBGEXT
?DBGEXT	equ 1	;1=log QueryInterface/AddRef/Release
endif

	.code

;--- table of interfaces implemented by the web browser container

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IOleWindow,        CContainer._IOleInPlaceSite
	dd offset IID_IOleInPlaceSite,   CContainer._IOleInPlaceSite
	dd offset IID_IOleInPlaceFrame,  CContainer._IOleInPlaceFrame
	dd offset IID_IOleClientSite,    CContainer._IOleClientSite
	dd offset IID_IOleControlSite,   CContainer._IOleControlSite
if ?IOC
	dd offset IID_IOleContainer,     CContainer._IOleContainer
	dd offset IID_ITargetContainer,  CContainer._ITargetContainer
endif
	dd offset IID_IOleCommandTarget, CContainer._IOleCommandTarget
	dd offset IID_IDispatch,         CContainer._IDispatch
	dd offset IID_IDocHostUIHandler, CContainer._IDocHostUIHandler
	dd offset IID_IDocHostShowUI,    CContainer._IDocHostShowUI
if ?ISP
	dd offset IID_IServiceProvider, CContainer._IServiceProvider
endif
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

;*** scan interface tab and see if requested interface is in there
;*** return valid ptr or NULL

IsInterfaceSupported proc public uses ebx esi edi pReqIF:ptr IID, pIFTab:ptr ptr IID, dwEntries:dword, pThis:ptr, ppReturn:ptr LPUNKNOWN
	
	mov ecx,dwEntries
	mov esi,pIFTab
	mov ebx,0
	.while (ecx)
		lodsd
		mov edi,eax
		lodsd
		mov edx,eax
		mov eax,esi
		mov esi,pReqIF
		push ecx
		mov ecx,4
		repz cmpsd
		pop ecx
		.if (ZERO?)
			mov ebx,edx
			add ebx,pThis
			.break
		.endif
		mov esi,eax
		dec ecx
	.endw
	mov ecx,ppReturn
	mov [ecx],ebx

	.if (ebx)
		invoke vf(ebx,IUnknown,AddRef)
		mov eax,S_OK
	.else
		mov eax,E_NOINTERFACE
	.endif
	ret
	align 4

IsInterfaceSupported endp

QueryInterface proc public pThis:ptr CContainer, riid:ptr IID, ppReturn:ptr ptr

ifdef _DEBUG
if ?DBGEXT
local	wszIID[40]:word
endif
endif

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn

ifdef _DEBUG
if ?DBGEXT
    push eax
	invoke StringFromGUID2,riid, addr wszIID,40
    pop eax
	DebugOut "IUnknown::QueryInterface(%S)=%X", addr wszIID, eax
endif
endif

	ret
	align 4

QueryInterface endp

AddRef proc public pThis:ptr CContainer

	mov eax,pThis
	inc [eax].CContainer.m_RefCnt

if ?DBGEXT
	DebugOut "IUnknown::AddRef Count=%u", [eax].CContainer.m_RefCnt
endif

	mov eax, [eax].CContainer.m_RefCnt
	ret
	align 4

AddRef endp

Release proc public pThis:ptr CContainer

	mov eax,pThis
	dec [eax].CContainer.m_RefCnt

if ?DBGEXT
	DebugOut "IUnknown::Release Count=%u", [eax].CContainer.m_RefCnt
endif

	mov eax,[eax].CContainer.m_RefCnt
	.if (eax == 0)
		invoke DestroyWBContainer, pThis
		xor eax,eax
	.endif
	ret
	align 4

Release endp

	end

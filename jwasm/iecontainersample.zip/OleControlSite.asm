
;--- IOleControlSite implementation
;--- currently virtually unused.

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl of interface IOleControlSite

CContainer@IOleControlSiteVtbl label IOleControlSiteVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd OnControlInfoChanged
	dd LockInPlaceActive
	dd GetExtendedControl
	dd TransformCoords
	dd TranslateAccelerator_
	dd @OnFocus
	dd ShowPropertyFrame

	.code

CastOffset textequ <CContainer._IOleControlSite>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

;-------------------------------------------------
;IOleControlSite interface
;-------------------------------------------------

OnControlInfoChanged proc this_:ptr CContainer

	DebugOut "IOleInPlaceFrame::OnControlInfoChanged"
	return S_OK
	align 4

OnControlInfoChanged endp


LockInPlaceActive proc this_:ptr CContainer, fLock:BOOL

	DebugOut "IOleInPlaceFrame::LockInPlaceActive"
	return E_NOTIMPL
	align 4

LockInPlaceActive endp


GetExtendedControl proc this_:ptr CContainer, ppDisp:ptr LPDISPATCH

	DebugOut "IOleControlSite::GetExtendedControl(%X)", ppDisp
	mov eax,ppDisp
	mov dword ptr [eax],NULL
	return E_NOTIMPL
	align 4

GetExtendedControl endp


TransformCoords proc this_:ptr CContainer, pPtlHimetric:ptr POINTL, pPtfContainer:ptr POINTF, dwFlags:DWORD

	DebugOut "IOleControlSite::TransformCoords(%X, %X, %X)", pPtlHimetric, pPtfContainer, dwFlags
	return E_NOTIMPL
	align 4

TransformCoords endp


TranslateAccelerator_ proc this_:ptr CContainer, lpMsg:ptr MSG, grfModifiers:DWORD

	DebugOut "IOleControlSite::TranslateAccelerator(%X,%X)", lpMsg, grfModifiers
	return S_FALSE
	align 4

TranslateAccelerator_ endp

@OnFocus: AdjustThis
OnFocus proc this_:ptr CContainer, fGotFocus:BOOL

	DebugOut "IOleControlSite::OnFocus(%u)", fGotFocus
	mov ecx, this_
	mov eax, fGotFocus
	mov [ecx].CContainer.m_bFocus, al
	return S_OK
	align 4

OnFocus endp

;*** IOleControlSite::ShowPropertyFrame
;*** return NOT_IMPL to let control show properties itself

ShowPropertyFrame proc this_:ptr CContainer

	DebugOut "IOleControlSite::ShowPropertyFrame"
	return E_NOTIMPL
	align 4

ShowPropertyFrame endp

	end

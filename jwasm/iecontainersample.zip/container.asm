
;--- create and destroy CContainer object

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc
	.list
	.cref

	include container.inc
	include macros.inc
	include debugout.inc

Create@CEvent proto :HWND

	.const

;--- the GUIDs "should" all be contained in UUID.LIB

CLSID_WebBrowser GUID <08856F961h, 340Ah, 11D0h, <0A9h, 06Bh, 00h, 0C0h, 04Fh, 0D7h, 005h, 0A2h>>
IID_IWebBrowser2 IID  <0D30C1661h,0CDAFh, 11d0h, <08Ah, 03Eh, 00h, 0C0h, 04Fh, 0C9h, 0E2h, 06Eh>>
DIID_DWebBrowserEvents2 IID <034A715A0h, 06587h, 011D0h, <092h, 04Ah, 000h, 020h, 0AFh, 0C7h, 0ACh, 04Dh>>

wszHost dw L("jie"),0
wszDoc  dw L("unnamed"),0

; --------------------------------------------------------------------------------------

	.code

if ?IEAPP

CHelper struct
_IUnknown IUnknown <>
m_RefCnt dd ?
m_pObject dd ?	;inner object
CHelper ends

CreateCHelper proc
	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CHelper
	.if (eax == NULL)
		DebugOut "CreateCHelper: LocalAlloc failed!!!"
		ret
	.endif
	mov [eax].CHelper._IUnknown, offset CHelper@IUnknownVtbl
	mov [eax].CHelper.m_RefCnt, 1
	ret
	align 4
CreateCHelper endp

	.const

CHelper@IUnknownVtbl IUnknownVtbl {QueryInterface@CHelper,
	AddRef@CHelper, Release@CHelper }

	.code

QueryInterface@CHelper PROC this_:ptr CHelper, riid:ptr IID, ppReturn:ptr LPUNKNOWN

ifdef _DEBUG
local	wszIID[40]:word
endif

if 1
	invoke IsEqualGUID, riid, addr IID_IOleObject
	.if ( eax )
		DebugOut "CHelper::QueryInterface(IID_IOleObject) returns E_NOINTERFACE"
		mov ecx, ppReturn
		mov dword ptr [ecx], NULL
		return E_NOINTERFACE
	.endif
endif
	mov ecx, this_
	invoke vf( [ecx].CHelper.m_pObject, IUnknown, QueryInterface ), riid, ppReturn
ifdef _DEBUG
    push eax
	invoke StringFromGUID2, riid, addr wszIID, 40
    pop eax
	DebugOut "CHelper::QueryInterface(%S)=%X", addr wszIID, eax
endif
	ret
	align 4
QueryInterface@CHelper endp

AddRef@CHelper PROC this_:ptr CHelper

	mov eax, this_
	inc [eax].CHelper.m_RefCnt
	invoke vf([eax].CHelper.m_pObject, IUnknown, AddRef )
	DebugOut "CHelper::AddRef returns %u", eax
	ret
	align 4

AddRef@CHelper ENDP

Release@CHelper PROC this_:ptr CHelper

	mov eax, this_
	dec [eax].CHelper.m_RefCnt
	pushfd
	invoke vf([eax].CHelper.m_pObject, IUnknown, Release )
	popfd
	.if (ZERO?)
		invoke LocalFree, this_
		xor eax,eax
	.endif
	DebugOut "CHelper::Release returns %u", eax
	ret
	align 4

Release@CHelper ENDP

endif

;*** create web browser container

CreateWBContainer proc public uses ebx hWndParent:HWND, dwFlags:DWORD

LOCAL pCPC:LPCONNECTIONPOINTCONTAINER
ifdef _DEBUG
LOCAL pThis:ptr CContainer
LOCAL pApp:LPDISPATCH
LOCAL pWebBrowser:LPWEBBROWSER
LOCAL dwStatus:DWORD
endif

	DebugOut "CreateWBContainer(%X, %X) enter", hWndParent, dwFlags

; ----------------- allocate object
	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CContainer
	.if (eax == NULL)
		DebugOut "CreateWBContainer: LocalAlloc failed!!!"
		ret
	.endif
	DebugOut "CreateWBContainer: container object=%X", eax

	mov ebx, eax
	assume ebx:ptr CContainer
ifdef DEBUG
	mov pThis,eax
endif

	mov [ebx]._IOleInPlaceSite,   offset CContainer@IOleInPlaceSiteVtbl
	mov [ebx]._IOleInPlaceFrame,  offset CContainer@IOleInPlaceFrameVtbl
	mov [ebx]._IOleClientSite,    offset CContainer@IOleClientSiteVtbl
	mov [ebx]._IOleControlSite,   offset CContainer@IOleControlSiteVtbl
if ?IOC
	mov [ebx]._IOleContainer,     offset CContainer@IOleContainerVtbl
	mov [ebx]._ITargetContainer,  offset CContainer@ITargetContainerVtbl
endif
	mov [ebx]._IOleCommandTarget, offset CContainer@IOleCommandTargetVtbl
	mov [ebx]._IDispatch,         offset CContainer@IDispatchVtbl
	mov [ebx]._IDocHostUIHandler, offset CContainer@IDocHostUIHandlerVtbl
	mov [ebx]._IDocHostShowUI,    offset CContainer@IDocHostShowUIVtbl
if ?ISP
	mov [ebx]._IServiceProvider,  offset CContainer@IServiceProviderVtbl
endif

	mov [ebx].m_RefCnt, 1

	mov eax, hWndParent
	mov [ebx].m_hwndSite,eax
;--- Create an instance of the Control (WebBrowser)
if ?IEAPP
	.if ( dwFlags & COF_AGGREGATE )
		invoke CreateCHelper
		DebugOut "CreateWBContainer: CreateCHelper()=%X", eax
		mov ecx, eax
		push ecx
		invoke CoCreateInstance, ADDR CLSID_WebBrowser, ecx,
			CLSCTX_INPROC_SERVER or CLSCTX_INPROC_HANDLER, ADDR IID_IUnknown,
			ADDR [ebx].m_pUnknown
		pop ecx
		.IF FAILED(eax)
			mov eax, CStr("CoCreateInstance of WebBrowser object failed")
			jmp error
		.ENDIF
		mov eax, [ebx].m_pUnknown
		mov [ecx].CHelper.m_pObject, eax
		invoke vf( [ebx].m_pUnknown, IUnknown, QueryInterface ), addr IID_IOleObject, addr [ebx].m_pOleObject
	.else
endif
		invoke CoCreateInstance, ADDR CLSID_WebBrowser, NULL,
			CLSCTX_INPROC_SERVER or CLSCTX_INPROC_HANDLER, ADDR IID_IOleObject,
			ADDR [ebx].m_pOleObject
		DebugOut "CreateWBContainer: CoCreateInstance(CLSID_WebBrowser)=%X [%X]", eax, [ebx].m_pOleObject
		.IF FAILED(eax)
			mov eax, CStr("CoCreateInstance of WebBrowser object failed")
			jmp error
		.ENDIF
if ?IEAPP
	.endif
endif

;--- Set the Control's clientsite
	invoke vf([ebx].m_pOleObject, IOleObject, SetClientSite), addr [ebx]._IOleClientSite
	DebugOut "CreateWBContainer: IOleObject::SetClientSite()=%X", eax
	.IF FAILED(eax)
		mov eax, CStr("SetClientSite failed")
		jmp error
	.ENDIF

ifdef _DEBUG
	invoke vf([ebx].m_pOleObject, IOleObject, GetMiscStatus), DVASPECT_CONTENT, addr dwStatus
	DebugOut "CreateWBContainer: IOleObject::GetMiscStatus()=%X [%X]", eax, dwStatus
endif
	invoke vf([ebx].m_pOleObject, IOleObject, SetHostNames), addr wszHost, addr wszDoc
	DebugOut "CreateWBContainer: IOleObject::SetHostNames()=%X", eax

	invoke vf([ebx].m_pOleObject,IOleObject,QueryInterface), addr IID_IConnectionPointContainer,addr pCPC
	DebugOut "CreateWBContainer: IOleObject::QueryInterface(IConnectionPointContainer)=%X", eax
	.if (eax == S_OK)
		invoke vf( pCPC, IConnectionPointContainer, FindConnectionPoint), addr DIID_DWebBrowserEvents2, addr [ebx].m_pConnectionPoint
		DebugOut "CreateWBContainer: IConnectionPointContainer::FindConnectionPoint(DIID_DWebBroserEvents2)=%X", eax
		.if ( eax == S_OK )
			invoke Create@CEvent, hWndParent
			mov ecx, eax
			invoke vf( [ebx].m_pConnectionPoint, IConnectionPoint, Advise ), ecx, addr [ebx].m_cookie
			DebugOut "CreateWBContainer: IConnectionPoint::Advise()=%X", eax
		.endif
		invoke vf( pCPC, IUnknown, Release)
	.endif

	DebugOut "CreateWBContainer exit"

	return ebx
error:
	invoke MessageBox, 0, eax, 0, MB_OK
	invoke DestroyWBContainer, ebx
	return 0
	assume ebx:nothing
	align 4

CreateWBContainer endp


DestroyWBContainer proc public uses ebx pThis: ptr CContainer

	mov ebx,pThis
	assume ebx: ptr CContainer

	DebugOut "DestroyWBContainer(%X) enter", ebx

	.if ([ebx].m_pConnectionPoint)
		.if ( [ebx].m_cookie )
			invoke vf( [ebx].m_pConnectionPoint, IConnectionPoint, Unadvise ), [ebx].m_cookie
			DebugOut "DestroyWBContainer: IConnectionPoint::Unadvise()=%X", eax
		.endif
		invoke vf([ebx].m_pConnectionPoint,IUnknown,Release)
		DebugOut "DestroyWBContainer: IConnectionPoint::Release()=%X", eax
		mov [ebx].m_pConnectionPoint,NULL
	.endif

	.if ([ebx].m_bInPlaceActive)
		invoke vf([ebx].m_pOleInPlaceObject,IOleInPlaceObject,InPlaceDeactivate)
		DebugOut "DestroyWBContainer: IOleInPlaceObject::InPlaceDeactivate()=%X", eax
	.endif
	.if ([ebx].m_pOleInPlaceActiveObject)
		invoke vf([ebx].m_pOleInPlaceActiveObject,IUnknown,Release)
		DebugOut "DestroyWBContainer: IOleInPlaceActiveObject::Release()=%X", eax
		mov [ebx].m_pOleInPlaceActiveObject,NULL
	.endif
	.if ([ebx].m_pOleInPlaceObject)
		invoke vf([ebx].m_pOleInPlaceObject,IUnknown,Release)
		DebugOut "DestroyWBContainer: IOleInPlaceObject::Release()=%X", eax
		mov [ebx].m_pOleInPlaceObject,NULL
	.endif

	.if ([ebx].m_pOleObject)
		invoke vf([ebx].m_pOleObject, IOleObject, Close), OLECLOSE_NOSAVE
		DebugOut "DestroyWBContainer: IOleObject::Close()=%X", eax
		invoke vf([ebx].m_pOleObject, IOleObject, SetClientSite), NULL
		DebugOut "DestroyWBContainer: IOleObject::SetClientSite(0) returned %X", eax
		invoke vf([ebx].m_pOleObject, IUnknown, Release)
		DebugOut "DestroyWBContainer: IOleObject::Release()=%X", eax
		mov [ebx].m_pOleObject,NULL
	.endif

	DebugOut "DestroyWBContainer: m_RefCnt=%X", [ebx].m_RefCnt
	invoke LocalFree, ebx
	DebugOut "DestroyWBContainer: LocalFree(%X)=%X", ebx, eax

	DebugOut "DestroyWBContainer(%X) exit", ebx

	ret
	assume ebx:nothing
	align 4

DestroyWBContainer endp

	end


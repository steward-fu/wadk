
;--- IServiceProvider interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc
	include shlguid.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

if ?ISP

ifndef ?ISPDBG
?ISPDBG equ 1
endif

	.const

;*** vtbl IServiceProvider

CContainer@IServiceProviderVtbl label IServiceProviderVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd @QueryService

	.code

; -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CastOffset textequ <offset CContainer._IServiceProvider>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

@QueryService: AdjustThis
QueryService proc this_:ptr CContainer, guidService:ptr GUID, riid:ptr IID, ppv: ptr ptr

ifdef _DEBUG
local wszIID1[40]:word
local wszIID2[40]:word
endif

if ?ISPDBG
ifdef _DEBUG
	invoke StringFromGUID2, guidService, addr wszIID1, 40
	invoke StringFromGUID2, riid, addr wszIID2, 40
	DebugOut "IServiceProvider::QueryService(%S, %S)", addr wszIID1, addr wszIID2
endif
	invoke IsEqualGUID, guidService, addr SID_STopLevelBrowser
	.if (eax)
		DebugOut "IServiceProvider::QueryService: SID_STopLevelBrowser"
		invoke vf(this_, IUnknown, QueryInterface), riid, ppv
		ret
	.endif
	invoke IsEqualGUID, guidService, addr SID_STopWindow
	.if (eax)
		DebugOut "IServiceProvider::QueryService: SID_STopWindow"
		invoke vf(this_, IUnknown, QueryInterface), riid, ppv
		ret
	.endif
if 0
	invoke IsEqualGUID, guidService, addr CLSID_ShellDesktop
	.if (eax)
		DebugOut "IServiceProvider::QueryService: CLSID_ShellDesktop"
		invoke vf(this_, IUnknown, QueryInterface), riid, ppv
		ret
	.endif
endif
endif
;--- the service is unknown, but the error code is still E_NOINTERFACE
	return E_NOINTERFACE

QueryService endp

endif

	end

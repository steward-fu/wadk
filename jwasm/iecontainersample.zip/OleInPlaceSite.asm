
;--- IOleWindow and IOleInPlaceSite interfaces

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

GetControlRect proto :HWND, :ptr RECT

	.const

;*** vtbl of interfaces IUnknown, IOleWindow, IOleInPlaceSite

CContainer@IOleInPlaceSiteVtbl label IOleInPlaceSiteVtbl
	IUnknownVtbl {QueryInterface, AddRef, Release}
	dd	offset GetWindow_
	dd	offset ContextSensitiveHelp
	dd	offset CanInPlaceActivate
	dd	offset OnInPlaceActivate
	dd	offset OnUIActivate
	dd	offset GetWindowContext
	dd	offset Scroll_
	dd	offset OnUIDeactivate
	dd	offset OnInPlaceDeactivate
	dd	offset DiscardUndoState
	dd	offset DeactivateAndUndo
	dd	offset OnPosRectChange

	.code

;-------------------------------------------------
;IOleWindow interface
;-------------------------------------------------

GetWindow_ proc pThis:ptr CContainer, phwnd:ptr HWND

	DebugOut "IOleWindow::GetWindow(%X)", phwnd
	mov edx, pThis
	mov eax, phwnd
	mov ecx,[edx].CContainer.m_hwndSite
	mov [eax], ecx
	return S_OK
	align 4

GetWindow_ endp

ContextSensitiveHelp proc pThis:ptr CContainer, fEnterMode:BYTE

	DebugOut "IOleWindow::ContextSensitiveHelp(%X)", fEnterMode
	return E_NOTIMPL
	align 4

ContextSensitiveHelp endp

;-------------------------------------------------
;IOleInPlaceSite interface
;-------------------------------------------------

;*** IOleInPlaceSite::CanInPlaceActivate

CanInPlaceActivate proc pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::CanInPlaceActivate"
	return S_OK
	align 4

CanInPlaceActivate endp

;*** IOleInPlaceSite::OnInPlaceActivate

OnInPlaceActivate proc uses ebx pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::OnInPlaceActivate"
	mov ebx,pThis
	mov [ebx].CContainer.m_bInPlaceActive, TRUE

	.if ( [ebx].CContainer.m_pOleInPlaceObject == NULL )
		invoke vf([ebx].CContainer.m_pOleObject, IUnknown, QueryInterface), addr IID_IOleInPlaceObject, addr [ebx].CContainer.m_pOleInPlaceObject
		DebugOut "IOleInPlaceSite: QueryInterface( IOleInPlaceObject )=%X", eax
	.endif

	return S_OK
	align 4

OnInPlaceActivate endp

;*** IOleInPlaceSite::OnUIActivate

OnUIActivate proc pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::OnUIActivate"
	return S_OK
	align 4

OnUIActivate endp

;*** IOleInPlaceSite::GetWindowContext

GetWindowContext proc uses ebx pThis:ptr CContainer, ppFrame:ptr LPOLEINPLACEFRAME,
			ppDoc:ptr LPOLEINPLACEUIWINDOW, lprcPosRect:ptr RECT,
			lprcClipRect:ptr RECT, lpFrameInfo:ptr OLEINPLACEFRAMEINFO

	DebugOut "IOleInPlaceSite::GetWindowContext(%X,%X,%X,%X,%X)", ppFrame, ppDoc, lprcPosRect, lprcClipRect, lpFrameInfo
	mov ebx,pThis

	mov ecx,ppFrame
	lea eax, [ebx].CContainer._IOleInPlaceFrame
	mov dword ptr [ecx],eax
	inc [ebx].CContainer.m_RefCnt

	mov eax,ppDoc
	mov dword ptr [eax],NULL

	invoke GetControlRect, [ebx].CContainer.m_hwndSite, lprcPosRect
	invoke GetControlRect, [ebx].CContainer.m_hwndSite, lprcClipRect

	mov eax,lpFrameInfo
	mov [eax].OLEINPLACEFRAMEINFO.fMDIApp,FALSE
	mov ecx, [ebx].CContainer.m_hwndSite
	mov [eax].OLEINPLACEFRAMEINFO.hwndFrame,ecx
	mov [eax].OLEINPLACEFRAMEINFO.haccel,NULL
	mov [eax].OLEINPLACEFRAMEINFO.cAccelEntries,0

	return S_OK
	align 4

GetWindowContext endp

;*** IOleInPlaceSite::Scroll

Scroll_ proc pThis:ptr CContainer, scrollExtent:SIZEL

	DebugOut "IOleInPlaceSite::Scroll(%X)", scrollExtent
	return S_FALSE
	align 4

Scroll_ endp

;*** IOleInPlaceSite::OnUIDeactivate

OnUIDeactivate proc pThis:ptr CContainer, fUndoable:DWORD

	DebugOut "IOleInPlaceSite::OnUIDeactivate(%X)", fUndoable
	return S_OK
	align 4

OnUIDeactivate endp

;*** IOleInPlaceSite::OnInPlaceDeactivate

OnInPlaceDeactivate proc uses ebx pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::OnInPlaceDeactivate"
	mov ebx,pThis
	mov [ebx].CContainer.m_bInPlaceActive, FALSE
	.IF ([ebx].CContainer.m_pOleInPlaceObject)
		invoke vf([ebx].CContainer.m_pOleInPlaceObject,IOleInPlaceObject,Release)
		mov [ebx].CContainer.m_pOleInPlaceObject, NULL
	.ENDIF
	return S_OK
	align 4

OnInPlaceDeactivate endp

;*** IOleInPlaceSite::DiscardUndoState

DiscardUndoState proc pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::DiscardUndoState"
	return S_OK
	align 4

DiscardUndoState endp

;*** IOleInPlaceSite::DeactivateAndUndo

DeactivateAndUndo proc pThis:ptr CContainer

	DebugOut "IOleInPlaceSite::DeactivateAndUndo"
	return S_OK
	align 4

DeactivateAndUndo endp

;*** IOleInPlaceSite::OnPosRectChange

OnPosRectChange proc pThis:ptr CContainer, lprcPosRect:ptr RECT

	DebugOut "IOleInPlaceSite::OnPosRectChange(%X)", lprcPosRect

	mov ecx,pThis
	.if ([ecx].CContainer.m_pOleInPlaceObject)
		invoke vf([ecx].CContainer.m_pOleInPlaceObject, IOleInPlaceObject, SetObjectRects), lprcPosRect, lprcPosRect
	.endif
	return S_OK
	align 4

OnPosRectChange endp

	end

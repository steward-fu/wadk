
;*** implements IDocHostUIHandler interface

	.486
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl IDocHostUIHandler

CContainer@IDocHostUIHandlerVtbl label IDocHostUIHandlerVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd ShowContextMenu
	dd GetHostInfo
	dd ShowUI
	dd HideUI
	dd UpdateUI
	dd EnableModeless
	dd OnDocWindowActivate
	dd OnFrameWindowActivate
	dd ResizeBorder
	dd TranslateAccelerator_
	dd GetOptionKeyPath
	dd GetDropTarget
	dd @GetExternal
	dd @TranslateUrl
	dd FilterDataObject

	.code

CastOffset textequ <CContainer._IDocHostUIHandler>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

ShowContextMenu proc pThis:ptr CContainer, dwID:DWORD, ppt:DWORD, pcmdtReserved:DWORD, pdispReserved:DWORD

	DebugOut "IDocHostUIHandler::ShowContextMenu(%X, %X, %X, %X)", dwID, ppt, pcmdtReserved, pdispReserved
	return S_FALSE	;means: host did not display its UI
	align 4

ShowContextMenu endp


GetHostInfo proc pThis:ptr CContainer, pInfo:ptr DOCHOSTUIINFO

	DebugOut "IDocHostUIHandler::GetHostInfo(%X)", pInfo
	mov eax,pInfo
	assume eax:ptr DOCHOSTUIINFO
	mov [eax].cbSize, sizeof DOCHOSTUIINFO

;--- optionally add DOCHOSTUIFLAG_OPENNEWWIN to open new window when a link is clicked

	mov [eax].dwFlags, DOCHOSTUIFLAG_DISABLE_HELP_MENU or DOCHOSTUIFLAG_FLAT_SCROLLBAR or \
		DOCHOSTUIFLAG_LOCAL_MACHINE_ACCESS_CHECK or DOCHOSTUIFLAG_DISABLE_UNTRUSTEDPROTOCOL
	mov [eax].dwDoubleClick, DOCHOSTUIDBLCLK_DEFAULT
;	mov [eax].pchHostCss, NULL
;	mov [eax].pchHostNS, NULL
	return S_OK
	assume eax:nothing
	align 4

GetHostInfo endp


ShowUI proc pThis:ptr CContainer, dwID:DWORD,
	pActiveObject:LPOLEINPLACEACTIVEOBJECT,
	pCommandTarget:LPOLECOMMANDTARGET,
	pFrame:LPOLEINPLACEFRAME,
	pDoc:LPOLEINPLACEUIWINDOW

	DebugOut "IDocHostUIHandler::ShowUI(%X, %X, %X, %X, %X)", dwID, pActiveObject, pCommandTarget, pFrame, pDoc
	return S_FALSE ;means: host won't display its user interface
	align 4

ShowUI endp


HideUI proc pThis:ptr CContainer

	DebugOut "IDocHostUIHandler::HideUI"
	return S_OK
	align 4

HideUI endp


UpdateUI proc uses ebx pThis:ptr CContainer

	DebugOut "IDocHostUIHandler::UpdateUI"
	return S_OK
	align 4

UpdateUI endp


EnableModeless proc pThis:ptr CContainer, fEnable:DWORD

	DebugOut "IDocHostUIHandler::EnableModeless(%u)", fEnable
	return S_OK
	align 4

EnableModeless endp


OnDocWindowActivate proc pThis:ptr CContainer, fActivate:BOOL

	DebugOut "IDocHostUIHandler::OnDocWindowActivate(%X)", fActivate
	return S_OK
	align 4

OnDocWindowActivate endp


OnFrameWindowActivate proc pThis:ptr CContainer, fActivate:BOOL

	DebugOut "IDocHostUIHandler::OnFrameWindowActivate(%X)", fActivate
	return S_OK
	align 4

OnFrameWindowActivate endp


ResizeBorder proc pThis:ptr CContainer, prcBorder:ptr RECT, pUIWindow:ptr, fFrameWindow:DWORD

	DebugOut "IDocHostUIHandler::ResizeBorder(%X, %X, %u)", prcBorder, pUIWindow, fFrameWindow
	return E_NOTIMPL
	align 4

ResizeBorder endp


TranslateAccelerator_ proc pThis:ptr CContainer, lpMsg:ptr MSG, pguidCmdGroup:ptr GUID, nCmdID:DWORD

	DebugOut "IDocHostUIHandler::TranslateAccelerator(%X,%X,%u)", lpMsg, pguidCmdGroup, nCmdID
	return S_FALSE
	align 4

TranslateAccelerator_ endp


GetOptionKeyPath proc pThis:ptr CContainer, pchKey:ptr LPOLESTR, dwReserved:DWORD

	DebugOut "IDocHostUIHandler::GetOptionKeyPath(%X, %X)", pchKey, dwReserved
	mov eax,pchKey
	mov dword ptr [eax], 0
	return S_FALSE
	align 4

GetOptionKeyPath endp


GetDropTarget proc pThis:ptr CContainer, pDropTarget:DWORD, ppDropTarget:DWORD

	DebugOut "IDocHostUIHandler::GetDropTarget"
	return E_NOTIMPL
	align 4

GetDropTarget endp

@GetExternal: AdjustThis
GetExternal proc pThis:ptr CContainer, ppDispatch:DWORD

	DebugOut "IDocHostUIHandler::GetExternal(%X)", ppDispatch
	mov ecx, pThis
	mov edx, ppDispatch
	lea eax, [ecx].CContainer._IDispatch
	mov [edx], eax
	inc [ecx].CContainer.m_RefCnt
	return S_OK
	align 4

GetExternal endp


@TranslateUrl: AdjustThis
TranslateUrl proc uses ebx pThis:ptr CContainer, dwTranslate:DWORD, pchURLIn:ptr WORD, ppchURLOut:ptr ptr WORD

	DebugOut "IDocHostUIHandler::TranslateUrl(%X, %S, %X)", dwTranslate, pchURLIn, ppchURLOut
	mov ecx, ppchURLOut
	mov dword ptr [ecx], NULL
	return S_FALSE	;url was not translated
	align 4

TranslateUrl endp


FilterDataObject proc pThis:ptr CContainer, pDO:ptr, ppDORet:ptr ptr

	DebugOut "IDocHostUIHandler::FilterDataObject(%X, %X)", pDO, ppDORet
	return S_FALSE   ;data object wasn't replaced
	align 4

FilterDataObject endp

	end


;--- implements containers's IDispatch interface.
;--- not to be confused with the event sink's IDispatch,
;--- which is implemented in eventobj.asm.

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include MsHtmHst.inc
	include ExDisp.inc
	include ExDispId.inc
	include idispids.inc
	include MsHtmDid.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl IDispatch

CContainer@IDispatchVtbl label IDispatchVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd GetTypeInfoCount
	dd GetTypeInfo
	dd GetIDsOfNames
	dd @Invoke_

	.code

CastOffset textequ <CContainer._IDispatch>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4


GetTypeInfoCount proc pThis:ptr CContainer, pctinfo:ptr DWORD

	DebugOut "IDispatch::GetTypeInfoCount"
	return E_NOTIMPL
	align 4

GetTypeInfoCount endp


GetTypeInfo proc pThis:ptr CContainer, iTInfo:DWORD, lcid:LCID, ppTInfo:ptr LPTYPEINFO

	DebugOut "IDispatch::GetTypeInfo"
	return E_NOTIMPL
	align 4

GetTypeInfo endp


GetIDsOfNames proc uses esi edi pThis:ptr CContainer, riid:ptr IID, rgszNames:DWORD, cNames:DWORD, lcid:LCID, rgDispId:ptr DISPID

	DebugOut "IDispatch::GetIDsOfNames(%X, %X, %X, %X, %X)", riid, rgszNames, cNames, lcid, rgDispId
	cld
	mov esi, rgszNames
	mov edi, rgDispId
	mov ecx, cNames
	.while (ecx)
		push ecx
		lodsd
		DebugOut "IDispatch::GetIDsOfNames: %S", eax
		mov eax, DISPID_UNKNOWN
		stosd
		pop ecx
		dec ecx
	.endw
	return DISP_E_UNKNOWNNAME
	align 4

GetIDsOfNames endp


@Invoke_: AdjustThis
Invoke_ proc uses ebx pThis:ptr CContainer, dispIdMember:DISPID, riid:ptr IID, lcid:LCID,
	wFlags:WORD, pDispParams:ptr DISPPARAMS, pVarResult:ptr VARIANT, pExcepInfo:DWORD, puArgErr:ptr DWORD

	DebugOut "IDispatch::Invoke(%d, %X, %X, %X, %X, %X)", dispIdMember, riid, lcid, wFlags, pDispParams, pVarResult
	mov eax, dispIdMember
	mov ebx, DISP_E_MEMBERNOTFOUND
if 0
	.if ( eax == DISPID_AMBIENT_DLCONTROL )
		;"download" control. set DLCTL_xxx flags in pvarresult
	.elseif ( eax == DISPID_AMBIENT_SILENT )
		;the "silent" property tells whether the object may dispay dialog boxes
		;example how to set the return value:
		.if ( wFlags & DISPATCH_PROPERTYGET )
			mov edx,pVarResult
			mov [edx].VARIANTARG.vt, VT_BOOL
			mov [edx].VARIANTARG.boolVal, VARIANT_FALSE
			mov ebx, S_OK
		.endif
	.endif
endif
	return ebx
	align 4

Invoke_ endp

	end

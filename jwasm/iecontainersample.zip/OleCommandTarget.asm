
;--- IOleCommandTarget interface

	.486
	.model flat, stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include mshtmhst.inc
	include exdisp.inc
	include shlguid.inc

	include container.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.const

;*** vtbl IOleCommandTarget

CContainer@IOleCommandTargetVtbl label IOleCommandTargetVtbl
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd QueryStatus_
	dd Exec_

	.code

; -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CastOffset textequ <CContainer._IOleCommandTarget>
AdjustThis textequ <sub dword ptr [esp+4],CastOffset>

QueryInterface_:
	AdjustThis
	jmp QueryInterface
	align 4
AddRef_:
	AdjustThis
	jmp AddRef
	align 4
Release_:
	AdjustThis
	jmp Release
	align 4

QueryStatus_ proc this_:ptr CContainer, pguidCmdGroup:REFGUID, cCmds:DWORD, prgCmds:ptr OLECMD, pCmdText:ptr OLECMDTEXT

ifdef _DEBUG
local wszGUID[40]:word
	.if ( pguidCmdGroup == NULL )
		mov dword ptr wszGUID+0,0055004Eh   ;wide "NULL"
		mov dword ptr wszGUID+4,004C004Ch
		mov word ptr wszGUID+8,0
	.else
		invoke StringFromGUID2, pguidCmdGroup, addr wszGUID, 40
	.endif
	DebugOut "IOleCommandTarget::QueryStatus(%S, %X, %X, %X)", addr wszGUID, cCmds, prgCmds, pCmdText
	mov ecx, cCmds
	mov edx, prgCmds
	.while (ecx)
		DebugOut "IOleCommandTarget::QueryStatus: cmd ID=%u flags=%X", [edx].OLECMD.cmdID, [edx].OLECMD.cmdf
		add edx, sizeof OLECMD
		dec ecx
	.endw
endif
	.if ( pguidCmdGroup )
		invoke IsEqualGUID, pguidCmdGroup, addr CGID_Explorer	;000214d0?
		.if ( eax == 0)
			return OLECMDERR_E_UNKNOWNGROUP
		.endif
	.endif
	mov ecx, cCmds
	mov edx, prgCmds
	.while (ecx)
		mov [edx].OLECMD.cmdf, 0	;=cmd disabled
		add edx, sizeof OLECMD
		dec ecx
	.endw
	return S_OK

QueryStatus_ endp

Exec_ proc this_:ptr CContainer, pguidCmdGroup:REFGUID, nCmdID:DWORD, nCmdExecOpt:DWORD, pvaIn:ptr VARIANT, pvaOut:ptr VARIANT

ifdef _DEBUG
local wszGUID[40]:word
	.if ( pguidCmdGroup == NULL )
		mov dword ptr wszGUID+0,0055004Eh   ;wide "NULL"
		mov dword ptr wszGUID+4,004C004Ch
		mov word ptr wszGUID+8,0
	.else
		invoke StringFromGUID2, pguidCmdGroup, addr wszGUID, 40
	.endif
	DebugOut "IOleCommandTarget::Exec(%S, %u, %X, %X, %X)", addr wszGUID, nCmdID, nCmdExecOpt, pvaIn, pvaOut
endif
	.if ( pguidCmdGroup )
		invoke IsEqualGUID, pguidCmdGroup, addr CGID_Explorer	;000214d0?
		.if ( eax == 0)
			return OLECMDERR_E_UNKNOWNGROUP
		.endif
	.endif
	return OLECMDERR_E_DISABLED

Exec_ endp

	end

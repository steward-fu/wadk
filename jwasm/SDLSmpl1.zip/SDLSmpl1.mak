
# this is a NMAKE makefile
# before running it do:
# 1. ensure subdirs DEBUG and RELEASE exist
# 2. adjust SDLLIB: directory where SDL libs could be found
# 3. adjust SDLINC: directory where SDL MASM includes are located
# 4. adjust the WIN32INC definition below

name = SDLSmpl1

WIN32INC=\asm\win32inc

DEBUG=1

!if $(DEBUG)
LOPTD=/DEBUG:FULL
AOPTD=-Zi -DDEBUG
OUTDIR=DEBUG
!else
LOPTD=/DEBUG:NONE
AOPTD=
OUTDIR=RELEASE
!endif

SDLINC=\asm\sdlinc
SDLLIB=\sdl\sdl-1.2.9\VisualC

!include <dirs>

ASM = ml -c -Sg -Fl$* -Fo$* -D?FLAT=1 -coff -I$(WIN32INC)\include -I$(SDLINC) $(AOPTD)
SDLLIBS=$(SDLLIB)\SDL\Debug\sdl.lib $(SDLLIB)\SDLMain\Debug\sdlmain.lib
LIBS=kernel32.lib user32.lib gdi32.lib $(SDLLIBS) msvcrt.lib
LOPT=/OUT:$*.exe /MAP:$*.map /SUBSYSTEM:WINDOWS /FIXED:NO $(LOPTD)
LINK=link
MODS=$*.obj

$(OUTDIR)\$(name).exe: $*.obj
    $(LINK) $(MODS) $(LIBS) $(LOPT)

$(OUTDIR)\$(name).obj: $(name).asm $(name).mak
     $(ASM) $(name).asm


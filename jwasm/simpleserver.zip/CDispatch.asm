
;-----------------------------------------------------------------------
;--- dual interface implementation
;-----------------------------------------------------------------------

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32    
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include objidl.inc
	include debugout.inc
	.list
	.cref

	include SimpleServer.inc
	include CSimpleServer.inc

;-----------------------------------------------------------------------
;--- definitions to allow member variable access by
;--- "m_VarName" instead of "[ebx].CSimpleServer.VarName"
;-----------------------------------------------------------------------

__this	textequ <ebx>
_this	textequ <[__this].CSimpleServer>

	MEMBER _IDispatch, dwRefCount, pTypeInfo, dwProperty1
;-------------------- add further MEMBER definitions here if you want
;-------------------- to access new variables by "m_<VarName>"

	.const

;-----------------------------------------------------------------------
;--- vtable of dual interface
;--- order of methods must match those in .IDL file
;-----------------------------------------------------------------------

CSimpleServerVtbl label ISimpleServerVtbl
	IDispatchVtbl {QueryInterface@CSimpleServer, AddRef@CSimpleServer, Release@CSimpleServer,\
		GetTypeInfoCount@CSimpleServer, GetTypeInfo@CSimpleServer, GetIDsOfNames@CSimpleServer, Invoke@CSimpleServer}
	dd get_Property1, put_Property1
;------------------------------- address of further properties/methods to add here

	.code

;-----------------------------------------------------------------------
;--- IDispatch methods
;-----------------------------------------------------------------------

GetTypeInfoCount@CSimpleServer proc this_:ptr CSimpleServer, pCntinfo:ptr SDWORD

	DebugOut "IDispatch::GetTypeInfoCount"
	mov ecx, pCntinfo
	mov dword ptr [ecx], 1		;provide 1 typeinfo
	return S_OK

GetTypeInfoCount@CSimpleServer endp

;------------------------------------------------------------------------

GetTypeInfo@CSimpleServer proc uses __this this_:ptr CSimpleServer, iTypeInfo:DWORD, lcid:LCID, ppTInfo:ptr LPTYPEINFO
             
	DebugOut "IDispatch::GetTypeInfo(Index=%u, LCID=%X)", iTypeInfo, lcid

	mov __this, this_

	mov ecx, ppTInfo
	mov dword ptr [ecx],NULL

	.if (iTypeInfo != 0)
		return DISP_E_BADINDEX
	.endif

    mov eax, m_pTypeInfo
	mov ecx, ppTInfo
	mov [ecx], eax
	.if (eax)
		invoke vf(eax, IUnknown, AddRef)
		mov eax, S_OK
	.else
		mov eax, E_FAIL
	.endif
	ret

GetTypeInfo@CSimpleServer endp

;------------------------------------------------------------------------
;--- IDispatch::GetIDsOfNames: since we have a typeinfo available
;--- the real work is done by ITypeInfo::GetIDsOfNames
;------------------------------------------------------------------------

GetIDsOfNames@CSimpleServer proc uses __this this_:ptr CSimpleServer, rrid:ptr IID, rgszNames:DWORD, cNames:DWORD, lcid:LCID, rgDispID:DWORD
			 
	DebugOut "IDispatch::GetIDsOfNames"

	mov __this, this_

    mov eax, m_pTypeInfo
	.if (eax)
		invoke vf( m_pTypeInfo, ITypeInfo, GetIDsOfNames), rgszNames, cNames, rgDispID
	.else
		mov eax, E_FAIL
	.endif
	ret

GetIDsOfNames@CSimpleServer endp

;-----------------------------------------------------------------------
;--- IDispatch::Invoke. Clients may call this function
;--- to set/get properties or call members in "late binding" mode.
;--- The real work inhere is done by ITypeInfo:Invoke.
;-----------------------------------------------------------------------

Invoke@CSimpleServer proc uses __this this_:ptr CSimpleServer, dispIdMember:DISPID, riid:ptr IID, lcid:LCID, wFlags:DWORD, 
            pDispParams:ptr DISPPARAMS, pVarResult:ptr VARIANT, pExcepInfo:ptr EXCEPINFO, puArgErr:ptr DWORD

	mov __this, this_

    .if (!m_pTypeInfo)     
		return DISP_E_MEMBERNOTFOUND
    .endif
	invoke SetErrorInfo, NULL, NULL

	invoke vf( m_pTypeInfo, ITypeInfo, Invoke_), __this, dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr

ifdef _DEBUG
	.if (eax != S_OK)
		DebugOut "IDispatch::Invoke DispID=%X returned %X", dispIdMember, eax
	.endif
endif
	ret

Invoke@CSimpleServer endp

;------------------------------------------------------------
;--- custom interface methods/properties
;------------------------------------------------------------

get_Property1 proc this_:ptr CSimpleServer, pValue:ptr DWORD
	mov ecx, pValue
	mov eax, this_
	mov eax, [eax].CSimpleServer.dwProperty1
	mov [ecx], eax
	return S_OK
get_Property1 endp

put_Property1 proc this_:ptr CSimpleServer, dwNewValue:DWORD
	mov eax, this_
	mov ecx, dwNewValue
	mov [eax].CSimpleServer.dwProperty1, ecx
	return S_OK
put_Property1 endp

;--- add implementation of further properties/method here

	end


;-----------------------------------------------------------------------
;--- IUnknown implementation
;-----------------------------------------------------------------------

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include debugout.inc
	.list
	.cref

	include SimpleServer.inc		;COMView generated include
	include CSimpleServer.inc

	.const

;-----------------------------------------------------------------------
;--- define the table of exposed interfaces by this object
;-----------------------------------------------------------------------

iftab	label dword
	dd offset IID_IUnknown, 0
	dd offset IID_IDispatch, CSimpleServer._IDispatch
	dd offset IID_ISimpleServer, CSimpleServer._IDispatch
;--------------------- insert new exposed interfaces here
IFTABSIZE equ ($ - offset iftab) / 8

	.code

;*** scan interface tab and see if requested interface is in there

IsInterfaceSupported proc public uses ebx esi edi pReqIF:ptr IID, pIFTab:ptr ptr IID, dwEntries:dword, pThis:ptr, ppReturn:ptr LPUNKNOWN
	
	mov ecx,dwEntries
	mov esi,pIFTab
	mov ebx,0
	.while (ecx)
		lodsd
		mov edi,eax
		lodsd
		mov edx,eax
		mov eax,esi
		mov esi,pReqIF
		push ecx
		mov ecx,4
		repz cmpsd
		pop ecx
		.if (ZERO?)
			mov ebx,edx
			add ebx,pThis
			.break
		.endif
		mov esi,eax
		dec ecx
	.endw
	mov ecx,ppReturn
	mov [ecx],ebx

	.if (ebx)
		invoke vf(ebx,IUnknown,AddRef)
		mov eax,S_OK
	.else
		mov eax,E_NOINTERFACE
	.endif
	ret

IsInterfaceSupported endp


;*** IUnknown::QueryInterface - the real, nondelegated QueryInterface

QueryInterface@CSimpleServer PROC public this_:ptr CSimpleServer,riid:ptr IID,ppReturn:ptr LPUNKNOWN

ifdef _DEBUG
local	wszIID[40]:word
local	szKey[128]:byte
local	dwSize:DWORD
local	hKey:HANDLE
endif

	invoke IsInterfaceSupported, riid, offset iftab, IFTABSIZE,  this_, ppReturn
ifdef _DEBUG
    push eax
	invoke StringFromGUID2,riid, addr wszIID,40
	invoke wsprintf, addr szKey, CStr("Interface\%S"),addr wszIID
	invoke RegOpenKeyEx, HKEY_CLASSES_ROOT, addr szKey, 0, KEY_READ, addr hKey 
	.if (eax == ERROR_SUCCESS)
		mov dwSize, sizeof szKey
		invoke RegQueryValueEx,hKey,CStr(""),NULL,NULL,addr szKey,addr dwSize
		invoke RegCloseKey, hKey
	.else
		mov szKey,0
	.endif
    pop eax
	DebugOut "IUnknown::QueryInterface(%S[%s])=%X", addr wszIID, addr szKey, eax
endif
	ret

QueryInterface@CSimpleServer ENDP

;*** IUnknown::AddRef

AddRef@CSimpleServer PROC public this_:ptr CSimpleServer

	mov eax,this_
	inc [eax].CSimpleServer.dwRefCount
	mov	eax, [eax].CSimpleServer.dwRefCount
	ret
AddRef@CSimpleServer ENDP		

;*** IUnknown::Release

Release@CSimpleServer PROC public this_:ptr CSimpleServer

	mov eax,this_
	dec [eax].CSimpleServer.dwRefCount
	mov eax,[eax].CSimpleServer.dwRefCount
	.if (eax == 0)
		invoke Destroy@CSimpleServer, this_
		xor eax,eax
	.endif
	ret

Release@CSimpleServer ENDP	

	end


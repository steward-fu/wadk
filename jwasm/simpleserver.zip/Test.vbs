
' create control (use ProgID as name)

  Set object = WScript.CreateObject("SimpleServerASM")

  MsgBox "Property=" & object.Property1
	
 
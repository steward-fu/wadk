
rem create proxy/stub dll
rem needed for "special" cases only

rem the link step will require some RPC libraries not included in WinInc

rem use WinInc
cd RelW32

rem use MASM32
rem cd RelM32

cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL dlldata.c
cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL ComExeSvr_p.c
cl /c /Ox /DWIN32 /D_WIN32_WINNT=0x0400 /DREGISTER_PROXY_DLL ComExeSvr_i.c
link /dll /out:ComExeSvrps.dll /def:..\ComExeSvrps.def /entry:DllMain dlldata.obj ComExeSvr_p.obj ComExeSvr_i.obj kernel32.lib rpcndr.lib rpcns4.lib rpcrt4.lib oleaut32.lib uuid.lib 

cd ..

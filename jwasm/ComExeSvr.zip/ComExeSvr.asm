
;-----------------------------------------------------------------------
;--- main file, defines constructors/destructors and WinMain
;-----------------------------------------------------------------------

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32    
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include olectl.inc
	include debugout.inc
	.list
	.cref

	include ComExeSvr.inc
	include CComExeSvr.inc
	include utility.inc

RegisterServer		proto
UnregisterServer	proto

__this	textequ <ebx>
_this	textequ <[__this].CComExeSvr>

	MEMBER _IDispatch, dwRefCount, pTypeInfo, dwValue

	.data

g_hInstance		HINSTANCE NULL
g_dwRefCount	DWORD 0
g_dwThreadId	DWORD 0
g_lpszCmdLine	dd CStr("")

	.const

ProgId			textequ <"ComExeSvrASM">
Description		textequ <"Simple out-of-process Server in ASM">
CLSID_ComExeSvr	sCLSID_ComExeSvr
LIBID_ComExeSvr	sTLBID_ComExeSvr
IID_IComExeSvr	sIID_IComExeSvr

;-----------------------------------------------------------------------
;--- registry definitions for ComExeSvr CLSID
;-----------------------------------------------------------------------

;--- proc RegisterServer will interpret these definitions as follows:
;--- types of items in regkeys table:
;--- 1. first col == -1: create/open current key, name in third col
;--- 2. first col == 0: set a value (name in second col or 0 for default value)
;--- 3. first col != 0/-1, create a subkey (name in first col), optionally with
;---    a (named if second col != 0) value (third col != 0)
;---  string in third col will be scanned for variables:
;---  %1 = CLSID string
;---  %2 = LIBID string
;---  %3 = module path (==%MODULE%)

RegKeys_ComExeSvr label REGSTRUCT
	REGSTRUCT <-1, 0, CStr("CLSID\%1")>
	REGSTRUCT <0, 0, CStr(Description)>
	REGSTRUCT <0, CStr("AppID"), CStr("%1")>
	REGSTRUCT <CStr("LocalServer32"), 0, CStr("%3")>
	REGSTRUCT <CStr("ProgID"), 0, CStr(<ProgId,".", _MajorVer_ComExeSvr+'0'>)>
	REGSTRUCT <CStr("VersionIndependentProgID"), 0, CStr(ProgId)>
	REGSTRUCT <CStr("Programmable"), 0, 0>
	REGSTRUCT <CStr("TypeLib"), 0, CStr("%2")>
	REGSTRUCT <CStr("Version"), 0, CStr(<_MajorVer_ComExeSvr+'0','.',_MinorVer_ComExeSvr+'0'>)>
	REGSTRUCT <-1, 0, CStr(ProgId)>
	REGSTRUCT <0, 0, CStr(Description)>
	REGSTRUCT <CStr("CLSID"), 0, CStr("%1")>
	REGSTRUCT <CStr("CurVer"), 0, CStr(<ProgId,".",_MajorVer_ComExeSvr+'0'>)>
	REGSTRUCT <-1, 0, CStr(<ProgId,".",_MajorVer_ComExeSvr+'0'>)>
	REGSTRUCT <0, 0, CStr(Description)>
	REGSTRUCT <CStr("CLSID"), 0, CStr("%1")>
	REGSTRUCT <-1, 0, CStr("AppID\%1")>
	REGSTRUCT <0, 0, CStr(Description)>
	REGSTRUCT <-1, 0, 0>

;-----------------------------------------------------------------------
;--- ObjectMap: contains an ObjectEntry item for each coclass
;--- implemented by this server
;-----------------------------------------------------------------------

	.data	;has to be in data segment

ObjectMap label ObjectEntry
	ObjectEntry {\
		offset CLSID_ComExeSvr,\
		offset LIBID_ComExeSvr, _MajorVer_ComExeSvr, _MinorVer_ComExeSvr,\
		offset RegKeys_ComExeSvr,\
		Create@CComExeSvr}
;-------------------------------------------
;--- include further ObjectEntry {} here ---
;-------------------------------------------
OBJECTMAPITEMS	equ ($ - offset ObjectMap) / sizeof ObjectEntry

	.code

;-----------------------------------------------------------------------
;--- constructor coclass ComExeSvr
;-----------------------------------------------------------------------

Create@CComExeSvr proc public uses esi __this pClass: ptr ObjectEntry, pUnkOuter:LPUNKNOWN

local	pTypeLib:LPTYPELIB

	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT,sizeof CComExeSvr
	mov __this,eax
	mov m__IDispatch, offset CComExeSvrVtbl
;---------------------------------- further interface vtable initialization
;---------------------------------- to add here

	mov m_dwRefCount, 1

	mov esi, pClass
	invoke LoadRegTypeLib, [esi].ObjectEntry.pLibId, [esi].ObjectEntry.dwVerMajor,\
   				[esi].ObjectEntry.dwVerMinor, LOCALE_USER_DEFAULT, ADDR pTypeLib 
   	.if (eax == S_OK)
		invoke vf(pTypeLib, ITypeLib, GetTypeInfoOfGuid), addr IID_IComExeSvr, ADDR m_pTypeInfo
   		invoke vf(pTypeLib, ITypeLib, Release)
	.endif

	inc g_dwRefCount

	DebugOut "Create@CComExeSvr glbCnt=%u", g_dwRefCount

	.if (!m_pTypeInfo)
		invoke Destroy@CComExeSvr, __this
		return NULL
	.endif
	return __this
Create@CComExeSvr endp

;-----------------------------------------------------------------------
;--- destructor coclass ComExeSvr
;-----------------------------------------------------------------------

Destroy@CComExeSvr proc public this_:ptr CComExeSvr

	mov ecx, this_
	.if ([ecx].CComExeSvr.pTypeInfo)
		invoke vf([ecx].CComExeSvr.pTypeInfo, IUnknown, Release)
	.endif

	dec g_dwRefCount

	DebugOut "Destroy@CComExeSvr glbCnt=%u", g_dwRefCount

	.if (!g_dwRefCount)
		invoke PostThreadMessage, g_dwThreadId, WM_QUIT, 0, 0
	.endif

	invoke LocalFree, this_
	ret
Destroy@CComExeSvr endp

;--------------------------------------------------------------
;--- helper proc for RegisterServer and UnregisterServer
;--- will copy pszInp to pszOut, 
;--- thereby replacing %1, %2, %3 by pszVar1, pszVar2, pszVar3
;--------------------------------------------------------------

CopyReplace	proc uses esi edi pszOut:LPSTR, pszInp:LPSTR, pszVar1:LPSTR, pszVar2:LPSTR, pszVar3:LPSTR

local	szTmp[2]:byte

		mov edi, pszOut
		mov esi, pszInp
		xor ah, ah
		.repeat
			lodsb
			.if (ah)
				mov ah, 00
				.if (al == '1')
					mov edx, pszVar1
				.elseif (al == '2')
					mov edx, pszVar2
				.elseif (al == '3')
					mov edx, pszVar3
				.else
					lea edx, szTmp
					mov [edx], ax
				.endif
				push esi
				mov esi, edx
				.repeat
					lodsb
					stosb
				.until (al == 0)
				pop esi
				inc al
			.elseif (al == '%')
				mov ah, al
			.else
				stosb
			.endif
		.until (al == 0)
		mov eax, edi
		sub eax, pszOut
		ret

CopyReplace	endp

;--------------------------------------------------------------
;--- helper proc for RegisterServer and UnregisterServer
;--- will set values for variables %1, %2, %3
;--------------------------------------------------------------

GetVarStrings proc uses esi pObjectEntry:ptr ObjectEntry, pszCLSID:LPSTR, pszLIBID:LPSTR, pszModule:LPSTR

local	wszGUID[40]:word

		mov esi, pObjectEntry
;------------------------------ get the CLSID in string form
		invoke StringFromGUID2, [esi].ObjectEntry.pClsId, addr wszGUID, LENGTHOF wszGUID
		invoke WideCharToMultiByte, CP_ACP, 0, addr wszGUID, -1, pszCLSID, 40, NULL, NULL

;------------------------------ get the LIBID in string form
		invoke StringFromGUID2, [esi].ObjectEntry.pLibId, addr wszGUID, LENGTHOF wszGUID
		invoke WideCharToMultiByte, CP_ACP, 0, addr wszGUID, -1, pszLIBID, 40, NULL, NULL

;------------------------------ get this DLL's path and file name
		invoke GetModuleFileName, g_hInstance, pszModule, MAX_PATH
		ret
GetVarStrings endp

;--------------------------------------------------------------
;--- RegisterServer: register this server
;--------------------------------------------------------------

RegisterServer PROC uses ebx esi edi

local	hKey:HANDLE
local	dwDisp:dword
local   pTypeLib:LPTYPELIB
local	szCLSID[40]:byte
local	szLIBID[40]:byte
local	szKeyPrefix[64]:byte
local	szSubKey[MAX_PATH]:byte
local	szModule[MAX_PATH]:byte
local	szData[MAX_PATH]:byte
local	wszModule[MAX_PATH]:word

	mov esi, offset ObjectMap
	mov edi, OBJECTMAPITEMS
	.while (edi)
		invoke GetVarStrings, esi, addr szCLSID, addr szLIBID, addr szModule

;------------------------------ register the CLSID entries

		mov ebx, [esi].ObjectEntry.pRegKeys
		assume ebx:ptr REGSTRUCT

		.while (1)
			.if ([ebx].lpszSubKey == -1)
				.break .if ([ebx].lpszData == 0)
				invoke CopyReplace, addr szKeyPrefix, [ebx].lpszData, addr szCLSID,\
						addr szLIBID, addr szModule
				add ebx, sizeof REGSTRUCT
				.continue
			.endif
			invoke lstrcpy, addr szSubKey, addr szKeyPrefix
			.if ([ebx].lpszSubKey)
				invoke lstrlen, addr szSubKey
				lea ecx, szSubKey
				add ecx, eax
				mov byte ptr [ecx],'\'
				inc ecx
;------------------------------ Create the sub key string.
				invoke lstrcpy, ecx, [ebx].lpszSubKey
			.endif

			invoke RegCreateKeyEx, HKEY_CLASSES_ROOT,\
					addr szSubKey,0,NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, \
					NULL, addr hKey, addr dwDisp
			.if (eax == NOERROR)
;------------------------------ if necessary, create the value string
	          .if ([ebx].lpszData)
					invoke CopyReplace, addr szData, [ebx].lpszData, addr szCLSID,\
						addr szLIBID, addr szModule
					mov edx, eax
					invoke RegSetValueEx, hKey, [ebx].lpszValueName,\
			    			0, REG_SZ, addr szData, edx
	            .endif
				invoke	RegCloseKey, hKey
			.else
				return SELFREG_E_CLASS
			.endif

			add ebx,sizeof REGSTRUCT
		.endw

		add esi, sizeof ObjectEntry
		dec edi
	.endw

;------------------------------ Register Type Library and Interfaces

    invoke MultiByteToWideChar,CP_ACP,MB_PRECOMPOSED,addr szModule,sizeof szModule,addr wszModule, LENGTHOF wszModule 
	invoke LoadTypeLibEx, addr wszModule, REGKIND_REGISTER, addr pTypeLib
	.if (eax == S_OK)
		invoke vf(pTypeLib,ITypeLib,Release)
	.endif

	return S_OK
	assume ebx:nothing

RegisterServer ENDP

;--------------------------------------------------------------
;--- helper proc for UnregisterServer
;--------------------------------------------------------------

DeleteKeyWithSubKeys proc uses ebx hKey:HANDLE,pszKey:ptr byte

local	szKey[MAX_PATH]:byte
local	hSubKey:HANDLE
local	filetime:FILETIME
local	dwSize:dword

		invoke RegOpenKeyEx,hKey,pszKey,NULL,KEY_ALL_ACCESS,addr hSubKey
		.if (eax == ERROR_SUCCESS)
			mov ebx,0
			.while (1)
				mov dwSize,sizeof szKey
				invoke RegEnumKeyEx,hSubKey,ebx,addr szKey,addr dwSize,NULL,NULL,NULL,addr filetime
				.break .if (eax != ERROR_SUCCESS)
				invoke DeleteKeyWithSubKeys,hSubKey,addr szKey
			.endw							
			invoke RegCloseKey,hSubKey
		.endif
		invoke RegDeleteKey,hKey,pszKey		;and delete subkey
		ret
DeleteKeyWithSubKeys endp

;--------------------------------------------------------------
;--- UnregisterServer: unregister this server
;--------------------------------------------------------------

UnregisterServer PROC uses ebx esi edi

local	szCLSID[40]:byte
local	szLIBID[40]:byte
local	szModule[MAX_PATH]:byte
local	szSubKey[MAX_PATH]:byte

	mov esi, offset ObjectMap
	mov edi, OBJECTMAPITEMS
	.while (edi)
		invoke GetVarStrings, esi, addr szCLSID, addr szLIBID, addr szModule

		mov ebx, [esi].ObjectEntry.pRegKeys
		assume ebx:ptr REGSTRUCT

		.while (1)
			.if ([ebx].lpszSubKey == -1)
				.break .if ([ebx].lpszData == 0)
				invoke CopyReplace, addr szSubKey, [ebx].lpszData, addr szCLSID,\
						addr szLIBID, addr szModule
ifdef _DEBUG
;------------------------------ ensure that a wrong REGSTRUCT entry does
;------------------------------ no fatal damage in registry
				.if (!szSubKey)
					invoke DebugBreak
					return SELFREG_E_CLASS
				.endif
				invoke lstrcmpi, addr szSubKey, CStr("CLSID")
				.if (!eax)
					invoke DebugBreak
					return SELFREG_E_CLASS
				.endif
				invoke lstrcmpi, addr szSubKey, CStr("TYPELIB")
				.if (!eax)
					invoke DebugBreak
					return SELFREG_E_CLASS
				.endif
				invoke lstrcmpi, addr szSubKey, CStr("INTERFACE")
				.if (!eax)
					invoke DebugBreak
					return SELFREG_E_CLASS
				.endif
				invoke lstrcmpi, addr szSubKey, CStr("APPID")
				.if (!eax)
					invoke DebugBreak
					return SELFREG_E_CLASS
				.endif
endif
				invoke DeleteKeyWithSubKeys, HKEY_CLASSES_ROOT, addr szSubKey
			.endif
			add ebx, sizeof REGSTRUCT
		.endw

;------------------------------ Unregister Type Library and Interfaces
		invoke UnRegisterTypeLib, [esi].ObjectEntry.pLibId,\
			[esi].ObjectEntry.dwVerMajor, [esi].ObjectEntry.dwVerMinor, 0, SYS_WIN32

		add esi, sizeof ObjectEntry
		dec edi

	.endw

	return S_OK
	assume ebx:nothing

UnregisterServer endp

;--- scan command line for tokens beginning with "/" or "-"

FindOption	proc uses esi lpszCmdLine:LPSTR, lpszWatch:LPSTR
	
	mov esi, lpszCmdLine
	.while (1)
		xor eax, eax
		lodsb
		.break .if (!al)
		mov ah, al
		mov edx, esi
		mov esi, lpszWatch
		.while (1)
			lodsb
			.break .if (!al)
			.if (al == ah)
				mov eax, edx
				ret
			.endif
		.endw
		mov esi, edx
	.endw
	ret
FindOption	endp

;--- register a class factory object for each coclass exposed

RegisterClassObjects proc uses esi

local	pUnknown:LPUNKNOWN

	mov esi, offset ObjectMap
	mov ecx, OBJECTMAPITEMS
	.while (ecx)
		push ecx
		invoke	Create@CClassFactory, esi
		.if (eax)
			mov pUnknown, eax
			invoke CoRegisterClassObject, [esi].ObjectEntry.pClsId, pUnknown,\
				CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE, addr [esi].ObjectEntry.dwRegister
			invoke vf(pUnknown, IUnknown, Release)
		.endif
		pop ecx
		add esi, sizeof ObjectEntry
		dec ecx
	.endw
	ret
RegisterClassObjects endp

;--- unregister all objects

UnregisterClassObjects proc uses esi

	mov esi, offset ObjectMap
	mov ecx, OBJECTMAPITEMS
	.while (ecx)
		push ecx
		invoke CoRevokeClassObject, [esi].ObjectEntry.dwRegister
		pop ecx
		add esi, sizeof ObjectEntry
		dec ecx
	.endw
	ret

UnregisterClassObjects endp

;--------------------------------------------------------------
;--- WinMain
;--------------------------------------------------------------

WinMain PROC public uses esi hInstance:HINSTANCE, hPrevInstance:HINSTANCE, lpszCmdLine:LPSTR, iCmdShow:DWORD

local	msg:MSG

	invoke CoInitialize, NULL

	invoke GetCurrentThreadId
	mov g_dwThreadId, eax

	mov esi, lpszCmdLine
	.while (1)
		invoke FindOption, esi, CStr("-/")
		.break .if (!eax)
		mov esi, eax
		invoke lstrcmpi, esi, CStr("RegServer")
		.if (!eax)
			invoke RegisterServer
			jmp done
		.endif
		invoke lstrcmpi, esi, CStr("UnregServer")
		.if (!eax)
			invoke UnregisterServer
			jmp done
		.endif
	.endw

	invoke RegisterClassObjects

	.while (1)
		invoke GetMessage, addr msg, 0, 0, 0
		.break .if (!eax)
		invoke DispatchMessage, addr msg
	.endw

	invoke UnregisterClassObjects

done:
	invoke CoUninitialize
	xor eax, eax
	ret
WinMain ENDP

;--------------------------------------------------------------
;--- WinMainCRTStartup: starting point of this app
;--------------------------------------------------------------

WinMainCRTStartup proc public

	invoke GetModuleHandle, NULL
	mov g_hInstance, eax
	invoke GetCommandLine
	mov esi, eax
;--------------------------------- skip application name
	xor ah, ah
	.while (1)
		lodsb
		.break .if (!al)
		.if (al == '"')
			xor ah, 01
		.elseif ((ah == 0) && ((al == ' ') || (al == 9)))
			mov g_lpszCmdLine, esi
			.break
		.endif
	.endw
	invoke WinMain, g_hInstance, NULL, g_lpszCmdLine, 0
	invoke ExitProcess, eax

WinMainCRTStartup endp

	end

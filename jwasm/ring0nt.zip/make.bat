@echo off
jwasm -nologo -coff -Fl -Sg ring0nt.asm
rem ml -coff -c -Fl ring0nt.asm
link /nologo /subsystem:console ring0nt.obj /LIBPATH:\Win32Inc\Lib ntdll.lib kernel32.lib advapi32.lib user32.lib

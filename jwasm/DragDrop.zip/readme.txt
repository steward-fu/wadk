
 About
 
 This code sample implementing OLE Drag&Drop was written by Random.
 I changed it so it is now free of "unfree" software references (CoLib).
 So you can now really use it as you wish.

 Please read file Makefile for details about how to create the binary.
 
 If you use Win32Inc, the MASM32 subdirectory is not needed and can
 be deleted. It contains some COM definitions lacking in MASM32.

 Japheth


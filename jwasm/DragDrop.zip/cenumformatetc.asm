
	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc

	include unknwn.inc
	include objidl.inc
if ?MASM32
	include kernel32.inc
	include ole32.inc
endif
	include oledragdrop.inc
	.list
	.cref

;-----------------------------------------------------------------------------
; declare the object structure
CEnumFORMATETC struct
    ; interface object
    interface   IEnumFORMATETC  <?>
    ; object data
    cRef      dd          ?
    pUnkRef   LPUNKNOWN   ?;  //IUnknown for ref counting
    iCur      dd          ?;  //Current element
    cfe       dd          ?;  //Number of FORMATETCs in us
    prgFE     dd          ?;  //Source of FORMATETCs
CEnumFORMATETC ends
;-----------------------------------------------------------------------------

QueryInterface proto :ptr CEnumFORMATETC, :REFIID, :ptr LPUNKNOWN
AddRef	proto :ptr CEnumFORMATETC
Release proto :ptr CEnumFORMATETC

	.data

externdef stdcall IID_IEnumFORMATETC: GUID

	.const

;-----------------------------------------------------------------------------
; define the vtable

vtblIEnumFORMATETC label dword
    dd      offset QueryInterface
    dd      offset AddRef
    dd      offset Release
    dd      offset Next
    dd      offset Skip
    dd      offset Reset
    dd      offset Clone

	.code

__this	textequ <ebx>
_this	textequ <[__this].CEnumFORMATETC>

	MEMBER interface, cRef, pUnkRef, iCur, cfe, prgFE


;//**********************************************************************
;// Implementation of the IEnumFORMATETC interface
;//**********************************************************************
;-----------------------------------------------------------------------------
;Constructor
;
CreateCEnumFORMATETC proc public uses __this esi edi pobj:ptr ptr CEnumFORMATETC, pUnkRef:LPUNKNOWN, cFE:DWORD, prgFE:DWORD

;---------------------- set *ppv to 0
	mov 	eax, pobj
	mov 	dword ptr [eax], 0
;---------------------- allocate object
	invoke	LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CEnumFORMATETC
	.if (!eax)
;---------------------- alloc failed, so return
		mov 	eax, E_OUTOFMEMORY
		jmp 	exit
	.endif
	mov 	__this, eax
	mov 	m_interface.lpVtbl, offset vtblIEnumFORMATETC
	mov 	m_cRef, 0
;--------------------------------- PERSONALISE
	mov 	eax,pUnkRef
	mov 	m_pUnkRef,eax
	mov 	m_iCur, 0
	mov 	eax, cFE
	mov 	m_cfe,eax

;--------------------------------- Allocate the array of FORMATETC
	xor 	edx,edx
	mov 	ecx,SIZEOF FORMATETC
	imul	ecx
	push	eax 					;number of FORMATETC * SIZEOF FORMATETC
	invoke	LocalAlloc, LMEM_FIXED, eax
	mov 	m_prgFE,eax
;--------------------------------- initialise the array of FORMATETC
	pop 	ecx
	mov 	edi,eax
	mov 	esi, prgFE
	rep 	movsb

	invoke	QueryInterface, __this, addr IID_IEnumFORMATETC, pobj
	.if (eax != S_OK)
;--------------------------------- error in QueryInterface, so free memory
		push	eax
		invoke	LocalFree, __this
		pop 	eax
	.endif
exit:
	ret
CreateCEnumFORMATETC endp

;-----------------------------------------------------------------------------
;IUnknown methods
;
QueryInterface proc pThis:ptr CEnumFORMATETC, riid:REFIID, ppv:ptr LPUNKNOWN

    invoke  IsEqualGUID, riid, addr IID_IEnumFORMATETC
    test    eax,eax
    jnz     @F
    invoke  IsEqualGUID, riid, addr IID_IUnknown
    test    eax,eax
    jnz     @F
    mov     eax, ppv
    mov     dword ptr [eax], NULL
    mov     eax, E_NOINTERFACE
    jmp     exit
@@:
    mov		eax, pThis
    mov     ecx, ppv
    mov     [ecx], eax
    invoke  AddRef, pThis
    mov     eax, S_OK
exit:
    ret

QueryInterface endp

AddRef proc uses __this pThis:ptr CEnumFORMATETC

    mov		__this,pThis
    ; increment the reference count
    inc     m_cRef

    invoke  vf(m_pUnkRef, IUnknown, AddRef)

    ; now return the count
    mov     eax, m_cRef
    ret

AddRef endp


Release proc uses __this pThis:ptr CEnumFORMATETC

    mov     __this,pThis
;---------------------------- decrement the reference count
    dec     m_cRef

    invoke  vf(m_pUnkRef, IUnknown, Release)

;---------------------------- check to see if the reference count is zero.
;----------------------------  If it is, then destroy the object
    mov     eax, m_cRef
    or      eax, eax
    jnz     @F
;---------------------------- free object data & object itself
    invoke  LocalFree, m_prgFE
    invoke  LocalFree, __this
@@:
    ret

Release endp
;-----------------------------------------------------------------------------

;Returns the next element in the enumeration

Next proc uses __this esi edi, pThis:ptr CEnumFORMATETC, cFE:DWORD, pFE:ptr FORMATETC, pulFE:ptr DWORD
        Local       cReturn:DWORD

        mov     __this,pThis

        mov     eax, m_prgFE
        or      eax,eax
        jnz     @F
        mov     eax,S_FALSE
        jmp     exit
@@:
        mov     eax, pulFE
        or      eax,eax
        jz      @F
        mov     DWORD PTR [eax],0
@@:
        mov     eax, pFE
        or      eax,eax
        jnz     @F
        mov     eax,S_FALSE
        jmp     exit
@@:
        mov     eax, m_iCur
        mov     ecx, m_cfe
        cmp     eax,ecx
        jb      @F
        mov     eax,S_FALSE
        jmp     exit
@@:
        mov     cReturn, 0
        mov     edi,[pFE]
        mov     esi, m_prgFE
        mov     eax, m_iCur
        xor     edx,edx
        mov     ecx,SIZEOF FORMATETC
        imul    ecx
        add     esi,eax

        mov     edx, m_cfe
        .WHILE  m_iCur < edx && [cFE]>0
                mov     ecx,SIZEOF FORMATETC
                rep     movsb
                inc     m_iCur
                inc     cReturn
                dec     cFE
        .ENDW
        mov     eax, pulFE
        or      eax,eax
        jz      @F
        mov     ecx, cReturn
        sub     ecx, cFE
        mov     DWORD PTR [eax],ecx
@@:
        mov     eax,NOERROR
exit:
    ret
Next endp

;Skips the next n elements in the enumeration

Skip proc uses __this pThis:ptr CEnumFORMATETC, cSkip:DWORD
		
        mov     __this, pThis
        mov     eax, m_prgFE
        or      eax,eax
        jnz     @F
        mov     eax, S_FALSE
        jmp     exit
@@:
        mov     eax, m_iCur
        add     eax, cSkip
        cmp     eax, m_cfe
        jb      @F
        mov     eax, S_FALSE
        jmp     exit
@@:
        mov     m_iCur, eax
        mov     eax, NOERROR
exit:
        ret
Skip endp

;Resets the current element index in the enumeration to zero

Reset proc uses ebx pThis:ptr CEnumFORMATETC
		mov		eax,pThis
        mov     [eax].CEnumFORMATETC.iCur,0
        mov     eax,NOERROR
        ret
Reset endp

;Returns another IEnumFORMATETC with the same state as ourselves

Clone proc uses ebx pThis:ptr CEnumFORMATETC, ppEnum:ptr ptr IEnumFORMATETC
        mov eax,E_OUTOFMEMORY
        ret
Clone endp

;-----------------------------------------------------------------------------
;//**********************************************************************
	end

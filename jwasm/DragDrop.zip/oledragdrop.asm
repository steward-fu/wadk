;**************************************************************************
;              WIN32ASM OLE/COM DragDrop Interfaces
;              by Random (c)2001 - norp74@hotmail.com
;*******DISCLAIMER*********************************************************
;Fill free to (re)use this code as you like, but please put a reference to 
;me and to those I thank below
;Please email me any bug/suggestion and any development/improvement you've
;made on this code
;I should not be held responsible for any damage that may derive from the 
;use of this code
;*******REFERENCES*********************************************************
;The DragDrop classes I wrote are mainly derived from the C++ source of 
;John Rennie (jrennie@cix.compulink.co.uk)
;The COM interface structure in assembler come from the incredible tutorial 
;written by Bill T.  (billasm@usa.net)
;**************************************************************************

;--------------------------------------------------------------------------
;--- I took Randoms sample and freed it from this "CoLib" thingy.
;--- Japheth 2002
;--------------------------------------------------------------------------

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nocref
	.nolist
	include windows.inc
    include commctrl.inc

	include unknwn.inc
	include oleidl.inc
	include objidl.inc
	include windowsx.inc
    include shlobj.inc
	include debugout.inc
if ?MASM32
	include kernel32.inc
	include user32.inc
    include ole32.inc
endif

	.cref
	.list

	include oledragdrop.inc

;-----------------------------------------------------------------------------

if ?MASM32
WinMain         PROTO :HINSTANCE,:HINSTANCE,:ptr byte,:DWORD
endif
CreateListView  PROTO :HWND
CreateHDrop     PROTO :HWND, :ptr DWORD

	.data

g_hInstance      DWORD 0
g_hListView      DWORD 0
g_hwndDropSource HWND 0

	.code


WinMainCRTStartup proc public
        invoke  GetModuleHandle,NULL
        mov     [g_hInstance],eax
        invoke  WinMain,[g_hInstance],NULL,NULL,SW_SHOWDEFAULT
        invoke  ExitProcess,eax
WinMainCRTStartup endp

WinMain PROC hInst:HINSTANCE, hPrevInst:HINSTANCE, CmdLine:LPSTR, CmdShow:DWORD

        LOCAL   hwnd:DWORD,wclass:WNDCLASSEX,msg:MSG

        mov     [wclass].cbSize,SIZEOF WNDCLASSEX
        mov     [wclass].style,CS_HREDRAW or CS_VREDRAW or CS_DBLCLKS
        mov     [wclass].lpfnWndProc,offset WndProc
        mov     [wclass].cbClsExtra,NULL
        mov     [wclass].cbWndExtra,NULL
        mov     eax,[hInst]
        mov     [wclass].hInstance, eax
        mov     [wclass].hbrBackground,COLOR_WINDOW
        mov     [wclass].lpszMenuName,NULL      ;IDR_MAINMENU
        mov     [wclass].lpszClassName,CStr("MM32")
        invoke  LoadIcon,NULL,IDI_APPLICATION
        mov     [wclass].hIcon, eax
        mov     [wclass].hIconSm, eax
        invoke  LoadCursor,NULL,IDC_ARROW
        mov     [wclass].hCursor, eax
        invoke  RegisterClassEx,ADDR wclass
        invoke  CreateWindowEx,NULL,CStr("MM32"),CStr("Random's OLE DragDrop FileStop"),\
                WS_OVERLAPPEDWINDOW or WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,700,400,\
                NULL,NULL,[hInst],NULL
        mov     [hwnd], eax
        invoke  ShowWindow,[hwnd],SW_NORMAL
        invoke  UpdateWindow,[hwnd]
        .WHILE TRUE
                invoke  GetMessage,ADDR msg,NULL,0,0
                .BREAK .IF (!eax)
                invoke  TranslateMessage,ADDR msg
                invoke  DispatchMessage,ADDR msg
        .ENDW
        mov     eax,[msg.wParam]
        ret
		align 4

WinMain ENDP


;--- main window proc


WndProc PROC hwnd:HWND, uMsg:DWORD, wParam:WPARAM, lParam:LPARAM

	LOCAL	dwSize:DWORD
	local	hDrop:HANDLE
	LOCAL	pDropSource:LPDROPSOURCE
	LOCAL	pDropTarget:LPDROPTARGET
	LOCAL	pDataObject:LPDATAOBJECT
	LOCAL	deffect:DWORD
	LOCAL	rect:RECT

	mov eax,uMsg

	.IF (eax == WM_CREATE)

		invoke	CreateListView,[hwnd]
		mov 	[g_hListView],eax
		invoke	OleInitialize, NULL
;------------------- Register window as a drag drop client
		invoke	CreateCDropTarget, ADDR pDropTarget, g_hListView
		invoke	RegisterDragDrop, hwnd, pDropTarget

	.ELSEIF (eax == WM_SIZE)

		invoke	GetClientRect, hwnd, ADDR rect
		invoke	MoveWindow, g_hListView,0,0,rect.right, rect.bottom, TRUE

	.ELSEIF (eax == WM_NOTIFY)

		mov 	eax,lParam
		.IF (([eax].NM_LISTVIEW.hdr.code == LVN_BEGINDRAG) || \
			([eax].NM_LISTVIEW.hdr.code == LVN_BEGINRDRAG))

			invoke	CreateCDropSource, ADDR pDropSource
			invoke	CreateHDrop, g_hListView, addr dwSize
			mov hDrop, eax
			invoke	CreateCDataObject, ADDR pDataObject, hDrop, dwSize

			mov eax, g_hListView
            mov g_hwndDropSource, eax

			invoke	DoDragDrop, pDataObject, pDropSource, DROPEFFECT_MOVE or DROPEFFECT_COPY or DROPEFFECT_LINK, ADDR deffect
            mov g_hwndDropSource, NULL
			push	eax
			invoke	vf(pDataObject, IDataObject, Release)
			invoke	vf(pDropSource, IDropSource, Release)
			pop 	eax
			.IF (eax == DRAGDROP_S_DROP)
				mov 	eax, deffect
				.IF (eax == DROPEFFECT_MOVE)
					.while (1)
						invoke ListView_GetNextItem( g_hListView,-1,LVNI_SELECTED)
						.break .if (eax == -1)
						invoke ListView_DeleteItem( g_hListView, eax)
					.ENDW
				.ENDIF
			.ENDIF
		.ENDIF

	.ELSEIF (eax == WM_DESTROY)

		invoke	RevokeDragDrop, hwnd
		invoke	OleUninitialize
		invoke	PostQuitMessage,NULL

	.ELSE

		invoke	DefWindowProc,hwnd,uMsg,wParam,lParam
		ret

	.ENDIF
	xor 	eax,eax
	ret
	align 4

WndProc ENDP

;--- create listview child

CreateListView PROC hwnd:HWND

	LOCAL	lhwnd:HWND
	local	lpData[256]:BYTE
	local	lvc:LV_COLUMN

	DebugOut "CreateListView"

	invoke	CreateWindowEx,WS_EX_CLIENTEDGE,CStr("SysListView32"),\
				0,WS_CHILD+WS_VISIBLE+WS_BORDER+LVS_REPORT,\
				CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,\
				hwnd,0,g_hInstance,0
	mov 	lhwnd,eax

if ?MASM32
	mov 	lvc.imask,LVCF_FMT + LVCF_WIDTH + LVCF_TEXT + LVCF_SUBITEM
else
	mov 	lvc.mask_,LVCF_FMT + LVCF_WIDTH + LVCF_TEXT + LVCF_SUBITEM
endif    
	mov 	lvc.fmt,LVCFMT_LEFT
if ?MASM32
	mov 	lvc.lx,350
else
	mov 	lvc.cx_,350
endif
	mov 	lvc.iSubItem,0
	mov 	lvc.pszText,CStr("File Name")
	invoke	ListView_InsertColumn( lhwnd,0,addr lvc)
	mov 	eax,lhwnd
	ret
	align 4

CreateListView ENDP


;--- create a DROPFILES object from selected listview items
;--- returns object in eax and size in pdwSize


CreateHDrop proc uses ebx esi edi hWndLV:HWND, pdwSize:ptr DWORD

local	lvi:LVITEM
LOCAL	szPath[MAX_PATH]:BYTE

		invoke	GlobalAlloc,GPTR,SIZEOF DROPFILES
		mov 	edi,eax
		mov 	[edi].DROPFILES.pFiles,SIZEOF DROPFILES
		mov 	[edi].DROPFILES.fNC,0
		mov 	[edi].DROPFILES.fWide,0
		mov 	esi,-1
		mov 	ebx,SIZEOF DROPFILES
		.while (1)
			invoke	ListView_GetNextItem( hWndLV,esi,LVNI_SELECTED)
			.break .if (eax == -1)
			mov 	esi,eax
			mov 	lvi.iItem,eax
			mov 	lvi.iSubItem,0
			lea 	eax, szPath
			mov 	lvi.pszText,eax
			mov 	lvi.cchTextMax,SIZEOF szPath
if ?MASM32
			mov 	lvi.imask,LVIF_TEXT
else            
			mov 	lvi.mask_,LVIF_TEXT
endif            
			invoke	ListView_GetItem( hWndLV, addr lvi)

			invoke	lstrlen, ADDR szPath
			inc 	eax
			push	eax
			inc 	eax
			add 	eax,ebx
			invoke	GlobalReAlloc,edi,eax,GMEM_MOVEABLE or GMEM_ZEROINIT
			mov 	edi,eax
			add 	eax,ebx
			mov 	ecx,eax
			invoke	lstrcpy,ecx, ADDR szPath
			pop 	eax
			add 	ebx,eax
		.endw
		inc 	ebx
		mov ecx, pdwSize
		mov [ecx], ebx
		return edi
		align 4

CreateHDrop endp

end

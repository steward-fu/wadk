
;--------------------------------------------------------------------------
;--- this is a special version with 2 listviews in main window!
;--- Japheth 2005
;--------------------------------------------------------------------------

;**************************************************************************
;              WIN32ASM OLE/COM DragDrop Interfaces
;              by Random (c)2001 - norp74@hotmail.com
;*******DISCLAIMER*********************************************************
;Fill free to (re)use this code as you like, but please put a reference to 
;me and to those I thank below
;Please email me any bug/suggestion and any development/improvement you've
;made on this code
;I should not be held responsible for any damage that may derive from the 
;use of this code
;*******REFERENCES*********************************************************
;The DragDrop classes I wrote are mainly derived from the C++ source of 
;John Rennie (jrennie@cix.compulink.co.uk)
;The COM interface structure in assembler come from the incredible tutorial 
;written by Bill T.  (billasm@usa.net)
;**************************************************************************


	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nocref
	.nolist
	include windows.inc
	include commctrl.inc
	include shlobj.inc

	include unknwn.inc
	include oleidl.inc
	include objidl.inc
	include windowsx.inc
	include debugout.inc

	.cref
	.list

	include oledragdrop.inc

?PRIVATECF	equ 0	;0=CF_HDROP als clipboardformat, 1=privates format

ID_LV1	equ 0
ID_LV2	equ 1

;-----------------------------------------------------------------------------

;WinMain         PROTO :HINSTANCE,:HINSTANCE,:ptr byte,:DWORD
CreateListView  PROTO :HWND, :DWORD
CreateHDrop     PROTO :HWND, :ptr DWORD

	.data

g_hInstance      DWORD 0
g_hwndDropSource HWND 0
g_cbFormat       DWORD MYCBFORMAT

	.code


WinMainCRTStartup proc public
        invoke  GetModuleHandle,NULL
        mov     [g_hInstance],eax
        invoke  WinMain,[g_hInstance],NULL,NULL,SW_SHOWDEFAULT
        invoke  ExitProcess,eax
WinMainCRTStartup endp

WinMain PROC hInst:HINSTANCE, hPrevInst:HINSTANCE, CmdLine:LPSTR, CmdShow:DWORD

        LOCAL   hwnd:DWORD,wclass:WNDCLASSEX,msg:MSG

        mov     [wclass].cbSize,SIZEOF WNDCLASSEX
        mov     [wclass].style,CS_DBLCLKS
        mov     [wclass].lpfnWndProc,offset WndProc
        mov     [wclass].cbClsExtra,NULL
        mov     [wclass].cbWndExtra,NULL
        mov     eax,[hInst]
        mov     [wclass].hInstance, eax
        mov     [wclass].hbrBackground,COLOR_WINDOW
        mov     [wclass].lpszMenuName,NULL      ;IDR_MAINMENU
        mov     [wclass].lpszClassName,CStr("MM32")
        invoke  LoadIcon,NULL,IDI_APPLICATION
        mov     [wclass].hIcon, eax
        mov     [wclass].hIconSm, eax
        invoke  LoadCursor,NULL,IDC_ARROW
        mov     [wclass].hCursor, eax
        invoke  RegisterClassEx,ADDR wclass
        invoke  CreateWindowEx,NULL,CStr("MM32"),CStr("Random's OLE DragDrop FileStop"),\
                WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,700,400,\
                NULL,NULL,[hInst],NULL
        mov     [hwnd], eax
        invoke  ShowWindow,[hwnd],SW_NORMAL
        invoke  UpdateWindow,[hwnd]
        .WHILE TRUE
                invoke  GetMessage,ADDR msg,NULL,0,0
                .BREAK .IF (!eax)
                invoke  TranslateMessage,ADDR msg
                invoke  DispatchMessage,ADDR msg
        .ENDW
        mov     eax,[msg.wParam]
        ret
		align 4

WinMain ENDP


;--- main window proc


WndProc PROC hwnd:HWND, uMsg:DWORD, wParam:WPARAM, lParam:LPARAM

	LOCAL	dwSize:DWORD
	local	hDrop:HANDLE
    local	hwndLV:HWND
	LOCAL	pDropSource:LPDROPSOURCE
	LOCAL	pDropTarget:LPDROPTARGET
	LOCAL	pDataObject:LPDATAOBJECT
	LOCAL	deffect:DWORD
	LOCAL	rect:RECT
    local	lvi:LVITEM

	mov eax,uMsg

	.IF (eax == WM_CREATE)

		invoke	OleInitialize, NULL
;------------------- create 2 listviews and register them as drop target
		invoke	CreateListView,[hwnd], ID_LV1
        mov hwndLV, eax
		invoke	CreateCDropTarget, ADDR pDropTarget, hwndLV
		invoke	RegisterDragDrop, hwndLV, pDropTarget
		invoke	CreateListView,[hwnd], ID_LV2
        mov hwndLV, eax
		invoke	CreateCDropTarget, ADDR pDropTarget, hwndLV
		invoke	RegisterDragDrop, hwndLV, pDropTarget
if ?PRIVATECF
		invoke	RegisterClipboardFormat, CStr("japheth drag&drop")
        mov		g_cbFormat, eax
;--------------------- now fill the 1. listview, cause anything from
;--------------------- outside isn't accepted anymore
        invoke	GetDlgItem, hwnd, ID_LV1
        mov		hwndLV, eax
		mov 	lvi.mask_,LVIF_TEXT+LVIF_PARAM
		mov 	lvi.pszText,CStr("sample entry")
		mov 	lvi.iItem,0
		mov 	lvi.lParam,0
		mov 	lvi.iSubItem,0
		invoke	ListView_InsertItem( hwndLV,ADDR lvi)
endif

	.ELSEIF (eax == WM_SIZE)

		invoke	GetClientRect, hwnd, ADDR rect
;;		DebugOut "WM_SIZE %u, %u, %u, %u",rect.left, rect.top,rect.right,rect.bottom
        invoke GetDlgItem, hwnd, ID_LV1
        mov ecx, rect.bottom
        shr ecx, 1
        push ecx
		invoke	MoveWindow, eax, 0, 0, rect.right, ecx, TRUE
        invoke GetDlgItem, hwnd, ID_LV2
        pop ecx
        mov edx, ecx
		invoke	MoveWindow, eax, 0, ecx, rect.right, edx, TRUE

	.ELSEIF (eax == WM_NOTIFY)

		mov 	eax,lParam
		.IF (([eax].NM_LISTVIEW.hdr.code == LVN_BEGINDRAG) || \
			([eax].NM_LISTVIEW.hdr.code == LVN_BEGINRDRAG))

			invoke	CreateCDropSource, ADDR pDropSource
            mov ecx, lParam
			invoke	CreateHDrop, [ecx].NMHDR.hwndFrom, addr dwSize
			mov hDrop, eax
			invoke	CreateCDataObject, ADDR pDataObject, hDrop, dwSize

            mov ecx, lParam
			mov eax, [ecx].NMHDR.hwndFrom
            mov g_hwndDropSource, eax

			invoke	DoDragDrop, pDataObject, pDropSource, DROPEFFECT_MOVE or DROPEFFECT_COPY or DROPEFFECT_LINK, ADDR deffect
            mov g_hwndDropSource, NULL
			DebugOut "DoDragDrop returned %X, deffect=%X",eax, deffect
			push	eax
			invoke	vf(pDataObject, IDataObject, Release)
			invoke	vf(pDropSource, IDropSource, Release)
			pop 	eax
			.IF (eax == DRAGDROP_S_DROP)
				mov 	eax, deffect
				.IF (eax == DROPEFFECT_MOVE)
					.while (1)
			            mov ecx, lParam
						invoke ListView_GetNextItem( [ecx].NMHDR.hwndFrom,-1,LVNI_SELECTED)
						.break .if (eax == -1)
			            mov ecx, lParam
						invoke ListView_DeleteItem( [ecx].NMHDR.hwndFrom,eax)
					.ENDW
				.ENDIF
			.ENDIF
		.ENDIF

	.ELSEIF (eax == WM_DESTROY)

        invoke GetDlgItem, hwnd, ID_LV1
		invoke	RevokeDragDrop, eax
        invoke GetDlgItem, hwnd, ID_LV2
		invoke	RevokeDragDrop, eax
		invoke	OleUninitialize
		invoke	PostQuitMessage,NULL

	.ELSE

		invoke	DefWindowProc,hwnd,uMsg,wParam,lParam
		ret

	.ENDIF
	xor 	eax,eax
	ret
	align 4

WndProc ENDP

;--- create listview child

CreateListView PROC hwnd:HWND, id:DWORD

	LOCAL	lhwnd:HWND
	local	lpData[256]:BYTE
	local	lvc:LV_COLUMN

	DebugOut "CreateListView"

	invoke	CreateWindowEx,WS_EX_CLIENTEDGE,CStr("SysListView32"),\
				0,WS_CHILD+WS_VISIBLE+WS_BORDER+WS_VSCROLL+LVS_REPORT,\
				CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,\
				hwnd,id,g_hInstance,0
	mov 	lhwnd,eax

	mov 	lvc.mask_,LVCF_FMT + LVCF_WIDTH + LVCF_TEXT + LVCF_SUBITEM
	mov 	lvc.fmt,LVCFMT_LEFT
	mov 	lvc.cx_,350
	mov 	lvc.iSubItem,0
	mov 	lvc.pszText,CStr("File Name")
	invoke	ListView_InsertColumn( lhwnd,0,addr lvc)
	mov 	eax,lhwnd
	ret
	align 4

CreateListView ENDP


;--- create a DROPFILES object from selected listview items
;--- returns object in eax and size in pdwSize


CreateHDrop proc uses ebx esi edi hWndLV:HWND, pdwSize:ptr DWORD

local	lvi:LVITEM
LOCAL	szPath[MAX_PATH]:BYTE

		invoke	GlobalAlloc,GPTR,SIZEOF DROPFILES
		mov 	edi,eax
		mov 	[edi].DROPFILES.pFiles,SIZEOF DROPFILES
		mov 	[edi].DROPFILES.fNC,0
		mov 	[edi].DROPFILES.fWide,0
		mov 	esi,-1
		mov 	ebx,SIZEOF DROPFILES
		.while (1)
			invoke	ListView_GetNextItem( hWndLV,esi,LVNI_SELECTED)
			.break .if (eax == -1)
			mov 	esi,eax
			mov 	lvi.iItem,eax
			mov 	lvi.iSubItem,0
			lea 	eax, szPath
			mov 	lvi.pszText,eax
			mov 	lvi.cchTextMax,SIZEOF szPath
			mov 	lvi.mask_,LVIF_TEXT
			invoke	ListView_GetItem( hWndLV, addr lvi)

			invoke	lstrlen, ADDR szPath
			inc 	eax
			push	eax
			inc 	eax
			add 	eax,ebx
			invoke	GlobalReAlloc,edi,eax,GMEM_MOVEABLE or GMEM_ZEROINIT
			mov 	edi,eax
			add 	eax,ebx
			mov 	ecx,eax
			invoke	lstrcpy,ecx, ADDR szPath
			pop 	eax
			add 	ebx,eax
		.endw
		inc 	ebx
		mov ecx, pdwSize
		mov [ecx], ebx
		return edi
		align 4

CreateHDrop endp

end

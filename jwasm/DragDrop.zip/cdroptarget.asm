
.386
.model flat,stdcall
option casemap:none
option proc:private

	.nolist
	.nocref
	include windows.inc
	include commctrl.inc
    
	include windowsx.inc
	include unknwn.inc
	include ObjIdl.inc
	include OleIdl.inc
	include debugout.inc
if ?MASM32
	include kernel32.inc
	include user32.inc
    include ole32.inc
    include shell32.inc
endif
	.list
	.cref

	include oledragdrop.inc


; declare the interface prototype

;-----------------------------------------------------------------------------
; declare the object structure
CDropTarget struct
    ; interface object
    interface   IDropTarget  <?>
    ; object data
    cRef		dd          ?
    hwndLV		dd			?
	bAcceptDrop BOOLEAN		?
CDropTarget ends
;-----------------------------------------------------------------------------

QueryInterface proto :ptr CDropTarget, :REFIID, :ptr LPUNKNOWN
AddRef	proto :ptr CDropTarget
Release proto :ptr CDropTarget

	.data

externdef stdcall IID_IDropTarget: GUID 

;-----------------------------------------------------------------------------
	.const

; define the vtable
vtblIDropTarget label dword
    dd      offset QueryInterface
    dd      offset AddRef
    dd      offset Release
    dd      offset DragEnter
    dd      offset DragOver
    dd      offset DragLeave
    dd      offset Drop

	.code

__this	textequ <ebx>
_this	textequ <[__this].CDropTarget>

	MEMBER interface, cRef, bAcceptDrop, hwndLV

;//**********************************************************************
;// Implementation of the IDropTarget interface
;//**********************************************************************
;-----------------------------------------------------------------------------
;Constructor
;
CreateCDropTarget proc public uses __this esi edi  pobj:ptr ptr CDropTarget, hwndLV:HWND

	DebugOut "CreateCDropTarget"

    mov     eax, pobj
    mov     dword ptr [eax], NULL
;--------------------- allocate object
    invoke  LocalAlloc, LMEM_FIXED, sizeof CDropTarget
    or      eax, eax
    jnz     @1
;--------------------- alloc failed, so return
    mov     eax, E_OUTOFMEMORY
    jmp     exit
@1:

    mov     __this, eax
    mov     m_interface.lpVtbl, offset vtblIDropTarget
    mov     m_cRef, 0
    mov		eax, hwndLV
    mov		m_hwndLV, eax

    ;***********************************************

    ;***********************************************
;--------------------- Query the interface
    invoke  QueryInterface, __this, addr IID_IDropTarget, pobj
    cmp     eax, S_OK
    je      exit
;--------------------- error in QueryInterface, so free memory
    push    eax
    invoke  LocalFree, __this
    pop     eax

exit:
    ret
CreateCDropTarget endp

;-----------------------------------------------------------------------------
;IUnknown methods
;
QueryInterface proc pThis:ptr CDropTarget, riid:REFIID, ppv:ptr LPUNKNOWN

	DebugOut "IDropTarget::QueryInterface"

    invoke  IsEqualGUID, [riid], addr IID_IDropTarget
    test    eax,eax
    jnz     @F
    invoke  IsEqualGUID, [riid], addr IID_IUnknown
    test    eax,eax
    jnz     @F
    mov     eax, ppv
    mov     dword ptr [eax], 0
    mov     eax, E_NOINTERFACE
    jmp     exit
@@:
    mov		eax,pThis
    mov     ecx, ppv
    mov     dword ptr [ecx], eax
    invoke  AddRef, pThis
    mov     eax, S_OK
exit:
    ret
QueryInterface endp

AddRef proc pThis:ptr CDropTarget

	DebugOut "IDropTarget::AddRef"

	mov		eax,pThis
    inc     [eax].CDropTarget.cRef
    mov     eax, [eax].CDropTarget.cRef
    ret
AddRef endp

Release proc uses __this pThis:ptr CDropTarget

	DebugOut "IDropTarget::Release"

    mov		__this,pThis
    ; decrement the reference count
    dec     m_cRef
    mov     eax, m_cRef
    or      eax, eax
    jnz     @F
    ; free object
    invoke  LocalFree, __this
@@:
    ret
Release endp
;-----------------------------------------------------------------------------

;// Indicates that data in a drag operation has been dragged over our window that's a potential target

DragEnter proc uses __this pThis:ptr CDropTarget, pDataObject:ptr IDataObject, grfKeyState:DWORD, pt:POINTL, pdwEffect:ptr DWORD

	LOCAL	fe:FORMATETC

	DebugOut "IDropTarget::DragEnter"

	mov __this,pThis
	mov ecx, pdwEffect
	mov DWORD PTR [ecx],DROPEFFECT_COPY
;--- if DropSource hwnd is equal DropTarget hwnd, dont accept dropping    
	mov eax, m_hwndLV
    cmp eax, g_hwndDropSource
	je  refusedrop
;-------------- Check for a valid clipboard format in the data object
	mov fe.cfFormat, MYCBFORMAT
	mov fe.ptd, NULL
	mov fe.dwAspect, DVASPECT_CONTENT
	mov fe.lindex, -1
	mov fe.tymed, TYMED_HGLOBAL
	invoke	vf(pDataObject, IDataObject, QueryGetData), ADDR fe
	.IF (eax == S_OK)
		DebugOut "IDropTarget::DragEnter Drop accepted"
		mov m_bAcceptDrop, TRUE
	.else
refusedrop:    
		DebugOut "IDropTarget::DragEnter Drop refused"
		mov ecx, pdwEffect
		mov DWORD PTR [ecx],DROPEFFECT_NONE
		mov m_bAcceptDrop, FALSE
	.ENDIF
	mov eax,NOERROR
	ret
DragEnter endp

;// Indicates that the mouse was moved inside the window represented by this drop target

DragOver proc uses __this pThis:ptr CDropTarget, grfKeyState:DWORD, pt:POINTL, pdwEffect:ptr DWORD

	DebugOut "IDropTarget::DragOver"

	mov		__this, pThis
	mov 	ecx, pdwEffect
	.if (m_bAcceptDrop == FALSE)
		mov dword ptr [ecx], DROPEFFECT_NONE
		jmp @F
	.endif
;	mov 	eax,DWORD PTR [ecx]
;	cmp 	eax,DROPEFFECT_NONE 	;was set by DragEnter if data dragged is our own
;	je		@F
	mov 	DWORD PTR [ecx],DROPEFFECT_MOVE
	mov 	eax,[grfKeyState]
	and 	eax,MK_CONTROL
	or		eax,eax
	jz		@F
	mov 	DWORD PTR [ecx],DROPEFFECT_COPY
@@:
	mov 	eax,NOERROR
	ret
DragOver endp

;// Informs the drop target that the operation has left its window
DragLeave proc uses ebx pThis:ptr CDropTarget
	DebugOut "IDropTarget::DragLeave"
    mov     eax,NOERROR
    ret
DragLeave endp

;--- add an item to a listview
;*** pitem points to path of object

AddListViewItem PROC uses ebx edi hWndLV:HWND, pitem:ptr byte

	LOCAL	lpData[256]:BYTE
	local	psfi:SHFILEINFO
	local	lvi:LV_ITEM
	local	fTime:FILETIME
	local	sysTime:SYSTEMTIME

	DebugOut "AddListViewItem"

	mov 	edi,pitem
	invoke	SHGetFileInfo, edi, FILE_ATTRIBUTE_NORMAL,\
				ADDR psfi,SIZEOF psfi,\
				SHGFI_USEFILEATTRIBUTES+SHGFI_SYSICONINDEX+SHGFI_SMALLICON
	invoke	ImageList_Duplicate,eax
	invoke	ListView_SetImageList(hWndLV, eax, LVSIL_SMALL)
;---------------------- destroy previous image list associated with listview
	.IF (eax != 0)
		invoke	ImageList_Destroy,eax	
	.ENDIF
	mov 	eax,psfi.iIcon
	mov 	lvi.iImage,eax
	mov 	lvi.pszText,edi
if ?MASM32
	mov 	lvi.imask,LVIF_TEXT+LVIF_IMAGE+LVIF_PARAM+LVIF_STATE
else
	mov 	lvi.mask_,LVIF_TEXT+LVIF_IMAGE+LVIF_PARAM+LVIF_STATE
endif
	mov 	lvi.state,0
	mov 	lvi.stateMask,0
	invoke	ListView_GetItemCount(hWndLV)
	mov 	lvi.iItem,eax
	mov 	lvi.lParam,eax
	mov 	lvi.iSubItem,0
	invoke	ListView_InsertItem(hWndLV,ADDR lvi)
	ret

AddListViewItem ENDP

;--- insert dropped items into listview

DropList proc uses ebx esi edi hwndLV:HWND, pDataObject:LPDATAOBJECT

	LOCAL	LocalBuffer[MAX_PATH]:BYTE
	LOCAL	pEnumFORMATETC:LPENUMFORMATETC
	LOCAL	formatetc:FORMATETC
	LOCAL	stgmedium:STGMEDIUM
	LOCAL	d:DWORD
	
	DebugOut "OLE2ModuleDrop"

	;Get the format enumerator

	invoke	vf(pDataObject, IDataObject, EnumFormatEtc), DATADIR_GET, ADDR pEnumFORMATETC
	.IF (eax != S_OK)
		ret
	.ENDIF

	.while (1)
;---------------------------------- Enumerate the dropped formats
		invoke	vf(pEnumFORMATETC, IEnumFORMATETC, Next), 1, ADDR formatetc, ADDR d
		.break .if (eax != NOERROR)
		.break .if (d == 0)
		movzx	eax,[formatetc].cfFormat
		.IF (eax == MYCBFORMAT)
			mov 	eax,[formatetc].tymed
			.IF (eax == TYMED_HGLOBAL)
				mov 	[formatetc].cfFormat,MYCBFORMAT
				mov 	[formatetc].ptd,NULL
				mov 	[formatetc].dwAspect,DVASPECT_CONTENT
				mov 	[formatetc].lindex,-1
				mov 	[formatetc].tymed,TYMED_HGLOBAL

				invoke	vf(pDataObject, IDataObject, QueryGetData), ADDR formatetc
				.IF (eax == S_OK)
					invoke	vf(pDataObject, IDataObject, GetData), ADDR formatetc, ADDR stgmedium
					.IF (eax == S_OK)
						invoke	GlobalLock,[stgmedium].hGlobal
						mov 	ebx,eax
						invoke	DragQueryFile,ebx,-1,0,0
						mov 	edi,eax
						xor 	esi,esi
						.while (edi > 0)
							invoke	DragQueryFile,ebx,esi,ADDR LocalBuffer,SIZEOF LocalBuffer
							invoke	AddListViewItem, hwndLV, ADDR LocalBuffer
							inc 	esi
							dec 	edi
						.endw

						invoke	GlobalUnlock,[stgmedium].hGlobal
						invoke	ReleaseStgMedium,ADDR stgmedium
					.ENDIF
				.ENDIF
			.ENDIF
		.ENDIF
	.ENDW
;--------------------------- Release the format enumerator
	invoke	vf(pEnumFORMATETC, IEnumFORMATETC, Release)

	ret
	align 4

DropList endp

;// Instructs the drop target to paste the data that was just now dropped on it

Drop proc uses ebx pThis:ptr CDropTarget, pDataSource:ptr IDataSource, grfKeyState:DWORD, pt:POINTL, pdwEffect:ptr DWORD

	DebugOut "IDropTarget::Drop"
	mov		__this, pThis
    .if (m_bAcceptDrop)
	    invoke  DropList, m_hwndLV, pDataSource
    .endif
    mov     eax,NOERROR
    ret
Drop endp


	end

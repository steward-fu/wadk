
	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
    include windows.inc
	include unknwn.inc
	include ObjIdl.inc
	include OleIdl.inc
	include Ole2.inc
	include debugOut.inc
if ?MASM32
	include kernel32.inc
	include ole32.inc
endif
	.list
	.cref

	include oledragdrop.inc

;--- declare the object structure

CDataObject struct
    ; interface object
    interface   IDataObject  <?>
    ; object data
    cRef		dd          ?
    Data		dd          ?
    lenData		dd          ?
    FmtEtc		dd          ?
    NumFmtEtc	dd          ?
CDataObject ends
;-----------------------------------------------------------------------------

QueryInterface proto :ptr CDataObject, :REFIID, :ptr LPUNKNOWN
AddRef	proto :ptr CDataObject
Release proto :ptr CDataObject

	.data

externdef stdcall IID_IDataObject:GUID


	.const

; define the vtable

vtblIDataObject label dword
    dd      offset QueryInterface
    dd      offset AddRef
    dd      offset Release
    dd      offset GetData
    dd      offset GetDataHere
    dd      offset QueryGetData
    dd      offset GetCanonicalFormatEtc
    dd      offset SetData
    dd      offset EnumFormatEtc
    dd      offset DAdvise
    dd      offset DUnadvise
    dd      offset EnumDAdvise

	.code

__this	textequ <ebx>
_this	textequ <[__this].CDataObject>

	MEMBER interface, cRef, Data, lenData, FmtEtc, NumFmtEtc


;//**********************************************************************
;// Implementation of the IDataObject interface
;//**********************************************************************
;-----------------------------------------------------------------------------
;Constructor
;
CreateCDataObject proc public uses __this pobj:ptr ptr CDataObject, lpInitData:LPVOID, nInitData:DWORD

	DebugOut "CreateCDataObject"

;------------------- set *ppv to 0
	mov 	eax, [pobj]
	mov 	dword ptr [eax], 0
;------------------- allocate object
	invoke	LocalAlloc, LMEM_FIXED, sizeof CDataObject
	.if (eax == 0)
		ret
	.endif
	mov 	__this, eax
	mov 	m_interface.lpVtbl, offset vtblIDataObject
	mov 	m_cRef, 0

;------------------ allocate the data buffer
	mov 	eax, nInitData
	mov 	m_lenData, eax
	invoke	LocalAlloc, LMEM_FIXED, eax
	mov 	m_Data, eax
	invoke	CopyMemory, m_Data, lpInitData, m_lenData

;------------------ Allocate the FORMATETC to describe our data
	invoke	LocalAlloc, LMEM_FIXED, SIZEOF FORMATETC
	mov 	m_FmtEtc, eax

	mov 	(FORMATETC ptr [eax]).cfFormat,MYCBFORMAT

	mov 	(FORMATETC ptr [eax]).ptd,NULL
	mov 	(FORMATETC ptr [eax]).dwAspect,DVASPECT_CONTENT
	mov 	(FORMATETC ptr [eax]).lindex,-1
	mov 	(FORMATETC ptr [eax]).tymed, TYMED_HGLOBAL

	mov 	m_NumFmtEtc,1

;------------------ Now get interface & increment counter
	; Query the interface
	invoke	QueryInterface, __this, addr IID_IDataObject, pobj
	cmp 	eax, S_OK
	je		exit

	push	eax
	invoke	LocalFree, m_Data
	invoke	LocalFree, m_FmtEtc
	invoke	LocalFree, __this
	pop 	eax

exit:
	ret
CreateCDataObject endp

;-----------------------------------------------------------------------------
;*** IUnknown methods
;

QueryInterface proc pThis:ptr CDataObject, riid:REFIID, ppv:ptr LPUNKNOWN

	DebugOut "IDataObject::QueryInterface"

    invoke  IsEqualGUID, riid, addr IID_IDataObject
    test    eax,eax
    jnz     @F
    invoke  IsEqualGUID, riid, addr IID_IUnknown
    test    eax,eax
    jnz     @F
    mov     eax, ppv
    mov     dword ptr [eax], NULL
    mov     eax, E_NOINTERFACE
    jmp     exit
@@:
	mov		eax, pThis
    mov     ecx, ppv
    mov     dword ptr [ecx], eax
    invoke  AddRef, pThis
    mov     eax, S_OK
exit:
    ret

QueryInterface endp

AddRef proc pThis:ptr CDataObject

	DebugOut "IDataObject::AddRef"
	mov		eax,pThis
    inc     [eax].CDataObject.cRef
    mov     eax, [eax].CDataObject.cRef
    ret
AddRef endp

Release proc uses __this pThis:ptr CDataObject

	DebugOut "IDataObject::Release"

	mov		__this, pThis
    dec     m_cRef
;---------------------------- if reference count is zero destroy the object
	mov		eax, m_cRef
    .if (eax == 0)
;---------------------------- free allocated data
        invoke  LocalFree, m_Data
        invoke  LocalFree, m_FmtEtc
;---------------------------- free the object
	    invoke  LocalFree, __this
	.endif
    ret
Release endp

;-----------------------------------------------------------------------------
;*** Retrieves data described by a specific FormatEtc into a StgMedium allocated by this function

GetData proc uses __this pThis:ptr CDataObject, pFE:ptr FORMATETC, pSTM:ptr STGMEDIUM

        LOCAL   handle:DWORD

		DebugOut "IDataObject::GetData"

        mov		__this,pThis
;----------------------------- Check the aspects we support.
        mov     ecx, pFE
        mov     eax, [ecx].FORMATETC.dwAspect
        and     eax,DVASPECT_CONTENT
        test    eax,eax
        jnz     @F
        mov     eax,DATA_E_FORMATETC
        jmp     exit
@@:
;----------------------------- this object only contains DROPFILE structure
        movzx   eax, [ecx].FORMATETC.cfFormat
        cmp     eax,MYCBFORMAT
        je      @F
        mov     eax,DATA_E_FORMATETC
        jmp     exit
@@:
;----------------------------- copy our data for the dragtarget
        invoke  GlobalAlloc, GMEM_SHARE or GMEM_MOVEABLE, m_lenData
        test    eax,eax
        jnz     @F
        mov     eax,STG_E_MEDIUMFULL
        jmp     exit
@@:
        mov     handle, eax
        invoke  GlobalLock, eax
        invoke  CopyMemory, eax, m_Data, m_lenData
        invoke  GlobalUnlock, handle
;----------------------------- put the data in the storage medium
        mov     ecx, pSTM
        mov     eax, handle
        mov     [ecx].STGMEDIUM.hGlobal, eax
        mov     [ecx].STGMEDIUM.tymed, TYMED_HGLOBAL
        mov     [ecx].STGMEDIUM.pUnkForRelease, NULL
        mov     eax, NOERROR
exit:
        ret
GetData endp

;-----------------------------------------------------------------------------
;*** Renders the specific FormatEtc into caller-allocated medium provided in pSTM

GetDataHere proc uses ebx pThis:ptr CDataObject, pFE:DWORD, pSTM:DWORD

		DebugOut "IDataObject::GetDataHere"
        mov     eax,E_NOTIMPL
        ret
GetDataHere endp

;-----------------------------------------------------------------------------
;*** Tests if a call to GetData with this FormatEtc will provide any rendering

QueryGetData proc uses ebx pThis:ptr CDataObject, pFE:ptr FORMATETC

		DebugOut "IDataObject::QueryGetData"

		mov		__this, pThis
;--------------------- Check the aspects we support.
        mov     ecx, pFE
        mov     eax, [ecx].FORMATETC.dwAspect
        and     eax,DVASPECT_CONTENT
        test    eax,eax
        jnz     @F
        mov     eax,DATA_E_FORMATETC
        jmp     exit
@@:
;--------------------- this object only contains text
        movzx   eax, [ecx].FORMATETC.cfFormat
        cmp     eax,MYCBFORMAT
        jne     @F
        mov     eax,NOERROR
        jmp     exit
@@:
        mov     eax,S_FALSE
exit:
        ret
QueryGetData endp

;-----------------------------------------------------------------------------
;*** Provides the caller with an equivalent FormatEtc to the one provided

GetCanonicalFormatEtc proc uses ebx esi edi pThis:ptr CDataObject, pFEIn:ptr FORMATETC, pFEOut:ptr FORMATETC

		DebugOut "IDataObject::GetCanonicalFormatEtc"

        mov     esi, pFEIn
        mov     edi, pFEOut
        mov     ecx, SIZEOF FORMATETC
		mov		edx, edi
        rep     movsb
        mov     [edx].FORMATETC.ptd, NULL
        mov     eax, DATA_S_SAMEFORMATETC
        ret
GetCanonicalFormatEtc endp

;-----------------------------------------------------------------------------
;*** Places data described by a FormatEtc and living in a StgMedium into the object

SetData proc uses ebx pThis:ptr CDataObject, pFE:ptr FORMATETC, pSTM:ptr STGMEDIUM, fRelease:BOOL

		DebugOut "IDataObject::SetData"

        mov     eax,E_NOTIMPL
        ret
SetData endp

;-----------------------------------------------------------------------------
;*** Returns an IEnumFORMATETC object through which the caller can iterate
;*** to learn about all the data formats this object can provide

EnumFormatEtc proc uses __this pThis:ptr CDataObject, dwDir:DWORD, ppEnum:ptr ptr IEnumFORMATETC

LOCAL   pEnumFORMATETC:LPENUMFORMATETC

		DebugOut "IDataObject::EnumFormatEtc"

        mov		__this,pThis

        .IF     ((dwDir == DATADIR_GET) || (dwDir == DATADIR_SET))
                invoke  CreateCEnumFORMATETC,ADDR pEnumFORMATETC, __this, 1, m_FmtEtc
                mov     eax, pEnumFORMATETC
        .ELSE
                xor     eax,eax
        .ENDIF
        mov     ecx, ppEnum
        mov     DWORD PTR [ecx], eax
        or      eax,eax
        jnz     @F
        mov     eax,E_FAIL
        jmp     exit
@@:
        mov     eax, NOERROR
exit:
        ret
EnumFormatEtc endp

DAdvise proc uses __this pThis:ptr CDataObject, pFE:ptr FORMATETC, dwFlags:DWORD, pIAdviseSink:LPADVISESINK, pdwConn:ptr DWORD

		DebugOut "IDataObject::DAdvise"

;        mov     eax,E_OUTOFMEMORY
        mov     eax,E_NOTIMPL
        ret
DAdvise endp

DUnadvise proc uses __this pThis:ptr CDataObject, dwConn:DWORD

		DebugOut "IDataObject::DUnadvise"
        mov     eax,E_FAIL
        ret
DUnadvise endp

EnumDAdvise proc uses __this pThis:ptr CDataObject, ppEnum:ptr ptr IEnumSTATDATA

		DebugOut "IDataObject::EnumDAdvise"

;        mov     eax,E_FAIL
		mov     eax,OLE_E_ADVISENOTSUPPORTED 
        ret
EnumDAdvise endp
;-----------------------------------------------------------------------------
;//**********************************************************************

	end

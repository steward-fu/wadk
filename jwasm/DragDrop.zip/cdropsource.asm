
	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc

	include unknwn.inc
	include ObjIdl.inc
	include OleIdl.inc
	include debugout.inc
if ?MASM32
	include kernel32.inc
	include ole32.inc
endif
	.list
	.cref

	include oledragdrop.inc

; declare the object structure
CDropSource struct
    ; interface object
    interface   IDropSource  <?>
    ; object data
    cRef      dd          ?
CDropSource ends

QueryInterface proto :ptr CDropSource, :REFIID, :ptr LPUNKNOWN
AddRef	proto :ptr CDropSource
Release proto :ptr CDropSource

	.const

externdef stdcall IID_IDropSource: IID

;-----------------------------------------------------------------------------
; define the vtable

vtblIDropSource label dword
    dd      offset QueryInterface
    dd      offset AddRef
    dd      offset Release
    dd      offset QueryContinueDrag
    dd      offset GiveFeedback

	.code

__this	textequ <ebx>
_this	textequ <[__this].CDropSource>

	MEMBER interface, cRef

;//**********************************************************************
;// Implementation of the IDropSource interface
;//**********************************************************************
;-----------------------------------------------------------------------------
;Constructor
;
CreateCDropSource proc public uses __this pobj:ptr ptr CDropSource

	DebugOut "CreateCDropSource"

    mov     eax, pobj
    mov     dword ptr [eax], NULL
    invoke  LocalAlloc, LMEM_FIXED, sizeof CDropSource
	.if (eax == 0)
		return E_OUTOFMEMORY
	.endif

    mov     __this, eax
    mov     m_interface.lpVtbl, offset vtblIDropSource
    mov     m_cRef, 0

    invoke  QueryInterface, __this, addr IID_IDropSource, pobj
	.if (eax != S_OK)
	    push    eax
		invoke  LocalFree, __this
		pop     eax
	.endif
exit:
    ret
CreateCDropSource endp

;-----------------------------------------------------------------------------

QueryInterface proc pThis:ptr CDropSource, riid:REFIID, ppv:ptr LPUNKNOWN

	DebugOut "CDropSource::QueryInterface"

    invoke  IsEqualGUID, riid, addr IID_IDropSource
    test    eax,eax
    jnz     @F
    invoke  IsEqualGUID, riid, addr IID_IUnknown
    test    eax,eax
    jnz     @F
    mov     eax, ppv
    mov     dword ptr [eax], 0
    mov     eax, E_NOINTERFACE
    jmp     exit
@@:
    mov		eax,pThis
    mov     ecx, ppv
    mov     dword ptr [ecx], eax
	invoke  AddRef, pThis
    mov     eax, S_OK
exit:
    ret
QueryInterface endp

AddRef proc pThis:ptr CDropSource

	DebugOut "CDropSource::AddRef"

    mov		eax,pThis
    inc     [eax].CDropSource.cRef
    mov     eax, [eax].CDropSource.cRef
    ret
AddRef endp

Release proc uses __this pThis:ptr CDropSource

	DebugOut "CDropSource::Release"

    mov		__this, pThis
    dec     m_cRef
    mov     eax, m_cRef
	.if (!eax)
	    invoke  LocalFree, __this
	.endif
    ret
Release endp

;-----------------------------------------------------------------------------
;//  Determines whether to continue a drag operation or cancel it.

QueryContinueDrag proc uses ebx pThis:ptr CDropSource, fEsc:DWORD, grfKeyState:DWORD
	
		DebugOut "CDropSource::QueryContinueDrag"

        mov     eax, fEsc
        test    eax, eax
        jz      @F
        mov     eax, DRAGDROP_S_CANCEL   ;to stop the drag
        jmp     exit
@@:
        mov     eax, grfKeyState
        and     eax, MK_LBUTTON or MK_RBUTTON
        test    eax,eax
        jnz     @F
        mov     eax, DRAGDROP_S_DROP    ;to drop the data where it is
        jmp     exit
@@:
        mov     eax, S_OK
exit:
        ret
QueryContinueDrag endp

;//  Provides cursor feedback to the user

GiveFeedback proc uses ebx pThis:ptr CDropSource, dwEffect:DWORD

		DebugOut "CDropSource::GiveFeedback"

        mov     eax, DRAGDROP_S_USEDEFAULTCURSORS
        ret
GiveFeedback endp

		end



	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

;*** here interface IClassFactory is implemented

	include MainPrg.inc

CClassFactory struct
vtbl			dd ?
m_ObjRefCount	dd ?
CClassFactory ends

	.const

CClassFactoryVtbl IClassFactoryVtbl {QueryInterface@IClassFactory,\
	AddRef@IClassFactory,Release@IClassFactory,CreateInstance,LockServer}

	.code

Create@CClassFactory PROC public		; constructor ClassFactory

    DebugOut "Create@CClassFactory"

	invoke LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CClassFactory
	.if (eax == NULL)
		ret
	.endif

	mov [eax].CClassFactory.vtbl,OFFSET CClassFactoryVtbl

	inc g_DllRefCount

	mov [eax].CClassFactory.m_ObjRefCount, 1

	ret
Create@CClassFactory ENDP


Destroy@CClassFactory PROC this_:ptr CClassFactory

    DebugOut "Destroy@CClassFactory"

	invoke LocalFree, this_

	dec g_DllRefCount

	ret
Destroy@CClassFactory ENDP		

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IClassFactory,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface@IClassFactory PROC this_:ptr CClassFactory,riid:ptr IID,ppReturn:ptr

	DebugOut "IClassFactory::QueryInterface"

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  this_, ppReturn
	ret

QueryInterface@IClassFactory ENDP


AddRef@IClassFactory PROC this_:ptr CClassFactory

	DebugOut "IClassFactory::AddRef"

	mov eax, this_
	inc [eax].CClassFactory.m_ObjRefCount
	mov eax, [eax].CClassFactory.m_ObjRefCount
	ret

AddRef@IClassFactory ENDP


Release@IClassFactory PROC this_:ptr CClassFactory

	DebugOut "IClassFactory::Release"

	mov eax, this_
	dec [eax].CClassFactory.m_ObjRefCount

	mov eax,[eax].CClassFactory.m_ObjRefCount
	.if (eax == 0)
		invoke Destroy@CClassFactory, this_
		xor eax,eax
	.endif
	ret

Release@IClassFactory ENDP


CreateInstance PROC this_:ptr CClassFactory, pUnknown:ptr,riid:ptr IID,ppObject:ptr ptr

local	pIF:LPUNKNOWN
local	hResult:dword

	DebugOut "IClassFactory::CreateInstance"

	mov eax, ppObject
	mov DWORD PTR [eax], 0

	.if (pUnknown != NULL)
		return CLASS_E_NOAGGREGATION
	.endif

;------------------------------------ here's the one place to modify
;------------------------------------ call constructor of main class
	invoke Create@CShellPropSheetExt
	.if (eax == NULL)
		return E_OUTOFMEMORY
	.endif
	mov pIF,eax

	invoke vf(pIF,IUnknown,QueryInterface),riid,ppObject
	mov hResult, eax

	invoke vf(pIF,IUnknown,Release)

	return hResult

CreateInstance ENDP


LockServer PROC this_:ptr CClassFactory, bLockServer:dword

	DebugOut "IClassFactory::LockServer"

	.if (bLockServer)
		inc g_DllRefCount
	.else
		dec g_DllRefCount
	.endif
	return S_OK

LockServer ENDP

END



	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	include MainPrg.inc

	.code

;*** scan interface tab and see if requested iface is in there
;*** return valid ptr or NULL

IsInterfaceSupported proc public uses ebx esi edi pReqIF:ptr IID, pIFTab:ptr ptr IID, dwEntries:dword, pThis:ptr, ppReturn:ptr LPUNKNOWN
	
	mov ecx,dwEntries
	mov esi,pIFTab
	mov ebx,0
	.while (ecx)
		lodsd
		mov edi,eax
		lodsd
		mov edx,eax
		mov eax,esi
		mov esi,pReqIF
		push ecx
		mov ecx,4
		repz cmpsd
		pop ecx
		.if (ZERO?)
			mov ebx,edx
			add ebx,pThis
			.break
		.endif
		mov esi,eax
		dec ecx
	.endw
	mov ecx,ppReturn
	mov [ecx],ebx

	.if (ebx)
		invoke vf(ebx,IUnknown,AddRef)
		mov eax,S_OK
	.else
		mov eax,E_NOINTERFACE
	.endif
	ret
	align 4

IsInterfaceSupported endp



SaveGlobalSettings PROC public

	return TRUE

SaveGlobalSettings ENDP				; SaveGlobalSettings


GetGlobalSettings PROC public

	return TRUE

GetGlobalSettings ENDP


WideCharToLocal PROC public pLocal:LPSTR, pWide:LPWSTR, dwChars:DWORD

	mov	eax, pLocal
	mov	BYTE PTR [eax], 0

ifdef UNICODE
	invoke lstrcpyn, pLocal, pWide, dwChars
else
	invoke WideCharToMultiByte, CP_ACP, 0, pWide, -1, pLocal, dwChars, NULL, NULL
endif

	invoke lstrlen, pLocal

	ret
WideCharToLocal ENDP



LocalToWideChar PROC public pWide:LPWSTR, pLocal:LPSTR,  dwChars:DWORD

	mov	eax, pWide
	mov	WORD PTR [eax], 0

ifdef UNICODE
	invoke lstrcpyn, pWide, pLocal, dwChars
else
	invoke MultiByteToWideChar, CP_ACP, 0, pLocal, -1, pWide, dwChars
endif

	invoke lstrlenW, pWide

	ret
LocalToWideChar ENDP

;*** delete a registry entry with all its subkeys

DeleteKeyWithSubKeys proc public uses ebx hKey:HKEY,pszKey:ptr byte

local	szKey[MAX_PATH]:byte
local	hSubKey:HANDLE
local	filetime:FILETIME
local	dwSize:dword

		invoke RegOpenKeyEx,hKey,pszKey,NULL,KEY_ALL_ACCESS,addr hSubKey
		.if (eax == ERROR_SUCCESS)
			mov ebx,0
			.while (1)
				mov dwSize,sizeof szKey
				invoke RegEnumKeyEx,hSubKey,ebx,addr szKey,addr dwSize,NULL,NULL,NULL,addr filetime
				.break .if (eax != ERROR_SUCCESS)
				invoke DeleteKeyWithSubKeys,hSubKey,addr szKey
			.endw							
			invoke RegCloseKey,hSubKey
		.endif
		invoke RegDeleteKey,hKey,pszKey		;and delete subkey
		ret

DeleteKeyWithSubKeys endp

	END

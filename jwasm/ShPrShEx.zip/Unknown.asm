
    .386
    .MODEL	FLAT, STDCALL
    option	casemap:none
    option  proc:private

;---- implements interface IUnknown

    include MainPrg.inc

	.code

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IShellExtInit,offset CShellPropSheetExt.vtblIShellExtInit
	dd offset IID_IShellPropSheetExt,offset CShellPropSheetExt.vtblIShellPropSheetExt
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface PROC public pThis:ptr CShellPropSheetExt,riid:ptr IID,ppReturn:ptr

ifdef _DEBUG
local	szIID[40]:byte
local	wszIID[40]:word
local	szKey[128]:byte
local	dwSize:DWORD
local	hKey:HANDLE
endif

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn

ifdef _DEBUG
;-------------------------- print the name of the interface we have just been queried
    push eax
	invoke StringFromGUID2,riid, addr wszIID,40
	invoke WideCharToMultiByte, CP_ACP, 0, addr wszIID, -1, addr szIID, 40, NULL, NULL
	invoke wsprintf, addr szKey, CStr("Interface\%s"),addr szIID
	invoke RegOpenKeyEx, HKEY_CLASSES_ROOT, addr szKey, 0, KEY_READ, addr hKey 
	.if (eax == ERROR_SUCCESS)
		mov dwSize, sizeof szKey
		invoke RegQueryValueEx,hKey,CStr(""),NULL,NULL,addr szKey,addr dwSize
		invoke RegCloseKey, hKey
	.else
		mov szKey,0
	.endif
    pop eax
	DebugOut "IUnknown::QueryInterface(%s[%s])=%X", addr szIID, addr szKey, eax
endif

	ret

QueryInterface ENDP 

AddRef PROC public pThis:ptr CShellPropSheetExt

	mov eax,pThis
	inc [eax].CShellPropSheetExt.ObjRefCount
	mov	eax, [eax].CShellPropSheetExt.ObjRefCount
	ret
AddRef ENDP			

Release PROC public pThis:ptr CShellPropSheetExt

	mov eax,pThis
	dec [eax].CShellPropSheetExt.ObjRefCount
	mov eax,[eax].CShellPropSheetExt.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CShellPropSheetExt,pThis
		xor eax,eax
	.endif
	ret

Release ENDP

	end


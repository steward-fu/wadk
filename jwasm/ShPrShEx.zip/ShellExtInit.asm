
	.386
	.MODEL FLAT, STDCALL
	option casemap:none
	option proc:private

;--- implements IShellExtInit interface

	include MainPrg.inc

__this	textequ <ebx>
_this	textequ <[__this].CShellPropSheetExt>

	MEMBER ObjRefCount, szFile

	.const

CShellPropSheetExt@IShellExtInit@Vtbl IShellExtInitVtbl {QueryInterface, AddRef, Release,\
		Initialize}

	.code

Initialize proc uses __this this_:ptr CShellPropSheetExt,
					pidlFolder:DWORD, pDataObj:LPDATAOBJECT, hProgID:HKEY
;--------------------------------------------------------------------------
; Initializes
;
;--------------------------------------------------------------------------
  LOCAL fmt:FORMATETC
  LOCAL stg:STGMEDIUM
  LOCAL hDrop:DWORD
  LOCAL hResult:DWORD
 
	DebugOut "CShellPropSheetExt::Initialize"
  
	mov __this, this_
	
	mov hResult, E_INVALIDARG
	mov stg.hGlobal, NULL

	mov fmt.cfFormat, CF_HDROP 
	mov fmt.ptd, NULL
	mov fmt.dwAspect, DVASPECT_CONTENT
	mov fmt.lindex, -1
	mov fmt.tymed, TYMED_HGLOBAL 

;--------------------------------- Initialization of stg (useless)
	mov stg.tymed, TYMED_HGLOBAL

;--------------------------------- Look for CF_HDROP data in the data object.
	invoke vf(pDataObj, IDataObject, GetData), addr fmt, addr stg
	.IF FAILED(eax)
;--------------------------------- Nope! return an "invalid argument" error back to Explorer.
		jmp exit
	.endif
  
	.if stg.hGlobal == NULL
		jmp exit
	.endif

;--------------------------------- Sanity check to make sure there is at least one filename.
	invoke DragQueryFile, stg.hGlobal, 0FFFFFFFFh, NULL, 0
	.if !eax
		jmp exit
	.endif

;--------------------------------- Get the name of the first file and store it in our member variable m_szFile
	invoke DragQueryFile, stg.hGlobal, 0, addr m_szFile, MAX_PATH
	.if (!eax)
		mov hResult, E_INVALIDARG
		jmp exit
	.endif
	lea ecx,m_szFile
	mov eax,[ecx+eax-4]
	or eax,20202020h
;--------------------------------- show sheet for dlls only
	.if (eax == "lld.")
		mov hResult, S_OK
	.endif

exit:
	.if (stg.hGlobal)
		invoke ReleaseStgMedium, addr stg
	.endif
	return hResult
Initialize endp

	end

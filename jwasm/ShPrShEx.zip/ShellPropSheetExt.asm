
	.386
	.MODEL FLAT, STDCALL
	option casemap:none
	option proc:private

;--- implements interface IShellPropSheetExt

	include MainPrg.inc

IDD_DIALOG1 equ 100
IDC_LIST1	equ 1002

	.data

g_ObjectCount dd 1

	.const

;--- vtbl of IShellPropSheetExt

CShellPropSheetExt@IShellPropSheetExt@Vtbl IShellPropSheetExtVtbl {\
		QueryInterface_, AddRef_, Release_,	AddPages, ReplacePage}

__this	textequ <ebx>
_this	textequ <[__this].CShellPropSheetExt>

	MEMBER ObjRefCount, szFile

	.code

;--- IShellPropSheetExt isn't the first vtbl in object
;--- so we need some this_ ptr adjustments

CastOffset textequ <offset CShellPropSheetExt.vtblIShellPropSheetExt>

;--- this macro generates QueryInterface_, AddRef_ & Release_ stubs

	@MakeIUnknownStubs CastOffset

FNADDPROPSHEETPAGE typedef proto :HANDLE, :LPARAM
LPFNADDPROPSHEETPAGE typedef ptr FNADDPROPSHEETPAGE


AddPages proc uses __this this_:ptr CShellPropSheetExt, lpfnAddPage:LPFNADDPROPSHEETPAGE, lParam:DWORD

	LOCAL PropSheet:PROPSHEETPAGE
	LOCAL hPs:DWORD

	DebugOut "CShellPropSheetExt::AddPages"

	@AdjustThis
	mov __this,this_

	mov PropSheet.dwSize, sizeof PROPSHEETPAGE
	mov PropSheet.dwFlags, PSP_DEFAULT or PSP_USEREFPARENT or PSP_USETITLE 
	mov eax,g_hInstance
	mov PropSheet.hInstance, eax
	mov PropSheet.pResource, IDD_DIALOG1
	mov PropSheet.pszIcon, 0			;MainIcon
	mov PropSheet.pfnDlgProc, offset TabDlgProc
	mov PropSheet.pszTitle, CStr("ASM")

;----------------------------------- transfer filename to dlg proc

	invoke lstrlen, addr m_szFile
	inc eax
	invoke LocalAlloc, LMEM_FIXED, eax
	mov PropSheet.lParam, eax
	invoke lstrcpy, PropSheet.lParam, addr m_szFile

	mov PropSheet.pfnCallback, 0
;--------------------- prevent DLL from being unloaded while sheet is active
	mov PropSheet.pcRefParent,offset g_DllRefCount

	invoke CreatePropertySheetPage, ADDR PropSheet
	mov hPs, eax
	
	invoke lpfnAddPage, hPs, lParam

	.IF (eax==0)
		invoke DestroyPropertySheetPage, hPs
		mov eax, 0
		ret
	.ENDIF

	mov eax, S_OK

	ret
AddPages endp



ReplacePage proc uses __this this_:ptr CShellPropSheetExt, uPageID:DWORD, pfnReplacePage:DWORD, lParam:DWORD

	DebugOut "CShellPropSheetExt::ReplacePage"

	@AdjustThis
	mov __this,this_

	mov eax, E_NOTIMPL
	ret
ReplacePage endp

;--- fill the list view with some information about the current file

FillList proc hWndLV:HWND, pszName:LPSTR

	invoke LocalFree, pszName
	ret
FillList endp

;--- this is the dialog proc for our property sheet
;--- you cannot access members of CShellPropSheetExt here
;--- because it may be destroyed already. WM_INITDIALOG may be an exception

TabDlgProc proc hWnd:HWND, uMsg:DWORD, wParam:DWORD, lParam:DWORD

	.IF (uMsg==WM_INITDIALOG)
		invoke GetDlgItem, hWnd, IDC_LIST1
		mov ecx,lParam
		invoke FillList, eax, [ecx].PROPSHEETPAGE.lParam
		mov eax, 1
		ret
	.else
		xor eax,eax
	.ENDIF
	ret
TabDlgProc endp

	end

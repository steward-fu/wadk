
    .386
    .MODEL FLAT, STDCALL
    option casemap:none
    option proc:private

;*** this is the main file, contains
;*** constructor/destructor of class CShellPropSheetExt
;*** also defined here:
;*** DllMain, DllRegisterServer, DllUnregisterServer,
;*** DllGetClassObject, DllCanUnloadNow

	include MainPrg.inc

    includelib kernel32.lib
    includelib comdlg32.lib
    includelib user32.lib
    includelib gdi32.lib
    includelib comctl32.lib
    includelib shell32.lib
    includelib advapi32.lib
    includelib oleaut32.lib
    includelib ole32.lib


DESCRIPTION textequ <"Shell Property Sheet Extension in ASM">

    .DATA

g_hInstance		HINSTANCE 0
g_DllRefCount	DD 0

    .const

STRING_SHELLEXT db "*\ShellEx\PropertySheetHandlers",0
STRING_APPROVED db "Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved",0


CLSID_ShellExtPropSheet		GUID <0F5804B4Fh, 0E5A7h, 04129h,<0bbh, 03fh, 0fch, 0ah, 033h, 07ah, 09ch, 051h>>

;--------- dispatch interface IID and typelibrary GUID not needed here
;IID_ShellExtPropSheet		GUID <0F5804B4Eh, 0E5A7h, 04129h,<0bbh, 03fh, 0fch, 0ah, 033h, 07ah, 09ch, 051h>>
;LIBID_ShellExtPropSheet	GUID <0F5804B4Dh, 0E5A7h, 04129h,<0bbh, 03fh, 0fch, 0ah, 033h, 07ah, 09ch, 051h>>

	.CODE

__this	textequ <ebx>
_this	textequ <[__this].CShellPropSheetExt>

	MEMBER vtblIShellExtInit, vtblIShellPropSheetExt
	MEMBER ObjRefCount, szFile


;*** constructor of CShellPropSheetExt, called from IClassFactory::CreateInstance


Create@CShellPropSheetExt proc public uses __this

    DebugOut "Create@CShellPropSheetExt"

	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CShellPropSheetExt
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

;------------------------------- init vtbls
	mov m_vtblIShellExtInit,		OFFSET CShellPropSheetExt@IShellExtInit@Vtbl
	mov m_vtblIShellPropSheetExt,	OFFSET CShellPropSheetExt@IShellPropSheetExt@Vtbl

	inc g_DllRefCount

	mov m_ObjRefCount,1

	return __this

Create@CShellPropSheetExt endp


;*** destructor of CShellPropSheetExt, hopefully called from IUnknown::Release()


Destroy@CShellPropSheetExt PROC public uses __this this_:ptr CShellPropSheetExt

    DebugOut "Destroy@CShellPropSheetExt"

	mov __this,this_

	invoke LocalFree, __this

	dec g_DllRefCount

	ret

Destroy@CShellPropSheetExt ENDP


;--------------------------------------------------------------


DllMain PROC public hInstance:HINSTANCE, dwReason:dword, lpReserved:dword

    DebugOut "ShPrShEx.dll: DllMain(%X)", dwReason

	mov eax, dwReason
	.if (eax == DLL_PROCESS_ATTACH)
		mov ecx, hInstance
		mov g_hInstance, ecx
	.elseif (eax == DLL_PROCESS_DETACH)
	.endif
	mov eax, 1
	ret
DllMain ENDP

DllCanUnloadNow PROC public

    DebugOut "ShPrShEx.dll: DllCanUnloadNow, count=%u", g_DllRefCount

	xor eax, eax
	cmp g_DllRefCount, eax
	setne al
	ret
DllCanUnloadNow ENDP

	.data

;--- a structure to simplify register & unregister task

REGSTRUCT struct
hRootKey		HANDLE ? ;
lpszSubKey		LPSTR  ? ;
lpszValueName   LPSTR  ? ;
lpszData		LPSTR  ? ;
REGSTRUCT ends

LPREGSTRUCT typedef ptr REGSTRUCT

ClsidEntries label REGSTRUCT
	REGSTRUCT <HKEY_CLASSES_ROOT,CStr("CLSID\%s"),0,CStr("Shell PropertySheet Extension in ASM")>
	REGSTRUCT <HKEY_CLASSES_ROOT,CStr("CLSID\%s\InprocServer32"),0,CStr("%s")>
	REGSTRUCT <HKEY_CLASSES_ROOT,CStr("CLSID\%s\InprocServer32"),CStr("ThreadingModel"),CStr("Apartment")>
	REGSTRUCT <HKEY_CLASSES_ROOT,CStr("CLSID\%s\DefaultIcon"),0,CStr("%s,0")>
NUMCLSIDENTRIES equ ($ - offset ClsidEntries) / sizeof REGSTRUCT

	.code

DllRegisterServer proc public uses ebx esi

local	i:dword
local	hKey:HANDLE
local	lResult:dword
local	dwDisp:dword
local	szSubKey[MAX_PATH]:byte
local	szCLSID[MAX_PATH]:byte
local	szModule[MAX_PATH]:byte
local	pwsz:LPWSTR
local	pMalloc:ptr
local	szData[MAX_PATH]:byte
local	dwData:dword
local	osvi:OSVERSIONINFO

	DebugOut "ShPrShEx.dll: DllRegisterServer"
;------------------------------------ get the CLSID in string form
	invoke StringFromIID,addr CLSID_ShellExtPropSheet, addr pwsz
	.if (pwsz)
		invoke WideCharToLocal, addr szCLSID, pwsz, sizeof szCLSID
;------------------------------------ free the string
		invoke CoGetMalloc,1,addr pMalloc
		.if (pMalloc)
			invoke vf(pMalloc,IMalloc,Free),pwsz
			invoke vf(pMalloc,IMalloc,Release)
		.endif
	.endif

;------------------------------ get this DLL's path and file name
	invoke GetModuleFileName,g_hInstance,addr szModule,sizeof szModule

;------------------------------ register the CLSID entries

	mov ebx,offset ClsidEntries
	assume ebx:ptr REGSTRUCT
	mov esi, NUMCLSIDENTRIES

	.while (esi)

;------------------------------ Create the sub key string.
		invoke wsprintf,addr szSubKey, [ebx].lpszSubKey, addr szCLSID

		invoke RegCreateKeyEx, [ebx].hRootKey,\
					addr szSubKey,0,NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, \
					NULL, addr hKey, addr dwDisp
		.if (eax == NOERROR)
;------------------------------ if necessary, create the value string
			invoke wsprintf, addr szData, [ebx].lpszData, addr szModule
			mov edx,eax
			inc edx
			invoke RegSetValueEx, hKey, [ebx].lpszValueName,\
						0, REG_SZ, addr szData, edx
			invoke RegCloseKey, hKey

		.else
			return SELFREG_E_CLASS
		.endif

		add ebx,sizeof REGSTRUCT
		dec esi
	.endw
	assume ebx:nothing

;------------------------------ Register the shell extension for all file types
    invoke lstrcpy, addr szSubKey, addr STRING_SHELLEXT
    invoke lstrcat, addr szSubKey, CStr("\")
    invoke lstrcat, addr szSubKey, addr szCLSID
	invoke RegCreateKeyEx, HKEY_CLASSES_ROOT, addr szSubKey,\
		0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, addr hKey, addr dwDisp
	.if (eax == NOERROR)
;------------------------------ Create the value string.
		invoke RegSetValueEx, hKey, CStr(""), 0, REG_SZ, CStr(DESCRIPTION), 26
		invoke RegCloseKey, hKey

	.else
		return SELFREG_E_CLASS
	.endif

;------------------------------ If running on NT, register the extension as approved.
	mov osvi.dwOSVersionInfoSize,sizeof osvi
	invoke GetVersionEx, addr osvi

	.if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)

		invoke RegCreateKeyEx, HKEY_LOCAL_MACHINE, addr STRING_APPROVED, 0, NULL, REG_OPTION_NON_VOLATILE,\
				KEY_WRITE, NULL, addr hKey, addr dwDisp
		.if (eax == NOERROR)
			invoke lstrcpy, addr szData, CStr(DESCRIPTION)
			invoke lstrlen, addr szData
			mov edx,eax
			inc eax
			invoke RegSetValueEx, hKey, addr szCLSID, 0, REG_SZ, addr szData, edx
			invoke RegCloseKey, hKey
		.else
			return SELFREG_E_CLASS
		.endif
	.endif

	return S_OK

DllRegisterServer endp

;--- unregister the server

DllUnregisterServer proc public uses ebx

local   fileTime:FILETIME
local	osvi:OSVERSIONINFO
local	hKey:HANDLE
local	lResult:dword
local	dwDisp:dword
local	szSubKey[MAX_PATH]:byte
local	szCLSID[40]:byte
local	wszCLSID[40]:word


    DebugOut "ShPrShEx.dll: DllUnregisterServer"
;------------------------------ get the CLSID in string form
	invoke StringFromGUID2,addr CLSID_ShellExtPropSheet, addr wszCLSID,40
	invoke WideCharToLocal, addr szCLSID, addr wszCLSID, sizeof szCLSID

	mov ebx,offset ClsidEntries
	assume ebx:ptr REGSTRUCT

	invoke wsprintf,addr szSubKey, [ebx].lpszSubKey, addr szCLSID
	invoke DeleteKeyWithSubKeys, HKEY_CLASSES_ROOT, addr szSubKey

;------------------------------ Unegister the shell extension for all file types
	invoke lstrcpy, addr szSubKey,	addr STRING_SHELLEXT
	invoke RegOpenKeyEx, HKEY_CLASSES_ROOT, addr szSubKey, NULL, KEY_ALL_ACCESS, addr hKey
	.if (eax == NOERROR)
		invoke RegDeleteKey, hKey, addr szCLSID
		invoke RegCloseKey, hKey

	.else
		return SELFREG_E_CLASS
	.endif

;------------------------------ If running on NT, unregister the extension as approved
	mov osvi.dwOSVersionInfoSize,sizeof osvi
	invoke GetVersionEx, addr osvi

	.if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)

        invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, addr STRING_APPROVED, NULL,\
		    KEY_SET_VALUE, ADDR hKey
		.if (eax == NOERROR)
            invoke RegDeleteValue, hKey, addr szCLSID
		    invoke RegCloseKey, hKey
        .endif
	.endif

	return S_OK

DllUnregisterServer endp

;--- the main entry, will create an IClassFactory object
;--- which in turn will create our CShellExtPropSheet object

DllGetClassObject PROC public rclsid:ptr CLSID,riid:ptr IID,ppReturn:ptr

local pClassFactory:ptr IClassFactory
local hResult:dword

    DebugOut "ShPrShEx.dll: DllGetClassObject"

	mov eax, ppReturn
	mov DWORD PTR [eax], 0

	invoke IsEqualGUID,rclsid,addr CLSID_ShellExtPropSheet
	.if (eax == 0)
		return CLASS_E_CLASSNOTAVAILABLE
	.endif

	invoke Create@CClassFactory
	.if (eax == NULL)
		return E_OUTOFMEMORY
	.endif
	mov pClassFactory,eax

	invoke vf(pClassFactory,IClassFactory,QueryInterface),riid,ppReturn
	mov	hResult, eax

	invoke vf(pClassFactory,IClassFactory,Release)

	return hResult

DllGetClassObject ENDP

End DllMain

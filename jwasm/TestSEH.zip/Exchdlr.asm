
;*** _except_handler3, called from system code
;*** the handler should be compatible to VC
;*** therefore names _except_handler3,_global_unwind2
;*** and _local_unwind2 are the same as in VC

	.386
	.MODEL FLAT,stdcall
	option casemap:none

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN equ 1
	include windows.inc
	include ntdll.inc
	include except.inc
	.list
	.cref

	.CODE

;RtlUnwind		proto :dword, :dword, :dword, :dword
_global_unwind2 proto near c pFrame:ptr FRAME
_local_unwind2	proto near c pFrame:ptr FRAME,index:dword


FRAME struct	; in fact an EXCEPTION_REGISTRATION record
				;  offs -12:ebp-28 <unknown>
				;  offs  -8:ebp-24 "normal" esp for this function
				;  offs  -4:ebp-20 will be filled with Exception_Info_Ptrs
pOldFrame	dd ?;  offs   0:ebp-16 old exception frameptr
pExcHandler	dd ?;  offs 1*4:ebp-12 exception handler
pScopeTbl	dd ?;  offs 2*4:ebp-08 ptr scopetable. filter function table (3 dwords each __try)
trylevel	dd ?;  offs 3*4:ebp-04 trylevel. index to filter function table)
FrameEBP	dd ?;  offs 4*4;ebp+00 old ebp (created by normal "push ebp" on function entry)
FRAME ends

p0proc typedef proto 
LPEXCEPTIONPROC typedef ptr p0proc

SCOPEENTRY	struct
iPrevIdx	dd ?
pFilter	LPEXCEPTIONPROC ?
pExcept LPEXCEPTIONPROC ?
SCOPEENTRY	ends

;*** a1=ptr EXCEPTION_RECORD
;*** a2=ptr FRAME (actual ptr in fs:[0])
;*** a3=ptr CONTEXT
;*** a4=dispatcher CONTEXT

_except_handler3 proc c uses ebx esi edi pReport:ptr EXCEPTION_RECORD,\
							pFrame:ptr FRAME,\
							pContext:ptr CONTEXT,\
							pContDisp:ptr CONTEXT

local  einfo:EXCEPTION_INFO_PTRS

	cld

	mov		ebx,pFrame
	mov		eax,pReport
	.if ([eax.EXCEPTION_RECORD.ExceptionFlags] & UNWIND)
		push ebp
		invoke _local_unwind2,ebx,-1
		pop ebp
		mov eax,_XCPT_CONTINUE_SEARCH
	.else
		mov einfo.preport,eax
		mov eax,pContext
		mov einfo.pcontext,eax
		lea eax,einfo
		mov dword ptr [ebx-4],eax
		mov esi,dword ptr [ebx.FRAME.trylevel]
		.while (esi != -1)
			mov ecx,dword ptr [ebx.FRAME.pScopeTbl]
			lea eax,[esi+esi*2]		;3 dwords for each _try block
			lea edi,[ecx+eax*4]
			.if ([edi].SCOPEENTRY.pFilter != NULL)
				push ebx
				push esi
				push edi
				push ebp
				lea ebp,dword ptr [ebx.FRAME.FrameEBP]	;setup ebp for locals access
				call [edi].SCOPEENTRY.pFilter
				pop ebp
				pop edi
				pop esi
				pop ebx
				or eax,eax
				.if (SIGN?)						;eax < 0
					mov eax,_XCPT_CONTINUE_EXECUTION
					jmp exit
				.elseif (!ZERO?)				;eax > 0 -> will handle exception

					invoke _global_unwind2,ebx
					invoke _local_unwind2,ebx,esi

					mov eax,[edi].SCOPEENTRY.iPrevIdx
					mov [ebx.FRAME.trylevel],eax
												;_except never returns!
					call [edi].SCOPEENTRY.pExcept
				.endif
			.endif
			mov esi,[edi].SCOPEENTRY.iPrevIdx
		.endw
		mov eax,_XCPT_CONTINUE_SEARCH
	.endif
exit:
	ret
_except_handler3 endp

	align 4

externdef _gu_return:proc 

_global_unwind2 proc c pFrame:ptr FRAME
	push ebx
	push esi
	push edi
	push ebp
	invoke RtlUnwind,pFrame,_gu_return,0,0
_gu_return::
	pop ebp
	pop edi
	pop esi
	pop ebx
	ret
_global_unwind2 endp

	align 4

	option prologue:none
	option epilogue:none

;*** proc to handle exceptions in local unwind

_unwind_handler proc c pReport:ptr EXCEPTION_RECORD,\
						pFrame:ptr FRAME,\
						pContext:ptr CONTEXT,\
						pContDisp:dword

	mov ecx,dword ptr [esp+4]	;= pReport
	test dword ptr [ecx].EXCEPTION_RECORD.ExceptionFlags,UNWIND
	mov eax,_XCPT_CONTINUE_SEARCH
	je @F
	mov eax,dword ptr [esp+8]		;pFrame
	mov edx,dword ptr [esp+10h]	;pContDisp
	mov dword ptr [edx],eax
	mov eax,_XCPT_CONTINUE_SEARCH or 2
@@:
	ret
_unwind_handler endp

	align 4

	assume fs:nothing

_local_unwind2 proc c pFrame:ptr FRAME,index:dword

iActIndex	equ <[esp+9*4]>

	push ebx
	push esi
	push edi

	mov ebx,[esp+4*4]			;FRAME parm
	lea ebp,[ebx.FRAME.FrameEBP]
	push ebx
	push -2				;"invalid" scope table
	push offset _unwind_handler
	push dword ptr fs:[0]
	mov dword ptr fs:[0],esp
	.while (1)
		mov esi,[ebx.FRAME.trylevel]
		.break .if (esi == -1)
		.break .if (esi == iActIndex)
		mov edi,[ebx.FRAME.pScopeTbl]
		lea esi,[esi+esi*2]
		lea edi,[edi+esi*4]
		mov eax,[edi].SCOPEENTRY.iPrevIdx
		mov [esp+8],eax
		mov [ebx.FRAME.trylevel],eax
;---------------------------------------------- is it a _finally block?
		.if ([edi].SCOPEENTRY.pFilter == NULL)
			push ebx
			call [edi].SCOPEENTRY.pExcept
			pop ebx
		.endif
	.endw
	pop dword ptr fs:[0]

	add esp,3 * 4
	pop edi
	pop esi
	pop ebx
	ret
_local_unwind2 endp

	   end



;*** test Win32 Exception Handling
;*** demonstrates use of .try/.except/.finally macros

	.386
	.Model flat,stdcall
	option casemap:none 
	option dotname

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN equ 1
	include windows.inc
	include windowsx.inc
	include try.inc

	includelib kernel32.lib
	includelib user32.lib
	.list
	.cref

IDD_DIALOG1	equ 101
IDC_LIST1	equ 1001

;--------------------------- macros

;--- CStr("xxx") defines a string

CStr macro y:req
local sym
	.const
ifidni <y>,<"">
sym db 0
else
sym db y,0
endif
	.code
	exitm <offset sym>
	endm

;--- @writemsg displays text (in listbox)

@writemsg macro x
ifidn @SubStr(x,0,1),<"> 
	invoke writemsg,CStr(x)
else
	invoke writemsg,x
endif
	endm

testx	proto
testy	proto


	.data

hWndLB	HWND 0

	.code

	option prologue: @sehprologue	; without these options SEH isn't active
	option epilogue: @sehepilogue

	align 4


writemsg proc uses ebx pMsg:ptr byte

;-------------------------------- do it in a .try block just to show
;-------------------------------- it is handled correctly.

	.try
		ListBox_AddString hWndLB,pMsg
	.exceptfilter
		mov eax,EXCEPTION_CONTINUE_SEARCH
	.except
	.endtry
	ret
	align 4

writemsg endp


testx proc

;-------------------------------- .tryf is used in conjunction with .finally
	.tryf
		@writemsg "in .try(1) block of testx"
		mov eax,0
		mov byte ptr [eax],0		;!!! should cause exception
	.finally
		@writemsg "in .finally(1) block of testx"
	.endtryf
	ret
	align 4

testx endp


OnCommand proc uses ebx esi edi hWnd:HWND

local	i:dword
local	szStr[64]:byte

	mov i,0
	@writemsg "start execution"

;------------------------------- .try block 1
	.try
		@writemsg "in .try(1) block"
		.try
			@writemsg "in .try(11) block"
			mov eax,-4
			mov byte ptr [eax],0		;!!! should cause exception
		.exceptfilter
			mov eax,_exception_code()
			invoke wsprintf,addr szStr,CStr("in .exceptfilter(11), code=%X"),eax
			@writemsg addr szStr
			mov eax,EXCEPTION_CONTINUE_SEARCH
		.except
			@writemsg "in .except(11) block"
			ret
		.endtry
		@writemsg "after .try(11) block"
	.exceptfilter								;check exception
		mov eax,_exception_code()
		invoke wsprintf,addr szStr,CStr("in .exceptfilter(1), code=%X"),eax
		@writemsg addr szStr
		mov eax,EXCEPTION_EXECUTE_HANDLER
	.except
		@writemsg "in .except(1) block"
	.endtry

	@writemsg "after .try(1) block"

;------------------------------- .try block 2
	.try
		@writemsg "in .try(2) block"

		.try
			@writemsg "in .try(21) block"
		.exceptfilter
			mov eax,_exception_code()
			invoke wsprintf,addr szStr,CStr("in .exceptfilter(21), code=%X"),eax
			@writemsg addr szStr
			mov eax,EXCEPTION_CONTINUE_SEARCH
		.except
			@writemsg "in .except(21) block"
		.endtry

		@writemsg "after .try(21) block"

		.try
			@writemsg "in .try(22) block"
			invoke testx
			@writemsg "should never execute (exception in testx)"

		.exceptfilter
			mov eax,_exception_code()
			invoke wsprintf,addr szStr,CStr("in .exceptfilter(22), code=%X"),eax
			@writemsg addr szStr
			mov eax,EXCEPTION_CONTINUE_SEARCH
		.except
			@writemsg "in .except(22) block"
		.endtry

;-------------- since we returned EXCEPTION_CONTINUE_SEARCH, this code
;-------------- should never be executed

		@writemsg "after .try(22) block"

	.exceptfilter								;check exception
		mov eax,_exception_code()
		invoke wsprintf,addr szStr,CStr("in .exceptfilter(2), code=%X"),eax
		@writemsg addr szStr
		mov eax,EXCEPTION_EXECUTE_HANDLER
	.except
		@writemsg "in .except(2) block"
	.endtry

	@writemsg "after .try(2) block"

;------------------------------- .try block 3
;------------------------------- a procedure is called which causes an exception,
;------------------------------- but has no guard blocks
	.try
		@writemsg "in .try(3) block"
		invoke testy
	.exceptfilter
		mov eax,_exception_code()
		invoke wsprintf,addr szStr,CStr("in .exceptfilter(3), code=%X"),eax
		@writemsg addr szStr
		mov eax,EXCEPTION_EXECUTE_HANDLER
	.except
		@writemsg "in .except(3) block"
	.endtry

	@writemsg "after .try(3) block"

	@writemsg "end execution"

	ret
	align 4

OnCommand endp

;--- testy is a proc with seh prologue/epilogue, but has no .try blocks

testy proc

	@writemsg "in testy"
	mov eax, 0
	mov byte ptr [eax],0		;should cause exception
	ret
	align 4

testy endp


	option prologue: prologuedef	;disables SEH
	option epilogue: epiloguedef

dlgproc proc hWnd:HWND, message:dword, wParam:WPARAM, lParam:LPARAM

	mov eax,message
	.if (eax == WM_INITDIALOG)
		invoke GetDlgItem,hWnd,IDC_LIST1
		mov hWndLB,eax
		mov eax,1
	.elseif (eax == WM_COMMAND)
		movzx eax,word ptr wParam
		.if (eax == IDOK)
			invoke OnCommand,hWnd
		.elseif (eax == IDCANCEL)
			invoke PostMessage,hWnd,WM_CLOSE,0,0
		.endif
	.elseif (eax == WM_CLOSE)
		invoke EndDialog,hWnd,0
	.else
		xor eax,eax
	.endif
	ret
	align 4

dlgproc endp


WinMain proc hInstance:HINSTANCE, hPrevInst:HINSTANCE, lpcmdline:LPSTR, cmdshow:DWORD

	invoke DialogBoxParam, hInstance, IDD_DIALOG1, 0, dlgproc, 0
	ret
	align 4

WinMain endp


WinMainCRTStartup proc c
	invoke GetModuleHandle, NULL
	invoke WinMain, eax, NULL, NULL, 0
	invoke ExitProcess,0
WinMainCRTStartup endp

	end


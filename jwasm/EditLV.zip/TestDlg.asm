
;*** GUI dialog demonstrating editable ListView control

	.386
	.model flat,stdcall
	option casemap :none
	option proc:private

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN equ 1
	include windows.inc
	include commdlg.inc
	include windowsx.inc
	include commctrl.inc
	include rsrc.inc
	include CListView.inc
	include debugout.inc
	.list
	.cref
	includelib comctl32.lib
	includelib comdlg32.lib

ZeroMemory equ <RtlZeroMemory>
CopyMemory equ <RtlMoveMemory>

DBGPRF equ <TestDlg.>

CStr macro Text:VARARG
local szText
    .const
szText  db Text,0
    .code
    exitm <offset szText>
endm

	.data

g_CustColors	COLORREF 16 dup (0)

	.code

;--- LVN_BEGINLABELEDIT

OnBeginLabelEdit proc pNMLVDI:ptr NMLVDISPINFO

local hWndEdit:HWND
local hWndCB:HWND
local dwRC:DWORD
local hwndLV:HWND
local lvi:LVITEM

	mov dwRC, FALSE
	mov eax, pNMLVDI
	mov ecx, [EAX].NMHDR.hwndFrom
	mov hwndLV, ecx
	mov ecx,[eax].NMLVDISPINFO.item.iItem
	mov lvi.iItem, ecx
	mov lvi.iSubItem, 0
	mov lvi.mask_, LVIF_PARAM
	invoke ListView_GetItem( hwndLV, addr lvi)

;------------------------------- if combobox mode, add some strings to combobox

	invoke SendMessage, hwndLV, LVM_GETCOMBOBOXCONTROL, 0, 0
	.if (eax)
		mov hWndCB, eax
		.if (lvi.iItem == 1)
			invoke ComboBox_AddString( hWndCB, CStr("Item 22")  )
			invoke ComboBox_AddString( hWndCB, CStr("Item 22A") )
			invoke ComboBox_AddString( hWndCB, CStr("Item 22B") )
			invoke ComboBox_AddString( hWndCB, CStr("Item 22C") )
		.elseif (lvi.iItem == 3)
			invoke ComboBox_AddString( hWndCB, CStr("Item 42")  )
			invoke ComboBox_AddString( hWndCB, CStr("Item 42A") )
			invoke ComboBox_AddString( hWndCB, CStr("Item 42B") )
		.endif
	.endif

	mov eax, dwRC
	ret
	align 4

OnBeginLabelEdit endp

;--- WM_NOTIFY

OnNotify proc uses ebx hWnd:HWND, pNMHdr:ptr NMHDR

local hti:LVHITTESTINFO
local pTypeAttr:ptr TYPEATTR
local pFuncDesc:ptr FUNCDESC
local hwndLV:HWND
local dwRC:DWORD
local cc:CHOOSECOLOR

	mov dwRC, FALSE
	mov ebx, pNMHdr
	.if ([ebx].NMHDR.idFrom == IDC_LIST1)

		DebugOut "OnNotify: code=%d, item=%d, subitem=%d", [ebx].NMHDR.code, [ebx].NMLISTVIEW.iItem, [ebx].NMLISTVIEW.iSubItem
		mov ecx, [ebx].NMHDR.hwndFrom
		mov hwndLV, ecx
		.if ([ebx].NMHDR.code == NM_CLICK)

			DebugOut "OnNotify: NM_CLICK"
;-------------------------------------- if user clicked in second column
;-------------------------------------- enter in-place-edit mode

			invoke GetCursorPos, addr hti.pt
			invoke ScreenToClient, hwndLV, addr hti.pt
			invoke ListView_SubItemHitTest( hwndLV, addr hti)
			.if (hti.iSubItem == 1)
				invoke ListView_GetItemCount( hwndLV)
				.if (eax > hti.iItem)
					DebugOut "OnNotify: subitem 1 clicked, enter in-place-edit"
;-------------------------------------- for items 1 and 3 enter combobox mode
					.if ((hti.iItem == 1) || (hti.iItem == 3))
						invoke SendMessage, hwndLV, LVM_COMBOBOXMODE, hti.iItem, hti.iSubItem
;-------------------------------------- for item 2 use button mode
					.elseif (hti.iItem == 2)
						invoke SendMessage, hwndLV, LVM_PUSHBUTTONMODE, hti.iItem, hti.iSubItem
					.else
;-------------------------------------- for item 0 use std edit mode
						invoke SendMessage, hwndLV, LVM_EDITLABEL, hti.iItem, hti.iSubItem
					.endif
				.endif
			.endif

		.elseif ([ebx].NMHDR.code == LVN_BEGINLABELEDIT)

			DebugOut "OnNotify: LVN_BEGINLABELEDIT received"
			invoke OnBeginLabelEdit, ebx
			mov dwRC, eax

		.elseif ([ebx].NMHDR.code == LVN_ENDLABELEDIT)

			DebugOut "OnNotify: LVN_ENDLABELEDIT received, pszText=%X", [ebx].NMLVDISPINFO.item.pszText
			.if ([ebx].NMLVDISPINFO.item.pszText)
				invoke SetWindowLong, hWnd, DWL_MSGRESULT, 1
				mov dwRC, TRUE
			.endif

		.elseif ([ebx].NMHDR.code == LVN_CLICKED)

			DebugOut "OnNotify: LVN_CLICKED received"
			.if ([ebx].NMLISTVIEW.iItem == 2)
				DebugOut "OnNotify: open a ChooseColor dialog" 
				invoke ZeroMemory, addr cc, sizeof CHOOSECOLOR
				mov cc.lStructSize, sizeof CHOOSECOLOR
				mov eax, hWnd
				mov cc.hwndOwner, eax
				invoke GetModuleHandle, NULL
				mov cc.hInstance, eax
				mov cc.lpCustColors, offset g_CustColors
				mov cc.Flags, 0
				invoke ChooseColor, addr cc
				DebugOut "OnNotify: invoke ChooseColor returned %X", eax
			.endif

		.endif

	.endif
	mov eax, dwRC
	ret
	align 4

OnNotify endp

;*** dialogproc

dialogproc proc hWnd:HWND,message:dword,wParam:WPARAM,lParam:LPARAM

local rc:dword
local hwndEdit:HWND
local hwndLV:HWND
local hwndBtn:HWND
local rect:RECT
local cbei:COMBOBOXEXITEM
local lvc:LVCOLUMN
local lvi:LVITEM

	mov rc,0
	mov eax,message
	.if (eax == WM_INITDIALOG)
;---------------------------------------- enter some items in listview
		invoke GetDlgItem, hWnd, IDC_LIST1
		mov hwndLV, eax
		mov lvc.mask_, LVCF_TEXT or LVCF_WIDTH
		mov lvc.pszText, CStr("Column 1")
		mov lvc.cx_, 24*8
		invoke ListView_InsertColumn( hwndLV, 0, addr lvc)
		mov lvc.pszText, CStr("Column 2")
		mov lvc.cx_, 24*8
		invoke ListView_InsertColumn( hwndLV, 1, addr lvc)
		invoke ListView_SetExtendedListViewStyle( hwndLV, LVS_EX_GRIDLINES)
		mov lvi.iItem, 0
		mov lvi.iSubItem, 0
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 11")
		invoke ListView_InsertItem( hwndLV, addr lvi)
		inc lvi.iSubItem
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 12")
		invoke ListView_SetItem( hwndLV, addr lvi)
		mov lvi.iItem, 1
		mov lvi.iSubItem, 0
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 21")
		invoke ListView_InsertItem( hwndLV, addr lvi)
		inc lvi.iSubItem
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 22")
		invoke ListView_SetItem( hwndLV, addr lvi)
		mov lvi.iItem, 2
		mov lvi.iSubItem, 0
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 31")
		invoke ListView_InsertItem( hwndLV, addr lvi)
		inc lvi.iSubItem
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 32")
		invoke ListView_SetItem( hwndLV, addr lvi)
		mov lvi.iItem, 3
		mov lvi.iSubItem, 0
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 41")
		invoke ListView_InsertItem( hwndLV, addr lvi)
		inc lvi.iSubItem
		mov lvi.mask_, LVIF_TEXT
		mov lvi.pszText, CStr("Item 42")
		invoke ListView_SetItem( hwndLV, addr lvi)

;------------------------------------ this call activates the new features

		invoke CreateEditListView, hwndLV

		mov rc,1

	.elseif (eax == WM_CLOSE)

		invoke EndDialog,hWnd,0

	.elseif (eax == WM_DESTROY)

	.elseif (eax == WM_NOTIFY)

		invoke OnNotify, hWnd, lParam
		mov rc, eax

	.elseif (eax == WM_COMMAND)

		movzx eax,word ptr wParam
		.if (eax == IDCANCEL)
			invoke EndDialog,hWnd,0

		.elseif (eax == IDOK)

		.endif

	.endif
	mov eax,rc
	ret
	align 4

dialogproc endp

;*** "dialog box" app

WinMain proc hInstance:HINSTANCE, hPrevInstance:HINSTANCE, lpszCmdLine:LPSTR, iCmdShow:dword

	invoke InitCommonControls
	invoke DialogBoxParam, hInstance, IDD_DIALOG1, 0, dialogproc,0
	ret
	align 4

WinMain endp

start proc c

	invoke GetModuleHandle,0
	invoke WinMain,eax,0,0,0
	invoke ExitProcess,eax

start endp

	end start

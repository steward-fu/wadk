

 1. About AsmCtrl

 AsmCtrl is a sample for an Active-X control written in assembly.
 It's a full control, supports aggregation and events. So this control
 can be inserted as "object" in a Word/Excel document, in a VB
 "form", in an IE HTML page or in any container application which supports
 this kind of stuff.


 2. How to generate and execute the sample

 To create the control you need Masm/JWasm, WinInc and
 MS LINK, MS RC and MS MIDL. Optionally, if type information is
 to be changed, COMView might be helpful to recreate AsmCtrl.inc
 ( this can probably also done manually without too much efforts ).
 There a Makefile supplied which will automate the job.

 After the binary has been created, it must be "registered":
 C:\>regsvr32.exe asmctrl.dll

 After registration, it can be used by any ActiveX container application
 ( Excel, COMView, VB, ... )

 When the control is to be uninstalled, it should first be unregistered
 with:
 C:\>regsvr32.exe /u asmctrl.dll


 3. Brief source file description

 The source files for the sample are:

 Name                 Description
-----------------------------------------------------------------
 AsmCtrl.inc          AsmCtrl interfaces in assembly format (COMView gen.)
 AsmCtrl.asm          creates/destroys CAsmCtrl objects
 DllMain.asm          dll entry points, register/unregister routines
 ClassFactory.asm     IClassFactory interface
 DataObject.asm       IDataObject interface (optional)
 OleObject.asm        IOleObject interface
 OleInPlaceObject.asm IOleInPlaceObject + IOleInPlaceActiveObject interfaces
 OleControl.asm       IOleControl interface
 Dispatch.asm         IDispatch, IAsmCtrl interfaces
 ConnectionPoint.asm  IConnectionPointContainer, IEnumConnectionPoints + IConnectionPoint
 Persist.asm          IPersistStorage, IPersistStreamInit, IPersistPropertyBag
 ViewObject.asm       IViewObject(2) interface
 Others.asm           IProvideClassInfo + ISpecifyPropertyPages interface
 Utility.asm          some non-interface-related procs
 CatProp.asm          ICategorizeProperties interface

 In directory Samples, there are:

 Name                 Description
-----------------------------------------------------------------
 ASMCTRL.HTM          to start the control via IE
 PROJECT1.VBP/VBW     to show the usage form within VB
 OCXContainer.exe     a simple container (MFC) for the control
 AsmCtrl.doc          a winword doc with AsmCtrl object inserted
 Test.vbs             shows how to use AsmCtrl with WSH


4. History

 V1.0, 12/2001: first version
 V1.1, 03/2002: aggregation implemented. So AsmCtrl works with WinWord + Excel
 V1.2, 06/2002: code rearranged.
 V1.3, 12/2002: a change in dispatch.asm so typeinfo of IAsmCtrl doesn't need 
                to be first typeinfo in type library.
 V1.4, 01/2011: put the dust off of this sample and made in compatible with
                WinInc
 V1.5, 02/2011: added DataObject.asm to make the sample support IDataObject.


5. License

 This sample is Public Domain.

 japheth

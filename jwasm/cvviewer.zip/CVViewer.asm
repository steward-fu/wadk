
;--- interface viewer dll for COMView 1.7.0+ and OLEView
;--- currently viewer for IShellFolder is implemented

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
	include \masm32\include\shell32.inc
	include macros.inc
	include windowsx.inc
	include unknwn.inc
	include objidl.inc
	include olectl.inc
	include oaidl.inc
	include ocidl.inc
	include shlobj.inc

?AGGREGATION	= 0	;no aggregation
?EVENTSUPPORT	= 0	;no event support

	include olecntrl.inc
	include debugout.inc
	include resource.inc
	.list
	.cref

	include CVViewer.inc
	include CShellBrowser.inc

	includelib  \masm32\lib\kernel32.lib
	includelib  \masm32\lib\advapi32.lib
	includelib  \masm32\lib\user32.lib
	includelib  \masm32\lib\gdi32.lib
	includelib  \masm32\lib\oleaut32.lib
	includelib  \masm32\lib\ole32.lib
	includelib  \masm32\lib\uuid.lib
	includelib  \masm32\lib\shell32.lib

;--------------------------------------------------------------------------

	.data

externdef g_DllRefCount:DWORD

	.const

CLSID_CVViewer GUID sCLSID_CVViewer

ifdef _DEBUG
externdef DEBUGPREFIX:LPSTR
DEBUGPREFIX LPSTR CStr("CVViewer:")
endif

;--- the object table: defines coclasses installed by this module
;--- used by DllGetClassObject, DllRegisterServer + DllUnregisterServer

BEGIN_OBJECT_MAP ObjectMap
	ObjectEntry {\
		offset CLSID_CVViewer,\
		offset 0, 0, 0,\
		offset RegKeys_CVViewer,\
		Create@CVViewer}
END_OBJECT_MAP

;--------------------------------------------------------------------------

;--- define standard COM functions
;--- one instance for all coclasses in this module

	DEFINE_COMHELPER
	DEFINE_CLASSFACTORY
	DEFINE_GETCLASSOBJECT offset ObjectMap
	DEFINE_REGISTERSERVER offset ObjectMap
	DEFINE_UNREGISTERSERVER offset ObjectMap
	DEFINE_CANUNLOADNOW
	DEFINE_DLLMAIN		;DllMain std (saves hInstance in g_hInstance)


;-------------------------------------------------------------
;--- coclass CVViewer
;-------------------------------------------------------------

	.const

IID_IInterfaceViewer IID {0fc37e5bah, 4a8eh, 11ceh, {87h,0bh,08h,00h,36h,8dh,23h,02h}}

Description		textequ <"Interface Viewers for COMView and OLEView">

;--- registry infos for registration/unregister CVViewer coclass

RegKeys_CVViewer label REGSTRUCT
	REGSTRUCT <-1, 0, CStr("CLSID\%s")>
	REGSTRUCT <0, 0, CStr(Description)>
	REGSTRUCT <CStr("InprocServer32"), 0, CStr("%s")>
	REGSTRUCT <CStr("InprocServer32"), CStr("ThreadingModel"), CStr("Apartment")>
	REGSTRUCT <-1, 0, CStr("Interface\{000214E6-0000-0000-C000-000000000046}")>
	REGSTRUCT <CStr("OLEViewerIViewerCLSID"), 0, -1>
	REGSTRUCT <-1, 0, 0>

;--- vtable for interface IInterfaceViewer

CInterfaceViewerVtbl label dword
	IUnknownVtbl {QueryInterface@CVViewer, AddRef@CVViewer, Release@CVViewer}
	dd View

;--- define interfaces known by IUnknown::QueryInterface

	DEFINE_KNOWN_INTERFACES CVViewer, IInterfaceViewer

	.code

__this	textequ <ebx>
_this	textequ <[__this].CVViewer>

	MEMBER pUnknown

;--- standard code (won't be much here besides IUnknown methods)

	DEFINE_STD_COM_METHODS CVViewer

;--- constructor coclass CVViewer

Create@CVViewer	proc public uses esi __this pClass: ptr ObjectEntry, pUnkOuter:LPUNKNOWN
	
	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT,sizeof CVViewer
	.if (eax == NULL)
		ret
	.endif
	mov __this,eax

	mov	m__IInterfaceViewer, OFFSET CInterfaceViewerVtbl

	STD_COM_CONSTRUCTOR CVViewer

	return __this

Create@CVViewer	endp

;--- destructor coclass CVViewer

Destroy@CVViewer proc public uses __this this_:ptr CVViewer

    mov __this,this_

	STD_COM_DESTRUCTOR CVViewer

	.if (m_pUnknown)
		invoke vf(m_pUnknown, IUnknown, Release)
	.endif

	invoke LocalFree, __this
    ret

Destroy@CVViewer endp

;----------------------------------------------------------------

;--- IInterfaceViewer::View method 

View	proc uses __this this_:ptr CVViewer, hwndParent:HWND, riid:REFIID, punk:LPUNKNOWN

	mov __this, this_
	mov eax, punk
	mov m_pUnknown, eax
	invoke vf(eax, IUnknown, AddRef)

	invoke IsEqualGUID, riid, addr IID_IShellFolder
	.if (eax)
		invoke Create@CShellBrowser, punk
		.if (eax)
			invoke Show@CShellBrowser, eax, NULL;hwndParent
		.endif
		mov eax, S_OK
		ret
	.else
		mov eax, S_OK
	.endif
	ret
View	endp

end DllMain

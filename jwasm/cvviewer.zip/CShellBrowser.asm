
;--- IShellBrowser object

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
	include \masm32\include\shell32.inc
	include macros.inc
	include windowsx.inc
	include unknwn.inc
	include objidl.inc
	include olectl.inc
	include oaidl.inc
	include ocidl.inc
	include shlobj.inc
	include servprov.inc	;for IServiceProvider
	include docobj.inc		;for IOleCommandTarget

?AGGREGATION	= 0	;no aggregation
?EVENTSUPPORT	= 0	;no event support

	include olecntrl.inc
	include debugout.inc
	include resource.inc
	.list
	.cref

INSIDE_CShellBrowser equ 1

	include CShellBrowser.inc

?SERVICEPROVIDER	equ 0		;support IServiceProvider
?OLECOMMANDTARGET	equ 0		;support IOleCommandTarget
?MODELESS			equ 1
WM_GETISHELLBROWSER equ 407h	;undocumented window message
IDM_FIRST			equ 10000
IDM_LAST			equ 10099

CShellBrowser struct

BEGIN_COM_MAP CShellBrowser
	COM_INTERFACE_ENTRY IShellBrowser
if ?SERVICEPROVIDER
	COM_INTERFACE_ENTRY IServiceProvider
endif
if ?OLECOMMANDTARGET
	COM_INTERFACE_ENTRY IOleCommandTarget
endif
END_COM_MAP

hWnd			HWND ?
hWndLV			HWND ?
hWndView		HWND ?
pShellFolder	LPSHELLFOLDER ?
pShellView		LPSHELLVIEW ?
pMalloc			LPMALLOC ?
pStream			LPSTREAM ?
rect			RECT <>
bCreateView		BOOL ?
bBindToObject	BOOL ?
bGetUIObjectOf	BOOL ?

CShellBrowser ends

DlgProc						PROTO :HWND, :DWORD, :WPARAM, :LPARAM
DlgProc@CShellBrowser		PROTO :ptr CShellBrowser, :DWORD, :WPARAM, :LPARAM
Destroy@CShellBrowser		PROTO :ptr CShellBrowser
SetShellView@CShellBrowser	PROTO :ptr CShellBrowser, :LPSHELLVIEW
SHBindToParent				PROTO :LPITEMIDLIST, :REFIID, :ptr LPUNKNOWN, :ptr LPITEMIDLIST

	.data

externdef g_DllRefCount:DWORD

g_bGetUIObjectOf BOOLEAN TRUE
g_bBindToObject	BOOLEAN TRUE
g_bCreateView	BOOLEAN FALSE
g_bOpenNewWnd	BOOLEAN TRUE

g_rect	RECT {0,0,480,360}

	.const

;--- vtable for interface IShellBrowser

CShellBrowserVtbl label dword
	IUnknownVtbl {QueryInterface@CShellBrowser, AddRef@CShellBrowser, Release@CShellBrowser}
	dd GetWindow_, ContextSensitiveHelp
	dd InsertMenusSB, SetMenuSB, RemoveMenusSB
	dd SetStatusTextSB, EnableModelessSB, TranslateAcceleratorSB
	dd BrowseObject, GetViewStateStream, GetControlWindow
	dd SendControlMsg, QueryActiveShellView, OnViewWindowActive, SetToolbarItems

if ?SERVICEPROVIDER
CServiceProviderVtbl label dword
	IUnknownVtbl {QueryInterface_, AddRef_, Release_}
	dd QueryService_
endif
if ?OLECOMMANDTARGET
COleCommandTargetVtbl label dword
	IUnknownVtbl {QueryInterface2, AddRef2, Release2}
	dd QueryStatus_, Exec_
endif


if ?OLECOMMANDTARGET
	DEFINE_KNOWN_INTERFACES CShellBrowser, IShellBrowser, IOleCommandTarget
elseif ?SERVICEPROVIDER
	DEFINE_KNOWN_INTERFACES CShellBrowser, IShellBrowser, IServiceProvider
else
	DEFINE_KNOWN_INTERFACES CShellBrowser, IShellBrowser
endif

	.code

__this	textequ <ebx>
_this	textequ <[__this].CShellBrowser>

	MEMBER _IShellBrowser, ObjRefCount
	MEMBER hWnd, hWndLV, hWndView
	MEMBER pShellFolder, pShellView, pStream, pMalloc
	MEMBER rect
	MEMBER bCreateView, bBindToObject, bGetUIObjectOf


	DEFINE_STD_COM_METHODS CShellBrowser


Create@CShellBrowser proc public uses __this pUnknown:LPUNKNOWN

	DebugOut "Create@CShellBrowser"
	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT,sizeof CShellBrowser
	.if (eax == NULL)
		ret
	.endif
	mov __this,eax

	mov m__IShellBrowser.pVtbl, offset CShellBrowserVtbl

if ?SERVICEPROVIDER
	mov m__IServiceProvider.pVtbl, offset CServiceProviderVtbl
endif
if ?OLECOMMANDTARGET
	mov m__IOleCommandTarget.pVtbl, offset COleCommandTargetVtbl
endif

	STD_COM_CONSTRUCTOR CShellBrowser

	invoke vf(pUnknown, IUnknown, QueryInterface), addr IID_IShellFolder, addr m_pShellFolder
	.if (eax != S_OK)
		invoke Destroy@CShellBrowser, __this
		return 0
	.endif

	invoke SHGetMalloc, addr m_pMalloc

	return __this

Create@CShellBrowser endp

Destroy@CShellBrowser proc uses __this this_:ptr CShellBrowser

	DebugOut "Destroy@CShellBrowser(%X)", this_

	mov __this, this_

	STD_COM_DESTRUCTOR CShellBrowser

	.if (m_pShellView)
		invoke vf(m_pShellView, IUnknown, Release)
	.endif
	.if (m_pShellFolder)
		invoke vf(m_pShellFolder, IUnknown, Release)
	.endif
	.if (m_pStream)
		invoke vf(m_pStream, IUnknown, Release)
	.endif
	.if (m_pMalloc)
		invoke vf(m_pMalloc, IUnknown, Release)
	.endif
	invoke LocalFree, this_
	ret

Destroy@CShellBrowser endp

Show@CShellBrowser proc public uses __this this_:ptr CShellBrowser, hWnd:HWND

	mov __this, this_
	.if (hWnd)
		invoke GetWindowRect, hWnd, addr m_rect
		mov eax, m_rect.right
		sub eax, m_rect.left
		mov m_rect.right, eax
		mov eax, m_rect.bottom
		sub eax, m_rect.top
		mov m_rect.bottom, eax
		add m_rect.left, 16
		add m_rect.top, 16
	.endif
if ?MODELESS
	invoke CreateDialogParam, g_hInstance, IDD_DIALOG1, 0, DlgProc, __this
else
	invoke DialogBoxParam, g_hInstance, IDD_DIALOG1, hWnd, DlgProc, __this
	invoke Destroy@CShellBrowser, __this
endif
	ret

Show@CShellBrowser endp


;----------------------------------------------------------------

;--- this function is not available in win9x and winnt systems

SHBindToParent proc uses esi edi pidl:LPITEMIDLIST, riid:REFIID, ppUnknown:ptr LPUNKNOWN, ppidl:ptr LPITEMIDLIST

local pShellFolder:LPSHELLFOLDER
local hr:DWORD

	xor ecx, ecx

	mov eax, ppidl
	.if (eax)
		mov [eax],ecx
	.endif
	mov eax, ppUnknown
	mov [eax], ecx

	mov edx, pidl
	.while (edx)
		movzx eax,[edx].SHITEMID.cb
		.break .if (!eax)
		mov esi, ecx
		add ecx, eax
		lea edx, [eax][edx]
	.endw
	add esi, sizeof WORD
	invoke vf(m_pMalloc, IMalloc, Alloc), esi
	.if (eax)
		mov ecx, esi
		mov esi, pidl
		mov edi, eax
		rep movsb
		mov [edi-2],cx
		mov edi, eax
		invoke vf(m_pShellFolder, IShellFolder, BindToObject), edi, NULL,\
			riid, addr pShellFolder
		mov hr, eax
		.if (eax == S_OK)
			.if (ppidl)
				mov ecx, ppidl
				mov [ecx],edi
			.else
				invoke vf(m_pMalloc, IMalloc, Free), edi
			.endif
			mov ecx, ppUnknown
			mov eax, pShellFolder
			mov [ecx], eax
		.else
			invoke vf(m_pMalloc, IMalloc, Free), edi
		.endif
		mov eax, hr
	.else
		mov eax, E_OUTOFMEMORY
	.endif
	ret
SHBindToParent endp

;----------------------------------------------------------------

;--- IShellFolder viewer: release ITEMIDLIST memory

ShellFolderRelease proc uses esi

local dwItems:DWORD
local lvi:LV_ITEM

	.if (m_pShellView)
		invoke vf(m_pShellView, IShellView, UIActivate), SVUIA_DEACTIVATE
		.if (m_hWndView)
			invoke vf(m_pShellView, IShellView, DestroyViewWindow)
			mov m_hWndView, NULL
		.endif
		invoke vf(m_pShellView, IUnknown, Release)
		mov m_pShellView, NULL
	.endif
	.if (eax == S_OK)
		ListView_GetItemCount m_hWndLV
		mov dwItems, eax
		xor esi, esi
		.while (esi < dwItems)
			mov lvi.iItem, esi
			mov lvi.iSubItem, 0
			mov lvi.imask, LVIF_PARAM
			ListView_GetItem m_hWndLV, addr lvi
			invoke vf(m_pMalloc, IMalloc, Free), lvi.lParam
			inc esi
		.endw
	.endif
	ret
ShellFolderRelease endp

;--- update menu items

UpdateMenu proc

local hMenu:HMENU

	invoke GetMenu, m_hWnd
	mov hMenu, eax

	.if (m_bCreateView)
		mov ecx, MF_CHECKED
	.else
		mov ecx, MF_UNCHECKED
	.endif
	invoke CheckMenuItem, hMenu, IDM_CREATEVIEWOBJECT, ecx

	.if (m_bBindToObject)
		mov ecx, MF_CHECKED
	.else
		mov ecx, MF_UNCHECKED
	.endif
	invoke CheckMenuItem, hMenu, IDM_BINDTOOBJECT, ecx

	.if (m_bGetUIObjectOf)
		mov ecx, MF_CHECKED
	.else
		mov ecx, MF_UNCHECKED
	.endif
	invoke CheckMenuItem, hMenu, IDM_GETUIOBJECTOF, ecx

	.if (g_bOpenNewWnd)
		mov ecx, MF_CHECKED
	.else
		mov ecx, MF_UNCHECKED
	.endif
	invoke CheckMenuItem, hMenu, IDM_OPENNEWWND, ecx
	ret

UpdateMenu endp

RefreshView proc

local pEnumIDList:LPENUMIDLIST
local pItemIDList:LPITEMIDLIST
local dwSize:DWORD
local lvi:LV_ITEM
local sfgaof:DWORD
local strret:STRRET
local szText[128]:byte

	invoke ShellFolderRelease
	ListView_DeleteAllItems m_hWndLV

	mov lvi.iItem, 0

	invoke vf(m_pShellFolder, IShellFolder, EnumObjects), m_hWnd,\
		SHCONTF_FOLDERS or SHCONTF_NONFOLDERS or SHCONTF_INCLUDEHIDDEN,\
		addr pEnumIDList
	.if (eax == S_OK)
		.while (1)
			invoke vf(pEnumIDList, IEnumIDList, Next), 1, addr pItemIDList, NULL
			.break .if (eax != S_OK)
			mov strret.uType, STRRET_CSTR
			invoke vf(m_pShellFolder, IShellFolder, GetDisplayNameOf), pItemIDList,\
					SHGDN_NORMAL, addr strret
			.if (eax == S_OK)
				mov lvi.imask, LVIF_TEXT or LVIF_PARAM
				mov lvi.iSubItem, 0
				mov eax, pItemIDList
				mov lvi.lParam, eax
				.if (strret.uType == STRRET_WSTR)
					invoke WideCharToMultiByte, CP_ACP, 0, strret.pOleStr, -1, addr szText, sizeof szText, 0, 0
					invoke vf(m_pMalloc, IMalloc, Free), strret.pOleStr
					lea eax, szText
				.elseif (strret.uType == STRRET_CSTR)
					lea eax, strret.cStr
				.else
					mov eax, pItemIDList
					add eax,strret.uOffset
				.endif
				mov lvi.pszText, eax
				ListView_InsertItem m_hWndLV, addr lvi
				invoke vf(m_pShellFolder, IShellFolder, GetAttributesOf), 1,\
						addr pItemIDList, addr sfgaof
				.if (eax == S_OK)
					inc lvi.iSubItem
					test sfgaof, SFGAO_FOLDER
					.if (!ZERO?)
						mov lvi.imask, LVIF_TEXT
						mov lvi.pszText, CStr("Folder")
						ListView_SetItem m_hWndLV, addr lvi
					.endif
				.endif
				inc lvi.iItem
			.endif
		.endw
		invoke vf(pEnumIDList, IUnknown, Release)
	.endif
	ret
	align 4

RefreshView endp


DeleteShellView proc
	
	.if (m_pShellView)
		invoke vf(m_pShellView, IShellView, UIActivate), SVUIA_DEACTIVATE
		.if (m_hWndView)
			invoke vf(m_pShellView, IShellView, DestroyViewWindow)
			mov m_hWndView, NULL
		.endif
		invoke vf(m_pShellView, IUnknown, Release)
		mov m_pShellView, NULL
	.endif
	ret

DeleteShellView endp

CreateViewObject proc

local pShellFolder:LPSHELLFOLDER
local pShellView:LPSHELLVIEW
local hWndView:HWND
local hSelItem:DWORD
local rect:RECT
local lvi:LV_ITEM
local folderset:FOLDERSETTINGS

	ListView_GetNextItem m_hWndLV, -1, LVNI_SELECTED
	mov hSelItem, eax

	.if ((!m_bCreateView) || (hSelItem == -1))
		invoke DeleteShellView
		jmp done
	.endif

	mov eax, hSelItem
	mov lvi.iItem, eax
	mov lvi.imask, LVIF_PARAM
	ListView_GetItem m_hWndLV, addr lvi
	.if (eax)
		mov pShellView, NULL
		invoke vf(m_pShellFolder, IShellFolder, BindToObject),\
			lvi.lParam, NULL, addr IID_IShellFolder, addr pShellFolder
		.if (eax == S_OK)
			DebugOut "will call IShellFolder::CreateViewObject"
			invoke vf(pShellFolder, IShellFolder, CreateViewObject),\
				m_hWnd, addr IID_IShellView, addr pShellView
			invoke vf(pShellFolder, IShellFolder, Release)
		.endif
		.if (pShellView)
			invoke GetClientRect, m_hWnd, addr rect
			mov ecx, rect.bottom
			sub ecx, rect.top
			shr ecx, 1
			.if (!m_pShellView)
				push ecx
				invoke SetWindowPos, m_hWndLV, 0, 0, 0, rect.right, ecx, SWP_NOMOVE or SWP_NOZORDER
				pop ecx
			.endif
			mov rect.top, ecx
			mov folderset.ViewMode, FVM_DETAILS
			mov folderset.fFlags, 0
			.if (m_pShellView)
				invoke vf(m_pShellView, IShellView, GetCurrentInfo), addr folderset
			.endif
			DebugOut "will call IShellView::CreateViewWindow"
			mov hWndView, NULL
			invoke vf(pShellView, IShellView, CreateViewWindow),\
				m_pShellView, addr folderset, __this, addr rect, addr hWndView
			invoke DeleteShellView
			mov eax, hWndView
			mov m_hWndView, eax
			mov eax, pShellView
			mov m_pShellView, eax
			.if (m_hWndView)
				invoke vf(m_pShellView, IShellView, UIActivate), SVUIA_ACTIVATE_FOCUS
			.endif
		.endif
	.endif

done:
	.if (!m_bCreateView)
		invoke GetClientRect, m_hWnd, addr rect
		invoke SetWindowPos, m_hWndLV, 0, 0, 0, rect.right, rect.bottom, SWP_NOMOVE or SWP_NOZORDER
		ret
	.endif

	ret
	align 4
CreateViewObject endp

;--- open new dialog/folder

Switch proc pShellFolder:LPSHELLFOLDER

	.if (g_bOpenNewWnd)
		invoke Create@CShellBrowser, pShellFolder
		.if (eax)
			invoke Show@CShellBrowser, eax, m_hWnd
		.endif
		invoke vf(pShellFolder, IUnknown, Release)
	.else
		invoke vf(m_pShellFolder, IUnknown, Release)
		mov eax, pShellFolder
		mov m_pShellFolder, eax
		invoke RefreshView
	.endif
	ret
Switch endp


;--- WM_NOTIFY


OnNotify proc pNMHDR:ptr NMHDR
	
local hSelItem:DWORD
local pShellFolder:LPSHELLFOLDER
local pContextMenu:LPCONTEXTMENU
local hPopupMenu:HMENU
local pt:POINT
local lvi:LV_ITEM
local cmic:CMINVOKECOMMANDINFO

	
	ListView_GetNextItem m_hWndLV, -1, LVNI_SELECTED
	mov hSelItem, eax


	mov eax, pNMHDR
	.if (([eax].NMHDR.code == NM_DBLCLK) && (m_bBindToObject))
;---------------------- DBLCLK: try to "bind" to selected item (possibly a subfolder)
;---------------------- if ok, create new dialog showing items in this folder
		.if (hSelItem != -1)
			mov eax, hSelItem
			mov lvi.iItem, eax
			mov lvi.imask, LVIF_PARAM
			ListView_GetItem m_hWndLV, addr lvi
			.if (eax)
				invoke vf(m_pShellFolder, IShellFolder, BindToObject),\
					lvi.lParam, NULL, addr IID_IShellFolder, addr pShellFolder
				.if (eax == S_OK)
					invoke Switch, pShellFolder
				.endif
			.endif
		.endif		
	.elseif (([eax].NMHDR.code == NM_RCLICK) && (m_bGetUIObjectOf))
		.if (hSelItem != -1)
			mov eax, hSelItem
			mov lvi.iItem, eax
			mov lvi.imask, LVIF_PARAM
			ListView_GetItem m_hWndLV, addr lvi
			.if (eax)
				invoke vf(m_pShellFolder, IShellFolder, GetUIObjectOf),\
						m_hWnd, 1, addr lvi.lParam, addr IID_IContextMenu,\
						NULL, addr pContextMenu
				.if (eax == S_OK)
					invoke CreatePopupMenu
					mov hPopupMenu, eax
					invoke vf(pContextMenu, IContextMenu, QueryContextMenu),\
						hPopupMenu, 0, IDM_FIRST, IDM_LAST, CMF_NORMAL
					.if (SUCCEEDED(eax))
						invoke GetCursorPos, addr pt
						invoke TrackPopupMenu, hPopupMenu, TPM_LEFTALIGN or TPM_LEFTBUTTON or TPM_RETURNCMD,\
							pt.x, pt.y, 0, m_hWnd, NULL
						.if (eax)
							mov cmic.cbSize, sizeof CMINVOKECOMMANDINFO
							mov cmic.fMask, 0
							sub eax, IDM_FIRST
							mov cmic.lpVerb, eax
							mov eax, m_hWnd
							mov cmic.hwnd, eax
							mov cmic.lpParameters, NULL
							mov cmic.lpDirectory, NULL
							mov cmic.nShow, SW_SHOWNORMAL
							invoke vf(pContextMenu, IContextMenu, InvokeCommand), addr cmic
						.endif
					.endif
					invoke DestroyMenu, hPopupMenu
					invoke vf(pContextMenu, IUnknown, Release)
				.endif
			.endif
		.endif
	.elseif ([eax].NMHDR.code == LVN_ITEMCHANGED)
		.if ([eax].NM_LISTVIEW.uNewState & LVIS_SELECTED)
			invoke CreateViewObject
		.endif
	.endif
	ret
	align 4

OnNotify endp


;--- WM_COMMAND


OnCommand proc wParam:WPARAM, lParam:LPARAM
		 
local hMenu:HMENU
local pidl:LPITEMIDLIST
local pShellFolder:LPSHELLFOLDER

		invoke GetMenu, m_hWnd
		mov hMenu, eax

		movzx eax, word ptr wParam+0
		.if (eax == IDCANCEL)

			invoke PostMessage, m_hWnd, WM_CLOSE, 0, 0

		.elseif (eax == IDM_CREATEVIEWOBJECT)

			xor m_bCreateView, 1
			mov eax, m_bCreateView
			mov g_bCreateView, al
			.if (m_bCreateView)
				mov ecx, MF_CHECKED
			.else
				mov ecx, MF_UNCHECKED
			.endif
			invoke CheckMenuItem, hMenu, IDM_CREATEVIEWOBJECT, ecx
			invoke CreateViewObject

		.elseif (eax == IDM_BINDTOOBJECT)

			xor m_bBindToObject, 1
			mov eax, m_bBindToObject
			mov g_bBindToObject, al
			.if (m_bBindToObject)
				mov ecx, MF_CHECKED
			.else
				mov ecx, MF_UNCHECKED
			.endif
			invoke CheckMenuItem, hMenu, IDM_BINDTOOBJECT, ecx

		.elseif (eax == IDM_GETUIOBJECTOF)

			xor m_bGetUIObjectOf, 1
			mov eax, m_bGetUIObjectOf
			mov g_bGetUIObjectOf, al
			.if (m_bGetUIObjectOf)
				mov ecx, MF_CHECKED
			.else
				mov ecx, MF_UNCHECKED
			.endif
			invoke CheckMenuItem, hMenu, IDM_GETUIOBJECTOF, ecx

		.elseif (eax == IDM_OPENNEWWND)

			xor g_bOpenNewWnd, 1
			.if (g_bOpenNewWnd)
				mov ecx, MF_CHECKED
			.else
				mov ecx, MF_UNCHECKED
			.endif
			invoke CheckMenuItem, hMenu, IDM_OPENNEWWND, ecx

		.endif
		ret
		align 4

OnCommand endp


;--- WM_SIZE


OnSize proc dwWidth:DWORD, dwHeight:DWORD

local rect:RECT

	.if (!m_hWndView)
		invoke SetWindowPos, m_hWndLV, NULL, 0, 0, dwWidth, dwHeight, SWP_NOMOVE or SWP_NOZORDER
	.else
		mov ecx, dwHeight
		shr ecx, 1
		invoke SetWindowPos, m_hWndLV, NULL, 0, 0, dwWidth, ecx, SWP_NOMOVE or SWP_NOZORDER
		mov ecx, dwHeight
		shr ecx, 1
		invoke SetWindowPos, m_hWndView, NULL, 0, ecx, dwWidth, ecx, SWP_NOZORDER
	.endif
	ret
	align 4

OnSize endp

;----------------------------------------------------------
;--- WM_INITDIALOG
;----------------------------------------------------------

OnInitDialog proc uses esi edi

local lvc:LV_COLUMN
local rect:RECT

	.if (m_rect.left)
		invoke SetWindowPos, m_hWnd, NULL, m_rect.left, m_rect.top,\
			m_rect.right, m_rect.bottom, SWP_NOZORDER or SWP_NOACTIVATE
	.else
		invoke SetWindowPos, m_hWnd, NULL, g_rect.left, g_rect.top,\
			g_rect.right, g_rect.bottom, SWP_NOMOVE or SWP_NOZORDER or SWP_NOACTIVATE
	.endif

	invoke GetDlgItem, m_hWnd, IDC_LIST1
	mov m_hWndLV, eax

	movzx eax, g_bCreateView
	mov m_bCreateView, eax
	movzx eax, g_bBindToObject
	mov m_bBindToObject, eax
	movzx eax,g_bGetUIObjectOf
	mov m_bGetUIObjectOf, eax

	invoke UpdateMenu

	invoke GetClientRect, m_hWndLV, addr rect
	invoke GetSystemMetrics,SM_CXVSCROLL
	inc eax
	sub rect.right,eax

	mov lvc.imask,LVCF_TEXT or LVCF_WIDTH
	mov eax, rect.right
	shr eax, 1
	mov lvc.lx, eax
	mov lvc.pszText, CStr("Name")
	ListView_InsertColumn m_hWndLV, 0, addr lvc

	mov lvc.pszText, CStr("Attribute")
	ListView_InsertColumn m_hWndLV, 1, addr lvc

	invoke RefreshView

	ret
	align 4

OnInitDialog endp

;----------------------------------------------------------
;--- dialog proc CShellBrowser
;----------------------------------------------------------

DlgProc@CShellBrowser proc uses __this this_:ptr CShellBrowser, message:DWORD, wParam:WPARAM, lParam:LPARAM

local wp:WINDOWPLACEMENT

	mov __this, this_

	mov eax, message
	.if (eax == WM_INITDIALOG)

		invoke OnInitDialog
		mov eax, 1

	.elseif (eax == WM_CLOSE)

		invoke ShellFolderRelease
if ?MODELESS
		invoke DestroyWindow, m_hWnd
		invoke Destroy@CShellBrowser, __this
else
		invoke EndDialog, m_hWnd, 0
endif
	.elseif (eax == WM_NOTIFY)

		invoke OnNotify, lParam

	.elseif (eax == WM_SIZE)

		movzx ecx,word ptr lParam+0
		movzx edx,word ptr lParam+2
		invoke OnSize, ecx, edx

		mov wp.iLength, sizeof WINDOWPLACEMENT
		invoke GetWindowPlacement, m_hWnd, addr wp
		invoke CopyRect, addr g_rect, addr wp.rcNormalPosition
		mov eax, g_rect.right
		sub eax, g_rect.left
		mov g_rect.right, eax
		mov eax, g_rect.bottom
		sub eax, g_rect.top
		mov g_rect.bottom, eax

	.elseif (eax == WM_COMMAND)

		invoke OnCommand, wParam, lParam

	.elseif (eax == WM_GETISHELLBROWSER)

		DebugOut "undocumented message WM_GETISHELLBROWSER received"
		invoke SetWindowLong, m_hWnd, DWL_MSGRESULT, __this
		mov eax, TRUE

	.else
		xor eax, eax
	.endif
	ret

DlgProc@CShellBrowser endp


;--- true dialog proc


DlgProc proc hWnd:HWND, message:DWORD, wParam:WPARAM, lParam:LPARAM

	.if (message == WM_INITDIALOG)

		mov ecx, lParam
		mov eax, hWnd
		mov [ecx].CShellBrowser.hWnd, eax
		invoke SetWindowLong, hWnd, DWL_USER, ecx
		mov eax, lParam
	.else
		invoke GetWindowLong, hWnd, DWL_USER
	.endif

	.if (eax)
		invoke DlgProc@CShellBrowser, eax, message, wParam, lParam
	.endif
	ret

DlgProc endp

;----------------------------------------------------------------

GetWindow_ proc uses __this this_:ptr CShellBrowser, phwnd:ptr HWND
	DebugOut "IShellBrowser::GetWindow"
	mov __this, this_
	mov eax, m_hWnd
	mov ecx, phwnd
	mov [ecx],eax
	return S_OK
GetWindow_ endp


ContextSensitiveHelp proc uses __this this_:ptr CShellBrowser, fEnterMode:BOOL
	DebugOut "IShellBrowser::ContextSensitiveHelp"
	mov __this, this_
	return E_UNEXPECTED
ContextSensitiveHelp endp


InsertMenusSB proc uses __this this_:ptr CShellBrowser, hmenuShared:HMENU, lpMenuWidths:ptr OLEMENUGROUPWIDTHS
	DebugOut "IShellBrowser::InsertMenusSB"
	mov __this, this_
	return E_NOTIMPL
InsertMenusSB endp


SetMenuSB proc uses __this this_:ptr CShellBrowser, hmenuShared:HMENU, dwReserved:DWORD, hwndActiveObject:HWND
	DebugOut "IShellBrowser::SetMenuSB"
	mov __this, this_
	return E_NOTIMPL
SetMenuSB endp


RemoveMenusSB proc uses __this this_:ptr CShellBrowser, hmenuShared:HMENU
	DebugOut "IShellBrowser::RemoveMenusSB"
	mov __this, this_
	return E_NOTIMPL
RemoveMenusSB endp


SetStatusTextSB proc uses __this this_:ptr CShellBrowser, lpszStatusText:LPCOLESTR 
	DebugOut "IShellBrowser::SetStatusTextSB"
	mov __this, this_
	return S_OK
SetStatusTextSB endp


EnableModelessSB proc uses __this this_:ptr CShellBrowser, fEnable:BOOL
	DebugOut "IShellBrowser::EnableModelessSB"
	mov __this, this_
	return S_OK
EnableModelessSB endp


TranslateAcceleratorSB proc uses __this this_:ptr CShellBrowser, lpmsg:ptr MSG, wID:WORD
	DebugOut "IShellBrowser::TranslateAcceleratorSB"
	mov __this, this_
	return S_OK
TranslateAcceleratorSB endp


BrowseObject proc uses __this this_:ptr CShellBrowser, pidl:LPITEMIDLIST, wFlags:DWORD
	DebugOut "IShellBrowser::BrowseObject"
	mov __this, this_
	return E_NOTIMPL
BrowseObject endp


GetViewStateStream proc uses __this this_:ptr CShellBrowser, grfMode:DWORD, ppStrm:ptr LPSTREAM
	DebugOut "IShellBrowser::GetViewStateStream"
	mov __this, this_
	.if (!m_pStream)
		invoke CreateStreamOnHGlobal, NULL, TRUE, addr m_pStream
	.endif
	mov ecx, ppStrm
	mov eax, m_pStream
	mov dword ptr [ecx], eax
	.if (eax)
		invoke vf(m_pStream, IUnknown, AddRef)
		return S_OK
	.else
		return E_OUTOFMEMORY
	.endif

GetViewStateStream endp


GetControlWindow proc uses __this this_:ptr CShellBrowser, id:DWORD, lphwnd:ptr HWND
	DebugOut "IShellBrowser::GetControlWindow"
	mov __this, this_
	mov ecx, lphwnd
	mov dword ptr [ecx],NULL
	return E_NOTIMPL
GetControlWindow endp


SendControlMsg proc uses __this this_:ptr CShellBrowser, id:DWORD, uMsg:DWORD, wParam:WPARAM, lParam:LPARAM, pres:ptr DWORD
	DebugOut "IShellBrowser::SendControlMsg(%X,%X,%X,%X)", id, uMsg, wParam, lParam
	mov __this, this_
	mov ecx, pres
	.if (ecx)
		mov dword ptr [ecx], 0
	.endif
	return E_NOTIMPL
SendControlMsg endp


QueryActiveShellView proc uses __this this_:ptr CShellBrowser, ppshv:ptr LPSHELLVIEW
	DebugOut "IShellBrowser::QueryActiveShellView"
	mov __this, this_
	mov ecx, ppshv
	mov eax, m_pShellView
	mov dword ptr [ecx], eax
	.if (eax)
		invoke vf(eax, IShellView, AddRef)
	.endif
	return S_OK
QueryActiveShellView endp


OnViewWindowActive proc uses __this this_:ptr CShellBrowser, pshv:LPSHELLVIEW
	DebugOut "IShellBrowser::OnViewWindowActive"
	mov __this, this_
	return S_OK
OnViewWindowActive endp


SetToolbarItems proc uses __this this_:ptr CShellBrowser, lpButtons:ptr TBBUTTON, nButtons:DWORD, uFlags:DWORD
	DebugOut "IShellBrowser::SetToolbarItems"
	mov __this, this_
	return S_OK
SetToolbarItems endp

if ?SERVICEPROVIDER
QueryInterface_:
	sub	DWORD PTR [esp+4], CShellBrowser._IServiceProvider
	jmp	QueryInterface@CShellBrowser
AddRef_:
	sub	DWORD PTR [esp+4], CShellBrowser._IServiceProvider
	jmp	AddRef@CShellBrowser
Release_:
	sub	DWORD PTR [esp+4], CShellBrowser._IServiceProvider
	jmp	Release@CShellBrowser
QueryService_:
	sub	DWORD PTR [esp+4], CShellBrowser._IServiceProvider
	jmp	QueryService

QueryService proc uses __this this_:ptr CShellBrowser, guidService:REFGUID, riid:REFIID, ppv:ptr LPVOID
ifdef _DEBUG
local szGUID[40]:byte	
local wszGUID[40]:word	
local szIID[40]:byte
local wszIID[40]:word
	invoke StringFromGUID2, guidService, addr wszGUID, 40
	invoke WideCharToMultiByte, CP_ACP, 0, addr wszGUID, -1, addr szGUID, 40, NULL, NULL
	invoke StringFromGUID2, riid, addr wszIID, 40
	invoke WideCharToMultiByte, CP_ACP, 0, addr wszIID, -1, addr szIID, 40, NULL, NULL
endif
	DebugOut "CShellBrowser::QueryService(%s, %s)", addr szGUID, addr szIID
	return E_NOINTERFACE
QueryService endp
endif

if ?OLECOMMANDTARGET
QueryInterface2:
	sub	DWORD PTR [esp+4], CShellBrowser._IOleCommandTarget
	jmp	QueryInterface@CShellBrowser
AddRef2:
	sub	DWORD PTR [esp+4], CShellBrowser._IOleCommandTarget
	jmp	AddRef@CShellBrowser
Release2:
	sub	DWORD PTR [esp+4], CShellBrowser._IOleCommandTarget
	jmp	Release@CShellBrowser
QueryStatus_:
	sub	DWORD PTR [esp+4], CShellBrowser._IOleCommandTarget
	jmp	QueryStatus
Exec_:
	sub	DWORD PTR [esp+4], CShellBrowser._IOleCommandTarget
	jmp	Exec

QueryStatus proc uses __this this_:ptr CShellBrowser, pguidCmdGroup:REFGUID, cCmds:DWORD, prgCmds:ptr OLECMD, pCmdText:ptr OLECMDTEXT
	DebugOut "CShellBrowser::QueryStatus(%X, %X)", pguidCmdGroup, cCmds
	return OLECMDERR_E_UNKNOWNGROUP
QueryStatus endp

Exec proc uses __this this_:ptr CShellBrowser, pguidCmdGroup:REFGUID, nCmdID:DWORD, nCmdExecOpt:DWORD, pvaIn:ptr VARIANT, pvaOut:ptr VARIANT
	DebugOut "CShellBrowser::Exec(%X, %X, %X)", pguidCmdGroup, nCmdID, nCmdExecOpt
	return OLECMDERR_E_DISABLED
Exec endp

endif

	end

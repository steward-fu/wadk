@echo off
\masm32\bin\ml -c -coff -nologo cvviewer.asm
\masm32\bin\rc rsrc.rc
\masm32\bin\link /NOLOGO /SUBSYSTEM:WINDOWS cvviewer rsrc.res /DEF:cvviewer.def /DLL /MAP /OUT:CVViewer.dll



 1. About PE

 PE is a COFF file dumper. It dumps PE binaries (also PE32+), stand-alone
 COFF object modules and COFF modules contained in a library. Optionally it
 can be instructed to write exports found in the binary to a .DEF file.

 PE is supplied in 2 formats:
 - PE.EXE  : Win32 console application
 - PED.EXE : 32bit DOS binary.

 Additionally, there is JDISASM.DLL, which is needed and dynamically loaded
 when option /DISASM has been entered. Please note that JDISASM.DLL is a bit
 ancient and also unable to disassemble 64-bit code.

 Current version of PE may be found at http://www.japheth.de.


 2. Usage Notes

  - Switch /CODEVIEW: to make MS C compilers write their debugging info into
    the object module, it may be necessary to set option -Z7 instead of -Zi.

  - to create a .DEF file from an import library, use switches /ARCHIVEMEMBERS
    and /D. Example:

      pe /D /ARCHIVEMEMBERS kernel32.lib >xxx

    will create kernel32.def. Note that if the .DEF file is to be used to 
    recreate a library, POLIB ( part of PellesC ) is supposed to be used. 
    MS LIB cannot properly handle the format written by PE.


 3. License

 PE is free to use. Copyright japheth 2002-2013.




 1. Overview of AsmCtrlX

 AsmCtrlX is an OLE control written in ASM. Unlike AsmCtrl, which is quite
 similiar in functionality and is written without the help of complex
 macros, AsmCtrlX DOES use such macros. The goal is to hide some of the
 COM peculiarities, to reduce complexity. So it is a bit like the combination
 of VC and ATL. 
  
 The object structure is MS VC compatible, all vtables are located at the
 start of the object (defined in CAsmClass.inc). Events are fully supported
 and on an abstraction level which avoids fiddling around with Connection 
 Points and IDispatch interface.


 2. How to generate and execute the sample

 a. Get the WinInc include files from
    http://www.japheth.de/WinInc.html

 b. run NMAKE to create the control. But first view file MakeFile for
    details. If you get assemble errors, activate macro vf() in winasm.inc,
    which may be inactive for earlier versions of WinInc.

 c. register the control with "regsvr32.exe asmctrlx.dll". regsvr32.exe
    should be found in the windows system directory.

 d. unpack the samples.zip to get a document for a container app. Then I
    suggest to start with clicking on AsmCtrlx.htm (you will need a browser
    supporting activex controls.
 
 e. unregister the control with "regsvr32.exe /u asmctrlx.dll"

 If file AsmCtrlx.IDL has been changed, MIDL must run to reflect
 the changes to AsmCtrlx.TLB. Furthermore, the new methods/properties
 have to be added to AsmCtrlx.inc. COMView may be used to automate this
 task (can be downloaded from http://www.japheth.de/Download/comview.zip).


 3. Brief source file description

 The relevant files for the sample are:

 - ASMCTRLX.ASM  : file for definitions on module level (DllRegisterServer, ...)
 - CASMCLASS.INC : defines coclass AsmClass (equates, structure, protos)
 - CASMCLASS.ASM : defines coclass AsmClass (data + procs)
 - CASMPROP.INC  : defines coclass AsmProp (equates, structure, protos)
 - CASMPROP.ASM  : defines coclass AsmProp (data + procs)
 - OLECNTRL.INC  : here the macros for OLE control support may be found
 - ASMCTRLX.INC  : ASM translation of .IDL file (COMView generated)
 - ASMCTRLXC.INC : dispatch helper (COMView generated)
 - CDUMMY.ASM    : sample for a new interface to add to CAsmClass coclass
 - ASMCTRLX.IDL  : IDL file describing the dual interface
 - RSRC.RC       : resources


 In samples.zip are some files for container apps: 

 - ASMCTRLX.HTM            : to start the control via IE
 - PROJECT1.VBP/VBW        : to show the usage form within VB
 - Test.vbs                : shows how to use AsmCtrlX with WSH



4. History

Version 1.0: 12/2001   first version
Version 1.1: 03/2002   aggregation implemented. So AsmCtrl works with
                       WinWord + Excel
Version 1.2: 06/2002   code rearranged.
Version 1.3: 12/2002   a change in dispatch.asm so typeinfo of IAsmCtrl
                       doesn't need to be first typeinfo in type library.
Version 2.0: 01/2003   large parts of source code ported to macros in new
                       include file OLECNTRL.INC. This should make things
                       a lot more easier to understand. Possibly this
                       source may now in fact be used as a template.
Version 2.1: 02/2003   Name of member m_pClientSite changed to m_pOleClientSite.
                       Verb OLEIVERB_SHOW now activates control as in ATL.
Version 2.2: 07/2003   control saves its size to persistent store. 
Version 2.3: 06/2004   added CDummy.asm to show how to add new interfaces. 
Version 2.3.1: 06/2004 description in CDummy.asm was not complete. 
Version 2.4: 01/2005   source changed so that MASM32 is no longer required.
Version 2.4.1: 01/2005 some minor adjustments
Version 2.5, 01/2005   property sheet added.
Version 2.5.1, 01/2005 readme.txt changed
Version 2.5.2, 02/2005 adjusted to new version of macro L()
Version 2.5.3, 02/2005 bugfix: CStrW() macro now appends a 0 (thanks Wayne!)
Version 2.5.4, 03/2005 Makefile added, make.bat deleted
Version 2.5.5, 07/2008 Makefile changed, now JWasm is used instead of Masm
Version 2.5.6, 02/2011 renamed to AsmCtrlX, since the plain AsmCtrl version
                       which doesn't use OLECNTL.INC is available again.


5. License

 This code is Public Domain.

japheth


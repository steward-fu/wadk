
;--- How to add new interfaces to CAsmClass coclass
;
;--- 1. changes in CAsmClass.inc:
;---    - add new COM_INTERFACE_ENTRY in CAsmClass struct
;---    - add new variables - if any - in CAsmClass struct
;---    - the vtable of the new interface must be public. 
;---      One method to achieve this is to define:
;---        externdef C<interface>Vtbl_CAsmClass:DWORD
;--- 2. changes in CAsmClass.asm:
;---    - initialize vtable pointer in the constructor Create@CAsmClass.
;---      This may be done by:
;---        mov m__I<interface>, offset C<interface>Vtbl_CAsmClass
;---    - initialize new variables in Create@CAsmClass.
;---      If simple access to the variables (with prefix "m_") is
;---      wanted, they have to be added to a MEMBER macro call.
;---    - add the new interface to the table of interfaces known by
;---      QueryInterface by changing macro call DEFINE_KNOWN_INTERFACES.
;---    - define the IID of the interface in the .CONST section:
;---        IID_I<interface> IID <0,1,2,<3,4,5,6,7,8,9,0Ah>>
;--- 3. new file C<interface>.asm:
;---    - create a new source file for the implementation of the 
;---      interface methods. CDummy.ASM may be used as a template.
;--- 4. MAKE.BAT or MAKEFILE:
;---    - add the new source file to the project.


;--- if the interface to add is NOT defined already in an include file
;--- it has to be defined like this:

;--- BEGIN INTERFACE IDummy, IUnknown
;---    STDMETHOD DummyProc
;--- END_INTERFACE

	.586
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN	equ 1
INC_OLE2			equ 1
	include windows.inc
	include olectl.inc

	include macros.inc
	include disphlp.inc
	include olecntrl.inc
	include debugout.inc

	include AsmCtrlX.inc	;type information (COMView generated)
	include AsmCtrlXc.inc	;dispatch helper (COMView generated)
	.list
	.cref

	include CAsmClass.inc

	.const

;--- this is the vtable and has to be public.
;--- usually this is achieved by an "externdef" line in CAsmClass.inc,
;--- but as well one may add a "public" definition here and an "extern"
;--- definition in CAsmClass.asm.

;	public CDummyVtbl_CAsmClass
    
CDummyVtbl_CAsmClass label dword
	dd QueryInterface, AddRef, Release
    dd DummyProc_

	.code

__this	textequ <ebx>
_this	textequ <[__this].CAsmClass>

;--------------------------------------------------------------------------
;--- provide short names for our members so "dwValue"
;--- can be accessed with "m_dwValue" instead of "[ebx].CAsmClass.dwValue"
;--------------------------------------------------------------------------

;--- add new properties here    
;	MEMBER dwDummy

;--- the implementation part: please note that this_ is adjusted
;--- so it points to the start of the real object

QueryInterface:
	sub dword ptr [esp+4], CAsmClass._IDummy
    jmp QueryInterface@CAsmClass
AddRef:
	sub dword ptr [esp+4], CAsmClass._IDummy
    jmp AddRef@CAsmClass
Release:
	sub dword ptr [esp+4], CAsmClass._IDummy
    jmp Release@CAsmClass

DummyProc_:
	sub dword ptr [esp+4], CAsmClass._IDummy
    
DummyProc proc uses __this this_:ptr CAsmClass
	mov __this, this_
    
;---- do anything useful here

	mov eax, S_OK
	ret
DummyProc endp

	end

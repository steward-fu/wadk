

;--- AsmCtrlX: An OCX control in ASM

;--- naming conventions:
;--- - the typelib/module is called AsmCtrlX
;--- - the coclass/CLSID is called AsmClass, with interface IAsmClass
;--- that should be distinguished, because a typelib may define
;--- more than 1 coclass/CLSID.

;--- So in this file define infos on the typelib level
;--- needed for DllRegisterServer, DllUnregisterServer + DllGetClassObject.
;--- Describe each coclass in its own source file (C<coclass>.asm)

;--- this sample can be used as a template. To create a control do:
;--- 1. adjust all infos in the .IDL file (AsmCtrlX.idl)
;--- 2. generate include file(s) with COMView (AsmCtrlX.inc)
;--- 3. adjust AsmCtrlX.asm (this file) if necessary (name of coclass i.e.)
;--- 4. supply CLSID specific definitions in .INC file (CAsmClass.inc)
;--- 5. supply CLSID specific data/procs  in .ASM file (CAsmClass.asm)

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN equ 1
INC_OLE2			equ 1
	include windows.inc
	include olectl.inc

	include macros.inc
	include disphlp.inc
	include olecntrl.inc
	include debugout.inc
	.list
	.cref

	includelib  kernel32.lib
	includelib  advapi32.lib
	includelib  user32.lib
	includelib  gdi32.lib
	includelib  oleaut32.lib
	includelib  ole32.lib
	includelib  uuid.lib

	include AsmCtrlX.inc		;COMView generated: AsmCtrlX interfaces
	include CAsmClass.inc
	include CAsmProp.inc

;--------------------------------------------------------------------------

externdef g_DllRefCount:DWORD

	.const

LIBID_AsmCtrlX	sTLBID_AsmCtrlX

;--- the DEBUGPREFIX is a string to distinguish our output
;--- from others on the debug terminal. look debugout.inc for details

ifdef _DEBUG
externdef DEBUGPREFIX:LPSTR
DEBUGPREFIX LPSTR CStr("AsmCtrlX:")
endif

;--- the object table: defines coclasses installed by this module
;--- used by DllGetClassObject, DllRegisterServer + DllUnregisterServer

;--- ObjectEntry = {REFGUID pClsId;
;---			REFGUID pLibId; SWORD wVerMajor; SWORD wVerMinor;
;---			LPREGSTRUCT pRegKeys;
;---			LPCONSTRUCTOR constructor}

BEGIN_OBJECT_MAP ObjectMap
	ObjectEntry {\
		offset CLSID_CAsmClass,\
		offset LIBID_AsmCtrlX, _MajorVer_AsmCtrlX, _MinorVer_AsmCtrlX,\
		offset RegKeys_CAsmClass,\
		Create@CAsmClass}
	ObjectEntry {\
		offset CLSID_CAsmProp,\
		NULL, 0, 0,\
		offset RegKeys_CAsmProp,\
		Create@CAsmProp}
;-------------------------------------------
;--- include further ObjectEntry {} here ---
;-------------------------------------------
END_OBJECT_MAP

;--------------------------------------------------------------------------

;--- define standard COM functions
;--- one instance for all coclasses in this module

	DEFINE_COMHELPER
	DEFINE_CLASSFACTORY
	DEFINE_GETCLASSOBJECT offset ObjectMap
	DEFINE_REGISTERSERVER offset ObjectMap
	DEFINE_UNREGISTERSERVER offset ObjectMap
	DEFINE_CANUNLOADNOW
	DEFINE_DLLMAIN		;DllMain std (saves hInstance in g_hInstance)


end DllMain

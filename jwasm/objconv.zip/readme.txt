
 About OBJCONV

 Objconv v2.09, 08/2009, written by Agner Fog. It's released under GNU
 General Public License www.gnu.org/copyleft/gpl.html.

 This package contains a DOS binary. Source may be found at
 http://www.japheth.de/Download/objconvs.zip
 
 The most recent source is available at http://www.agner.org/optimize. 
 A PDF manual can be found there as well.


modifications after running h2incx:

1. sdl_types.inc:

+ macro SDL_COMPILE_TIME_ASSERT()
+ __int64 not defined


2. sdl_audio.inc:

- SDL_AudioCVT structure contains a field of function pointers, 
  this is currently not supported by h2incx
- macro SDL_LoadWAV adjusted


3. sdk_keyboard.inc:

reserved word "mod" used as member name


4. sdl_mutex.inc:

SDL_semaphore not defined. in sdl_mutex.h, it is defined as

struct SDL_semaphore;

5. begin_code/close_code:

since MASM has no "undefine", usage of _begin_code_h has to be modified
SDLCALL has to be defined as <c>


6. sdl_joystick.inc

_SDL_Joystick not defined. in sdl_joystick.h, it is defined as

struct _SDL_Joystick;


7: sdl_video.inc:

  - macros SDL_LoadBmp/SDL_SaveBmp adjusted 
  - alignment 4 added to SDL_Surface


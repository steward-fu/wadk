
;*** a simple ISAPI extension ***

	.386
	.MODEL FLAT, STDCALL
	option casemap:none
	option proc:private

	.nolist
	.nocref
WIN32_LEAN_AND_MEAN equ 1
	include windows.inc
	include HttpExt.inc
	include macros.inc
	include debugout.inc
	.list
	.cref

	.data

g_hHeap	HANDLE 0

	.const

szHello db "<HTML><TITLE>AsmIsapi is here</TITLE><BODY>",13,10
		db "Method=%s<br>",13,10
		db "QueryString=%s<br>",13,10
		db "PathInfo=%s<br>",13,10
		db "PathTranslated=%s<br>",13,10
		db "TotalBytes=%u<br>",13,10
		db "Available=%u<br>",13,10
		db "ContentType=%s<br>",13,10
		db 0
		
szEndBody db "</BODY></HTML>",0

szNull	db "Null",0

szContHdr db "Content-Type: text/html",13,10
		db "Content-Length: %u",13,10,13,10,0

	.CODE

AddVarToBody proc pszVarName:LPSTR, pszBody:LPSTR

local dwLength:DWORD
local szVar[512]:byte

	assume ebx:ptr EXTENSION_CONTROL_BLOCK

	invoke lstrcat, pszBody, pszVarName
	mov dwLength, sizeof szVar-1
	mov szVar,'='
	invoke [ebx].GetServerVariable, [ebx].ConnID, pszVarName,\
		addr szVar+1, addr dwLength
	push eax
	.if (eax)
		invoke lstrcat, pszBody, addr szVar
	.else
		invoke lstrcat, pszBody, CStr(" unsupported")
	.endif
	invoke lstrcat, pszBody, CStr(<"<br>",13,10>)
	pop eax
	ret
	assume ebx:nothing

AddVarToBody endp



HttpExtensionProc proc public uses ebx pECB:ptr EXTENSION_CONTROL_BLOCK

local dwLength:DWORD
local szVar[128]:byte
local szHeader[128]:byte
local pszBody:LPSTR
local pszMethod:LPSTR
local pszQueryString:LPSTR
local pszPathInfo:LPSTR
local pszPathTranslated:LPSTR
local pszContentType:LPSTR
local pszVarName:LPSTR

	DebugOut "ASMISAPI: HttpExtensionProc"

	mov ebx,pECB
	assume ebx:ptr EXTENSION_CONTROL_BLOCK

	invoke HeapAlloc, g_hHeap, 0, 4096
	.if (!eax)
		return HSE_STATUS_ERROR
	.endif

	mov pszBody, eax

;---- make sure we have valid string pointers

	mov pszMethod, offset szNull
	mov pszQueryString, offset szNull
	mov pszPathInfo, offset szNull
	mov pszPathTranslated, offset szNull
	mov pszContentType, offset szNull

	mov eax,[ebx].lpszMethod
	.if (eax)
		mov pszMethod, eax
	.endif
			
	mov eax,[ebx].lpszQueryString
	.if (eax)
		mov pszQueryString, eax
	.endif

	mov eax,[ebx].lpszPathInfo
	.if (eax)
		mov pszPathInfo, eax
	.endif

	mov eax,[ebx].lpszPathTranslated
	.if (eax)
		mov pszPathTranslated, eax
	.endif

	mov eax,[ebx].lpszContentType
	.if (eax)
		mov pszContentType, eax
	.endif

	invoke wsprintf, pszBody, addr szHello, pszMethod,\
		pszQueryString, pszPathInfo, pszPathTranslated,\
		[ebx].cbTotalBytes, [ebx].cbAvailable, pszContentType


	invoke AddVarToBody, CStr("ALL_HTTP"), pszBody
	invoke AddVarToBody, CStr("REQUEST_METHOD"), pszBody
	invoke AddVarToBody, CStr("PATH_INFO"), pszBody
	invoke AddVarToBody, CStr("PATH_TRANSLATED"), pszBody
	invoke AddVarToBody, CStr("REMOTE_HOST"), pszBody
	invoke AddVarToBody, CStr("REMOTE_ADDR"), pszBody
	invoke AddVarToBody, CStr("CONTENT_LENGTH"), pszBody
	invoke AddVarToBody, CStr("CONTENT_TYPE"), pszBody
	invoke AddVarToBody, CStr("SERVER_NAME"), pszBody
	invoke AddVarToBody, CStr("SERVER_PORT"), pszBody
	invoke AddVarToBody, CStr("SERVER_SOFTWARE"), pszBody
	invoke AddVarToBody, CStr("SERVER_PROTOCOL"), pszBody
	invoke AddVarToBody, CStr("QUERY_STRING"), pszBody
	invoke AddVarToBody, CStr("HTTP_HOST"), pszBody
	invoke AddVarToBody, CStr("HTTP_ACCEPT"), pszBody
	invoke AddVarToBody, CStr("SCRIPT_NAME"), pszBody

	mov dwLength, sizeof szVar
	invoke [ebx].GetServerVariable, [ebx].ConnID, CStr("SCRIPT_NAME"),\
		addr szVar, addr dwLength
	.if (eax)
		invoke lstrcat, pszBody, CStr("translated SCRIPT_NAME=")
		mov dwLength, sizeof szVar
		invoke [ebx].ServerSupportFunction, [ebx].ConnID,\
			HSE_REQ_MAP_URL_TO_PATH,\
			addr szVar, addr dwLength, 0
		.if (eax)
			invoke lstrcat, pszBody, addr szVar
		.else
			invoke lstrcat, pszBody, CStr("unsupported")
		.endif
		invoke lstrcat, pszBody, CStr(<"<br>",13,10>)
	.endif

	invoke lstrcat, pszBody, addr szEndBody
	invoke lstrlen, pszBody
	mov dwLength, eax

;----------------------------- generate header "Content-Type"/"Content-Length"
	invoke wsprintf, addr szHeader, addr szContHdr, dwLength

;----------------------------- write header
	invoke [ebx].ServerSupportFunction,	[ebx].ConnID, \
			HSE_REQ_SEND_RESPONSE_HEADER,\
			0, 0, addr szHeader

;----------------------------- write content
	invoke [ebx].WriteClient, [ebx].ConnID,	pszBody, addr dwLength, HSE_IO_SYNC

	invoke HeapFree, g_hHeap, 0, pszBody

	return HSE_STATUS_SUCCESS_AND_KEEP_CONN
	assume ebx:nothing

HttpExtensionProc endp


GetExtensionVersion proc public pHVI:ptr HSE_VERSION_INFO

	DebugOut "ASMISAPI: GetExtensionVersion"

	mov ecx,pHVI
	mov [ecx].HSE_VERSION_INFO.dwExtensionVersion, HSE_VERSION
	invoke lstrcpy, addr [ecx].HSE_VERSION_INFO.lpszExtensionDesc, CStr("ASM ISAPI Extension")
	mov eax,1
	ret
GetExtensionVersion endp


;*** DllMain ***

DllMain proc public handle:dword, reason:dword, resrvd:dword

local	szStr[80]:byte

	mov eax,reason
	.if (eax == DLL_PROCESS_ATTACH)
ifdef _DEBUG
		invoke HeapCreate, HEAP_GENERATE_EXCEPTIONS, 8000h, 0
else
		invoke GetProcessHeap
endif
		mov g_hHeap, eax
		DebugOut "ASMISAPI: process attaching"
	.elseif (eax == DLL_PROCESS_DETACH)
		DebugOut "ASMISAPI: process detaching"
ifdef _DEBUG
		invoke HeapDestroy, g_hHeap
endif
	.endif
	mov eax,1
	ret
DllMain endp

	END DllMain



#define STRICT

#include "EmailClient.h"
#include "resource.h"

HINSTANCE g_hInstance;
CEmailClient * g_pMain;
WNDPROC g_pEditProc;


static char * pszMainWndClass = {"ThreePanelApp"};

static TBBUTTON g_tbbutton[] = {	// array of buttons for toolbar
	{1, IDM_DELETE, 0, TBSTYLE_BUTTON, 0, 0}
};

static CColHdr chtab[] = {16, "Column 1",
				16, "Column 2",
				12, "Column 3",
				48, "Column 4",
				0
};

// subclassing multi line edit control in main window
// to avoid closing window wenn ESC is pressed
// and to allow TAB to switch to next child

LRESULT CALLBACK myeditproc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (message == WM_GETDLGCODE)
		return DLGC_STATIC;
	return CallWindowProc(g_pEditProc, hWnd, message, wParam, lParam);
}

// definition of CEmailClient methods

// constructor of main class

CEmailClient::CEmailClient(): C3PanelView( pszMainWndClass, "3 Panel Sample")
{
	SetToolBar(2, IDB_BITMAP1, 1, g_tbbutton);
	hMenu = GetMenu(hWnd);
	SetMenu(FALSE);
	g_pEditProc = (WNDPROC)SetWindowLong(m_hWndEdit, GWL_WNDPROC, (LONG)myeditproc);
	SetColumns();
	InitTreeView();
}

// destructor

CEmailClient::~CEmailClient()
{
}

// Set state of some menu items

void CEmailClient::SetMenu(BOOL bEnable)
{
	DWORD dwLogonFlag;
	DWORD dwMenuFlag;

	if (bEnable) {
		dwLogonFlag = MF_BYCOMMAND | MF_DISABLED | MF_GRAYED;
		dwMenuFlag = MF_BYCOMMAND | MF_ENABLED;
	} else {
		dwLogonFlag = MF_BYCOMMAND | MF_ENABLED;
		dwMenuFlag = MF_BYCOMMAND | MF_DISABLED | MF_GRAYED;
	}

	EnableMenuItem(hMenu, IDM_LOGON,	dwLogonFlag);
	EnableMenuItem(hMenu, IDM_LOGOFF,	dwMenuFlag);
	return;
}


// SetColumns: set the listview column header	

void CEmailClient::SetColumns()
{
	int i;
	LV_COLUMN lvc;
	CColHdr * pCH;

	while (ListView_DeleteColumn(hWndLV,0));

	for (i = 0,pCH = chtab; pCH->iSize; pCH++,i++) {
		lvc.mask = LVCF_TEXT | LVCF_WIDTH;
		lvc.cx = pCH->iSize * 8;
		lvc.pszText = pCH->pText;
		ListView_InsertColumn(hWndLV,i,&lvc);
	}
	return;
}

// initialize listview (right panel)

int CEmailClient::UpdateListView(int iMode)
{
	int i,j;
	LV_ITEM lvi;
	char szText[128];

	SetWindowRedraw(hWndLV, FALSE);
	ListView_DeleteAllItems(hWndLV);
	SetWindowText(m_hWndEdit, "");

	switch( iMode) {
	case 0:
		for (i = 0; i < 6; i++) {
			lvi.iItem = i;
			lvi.iSubItem = 0;
			lvi.mask = LVIF_TEXT;
			wsprintf(szText, "Item %u", i);
			lvi.pszText = szText;
			ListView_InsertItem(hWndLV, &lvi);
			for (j = 1; j < 4 ; j++) {
				lvi.iSubItem++;
				wsprintf(szText, "Subitem %u,%u", i, j);
				ListView_SetItem(hWndLV, &lvi);
			}
		}
		SetStatusText( 0, "Mode 0");
		break;
	case 1:
		for (i = 0; i < 3; i++) {
			lvi.iItem = i;
			lvi.iSubItem = 0;
			lvi.mask = LVIF_TEXT;
			wsprintf(szText, "Item %u", i);
			lvi.pszText = szText;
			ListView_InsertItem(hWndLV, &lvi);
			for (j = 1; j < 4 ; j++) {
				lvi.iSubItem++;
				wsprintf(szText, "Subitem %u,%u", i, j);
				ListView_SetItem(hWndLV, &lvi);
			}
		}
		SetStatusText( 0, "Mode 1");
		break;
	}
	SetWindowRedraw(hWndLV, TRUE);
	return 1;
}

// handle WM_COMMAND of main window

LRESULT CEmailClient::OnCommand( WPARAM wParam, LPARAM lParam)
{
	ULONG	ulResult = SUCCESS_SUCCESS;

	switch (LOWORD(wParam)) {
	case IDM_LOGON:
		break;
	case IDM_LOGOFF:
		break;
	case IDM_EXIT:
		PostMessage(hWnd, WM_CLOSE, 0, 0);
		break;
	case IDC_LIST1:
		break;
	case IDC_EDIT1:
		break;
	case IDOK:
		break;
	case IDCANCEL:
		break;
	default:
		return C3PanelView::OnCommand( wParam, lParam);
	}

	return ulResult;
}

// handle WM_NOTIFY of main window

LRESULT CEmailClient::OnNotify( WPARAM wParam, LPNMHDR pNMHdr)
{
	LPNM_LISTVIEW pNMLV = (LPNM_LISTVIEW)pNMHdr;
	LPNM_TREEVIEW pNMTV = (LPNM_TREEVIEW)pNMHdr;
	char	szText[128];
	LV_ITEM	lvi;

	switch (pNMHdr->code) {
	case TVN_SELCHANGED:
		pNMTV = (LPNM_TREEVIEW)pNMHdr;
		UpdateListView(pNMTV->itemNew.lParam);
		break;
	case LVN_ITEMCHANGED:		// update edit window
		if (pNMLV->uNewState & LVIS_SELECTED) {
			SetStatusText(0, "");
			lvi.iItem = pNMLV->iItem;
			lvi.iSubItem = 0;
			lvi.pszText = szText;
			lvi.cchTextMax = sizeof(szText);
			lvi.mask = LVIF_TEXT;
			if (ListView_GetItem(hWndLV, &lvi)) {
				SetStatusText( 0, szText);
				wsprintf(szText, "Text of item %u", lvi.iItem);
				SetWindowText( m_hWndEdit, szText);
			}
		}
		break;
	case LVN_KEYDOWN:
		switch (((LV_KEYDOWN *)pNMHdr)->wVKey) {
		case VK_DELETE:		// user pressed delete
			break;
		}
		break;
	default:
		return C3PanelView::OnNotify( wParam, pNMHdr);
	}
	return 0;
}

// initialize treeview (left panel)

int CEmailClient::InitTreeView()
{
	HTREEITEM hTree;
	TV_INSERTSTRUCT tvs;

	SetWindowRedraw( m_hWndTreeView, FALSE);

	TreeView_DeleteAllItems( m_hWndTreeView);

	tvs.hInsertAfter = TVI_LAST;
	tvs.item.mask = TVIF_TEXT | TVIF_PARAM;		// only Text and Textmax in TV_ITEM is valid
	tvs.item.cchTextMax = 0;


	tvs.item.pszText = "Item 1";
	tvs.item.lParam = 0;
	tvs.hParent = 0;

	if (hTree = TreeView_InsertItem( m_hWndTreeView, &tvs)) {
	}

	tvs.item.pszText = "Item 2";
	tvs.item.lParam = 1;
	tvs.hParent = 0;

	if (hTree = TreeView_InsertItem( m_hWndTreeView, &tvs)) {
	}

	UpdateListView(-1);

	SetWindowRedraw( m_hWndTreeView, TRUE);

	return 1;
}

// WM_xxx

LRESULT CEmailClient::OnMessage(UINT Message, WPARAM wParam, LPARAM lParam)
{
	LRESULT rc = 0;

	switch (Message) {
	case WM_COMMAND:
		rc = OnCommand(wParam, lParam);
		break;
	case WM_NOTIFY:
		OnNotify(wParam, (LPNMHDR)lParam);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		rc = C3PanelView::OnMessage( Message, wParam, lParam);
	}
	return rc;
}

/************************************************************************/
/*																		*/
/* Main Window Procedure												*/
/*																		*/
/************************************************************************/

LRESULT CALLBACK WndProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	LRESULT rc = 0;
	
	if (Message == WM_CREATE) {
		g_pMain = (CEmailClient *)((CREATESTRUCT *)lParam)->lpCreateParams;
		g_pMain->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG)g_pMain);
	}

	CEmailClient * pV = (CEmailClient *)GetWindowLong(hWnd, 0);

	if (pV)
		rc = pV->OnMessage(Message, wParam, lParam);
	else
		rc = DefWindowProc(hWnd, Message, wParam, lParam);
	return rc;
}

// InitApp Function											

int InitApp(void)
{
 WNDCLASS	wndclass;

	memset(&wndclass, 0, sizeof(WNDCLASS));

	wndclass.style = 0;
	wndclass.lpfnWndProc = WndProc;

	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = sizeof(CEmailClient *);
	wndclass.hInstance = g_hInstance;
	wndclass.hIcon = LoadIcon(g_hInstance, MAKEINTRESOURCE(IDI_ICON1));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);

 	wndclass.hbrBackground = NULL;
	wndclass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	wndclass.lpszClassName = pszMainWndClass;
	return RegisterClass(&wndclass);
}

/************************************************************************/
/*																		*/
/* Windows Main Program Body											*/
/*																		*/
/************************************************************************/

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{

 MSG	msg;		   /* MSG structure to store your messages		  */
 int	nRc;		   /* return value from Register Classes		  */
// HACCEL hAccel;
 char	szString[128]; 

	InitCommonControls();

	g_hInstance = hInstance;
//------------------------- register window classes
	if ((nRc = InitApp()) == 0)	{
		LoadString(hInstance, IDS_ERR_REGISTER_CLASS, szString, sizeof(szString));
		MessageBox(NULL, szString, NULL, MB_ICONEXCLAMATION);
		return -1;
	}

//	hAccel = LoadAccelerators(g_hInstance, MAKEINTRESOURCE(IDR_ACCELERATOR1));

	g_pMain = new CEmailClient();
			
	if(g_pMain->hWnd == NULL) {
		LoadString(g_hInstance, IDS_ERR_CREATE_WINDOW, szString, sizeof(szString));
		MessageBox(NULL, szString, NULL, MB_ICONEXCLAMATION);
		return IDS_ERR_CREATE_WINDOW;
	}

	g_pMain->ShowWindow(nCmdShow);

	while(GetMessage(&msg, NULL, 0, 0))		/* Until WM_QUIT message	*/
	{
		if (IsDialogMessage(g_pMain->hWnd, &msg))
			continue;
//---------------------------------------- activate if accelerator exists
//		if (TranslateAccelerator(g_pMain->hWnd, hAccel, &msg))
//			continue;
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	delete g_pMain;

	return msg.wParam;
}


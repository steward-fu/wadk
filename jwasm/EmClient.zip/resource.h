//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EmailClient.rc
//
#define IDR_ACCELERATOR1                101
#define IDC_CURSOR1                     102
#define IDC_CURSOR2                     103
#define IDR_MENU1                       104
#define IDI_ICON1                       105
#define IDB_BITMAP1                     107
#define IDD_DIALOG1                     108
#define IDC_TREE1                       1000
#define IDC_LIST1                       1001
#define IDC_EDIT1                       1002
#define IDC_STATUSBAR                   1003
#define IDC_TOOLBAR                     1004
#define IDC_EDIT2                       1005
#define IDC_EDIT3                       1006
#define IDC_EDIT4                       1007
#define IDC_EDIT5                       1008
#define IDC_EDIT6                       1009
#define IDM_LOGON                       40001
#define IDM_LOGOFF                      40002
#define IDM_SENDMAIL                    40003
#define IDM_DOCUMENT                    40004
#define IDM_READ                        40005
#define IDM_DELETE                      40006
#define IDM_EXIT                        40007
#define IDM_SAVEMAIL                    40008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif


class C3PanelView {
	HCURSOR hCursorX;
	HCURSOR hCursorY;
	HBRUSH hHalftoneBrush;
	int iOldResizeLine;
	BOOL bVertical;
protected:
	HWND m_hWndTreeView;
	HWND hWndLV;
	HWND m_hWndEdit;
	HWND hWndToolBar;
	HWND hWndStatusBar;
	LPSTR pszEditClass;
	DWORD dwEditStyle;
public:
	HWND hWnd;
private:
	void OnPaint();
	void OnSize(int iNewHeight, int iNewWidth);
	void DrawResizeLine(int xPos, int yPos);
protected:
	LRESULT OnCreate();
	void SetToolBar(int iImages, int iBMResId, int uNumButtons, TBBUTTON * pTBB);
	LRESULT OnNotify( WPARAM wParam, LPNMHDR pNMHdr);
	LRESULT OnCommand(WPARAM wParam, LPARAM lParam);
	C3PanelView( LPSTR pszAppClass, LPSTR pszAppName);
	LRESULT OnMessage(UINT message, WPARAM wParam, LPARAM lParam);
	int SetStatusText(int iPart, LPSTR pszText);
public:
	int ShowWindow(int iCmdShow);
};



This is a code template in native C++ showing a window with:

- a toolbar control 
- a treeview control on the left side
- a listview control on the upper right side
- a edit control on the lower right side
- a statusbar control at the bottom

Some email clients use this structure, so I called the view CEmailView, but
it may be useful for many other purposes.

japheth





#include <windows.h>
#include <windowsx.h>
#include <mapi.h>
#include <commctrl.h>
#include <string.h>
#include <stdio.h>
#include "C3PanelView.h"

#define IDS_ERR_REGISTER_CLASS   100
#define IDS_ERR_CREATE_WINDOW    101

extern HINSTANCE g_hInstance;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);


class CColHdr {
public:
	int iSize;
	char * pText;
};

class CEmailClient: public C3PanelView {
	HMENU hMenu;

	LRESULT OnCommand(WPARAM wParam, LPARAM lParam);
	LRESULT OnNotify( WPARAM wParam, LPNMHDR pNMHdr);
	void SetMenu(BOOL);
	void SetColumns();
	int InitTreeView();
	int UpdateListView(int iMode);
	void InitMessage();
public:
	LRESULT OnMessage(UINT message, WPARAM wParam, LPARAM lParam);
	CEmailClient();
	~CEmailClient();
};

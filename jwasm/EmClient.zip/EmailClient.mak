# Microsoft Developer Studio Generated NMAKE File, Based on EmailClient.dsp
!IF "$(CFG)" == ""
CFG=EmailClient - Win32 Release
!MESSAGE Keine Konfiguration angegeben. EmailClient - Win32 Release wird als\
 Standard verwendet.
!ENDIF 

!IF "$(CFG)" != "EmailClient - Win32 Release" && "$(CFG)" !=\
 "EmailClient - Win32 Debug"
!MESSAGE Ung�ltige Konfiguration "$(CFG)" angegeben.
!MESSAGE Sie k�nnen beim Ausf�hren von NMAKE eine Konfiguration angeben
!MESSAGE durch Definieren des Makros CFG in der Befehlszeile. Zum Beispiel:
!MESSAGE 
!MESSAGE NMAKE /f "EmailClient.mak" CFG="EmailClient - Win32 Release"
!MESSAGE 
!MESSAGE F�r die Konfiguration stehen zur Auswahl:
!MESSAGE 
!MESSAGE "EmailClient - Win32 Release" (basierend auf\
  "Win32 (x86) Application")
!MESSAGE "EmailClient - Win32 Debug" (basierend auf  "Win32 (x86) Application")
!MESSAGE 
!ERROR Eine ung�ltige Konfiguration wurde angegeben.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "EmailClient - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\EmailClient.exe"

!ELSE 

ALL : "$(OUTDIR)\EmailClient.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\C3PanelView.obj"
	-@erase "$(INTDIR)\EmailClient.obj"
	-@erase "$(INTDIR)\EmailClient.res"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\EmailClient.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS"\
 /Fp"$(INTDIR)\EmailClient.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x407 /fo"$(INTDIR)\EmailClient.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\EmailClient.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 comctl32.lib advapi32.lib shell32.lib dcrt32s.lib /nologo /subsystem:windows\
 /incremental:no /pdb:"$(OUTDIR)\EmailClient.pdb" /machine:I386 /nodefaultlib\
 /out:"$(OUTDIR)\EmailClient.exe" 
LINK32_OBJS= \
	"$(INTDIR)\C3PanelView.obj" \
	"$(INTDIR)\EmailClient.obj" \
	"$(INTDIR)\EmailClient.res"

"$(OUTDIR)\EmailClient.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "EmailClient - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\EmailClient.exe"

!ELSE 

ALL : "$(OUTDIR)\EmailClient.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\C3PanelView.obj"
	-@erase "$(INTDIR)\EmailClient.obj"
	-@erase "$(INTDIR)\EmailClient.res"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\EmailClient.exe"
	-@erase "$(OUTDIR)\EmailClient.ilk"
	-@erase "$(OUTDIR)\EmailClient.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MLd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /Fp"$(INTDIR)\EmailClient.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x407 /fo"$(INTDIR)\EmailClient.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\EmailClient.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 comctl32.lib advapi32.lib shell32.lib dcrt32s.lib /nologo /subsystem:windows\
 /incremental:yes /pdb:"$(OUTDIR)\EmailClient.pdb" /debug /machine:I386\
 /nodefaultlib /out:"$(OUTDIR)\EmailClient.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\C3PanelView.obj" \
	"$(INTDIR)\EmailClient.obj" \
	"$(INTDIR)\EmailClient.res"

"$(OUTDIR)\EmailClient.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(CFG)" == "EmailClient - Win32 Release" || "$(CFG)" ==\
 "EmailClient - Win32 Debug"
SOURCE=.\C3PanelView.cpp

!IF  "$(CFG)" == "EmailClient - Win32 Release"

DEP_CPP_C3PAN=\
	".\C3PanelView.h"\
	"c:\programme\devstudio\vc6\include\basetsd.h"\
	"c:\programme\devstudio\vc6\include\msxml.h"\
	"c:\programme\devstudio\vc6\include\rpcasync.h"\
	

"$(INTDIR)\C3PanelView.obj" : $(SOURCE) $(DEP_CPP_C3PAN) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "EmailClient - Win32 Debug"

DEP_CPP_C3PAN=\
	".\C3PanelView.h"\
	"c:\programme\devstudio\vc6\include\basetsd.h"\
	"c:\programme\devstudio\vc6\include\msxml.h"\
	"c:\programme\devstudio\vc6\include\rpcasync.h"\
	

"$(INTDIR)\C3PanelView.obj" : $(SOURCE) $(DEP_CPP_C3PAN) "$(INTDIR)"


!ENDIF 

SOURCE=.\EmailClient.cpp

!IF  "$(CFG)" == "EmailClient - Win32 Release"

DEP_CPP_EMAIL=\
	".\C3PanelView.h"\
	".\EmailClient.h"\
	"c:\programme\devstudio\vc6\include\basetsd.h"\
	"c:\programme\devstudio\vc6\include\msxml.h"\
	"c:\programme\devstudio\vc6\include\rpcasync.h"\
	

"$(INTDIR)\EmailClient.obj" : $(SOURCE) $(DEP_CPP_EMAIL) "$(INTDIR)"


!ELSEIF  "$(CFG)" == "EmailClient - Win32 Debug"

DEP_CPP_EMAIL=\
	".\C3PanelView.h"\
	".\EmailClient.h"\
	"c:\programme\devstudio\vc6\include\basetsd.h"\
	"c:\programme\devstudio\vc6\include\msxml.h"\
	"c:\programme\devstudio\vc6\include\rpcasync.h"\
	

"$(INTDIR)\EmailClient.obj" : $(SOURCE) $(DEP_CPP_EMAIL) "$(INTDIR)"


!ENDIF 

SOURCE=.\EmailClient.rc
DEP_RSC_EMAILC=\
	".\C3PanelView.h"\
	".\EmailClient.h"\
	".\EmailClient.ico"\
	".\Splith.cur"\
	".\Splitv.cur"\
	".\Toolbar.bmp"\
	

"$(INTDIR)\EmailClient.res" : $(SOURCE) $(DEP_RSC_EMAILC) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)



!ENDIF 



#define STRICT

#include <windows.h>
#include <commctrl.h>
#include "C3PanelView.h"
#include "resource.h"

#define RESIZEBARHEIGHT 4

extern HINSTANCE g_hInstance;

// define methods of class C3PanelView

C3PanelView::C3PanelView(LPSTR pszAppName, LPSTR pszWndText)
{
 long	nWndunits;	   /* window units for size and location		  */
 int	nWndx;		   /* the x axis multiplier 					  */
 int	nWndy;		   /* the y axis multiplier 					  */
 int	nX; 		   /* the resulting starting point (x, y)		  */
 int	nY;
 int	nWidth; 	   /* the resulting width and height for this	  */
 int	nHeight;	   /* window									  */

//-------------------- default for window class/style of right lower panel
//-------------------- can be changed by child class before calling OnCreate()
	pszEditClass = "edit";
	dwEditStyle = WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | ES_READONLY | ES_MULTILINE;

	nWndunits = GetDialogBaseUnits();
	nWndx = LOWORD(nWndunits);
	nWndy = HIWORD(nWndunits);
	nX = ((60 * nWndx) / 4);
	nY = ((60 * nWndy) / 8);
	nWidth = ((308 * nWndx) / 4);
	nHeight = ((200 * nWndy) / 8);
// create window									
	hWnd = CreateWindow(
				pszAppName,				/* Window class name			*/
				pszWndText,				/* Window's title				*/
				WS_OVERLAPPEDWINDOW,
				nX, nY, 				/* X, Y						*/
				nWidth, nHeight,		/* Width, Height of window 	*/
				NULL,					/* Parent window's handle		*/
				NULL,					/* Default to Class Menu		*/
				g_hInstance,			/* Instance of window			*/
				this);					/* Create struct for WM_CREATE */
	return;
}

// ShowWindow - this is a public method

int C3PanelView::ShowWindow(int iCmdShow)
{
	return ::ShowWindow(hWnd, iCmdShow);
}

// set text in status bar

int C3PanelView::SetStatusText(int iPart, LPSTR pszText)
{
	return SendMessage(hWndStatusBar, SB_SETTEXT, iPart, (LPARAM)pszText);
}

// set ToolBar params

void C3PanelView::SetToolBar(int iImages, int iBMResId, int uNumButtons, TBBUTTON * pTBB)
{
	TBADDBITMAP tbab;

	tbab.hInst = g_hInstance;
	tbab.nID = iBMResId;
	SendMessage(hWndToolBar, TB_ADDBITMAP, iImages, (LPARAM)&tbab);
	SendMessage(hWndToolBar, TB_BUTTONSTRUCTSIZE, sizeof(TBBUTTON), 0);
	SendMessage(hWndToolBar, TB_ADDBUTTONS, uNumButtons, (LPARAM)pTBB);
}

// WM_PAINT main window
// the only painting required from the main window are the splitter bars

void C3PanelView::OnPaint()
{
	PAINTSTRUCT ps;
	HDC hDC;
	RECT rect;
	RECT rect2;
	int iTVWidth;
	int iTBHeight;
	HBRUSH hBrush;

	GetWindowRect(hWndToolBar, &rect);
	iTBHeight = rect.bottom - rect.top;	// dy of ToolBar

	hDC = BeginPaint(hWnd,&ps);
	hBrush = CreateSolidBrush(GetSysColor(COLOR_ACTIVEBORDER));

	GetWindowRect(hWndLV,&rect);
	GetWindowRect(m_hWndTreeView,&rect2);
	iTVWidth = rect2.right-rect2.left;

	rect.top = iTBHeight + rect.bottom - rect.top;
	rect.bottom = rect.top + RESIZEBARHEIGHT; 
	rect.right = rect.right - rect.left + iTVWidth + RESIZEBARHEIGHT;
	rect.left = iTVWidth;
	FillRect(hDC,&rect,hBrush);

	rect2.left = rect2.right - rect2.left;
	rect2.right = rect2.left + RESIZEBARHEIGHT; 
	rect2.bottom = iTBHeight + rect2.bottom - rect2.top;
	rect2.top = iTBHeight;
	FillRect(hDC,&rect2,hBrush);

	DeleteObject(hBrush);
	EndPaint(hWnd,&ps);

	return;
}

// handle WM_NOTIFY events of main window
// normally these events are handled by the derived class
// possibly showing a context menu could be implemented here

LRESULT C3PanelView::OnNotify( WPARAM wParam, LPNMHDR pNMHdr)
{
	LPTOOLTIPTEXT pTTT;

	switch (pNMHdr->code) {
	case TTN_NEEDTEXT:
		pTTT = (LPTOOLTIPTEXT)pNMHdr;
		pTTT->hinst = g_hInstance;
		pTTT->lpszText = (LPSTR)pTTT->hdr.idFrom;
		break;
	}
	return 0;
}

// handle WM_COMMAND of main window
// normally these events are handled by the derived class
// possibly some application-independant events like IDM_EXIT and IDM_ABOUT
// could be handled here

LRESULT C3PanelView::OnCommand( WPARAM wParam, LPARAM lParam)
{
//	switch (LOWORD(wParam)) {
//	}
	return 0;
}

// handle WM_CREATE of main window

LRESULT C3PanelView::OnCreate()
{
 int	dwTabs[3] = {20*8, 36*8, 42*8};
 int	iParts[1];
 RECT	rect;
 HFONT	hFont;

	hCursorY = LoadCursor(g_hInstance,MAKEINTRESOURCE(IDC_CURSOR1));
	hCursorX = LoadCursor(g_hInstance,MAKEINTRESOURCE(IDC_CURSOR2));

	GetClientRect(hWnd, &rect);
	m_hWndTreeView = CreateWindowEx(WS_EX_CLIENTEDGE, WC_TREEVIEW, 0, 
							WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | TVS_LINESATROOT| TVS_HASLINES | TVS_SHOWSELALWAYS,
							0, 0, 0, 0, hWnd,
							(HMENU)IDC_TREE1, g_hInstance, NULL);
	hWndLV = CreateWindowEx(WS_EX_CLIENTEDGE, WC_LISTVIEW, 0, 
							WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_VSCROLL | LVS_REPORT| LVS_SHOWSELALWAYS,
							0, 0, 0, 0, hWnd,
							(HMENU)IDC_LIST1, g_hInstance, NULL);
	ListView_SetExtendedListViewStyle(hWndLV,
		LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_INFOTIP);
//		if (hFont = (HFONT)GetStockObject( DEFAULT_GUI_FONT))
//			SendMessage(hWndLV, WM_SETFONT, (WPARAM)hFont, 0);

	m_hWndEdit = CreateWindowEx(WS_EX_CLIENTEDGE, pszEditClass, 0, 
							dwEditStyle,
							0, 0, 0, 0, hWnd,
							(HMENU)IDC_EDIT1, g_hInstance, NULL);
	if (hFont = (HFONT)GetStockObject( DEFAULT_GUI_FONT))
		SendMessage(m_hWndEdit, WM_SETFONT, (WPARAM)hFont, 0);

	hWndToolBar = CreateWindowEx ( 0, TOOLBARCLASSNAME, 0,
					WS_CHILD | WS_VISIBLE | TBSTYLE_TOOLTIPS | TBSTYLE_FLAT,
					0, 0, 0, 0, hWnd, 
					(HMENU)IDC_TOOLBAR, g_hInstance, NULL);

	hWndStatusBar = CreateWindowEx ( 0,	STATUSCLASSNAME, NULL,
					WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP | CCS_BOTTOM,
					0, 0, 0, 0,
					hWnd,
					(HMENU)IDC_STATUSBAR,
					g_hInstance,
					NULL);
	if (hWndStatusBar) {
		iParts[0] = -1;
		SendMessage(hWndStatusBar, SB_SETPARTS, 1, (LPARAM)&iParts);
	}
	return 0;
}

// Adjust all childs to new size of client area (then iNewHeight/iNewWidth is -1)
// or to new requested height of listview (in iNewHeight/iNewWidth)

void C3PanelView::OnSize(int iNewHeight, int iNewWidth)
{
	static int iOldHeight = -1;
	static int iOldHeightTotal = -1;
	static int iOldWidth = -1;
	static int iOldWidthTotal = -1;
	RECT rect;
	RECT rect2;
	RECT rect3;
	int iTBHeight;
	int iSBHeight;
	int iEditHeight;
	int iTVHeight;

	GetWindowRect(hWndToolBar, &rect2);
	iTBHeight = rect2.bottom - rect2.top;	// dy of ToolBar

	GetWindowRect(hWndStatusBar, &rect2);
	iSBHeight = rect2.bottom - rect2.top;	// dy of StatusBar

	// dy of clientarea without StatusBar and ToolBar
	GetClientRect(hWnd, &rect);
	iTVHeight = rect.bottom - (iTBHeight + iSBHeight);
	rect.bottom = rect.bottom - iSBHeight;

	GetWindowRect(m_hWndTreeView, &rect3);
	rect3.right = rect3.right - rect3.left;	// dx of treeview

	if (iOldHeight == -1) {					// first call?
		iNewHeight = (iTVHeight - RESIZEBARHEIGHT) / 2;	// new dy of listview
	} else {
		if (iNewHeight == -1) {
			iNewHeight = MulDiv(iOldHeight, iTVHeight, iOldHeightTotal);
		} else
			iNewHeight = iNewHeight - iTBHeight;

		if (iNewHeight > (iTVHeight - RESIZEBARHEIGHT))
			iNewHeight = iTVHeight - RESIZEBARHEIGHT;

	}
	if (iOldWidth == -1) {
		iNewWidth = (rect.right - RESIZEBARHEIGHT) / 4;	// new dx of treeview
	} else {
		if (iNewWidth == -1) {
//			iNewWidth = MulDiv(iOldWidth, rect.right, iOldWidthTotal);
			iNewWidth = rect3.right;
		}
		if (iNewWidth > (rect.right - RESIZEBARHEIGHT))
			iNewWidth = rect.right - RESIZEBARHEIGHT;
	}

	iEditHeight = iTVHeight - (RESIZEBARHEIGHT + iNewHeight);

	HDWP hdwp = BeginDeferWindowPos(5);

	DeferWindowPos(hdwp, hWndToolBar, NULL, 0, 0, rect.right, iTBHeight,
			SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
	DeferWindowPos(hdwp, m_hWndTreeView, NULL, 0, iTBHeight, iNewWidth, iTVHeight,
			SWP_NOZORDER | SWP_NOACTIVATE);
	DeferWindowPos(hdwp, hWndLV, NULL,
			iNewWidth + RESIZEBARHEIGHT,
			iTBHeight,
			rect.right - (iNewWidth + RESIZEBARHEIGHT),
			iNewHeight,
			SWP_NOZORDER | SWP_NOACTIVATE);
	DeferWindowPos(hdwp, m_hWndEdit, NULL,
			iNewWidth + RESIZEBARHEIGHT,
			iTBHeight + iNewHeight + RESIZEBARHEIGHT,
			rect.right - (iNewWidth + RESIZEBARHEIGHT),
			iEditHeight,
			SWP_NOZORDER | SWP_NOACTIVATE);
	DeferWindowPos(hdwp, hWndStatusBar, NULL,
			0,
			rect.bottom, rect.right, iSBHeight,
			SWP_NOZORDER | SWP_NOACTIVATE);
	
	EndDeferWindowPos(hdwp);

	iOldHeight = iNewHeight;
	iOldHeightTotal = iTVHeight;
	iOldWidth = iNewWidth;
	iOldWidthTotal = rect.right;
	return;
}

// draws "resize" lines if user wants to change size of child views

void C3PanelView::DrawResizeLine(int xPos, int yPos)
{
	int iWidth, iHeight;        
	HBRUSH hBrushOld;
	HDC hdc; 
	RECT rc;

	if (!hHalftoneBrush) {
		int i;
		HBITMAP hBitmap;
		WORD pattern[8];

		for (i=0;i<8;i++) 
			pattern[i] = 0x5555 << (i & 1);
										// Create a pattern halftone brush
		hBitmap = CreateBitmap(8,8,1,1,pattern);
		hHalftoneBrush = CreatePatternBrush(hBitmap);
		DeleteObject(hBitmap);				// bitmap no longer needed
	}

	GetWindowRect(hWndLV, &rc);
	iWidth = rc.right - rc.left;
	ScreenToClient(hWnd, (LPPOINT)&rc);

	if (iOldResizeLine == -1) {
		if (xPos < rc.left)
			bVertical = TRUE;
		else
			bVertical = FALSE;
	}
	if (bVertical) {
		GetWindowRect(m_hWndTreeView, &rc);
		iHeight = rc.bottom - rc.top;
		ScreenToClient(hWnd, (LPPOINT)&rc);
	}

	hdc = GetDC(hWnd);
	hBrushOld = (HBRUSH)SelectObject(hdc, hHalftoneBrush);
	if (bVertical) {
		if (xPos == -1)
			xPos = iOldResizeLine;
		PatBlt(hdc, xPos, rc.top, 4, iHeight, PATINVERT);
		iOldResizeLine = xPos;
	} else {
		if (yPos == -1)
			yPos = iOldResizeLine;
		PatBlt(hdc, rc.left, yPos, iWidth, 4, PATINVERT);
		iOldResizeLine = yPos;
	}

	SelectObject(hdc, hBrushOld);		// clean up 
	ReleaseDC(hWnd, hdc);

}


LRESULT C3PanelView::OnMessage(UINT Message, WPARAM wParam, LPARAM lParam)
{
	static BOOL fMenuLoop = FALSE;
	LRESULT rc = 0;
	POINT pt;
	static HWND hWndActive = NULL;

	switch (Message) {
	case WM_CREATE:
		OnCreate();
		break;
	case WM_COMMAND:
		OnCommand(wParam, lParam);
		break;
	case WM_NOTIFY:
		OnNotify(wParam, (LPNMHDR)lParam);
		break;
	case WM_MOVE:
		break;
	case WM_SIZE:
		if (wParam != SIZE_MINIMIZED)
			OnSize(-1, -1);
		break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_PAINT:
		OnPaint();
		break;
	case WM_ACTIVATE:
		if (LOWORD(wParam) == WA_INACTIVE) {
			hWndActive = GetFocus();			// get active child
		} else
			if (hWndActive)						// and restore it if we
				SetFocus(hWndActive);			// become active again
		break;
	case WM_SETCURSOR:
		if ((LOWORD(lParam) == HTCLIENT)) {
			DWORD dw;
			RECT rect;
			dw = GetMessagePos();
			pt.x = LOWORD(dw);
			pt.y = HIWORD(dw);
			ScreenToClient(hWnd,&pt);
			if (hWnd == ChildWindowFromPoint(hWnd,pt)) {
				GetWindowRect(m_hWndTreeView, &rect);
				ScreenToClient(hWnd,(LPPOINT)&rect.right);
				if ((pt.x >= rect.right) && (pt.x < (rect.right + 4)))
					SetCursor(hCursorX);
				else
					SetCursor(hCursorY);
				rc = 1;                                 
				break;
			}				
		}
		rc = DefWindowProc(hWnd, Message,wParam,lParam);
		break;
	case WM_LBUTTONDOWN:
		pt.x = LOWORD(lParam);
		pt.y = HIWORD(lParam);
		if (ChildWindowFromPoint(hWnd,pt) == hWnd) {
			RECT rect;
			RECT rect2;
			SetCapture(hWnd);
			iOldResizeLine = -1;
			DrawResizeLine( LOWORD(lParam), HIWORD(lParam));

			GetWindowRect(hWndLV, &rect);
			GetWindowRect(m_hWndEdit, &rect2);
			UnionRect(&rect, &rect, &rect2);

			if (bVertical) {
				GetWindowRect(m_hWndTreeView, &rect2);
				UnionRect(&rect, &rect, &rect2);
			}
			ClipCursor(&rect);
		}
		break;
	case WM_LBUTTONUP:
		if (GetCapture() == hWnd) {
			ReleaseCapture();
			ClipCursor(0);
			DrawResizeLine( -1, -1);
			if (bVertical)
				OnSize( -1, (int)LOWORD(lParam));
			else
				OnSize( (int)HIWORD(lParam), -1);
		}
		break;
	case WM_MOUSEMOVE:	
		if (GetCapture() == hWnd) { 	// nur beachten wenn cursor "gecaptured" ist
			DrawResizeLine( -1, -1);
			DrawResizeLine( LOWORD(lParam), HIWORD(lParam));
		}
		break;
	case WM_ENTERMENULOOP:
		SendMessage(hWndStatusBar, SB_SIMPLE, TRUE, 0);
		fMenuLoop = TRUE;
		break;
	case WM_EXITMENULOOP:
		SendMessage(hWndStatusBar, SB_SIMPLE, FALSE, 0);
		fMenuLoop = FALSE;
		break;
	case WM_MENUSELECT:
		if (fMenuLoop) {
			char szStr[128] = {0};
			LoadString(g_hInstance, LOWORD(wParam), szStr, sizeof(szStr));
			SendMessage( hWndStatusBar, SB_SETTEXT, 255, (LPARAM)szStr);		
		}
		break;
	default:
		rc = DefWindowProc(hWnd, Message, wParam, lParam);
	}
	return rc;
}

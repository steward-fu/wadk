
;--- implements CContextMenu, based on IContextMenu

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CCONTEXTMENU equ 1

	include RegView.inc

LPPITEMIDLIST typedef ptr LPITEMIDLIST

CContextMenu struct
_IContextMenu	IContextMenu <>

ObjRefCount		DWORD			?
aPidls			LPPITEMIDLIST	?
pMalloc			LPMALLOC		?
pShellFolder	LPSHELLFOLDER	?
fAllValues		BOOL			?	
   
CContextMenu ends

IDM_EXPLORE  equ 0
IDM_OPEN     equ 1
IDM_RENAME   equ 2

IDM_LAST     equ IDM_RENAME


;private methods
Destroy@CContextMenu	proto	:ptr CContextMenu
AllocPidlTable			proto	:ptr CContextMenu, :DWORD
FreePidlTable			proto	:ptr CContextMenu
FillPidlTable			proto	:ptr CContextMenu, : ptr LPCITEMIDLIST, :dword
CanRenameItems			proto	:ptr CContextMenu

	.const

CContextMenuVtbl	label IContextMenuVtbl
	dd QueryInterface, AddRef, Release
	dd QueryContextMenu, InvokeCommand, GetCommandString

	.code

__this	textequ <ebx>
_this	textequ <[__this].CContextMenu>

	MEMBER _IContextMenu, ObjRefCount
	MEMBER aPidls, pMalloc, pShellFolder, fAllValues

Create@CContextMenu PROC public uses __this esi pShellFolder:ptr CShellFolder, aPidls:ptr LPITEMIDLIST, uItemCount:dword

	DebugOut "Create@CContextMenu, DllCount=%u", g_DllRefCount

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CContextMenu
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m__IContextMenu, OFFSET CContextMenuVtbl

	inc g_DllRefCount

	mov eax,pShellFolder
	mov m_pShellFolder,eax

	.if (eax)
		invoke vf(m_pShellFolder, IShellFolder, AddRef)
	.endif

	mov m_ObjRefCount, 1

	mov m_aPidls, NULL

	invoke SHGetMalloc, addr m_pMalloc
	.if (!m_pMalloc)
		invoke Destroy@CContextMenu, __this
		return 0
	.endif

	invoke AllocPidlTable, __this, uItemCount
	.if (eax)
		invoke FillPidlTable, __this, aPidls, uItemCount
	.endif

	mov m_fAllValues, 1

	mov esi,0
	.while (esi < uItemCount)

		mov	ecx, aPidls
		invoke	IsValue_Pidl, [ecx+esi*4]

		neg	eax			;0 -> 0 + NC, !0 -> !0 + C
		sbb	eax, eax	;C -> -1, NC -> 0
		neg	eax			;-1 -> 1, 0 -> 0

		and	m_fAllValues, eax

		inc esi
	.endw

	return __this

Create@CContextMenu ENDP



Destroy@CContextMenu PROC uses __this pThis:ptr CContextMenu

	DebugOut "Destroy@CContextMenu, DllCount=%u", g_DllRefCount

	mov __this,pThis

	.if (m_pShellFolder)
		invoke vf(m_pShellFolder,IShellFolder,Release)
	.endif

;-------------- make sure the pidl is freed

	.if (m_aPidls && m_pMalloc)
		invoke FreePidlTable, __this
	.endif

;;	.if (m_pPidlMgr)
;;		invoke Destroy@CPidlMgr
;;	.endif

	.if (m_pMalloc)
		invoke vf(m_pMalloc,IMalloc,Release)
	.endif

	invoke LocalFree, __this

	dec g_DllRefCount

	ret

Destroy@CContextMenu ENDP


supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IContextMenu,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface PROC pThis:ptr CContextMenu,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP ; CContextMenu::QueryInterface



AddRef PROC pThis:ptr CContextMenu

	mov eax,pThis
	inc [eax].CContextMenu.ObjRefCount
	mov	eax, [eax].CContextMenu.ObjRefCount
	ret

AddRef ENDP



Release PROC pThis:ptr CContextMenu

	mov eax,pThis
	dec [eax].CContextMenu.ObjRefCount
	mov eax,[eax].CContextMenu.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CContextMenu,pThis
		xor eax,eax
	.endif
	ret

Release ENDP

MenuItemTab label dword
exploreItem		dd IDM_EXPLORE, CStr("&Explore")
openItem		dd IDM_OPEN, CStr("&Open")


QueryContextMenu PROC uses esi __this pThis:ptr CContextMenu, hMenu:HMENU, indexMenu:dword, idCmdFirst:dword,idCmdLast:dword,uFlags:dword

local mii:MENUITEMINFO
local dwIndex:DWORD
local dwItem[2]:DWORD
local fExplore:dword

	mov __this,pThis

	mov eax, indexMenu
	mov dwIndex, eax

	.if(!(uFlags & CMF_DEFAULTONLY))

		.if(!m_fAllValues)

			mov	edx, uFlags
			and edx, CMF_EXPLORE
			mov fExplore, edx

;-------------- explorer mode?

			.if (edx)
				mov dwItem[0*sizeof DWORD], offset exploreItem
				mov dwItem[1*sizeof DWORD], offset openItem
			.else
				mov dwItem[0*sizeof DWORD], offset openItem
				mov dwItem[1*sizeof DWORD], offset exploreItem
			.endif
			mov esi, 0
			.while (esi < 2)
				invoke ZeroMemory, addr mii, sizeof MENUITEMINFO
				mov mii.cbSize,sizeof MENUITEMINFO
				mov mii.fMask, MIIM_ID or MIIM_TYPE or MIIM_STATE
				lea ecx, dwItem
				mov eax, [ecx+esi*4]
				mov	ecx, idCmdFirst
				add ecx, [eax+0]
				mov mii.wID, ecx
				mov mii.fType,MFT_STRING
				mov ecx, [eax+4]
				mov mii.dwTypeData, ecx
				.if (esi == 0)
					mov mii.fState,MFS_ENABLED or MFS_DEFAULT
				.else
					mov mii.fState,MFS_ENABLED
				.endif
				invoke InsertMenuItem, hMenu, dwIndex, TRUE, addr mii
				inc dwIndex
				inc esi
			.endw

			.if (uFlags & CMF_CANRENAME)
				invoke ZeroMemory, addr mii, sizeof MENUITEMINFO
				mov mii.cbSize,sizeof MENUITEMINFO
				mov mii.fMask, MIIM_ID or MIIM_TYPE
				mov mii.wID,0
				mov mii.fType, MFT_SEPARATOR
				invoke InsertMenuItem, hMenu, dwIndex, TRUE, addr mii
				inc dwIndex

				invoke ZeroMemory, addr mii, sizeof MENUITEMINFO
				mov mii.cbSize,sizeof MENUITEMINFO
				mov mii.fMask, MIIM_ID or MIIM_TYPE or MIIM_STATE
				mov	ecx, idCmdFirst
				add ecx,IDM_RENAME
				mov mii.wID, ecx
				mov mii.fType,MFT_STRING
				mov mii.dwTypeData,CStr("&Rename")
			
				invoke	CanRenameItems, __this
				.if (eax)
					mov mii.fState, MFS_ENABLED
				.else
					mov mii.fState, MFS_DISABLED
				.endif
				invoke InsertMenuItem, hMenu, dwIndex, TRUE, addr mii
				inc dwIndex
			.endif
		.endif

		mov eax, dwIndex
		sub eax, indexMenu
		ret
	.endif
	return 0		;MAKE_HRESULT(SEVERITY_SUCCESS, 0, USHORT(0));

QueryContextMenu ENDP



InvokeCommand PROC uses __this esi edi pThis:ptr CContextMenu, lpcmi:ptr CMINVOKECOMMANDINFO 

local pidlTemp:LPITEMIDLIST
local pidlFQ:LPITEMIDLIST
local sei:SHELLEXECUTEINFO
;local i:dword == esi

	mov __this,pThis

	mov edi,lpcmi
	assume edi:ptr CMINVOKECOMMANDINFO

	mov eax,[edi].lpVerb
	shr eax,16

	.if (eax)
;------------------- the command is being sent via a verb
		return NOERROR
	.endif

	mov eax,[edi].lpVerb
	movzx eax,ax

	.if (eax > IDM_LAST)
		return E_INVALIDARG
	.endif

	.if (eax == IDM_EXPLORE || eax == IDM_OPEN)

;------------- Find the first item in the list that is not a value. These commands 
;------------- should never be invoked if there isn't at least one key item in the list.

		mov esi,0
		.while (1)
			mov ecx, m_aPidls
			.break .if (dword ptr [ecx+esi*4] == 0)

			mov ecx, m_aPidls
			invoke	IsValue_Pidl, [ecx+esi*4]
			.break .if (eax == 0)

			inc esi
		.endw
			
		mov eax, m_pShellFolder
		invoke GetPidl@CShellFolder, m_pShellFolder
		mov ecx, m_aPidls
		invoke Concatenate_Pidl, eax, [ecx+esi*4]
		mov	pidlTemp, eax

		invoke GetPidlRoot@CShellFolder, m_pShellFolder
		invoke Concatenate_Pidl, eax, pidlTemp
		mov	pidlFQ, eax

		invoke	Delete_Pidl, pidlTemp

		invoke ZeroMemory, addr sei, sizeof SHELLEXECUTEINFO

		mov sei.cbSize, sizeof SHELLEXECUTEINFO

		mov sei.fMask, SEE_MASK_IDLIST or SEE_MASK_CLASSNAME

		mov	ecx, pidlFQ
		mov	sei.lpIDList, ecx

		mov sei.lpClass, CStr("folder")

		mov	eax, [edi].hwnd
		mov	sei.hwnd,eax

		mov sei.nShow, SW_SHOWNORMAL

		mov eax,[edi].lpVerb
		movzx eax,ax

		.if (eax == IDM_EXPLORE)
			mov sei.lpVerb, CStr("explore")
		.else
			mov sei.lpVerb, CStr("open")
		.endif

		invoke ShellExecuteEx, addr sei

		invoke	Delete_Pidl, pidlFQ

	.elseif (eax == IDM_RENAME)

		invoke MessageBeep, MB_OK

	.endif

	return NOERROR

	assume edi:nothing

InvokeCommand ENDP



GetCommandString PROC uses __this pThis:ptr CContextMenu, idCommand:dword, uFlags:dword,lpReserved:ptr dword,lpszName:LPSTR,uMaxNameLen:dword 

local hr:dword

	mov  hr,E_INVALIDARG

	mov eax,uFlags
	.if (eax == GCS_HELPTEXT)
		mov hr,E_NOTIMPL

	.elseif (eax ==  GCS_VERBA)
		mov eax,idCommand
		.if (eax == IDM_RENAME)
			invoke lstrcpy, lpszName, CStr("rename")
			mov hr,NOERROR
		.endif

	.elseif (eax == GCS_VERBW)
		mov eax,idCommand
;---------- NT 4.0 with IE 3.0x or no IE will always call this with GCS_VERBW. In this 
;---------- case, you need to do the lstrcpyW to the pointer passed.
		.if (eax == IDM_RENAME)
			invoke lstrcpyW, lpszName, L("rename")
			mov hr,NOERROR
		.endif

	.elseif (eax == GCS_VALIDATE)

		mov hr, NOERROR

	.endif

	return hr

GetCommandString ENDP


AllocPidlTable PROC uses __this pThis:ptr CContextMenu, dwEntries:dword

	mov __this,pThis

;---------------- add one for NULL terminator

	inc dwEntries

	mov	ecx, dwEntries
	imul ecx, sizeof LPITEMIDLIST

	invoke vf(m_pMalloc,IMalloc,Alloc), ecx
	mov m_aPidls, eax

	.if (eax)
;----------------- set all of the entries to NULL
		mov	ecx, dwEntries
		imul ecx, sizeof LPITEMIDLIST
		invoke ZeroMemory, eax, ecx
	.endif

	return m_aPidls

AllocPidlTable ENDP


FreePidlTable PROC uses __this esi pThis:ptr CContextMenu

;local i:dword == esi

	mov __this,pThis

	.if (m_aPidls)

		mov esi,0
		.while (1)
			mov eax, m_aPidls
			.break .if	(DWORD PTR [eax+esi*4] == 0)
			invoke	Delete_Pidl, [eax+esi*4]
			inc esi
		.endw

		invoke vf(m_pMalloc,IMalloc,Free), m_aPidls

		mov m_aPidls, NULL

	.endif

	ret

FreePidlTable ENDP



FillPidlTable PROC uses __this esi pThis:ptr CContextMenu, aPidls:ptr LPCITEMIDLIST, uItemCount:dword

;local i:dword == esi

	mov __this,pThis

	.if (m_aPidls)
		mov	esi,0
		.while (esi < uItemCount)
			mov	ecx, aPidls
			invoke Copy_Pidl, [ecx+esi*4]
			mov ecx, m_aPidls
			mov [ecx+esi*4],eax
			inc esi
		.endw
		return TRUE
	.endif

	return FALSE

FillPidlTable ENDP



CanRenameItems PROC uses __this esi pThis:ptr CContextMenu

;local i:dword == esi
local dwAttributes:dword

	mov __this,pThis

	.if (m_aPidls)

;------------------ get the number of items assigned to this object
		mov esi,0
		.while (1)
			mov eax, m_aPidls
			.break .if	(DWORD PTR [eax+esi*4] == 0)
			inc esi
		.endw

;------------------ you can't rename more than one item at a time
		.if (esi > 1)
			return FALSE
		.endif

		mov dwAttributes, SFGAO_CANRENAME

		invoke vf(m_pShellFolder,IShellFolder,GetAttributesOf), esi, m_aPidls, addr dwAttributes

		mov eax,dwAttributes
		and eax, SFGAO_CANRENAME
		ret
	.endif
	return FALSE

CanRenameItems ENDP

	END

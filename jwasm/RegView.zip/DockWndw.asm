
;--- implements CDockingWindow, based on IDockingWindow

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include objidl.inc
	include oleidl.inc
	include ocidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CDOCKINGWINDOW equ 1

	include RegView.inc

LPDOCKINGWINDOWSITE typedef ptr IDockingWindowSite
LPINPUTOBJECTSITE	typedef ptr IInputObjectSite

CDockingWindow struct

_IDockingWindow	IDockingWindow <>
_IInputObject	IInputObject <>
_IObjectWithSite IObjectWithSite <>

ObjRefCount	DWORD ?

rcDisplay	RECT <>
bFocus		BOOL ?
hwndParent	HWND ?
hWnd		HWND ?
hwndCommand HWND ?
pView		LPSHELLVIEW ?
pSite		LPDOCKINGWINDOWSITE ?

CDockingWindow ends

TOOLBAR_HEIGHT  equ 50

;private methods

Destroy@CDockingWindow	proto :ptr CDockingWindow
WndProc proto				:HWND, :dword, :WPARAM, :LPARAM
OnPaint proto				:ptr CDockingWindow
OnCommand proto				:ptr CDockingWindow, :WPARAM, :LPARAM
FocusChange proto			:ptr CDockingWindow, :BOOL
OnSetFocus proto			:ptr CDockingWindow
OnKillFocus proto			:ptr CDockingWindow
NegotiateBorderSpace proto	:ptr CDockingWindow, :ptr IDockingWindowSite, :ptr RECT 

	.const

CDockingWindow@IDockingWindow@Vtbl label IDockingWindowVtbl
	dd QueryInterface, AddRef, Release
	dd GetWindow_, ContextSensitiveHelp, ShowDW, CloseDW, ResizeBorderDW

CDockingWindow@IInputObject@Vtbl label IInputObjectVtbl
	dd QueryInterface2, AddRef2, Release2
	dd UIActivateIO, HasFocusIO, TranslateAcceleratorIO

CDockingWindow@IObjectWithSite@Vtbl label IObjectWithSiteVtbl
	dd QueryInterface3, AddRef3, Release3
	dd SetSite, GetSite

SHTB_CLASS_NAME DB	'RegViewToolbarClass', 00H

	.code

__this	textequ <ebx>
_this	textequ <[__this].CDockingWindow>

	MEMBER _IDockingWindow, _IInputObject, _IObjectWithSite, ObjRefCount
	MEMBER rcDisplay, bFocus, hwndParent, hWnd, hwndCommand, pView, pSite

Create@CDockingWindow PROC public uses __this pView:ptr CShellView, hwndCommand:HWND


	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CDockingWindow
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m__IDockingWindow.lpVtbl,	OFFSET CDockingWindow@IDockingWindow@Vtbl
	mov	m__IInputObject.lpVtbl,		OFFSET CDockingWindow@IInputObject@Vtbl
	mov	m__IObjectWithSite.lpVtbl,	OFFSET CDockingWindow@IObjectWithSite@Vtbl

	inc g_DllRefCount

	mov eax,pView
	mov m_pView,eax

	.if (eax)
		invoke vf(m_pView,IShellView,AddRef)
	.else
		invoke Destroy@CDockingWindow, __this
		return 0
	.endif

	mov m_pSite, NULL
	mov m_hWnd, NULL

	mov eax,hwndCommand
	mov m_hwndCommand, eax

	mov m_bFocus, FALSE

	mov m_rcDisplay.left,0
	mov m_rcDisplay.top,0
	mov m_rcDisplay.right,0
	mov m_rcDisplay.bottom,0

	mov m_ObjRefCount,1

	return __this

Create@CDockingWindow ENDP



Destroy@CDockingWindow PROC uses __this pThis:ptr CDockingWindow

	mov __this,pThis

	.if (m_pView)
		invoke vf(m_pView, IShellView, Release)
	.endif

	dec g_DllRefCount

	ret

Destroy@CDockingWindow ENDP


supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IOleWindow,0
	dd offset IID_IDockingWindow,0
	dd offset IID_IInputObject,offset CDockingWindow._IInputObject
	dd offset IID_IObjectWithSite,offset CDockingWindow._IObjectWithSite
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)


QueryInterface PROC pThis:ptr CDockingWindow,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP ; CDockingWindow::QueryInterface



AddRef PROC pThis:ptr CDockingWindow

	mov eax,pThis
	inc [eax].CDockingWindow.ObjRefCount
	mov	eax, [eax].CDockingWindow.ObjRefCount
	ret

AddRef ENDP			; CDockingWindow::AddRef



Release PROC pThis:ptr CDockingWindow

	mov eax,pThis
	dec [eax].CDockingWindow.ObjRefCount
	mov eax,[eax].CDockingWindow.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CDockingWindow, pThis
		xor eax,eax
	.endif
	ret

Release ENDP			; CDockingWindow::Release



GetWindow_ PROC pThis:ptr CDockingWindow, phWnd:ptr HWND


	mov eax,pThis
	mov eax,[eax].CDockingWindow.hWnd
	mov ecx,phWnd
	mov [ecx],eax
	return S_OK

GetWindow_ ENDP	; CDockingWindow::GetWindow



ContextSensitiveHelp PROC pThis:ptr CDockingWindow

	return E_NOTIMPL

ContextSensitiveHelp ENDP	; CDockingWindow::ContextSensitiveHelp



ShowDW PROC uses __this pThis:ptr CDockingWindow, fShow:dword

local	hr:dword
local	wc:WNDCLASS
local	rc:RECT
local	bwRequest:BORDERWIDTHS

	mov __this,pThis

;-------------- if our window doesn't exist yet, create it now
	.if (!m_hWnd && m_pSite)


;-------------- if our window class has not been registered, then do so

		invoke GetClassInfo, g_hInstance, addr SHTB_CLASS_NAME, addr wc
		.if (!eax)
			invoke ZeroMemory, addr wc, sizeof WNDCLASS
			mov wc.style, CS_HREDRAW or CS_VREDRAW
			mov wc.lpfnWndProc, WndProc
			mov wc.cbClsExtra,0
			mov wc.cbWndExtra,0
			mov eax,g_hInstance
			mov wc.hInstance,eax
			mov wc.hIcon, NULL
			invoke LoadCursor, NULL, IDC_ARROW
			mov wc.hCursor,eax
			invoke CreateSolidBrush, RGB(192, 0, 0)
			mov wc.hbrBackground,eax
			mov wc.lpszMenuName, NULL
			mov wc.lpszClassName, offset SHTB_CLASS_NAME
			invoke RegisterClass, addr wc
		.endif

;-------------- get our parent window
		invoke vf(m_pSite, IOleWindow, GetWindow_), addr m_hwndParent
		mov	hr, eax
		.if (SUCCEEDED(eax))
			invoke GetClientRect, m_hwndParent, addr rc

;-------------- create the window - use zero for pos and size - it will get positioned and sized below

			invoke CreateWindowEx, WS_EX_CLIENTEDGE, addr SHTB_CLASS_NAME, NULL,\
						WS_CHILD or WS_CLIPSIBLINGS, 0, 0, 0, 0,\
						m_hwndParent, NULL, g_hInstance, __this
			mov m_hWnd,eax
			.if (!eax)
				return E_FAIL
			.endif

			invoke NegotiateBorderSpace, __this, m_pSite, 0
		.endif
	.endif


	.if (m_hWnd && m_pSite)
		mov	DWORD PTR bwRequest.left, 0
		mov	DWORD PTR bwRequest.top, 0
		mov	DWORD PTR bwRequest.right, 0
		mov	DWORD PTR bwRequest.bottom, 0

		.if (fShow)
;--------------- position the window - m_rcDisplay was set up in NegotiateBorderSpace
			invoke MoveWindow, m_hWnd, m_rcDisplay.left,\
					m_rcDisplay.top, m_rcDisplay.right,\
					m_rcDisplay.bottom, TRUE

;--------------- show our window
			invoke ShowWindow, m_hWnd, SW_SHOW

		.else
;--------------- hide our window
			invoke ShowWindow, m_hWnd, SW_HIDE


;--------------- release our border space - bwRequest was initialized above
			invoke vf( m_pSite, IDockingWindowSite,SetBorderSpaceDW), __this, addr bwRequest
		.endif
	.endif

	return S_OK

ShowDW ENDP



CloseDW PROC uses __this pThis:ptr CDockingWindow, dwReserved:dword

	mov __this,pThis

	.if (m_pSite)

		invoke vf(__this, IDockingWindow, ShowDW), FALSE

		invoke IsWindow, m_hWnd
		.if (eax)
			invoke DestroyWindow, m_hWnd
		.endif

		invoke vf(m_pSite, IDockingWindowSite, Release)
		mov m_pSite, NULL

	.endif

	return S_OK

CloseDW ENDP



ResizeBorderDW PROC uses __this pThis:ptr CDockingWindow, prcBorder: ptr RECT, punkSite: LPUNKNOWN, fResrvd:dword

local	pSite:LPDOCKINGWINDOWSITE
local	hr:dword

	mov __this,pThis

	mov	pSite, 0

;------------ if punkSite is not NULL, use it to negotiate our border space
	.if (punkSite)

		invoke vf(punkSite, IUnknown, QueryInterface), addr IID_IDockingWindowSite, addr pSite
		.if (FAILED(eax))
			return E_FAIL
		.endif

	.else
		.if (m_pSite)
			mov eax, m_pSite
			mov pSite,eax	
			invoke vf(pSite,IUnknown,AddRef)
		.endif
	.endif

	.if (pSite)

		mov hr, E_FAIL

		invoke NegotiateBorderSpace, __this, pSite, prcBorder
		.if (eax)
;-------------- updated our window's position
			invoke vf(__this, IDockingWindow, ShowDW), TRUE
			mov hr, S_OK
		.endif

		invoke vf(pSite, IUnknown, Release)
		return hr
	.endif

	return E_FAIL

ResizeBorderDW ENDP


;----------------------------------------------------------
;*** IInputObject::UIActivateIO


UIActivateIO PROC uses __this pThis:ptr CDockingWindow, fActivate:dword, pMsg:ptr MSG

	sub pThis,offset CDockingWindow._IInputObject.lpVtbl

	mov __this,pThis

	.if (fActivate)
		invoke SetFocus, m_hWnd
	.endif

	return S_OK

UIActivateIO ENDP	; CDockingWindow::UIActivateIO

;*** IInputObject::HasFocusIO

HasFocusIO PROC uses __this pThis:ptr CDockingWindow

	sub pThis,offset CDockingWindow._IInputObject

	mov __this,pThis

	.if (m_bFocus)
		return S_OK
	.endif

	return S_FALSE

HasFocusIO ENDP			; CDockingWindow::HasFocusIO

;*** IInputObject::TranslateAcceleratorIO

TranslateAcceleratorIO PROC pThis:ptr CDockingWindow, pMsg:ptr MSG

;	sub pThis,offset CDockingWindow.vtblIInputObject
	return S_FALSE

TranslateAcceleratorIO ENDP ; CDockingWindow::TranslateAcceleratorIO


;----------------------------------------------------------
;*** IObjectWithSite::SetSite


SetSite PROC uses __this pThis:ptr CDockingWindow, punkSite:LPUNKNOWN

	sub pThis,offset CDockingWindow. _IObjectWithSite

	mov __this,pThis

	.if (m_pSite)
		invoke vf(m_pSite,IUnknown,Release)
		mov m_pSite, NULL
	.endif

;------------- If punkSite is not NULL, we are connecting to the site.
	.if (punkSite)


		invoke vf(punkSite,IUnknown, QueryInterface), addr IID_IDockingWindowSite, addr m_pSite
		.if (SUCCEEDED(eax))
			return S_OK
		.endif
	.endif
		
	return S_OK

SetSite ENDP	; CDockingWindow::SetSite

;*** IObjectWithSite::GetSite

GetSite PROC uses __this pThis:ptr CDockingWindow, riid:ptr IID, ppvReturn:ptr

	sub pThis,offset CDockingWindow._IObjectWithSite

	mov __this,pThis

	mov	eax, ppvReturn
	mov	dword ptr [eax], 0

	.if (m_pSite)

		invoke vf(m_pSite, IUnknown, QueryInterface), riid, ppvReturn
		ret
	.else
		return E_FAIL
	.endif

GetSite ENDP


;----------------------------------------------------------


WndProc PROC uses __this hWnd:HWND, uMessage:dword, wParam:WPARAM, lParam:LPARAM

	invoke GetWindowLong, hWnd, GWL_USERDATA
	mov __this,eax

	mov eax,uMessage
	.if (eax == WM_NCCREATE)

		mov __this,lParam
		invoke SetWindowLong, hWnd, GWL_USERDATA, __this

;-------------- set the window handle
		mov eax,hWnd
		mov m_hWnd, eax

	.elseif (eax == WM_PAINT)

		invoke	OnPaint, __this
		ret

	.elseif (eax == WM_COMMAND)

		invoke OnCommand, __this, wParam, lParam
		ret

	.elseif (eax == WM_SETFOCUS)
	
		invoke OnSetFocus, __this
		ret

	.elseif (eax == WM_KILLFOCUS)

		invoke OnKillFocus, __this
		ret

	.endif

	invoke DefWindowProc , hWnd, uMessage, wParam, lParam

	ret

WndProc ENDP


OnPaint PROC uses __this pThis:ptr CDockingWindow

local ps:PAINTSTRUCT
local rc:RECT

	mov __this,pThis

	invoke BeginPaint, m_hWnd, addr ps

	invoke GetClientRect, m_hWnd, addr rc

	invoke SetTextColor, ps.hdc, RGB(0, 0, 0)

	invoke SetBkMode, ps.hdc, TRANSPARENT

	invoke DrawText, ps.hdc, CStr("IDockingWindow"), -1, addr rc, DT_SINGLELINE or DT_CENTER or DT_VCENTER

	invoke EndPaint, m_hWnd, addr ps

	return 0

OnPaint ENDP			; CDockingWindow::OnPaint



OnCommand PROC pThis:ptr CDockingWindow, wParam:WPARAM, lParam:LPARAM

;------- Since this is a toolbar object, we need to forward all WM_COMMAND messages to 
;------- our assigned command window.

	mov eax,pThis
	invoke	SendMessage, [eax].CDockingWindow.hwndCommand, WM_COMMAND, wParam, lParam
	ret

OnCommand ENDP		; CDockingWindow::OnCommand



FocusChange PROC uses __this pThis:ptr CDockingWindow, bFocus:dword

local pios:LPINPUTOBJECTSITE

	mov __this,pThis

	mov	ecx, bFocus
	mov	m_bFocus, ecx

;----------- inform the input object site that the focus has changed
	invoke vf(m_pSite, IUnknown, QueryInterface), addr IID_IInputObjectSite, addr pios
	.if (SUCCEEDED(eax))
		invoke vf(pios, IInputObjectSite, OnFocusChangeIS), __this, bFocus
		invoke vf(pios, IInputObjectSite, Release)
	.endif

	ret

FocusChange ENDP		; CDockingWindow::FocusChange


OnSetFocus PROC uses __this pThis:ptr CDockingWindow


	mov __this,pThis

	invoke FocusChange, __this, TRUE

	invoke OnActivate@CShellView, m_pView, SVUIA_ACTIVATE_FOCUS	;???

	return 0

OnSetFocus ENDP			; CDockingWindow::OnSetFocus



OnKillFocus PROC uses __this pThis:ptr CDockingWindow

	mov __this,pThis

	invoke FocusChange, __this, FALSE

	invoke	OnDeactivate@CShellView, m_pView	;???

	return 0

OnKillFocus ENDP		; CDockingWindow::OnKillFocus




NegotiateBorderSpace PROC uses __this pThis:ptr CDockingWindow, pSite: ptr IDockingWindowSite, prcBorder:ptr RECT 

local hr:dword
local bwRequest:BORDERWIDTHS
local rcTemp:RECT

	mov __this,pThis

	mov	bwRequest.left, 0
	mov	bwRequest.top, 0
	mov	bwRequest.right, 0
	mov	bwRequest.bottom, 0

	mov bwRequest.top, TOOLBAR_HEIGHT

	invoke vf(pSite, IDockingWindowSite, RequestBorderSpaceDW), __this , addr bwRequest
	mov	hr, eax
	.if (SUCCEEDED(eax))

		invoke vf(pSite, IDockingWindowSite, SetBorderSpaceDW), __this, addr bwRequest
		mov	hr, eax
		.if (SUCCEEDED(eax))

			.if (!prcBorder)

				invoke vf(pSite, IDockingWindowSite, GetBorderDW), __this, addr rcTemp
				mov	hr, eax
				.if (SUCCEEDED(eax))

					lea	eax,rcTemp
					mov	prcBorder, eax
				.endif
			.endif

			.if (prcBorder)

;---------------- set up our display rectangle
				mov eax,prcBorder

				mov ecx,[eax].RECT.left
				mov m_rcDisplay.left,ecx

				mov edx,[eax].RECT.top
				mov m_rcDisplay.top,edx

				mov ecx,[eax].RECT.right
				sub ecx,[eax].RECT.left
				mov m_rcDisplay.right,ecx

				mov edx,bwRequest.top
				mov m_rcDisplay.bottom,edx

				return TRUE
			.endif
		.endif
	.endif

	return FALSE

NegotiateBorderSpace ENDP ; CDockingWindow::NegotiateBorderSpace

;*** IUnknown instances of interface 2 and 3

QueryInterface2 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IInputObject
	jmp	QueryInterface
QueryInterface2 ENDP

AddRef2 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IInputObject
	jmp	AddRef
AddRef2 ENDP	

Release2 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IInputObject
	jmp	Release
Release2 ENDP	

QueryInterface3 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IObjectWithSite
	jmp	QueryInterface
QueryInterface3 ENDP

AddRef3 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IObjectWithSite
	jmp	AddRef
AddRef3 ENDP	

Release3 PROC NEAR
	sub	DWORD PTR [esp+4], offset CDockingWindow._IObjectWithSite
	jmp	Release
Release3 ENDP	

END

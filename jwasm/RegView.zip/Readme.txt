
 1. About RegView

 This is a conversion from C++ to ASM of REGVIEW, a Shell Namespace
 Extension sample from Microsoft. With it, the registry can be viewed
 inside explorer. Edit functions aren't implemented, though.


 2. Installation/Deinstallation

 To try it just build the DLL and register it with:

 c:\windows\system\regsvr32 regview.dll

 It may be unregistered by:

 c:\windows\system\regsvr32 /u regview.dll

 Your windows system directory path may vary.


 3. Creating the binary

 If you want to create the binary the following tools are needed:
 
  - JWasm or Masm
  - WinInc include files and import libraries
  - MS RC or PORC
  - MS LINK or POLINK

 Before running make, adjust the path for the WinInc root directory in
 Makefile. Then, to build the dll, just enter NMAKE on the command line.
 The debug version of RegView - which can be created by entering 
 "NMAKE Debug=1" - will display some messages onto the debug terminal for
 a better understanding of what is happening.


 4. History
 
 11/21/2010, v1.3.1: Win32Inc changed to WinInc
 09/21/2008, v1.3: now JWasm is the default assembler in Makefile
 01/13/2007, v1.2: changed to WinInc include files
 03/03/2003, v1.1.1: bug fix
 02/28/2002, v1.1: ???
 06/15/2002, v1.0: ???
 01/01/2002, v0.9: first version

 
 5. Copyright

 This is a non-trivial sample about how to use the WinInc include files. 
 It is Public Domain.

 Japheth

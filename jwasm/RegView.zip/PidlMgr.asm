

;--- implements PIDL helper functions

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CPIDLMGR equ 1

	include RegView.inc

;;DEBUG = 0


; private methods
Create				proto :PIDLTYPE, :LPVOID, :DWORD
GetData				proto :PIDLTYPE, :LPITEMIDLIST, :LPVOID, :DWORD
SeparateKeyAndValue	proto :LPITEMIDLIST, :ptr LPITEMIDLIST, :ptr LPITEMIDLIST

; other procs

_GetDataPointer		proto :LPITEMIDLIST

	.data

g_pMalloc   LPMALLOC NULL
g_dwCount	DWORD 0
g_cntPidl	DWORD 0

; macro 

GetDataPointer macro pidl
if 0
		invoke _GetDataPointer, pidl
else
		mov eax,pidl
		lea eax,[eax].ITEMIDLIST.mkid.abID
endif
		endm

	.code


Create@CPidlMgr PROC public

	inc g_DllRefCount

	.if (!g_dwCount)
		invoke	SHGetMalloc,addr g_pMalloc
		.if (FAILED(eax))
			return 0
		.endif
	.endif

	inc g_dwCount

	return 1

Create@CPidlMgr ENDP


Destroy@CPidlMgr PROC public

	dec g_dwCount

	.if (!g_dwCount)
		invoke vf(g_pMalloc, IMalloc, Release)
		mov g_pMalloc, NULL
	.endif

	dec g_DllRefCount

	ret
Destroy@CPidlMgr ENDP


Create PROC dwType:PIDLTYPE , pIn:ptr , uInSize:dword

local	pidlOut:LPITEMIDLIST
local	uSize:DWORD
local	pData:LPPIDLDATA

	mov	pidlOut, 0

;-------- Calculate the size. This consists of the ITEMIDLIST, the PIDL structure plus 
;-------- the size of the data. We subtract the size of an HKEY because that is included 
;-------- in uInSize.

	mov	eax, uInSize
	add	eax, sizeof ITEMIDLIST + (sizeof PIDLDATA - sizeof HANDLE)
	mov	uSize, eax

;------- Allocate the memory, adding an additional ITEMIDLIST for the NULL terminating 
;------- ID List.

	mov	ecx, uSize
	add	ecx, sizeof ITEMIDLIST
	invoke	vf(g_pMalloc,IMalloc,Alloc),ecx
	mov	pidlOut, eax

	.if (eax)
ifdef _DEBUG
		inc g_cntPidl
endif

;------------- set the size of this item

		mov	ecx, uSize
		mov	[eax].ITEMIDLIST.mkid.cb, cx

;------------- set the data for this item

		GetDataPointer eax
		mov	pData, eax

		mov	ecx, dwType
		mov	[eax].PIDLDATA.dwType, ecx

		.if (ecx == PT_ROOTKEY)

			mov	eax, pData
			mov	ecx, pIn
			mov	edx, [ecx]
			mov	[eax].PIDLDATA.hRootKey, edx

		.elseif (ecx == PT_SUBKEY || ecx == PT_VALUE)

			mov eax,pData
			lea ecx,[eax].PIDLDATA.szText
			invoke CopyMemory, ecx, pIn, uInSize

		.endif

;------------- set the NULL terminator to 0

		invoke	GetNextItem_Pidl, pidlOut
		mov	[eax].ITEMIDLIST.mkid.cb, 0
;;		mov	[eax].ITEMIDLIST.mkid.abID, 0
	.endif

	return pidlOut

Create ENDP


Delete_Pidl PROC public pidl:LPITEMIDLIST

	invoke vf(g_pMalloc,IMalloc,Free),pidl
	ret
Delete_Pidl ENDP


CreateRootKey@CPidlMgr PROC public hKeyRoot:HANDLE

	invoke	Create, PT_ROOTKEY, addr hKeyRoot, sizeof hKeyRoot
	ret
CreateRootKey@CPidlMgr ENDP


CreateSubKey@CPidlMgr PROC public lpszNew:LPSTR 

	invoke lstrlen,lpszNew
	inc	eax
	invoke Create, PT_SUBKEY, lpszNew, eax
	ret
CreateSubKey@CPidlMgr ENDP


CreateValue@CPidlMgr PROC public lpszNew:LPSTR 

	invoke lstrlen,lpszNew
	inc	eax
	invoke Create, PT_VALUE, lpszNew, eax
	ret
CreateValue@CPidlMgr ENDP

;*** get next item in ITEMIDLIST

GetNextItem_Pidl PROC pidl:LPITEMIDLIST 

	mov eax,pidl
	.if (eax)
		movzx ecx,[eax].ITEMIDLIST.mkid.cb
		add	eax, ecx
	.endif
	ret

GetNextItem_Pidl ENDP

;*** get size of a PIDL

GetSize_Pidl PROC uses ebx pidl:LPITEMIDLIST 

;local cbTotal:dword == ebx

	mov	ebx, 0		;used as byte counter here
	mov	eax, pidl

	.if (eax)
		.while (1)
			movzx	ecx, [eax].ITEMIDLIST.mkid.cb
			.break .if (ecx == 0)
			add	ebx, ecx
			invoke GetNextItem_Pidl, eax
		.endw
;------------------ add the size of the NULL terminating ITEMIDLIST
		add	ebx, sizeof ITEMIDLIST
	.endif
	return ebx

GetSize_Pidl ENDP

;*** GetData 

GetData PROC uses ebx dwType:PIDLTYPE , pidl:LPITEMIDLIST , pOut:LPVOID , uOutSize:dword

;local	pData:LPPIDLDATA	== ebx
local	dwReturn:dword

	.if (!pidl)
		return 0
	.endif

	GetDataPointer pidl
	mov	ebx, eax
	assume ebx:ptr PIDLDATA

	mov	dwReturn, 0

;------------------ copy the data
	mov eax,dwType

	.if (eax == PT_ROOTKEY)

		mov	edx, uOutSize
		.if (edx < sizeof HANDLE)
			return 0
		.endif

		.if ([ebx].dwType != PT_ROOTKEY)
			return 0
		.endif

		mov	ecx, pOut
		mov	eax, [ebx].hRootKey
		mov	[ecx], eax

		mov	dwReturn, sizeof PIDLDATA.hRootKey

	.elseif (eax == PT_SUBKEY || eax == PT_VALUE || eax == PT_TEXT)

		mov	ecx, pOut
		mov	BYTE PTR [ecx], 0

		invoke	lstrcpyn, pOut,addr [ebx].szText, uOutSize
		invoke	lstrlen, pOut
		mov	dwReturn, eax

	.endif

	return dwReturn
	assume ebx:nothing

GetData ENDP ; CPidlMgr::GetData

;*** 

GetRootKey@CPidlMgr PROC public pidl:LPITEMIDLIST , phKeyRoot:ptr HANDLE

	invoke	GetData, PT_ROOTKEY, pidl, phKeyRoot, sizeof HANDLE
	ret
GetRootKey@CPidlMgr ENDP


GetLastItem_Pidl PROC public pidl:LPITEMIDLIST 

local pidlLast:LPITEMIDLIST

	mov	pidlLast, 0

;------------------- get the PIDL of the last item in the list
	mov	eax, pidl
	.if (eax)
		.while (1)
			movzx	ecx, [eax].ITEMIDLIST.mkid.cb
			.break .if (ecx == 0)
			mov	pidlLast, eax
			invoke GetNextItem_Pidl, eax
		.endw
	.endif

	return pidlLast

GetLastItem_Pidl ENDP


GetItemText@CPidlMgr PROC public pidl:LPITEMIDLIST,lpszText:LPSTR, uSize:dword

local hKey:HANDLE

;------------ if this is a root key, it needs to be handled specially

	invoke	IsRootKey_Pidl, pidl
	.if (eax)

		invoke GetRootKey@CPidlMgr, pidl, addr hKey
		.if (eax == 0)
			xor eax,eax
			ret
		.endif

		invoke GetRootKeyText, hKey, lpszText, uSize
		ret
	.endif

	invoke GetData, PT_TEXT, pidl, lpszText, uSize

	ret

GetItemText@CPidlMgr ENDP


GetSubKeyText@CPidlMgr PROC public uses edi pidl:LPITEMIDLIST , lpszSubKey:LPSTR , dwSize:DWORD 

local pidlTemp:LPITEMIDLIST
local dwCopied:dword
local pData:LPPIDLDATA

	.if (!pidl)
		return 0
	.endif

	mov	dwCopied, 0

;---------- This may be a list of items, so if the first item is a key rather than a 
;---------- string, skip the first item because it contains the root key.

	invoke	IsRootKey_Pidl, pidl
	.if (eax)
		invoke	GetNextItem_Pidl, pidl
		mov	pidlTemp, eax
	.else
		mov	edx, pidl
		mov	pidlTemp, edx
	.endif

;------------ if this is NULL, return the required size of the buffer
	.if (!lpszSubKey)

		.while (1)
	
			mov	eax, pidlTemp
			movzx	ecx, [eax].ITEMIDLIST.mkid.cb
			.break .if (ecx == 0)

			GetDataPointer pidlTemp
			mov	pData, eax

;----------------- add the length of this item plus one for the backslash

			invoke	lstrlen,addr [eax].PIDLDATA.szText
			mov	ecx, dwCopied
			lea	edx, [ecx+eax+1]
			mov	dwCopied, edx

			invoke	GetNextItem_Pidl, pidlTemp
			mov	pidlTemp, eax

		.endw

;-------------- add one for the NULL terminator

		mov	eax, dwCopied
		inc eax
		ret
	.endif

	mov	edi, lpszSubKey
	mov	BYTE PTR [edi], 0

	.while (1)

		mov	edx, pidlTemp
		.break .if ([edx].ITEMIDLIST.mkid.cb == 0)
		mov	ecx, dwCopied
		.break .if (ecx >= dwSize)

		GetDataPointer pidlTemp
		mov	pData, eax

;-------------- if this item is a value, then skip it and finish
		.break .if([eax].PIDLDATA.dwType == PT_VALUE)

		mov	ecx, pData					;do a strcat (edi is target)
		push esi
		lea esi, [ecx].PIDLDATA.szText
		mov ecx,dwSize
		sub ecx,dwCopied
		mov edx,esi
@@:		
		lodsb
		stosb
		and al,al
		loopnz @B
		mov word ptr [edi-1],'\'		;and add a trailing '\'
		mov eax,esi
		sub eax,edx
		add dwCopied,eax
		pop esi

		invoke	GetNextItem_Pidl, pidlTemp
		mov	pidlTemp, eax

	.endw

;------------ remove the last backslash if necessary
	.if (dwCopied)
		.if (word ptr [edi-1] == '\')
			mov byte ptr [edi-1],0
			dec	dwCopied
		.endif
	.endif

	return dwCopied

GetSubKeyText@CPidlMgr ENDP


GetValueText@CPidlMgr PROC public pidl:LPITEMIDLIST , lpszValue:LPSTR , dwSize:DWORD 

local pidlTemp:LPITEMIDLIST
local szText[MAX_PATH]:byte

	.if (!pidl)
		return 0
	.endif

	mov	eax, pidl
	mov	pidlTemp, eax

;-------- This may be a list of items, so search through the list looking for an item 
;-------- that is a value. There should be only one, and it should be the last one, but 
;-------- we will assume it can be anywhere and only copy the first one.

	.while (1)
		mov	ecx, pidlTemp
		.break .if ([ecx].ITEMIDLIST.mkid.cb == 0)
		invoke 	IsValue_Pidl, ecx
		.break .if (eax != 0)
		invoke GetNextItem_Pidl, pidlTemp
		mov	pidlTemp, eax
	.endw

;--------- we didn't find a value pidl
	mov	edx, pidlTemp
	.if (![edx].ITEMIDLIST.mkid.cb)
		return 0
	.endif

;--------- get the item's text
	invoke GetItemText@CPidlMgr, pidlTemp, addr szText, sizeof szText

;--------- if this is NULL, return the required size of the buffer
	.if (!lpszValue)
		invoke lstrlen, addr szText
		inc eax
		ret
	.endif

	invoke lstrcpy,lpszValue, addr szText

	invoke	lstrlen, lpszValue

	ret

GetValueText@CPidlMgr ENDP


Copy_Pidl PROC public pidlSource:LPITEMIDLIST 

local pidlTarget:LPITEMIDLIST
local cbSource:dword

	mov	pidlTarget, 0
	mov	cbSource, 0

	.if (pidlSource == NULL)
		return NULL
	.endif

;--------------- Allocate the new pidl
	invoke	GetSize_Pidl, pidlSource
	mov	cbSource, eax

	invoke vf(g_pMalloc,IMalloc,Alloc),cbSource
	mov	pidlTarget, eax

	.if (!eax)
		return NULL
	.endif

ifdef _DEBUG
	inc g_cntPidl
endif

;---------------- Copy the source to the target
	invoke CopyMemory, pidlTarget, pidlSource, cbSource

	return pidlTarget

Copy_Pidl ENDP

;--- static function

IsRootKey_Pidl PROC public pidl: LPITEMIDLIST 

	GetDataPointer pidl
	mov	ecx, eax
	xor	eax, eax
	cmp	[ecx].PIDLDATA.dwType, PT_ROOTKEY
	sete	al
	ret
IsRootKey_Pidl ENDP

;--- static function

IsSubKey@CPidlMgr PROC public pidl:LPITEMIDLIST 

	GetDataPointer pidl
	mov	ecx, eax
	xor	eax, eax
	cmp	[ecx].PIDLDATA.dwType, PT_SUBKEY
	sete	al
	ret
IsSubKey@CPidlMgr ENDP


;--- static function

IsValue_Pidl PROC public pidl:LPITEMIDLIST 

	GetDataPointer pidl
	mov	ecx, eax
	xor	eax, eax
	cmp	[ecx].PIDLDATA.dwType, PT_VALUE
	sete	al
	ret
IsValue_Pidl ENDP


HasSubKeys@CPidlMgr PROC public uses esi hKeyRoot:HKEY , pszSubKey:LPSTR , pidl:LPITEMIDLIST 

local hKey:HANDLE
local lResult:dword
local ft:FILETIME
local lpszTemp:LPSTR
local dwSize:dword
local szTemp[MAX_PATH]:byte

	mov	lResult, 1	;!ERROR_SUCCESS

	.if (!pszSubKey)
		mov	pszSubKey, CStr("")
	.endif

	.if (!hKeyRoot)
		invoke	GetRootKey@CPidlMgr, pidl, addr hKeyRoot
	.endif

	invoke	GetSubKeyText@CPidlMgr, pidl, NULL, 0
	mov	esi, eax
	invoke	lstrlen,pszSubKey
	lea	ecx, [esi+eax+2]
	mov	dwSize, ecx

	invoke LocalAlloc,LPTR,dwSize
	mov	lpszTemp, eax

	.if (!eax)
		return FALSE
	.endif

	invoke	lstrcpy,lpszTemp,pszSubKey

	mov	edx, lpszTemp
	.if (byte ptr [edx])
		invoke	lstrcat,lpszTemp,CStr("\")
	.endif

	invoke	lstrlen,lpszTemp
	mov esi,eax

	mov	edx, lpszTemp
	add	edx, esi
	mov	ecx, dwSize
	sub	ecx, esi
	invoke	GetSubKeyText@CPidlMgr, pidl, edx, ecx

;-------------- open the specified key

	invoke RegOpenKeyEx, hKeyRoot, lpszTemp, 0, KEY_ENUMERATE_SUB_KEYS, addr hKey
	mov lResult,eax
	.if (eax == ERROR_SUCCESS)
		mov	dwSize, 260

;-------------------- try to get the specified subkey
		invoke RegEnumKeyEx, hKey, 0, addr szTemp, addr dwSize, NULL, NULL, NULL, addr ft
		mov	lResult, eax

		invoke RegCloseKey, hKey
	.endif

	invoke LocalFree,lpszTemp

	xor	eax, eax
	cmp	lResult, ERROR_SUCCESS
	sete	al
	ret

HasSubKeys@CPidlMgr ENDP

if 0
;*** deactivated cause inline code is better here

GetDataPointer PROC pidl:LPITEMIDLIST 

	mov	eax, pidl
	.if (eax)
		lea eax,[eax].ITEMIDLIST.mkid.abID
	.endif

	ret
GetDataPointer ENDP 
endif

GetValueType@CPidlMgr PROC public pidlFQ:LPITEMIDLIST,pdwType: ptr DWORD 

local	bReturn:dword
local	pidlKey:LPITEMIDLIST
local	pidlValue:LPITEMIDLIST

	invoke SeparateKeyAndValue, pidlFQ, addr pidlKey, addr pidlValue
	.if (eax == 0)
		return 0
	.endif

	invoke GetValueType2@CPidlMgr, pidlKey, pidlValue, pdwType
	mov	bReturn, eax

	invoke	Delete_Pidl, pidlKey

	invoke	Delete_Pidl, pidlValue

	return bReturn

GetValueType@CPidlMgr ENDP


GetValueType2@CPidlMgr PROC public pidlKey:LPITEMIDLIST , pidlValue:LPITEMIDLIST , pdwType:ptr DWORD 

local hKey:HANDLE
local hRootKey:HANDLE
local lpszSubKey:LPSTR
local lpszValueName:LPSTR
local dwNameSize:dword
local lResult:dword

	.if (!pidlKey)
		return FALSE
	.endif

	.if (!pidlValue)
		return FALSE
	.endif

	.if (!pdwType)
		return FALSE
	.endif

;---------------- get the root key
	invoke GetRootKey@CPidlMgr, pidlKey, addr hRootKey

;---------------- assemble the key string
	invoke GetSubKeyText@CPidlMgr, pidlKey, NULL, 0
	mov	dwNameSize, eax

	invoke LocalAlloc, LPTR, dwNameSize
	mov	lpszSubKey, eax

	.if(!eax)
		return FALSE
	.endif

	invoke GetSubKeyText@CPidlMgr, pidlKey, lpszSubKey, dwNameSize

;--------------- assemble the value name
	invoke GetValueText@CPidlMgr, pidlValue, NULL, 0
	mov	dwNameSize, eax

	invoke LocalAlloc, LPTR, dwNameSize
	mov	lpszValueName, eax

	.if (!eax)
		invoke LocalFree,lpszSubKey
		return FALSE
	.endif

	invoke GetValueText@CPidlMgr, pidlValue, lpszValueName, dwNameSize

;---------------- open the key
	invoke RegOpenKeyEx, hRootKey, lpszSubKey, 0, KEY_QUERY_VALUE, addr hKey
	mov	lResult, eax
	.if (eax == ERROR_SUCCESS)
		invoke RegQueryValueEx, hKey, lpszValueName, NULL, pdwType, NULL, NULL
		mov	lResult, eax
		invoke RegCloseKey, hKey
		mov lResult, TRUE
	.else
		mov lResult, FALSE
	.endif

	invoke LocalFree, lpszSubKey
	invoke LocalFree, lpszValueName

	return lResult

GetValueType2@CPidlMgr ENDP


if 0
GetDataText@CPidlMgr PROC pidlFQ:LPITEMIDLIST, lpszOut:LPSTR ,dwOutSize:DWORD 

local dwReturn:dword
local pidlKey:LPITEMIDLIST
local pidlValue:LPITEMIDLIST

	invoke SeparateKeyAndValue, pidlFQ, addr pidlKey, addr pidlValue
	.if (eax == 0)
		return 0
	.endif

	invoke GetDataText2@CPidlMgr, pidlKey, pidlValue, lpszOut, dwOutSize
	mov	dwReturn, eax

	invoke Delete_Pidl, pidlKey

	invoke Delete_Pidl, pidlValue

	return dwReturn

GetDataText@CPidlMgr ENDP
endif

GetDataText2@CPidlMgr PROC public uses esi pidlKey:LPITEMIDLIST, pidlValue:LPITEMIDLIST, lpszOut:LPSTR, dwOutSize:DWORD

local hKey:HANDLE
local hRootKey:HANDLE
local lpszSubKey:LPSTR
local lpszValueName:LPSTR
local dwNameSize:DWORD
local dwType:DWORD
local dwSize:DWORD
local dwReturn:DWORD
local lResult:SDWORD
local szData[MAX_PATH]:byte
local lpszBuffer:LPSTR
local lpszTemp:LPSTR
local pData:LPBYTE
;local dwTemp:DWORD == esi

	mov	dwReturn, 0

	.if (!lpszOut)
		return dwReturn
	.endif

	.if (!pidlKey)
		return dwReturn
	.endif
if 0
	.if (!pidlValue)
		return dwReturn
	.endif
endif

;---------------- get the root key
	mov hRootKey, NULL
	invoke GetRootKey@CPidlMgr, pidlKey, addr hRootKey

;---------------- assemble the key string
	invoke	GetSubKeyText@CPidlMgr, pidlKey, NULL, 0
	mov	dwNameSize, eax

	invoke LocalAlloc, LPTR, dwNameSize
	mov	lpszSubKey, eax

	.if (!eax)
		return dwReturn
	.endif

	invoke GetSubKeyText@CPidlMgr, pidlKey, lpszSubKey, dwNameSize


;--------------- assemble the value name
	mov lpszValueName, NULL
	.if (pidlValue)
		invoke	GetValueText@CPidlMgr, pidlValue, NULL, 0
		mov	dwNameSize, eax

		invoke LocalAlloc, LPTR, dwNameSize
		mov	lpszValueName, eax

		.if (!eax)
			jmp exit
		.endif

		invoke GetValueText@CPidlMgr, pidlValue, lpszValueName, dwNameSize
	.endif

;;	DebugOut "GetDataText, key=%s, value=%s", lpszSubKey, lpszValueName

;---------------- open the key
	invoke RegOpenKeyEx, hRootKey, lpszSubKey, 0, KEY_QUERY_VALUE, addr hKey
	mov	lResult, eax

	.if (eax != ERROR_SUCCESS)
		jmp exit
	.endif

;---------------- get the value
	mov dwSize,sizeof szData

	mov ecx, lpszValueName
	.if (!ecx)
		mov ecx, CStr("")
	.endif
	invoke RegQueryValueEx, hKey, ecx, NULL, addr dwType, addr szData, addr dwSize
	mov	lResult, eax

;---------- If this fails, then there is no default value set, so go ahead and add the 
;---------- empty default value.
	.if (eax == ERROR_SUCCESS)

;---------- format the data
		mov	ecx, dwType

		.if (ecx == REG_BINARY || ecx == REG_DWORD || ecx == REG_DWORD_BIG_ENDIAN)

			lea	edx, szData
			mov	pData, edx

			mov	eax, dwSize
			imul	eax, 3
			inc eax
			invoke LocalAlloc, LPTR, eax
			mov	lpszTemp, eax
			mov	lpszBuffer, eax

			.if (eax)

				mov	esi, 0
				.while (esi < dwSize)
					mov	ecx, pData
					add	ecx, esi
					movzx edx,byte ptr [ecx]
					invoke wsprintf,lpszTemp, CStr("%02x "), edx

					invoke	lstrlen, lpszBuffer
					add	eax, lpszBuffer
					mov	lpszTemp, eax
					inc esi
				.endw

				invoke lstrcpyn, lpszOut, lpszBuffer, dwOutSize

				invoke LocalFree, lpszBuffer
			.endif
		.else
			invoke lstrcpyn, lpszOut, addr szData, dwOutSize
		.endif

		invoke	lstrlen,lpszOut
		mov	dwReturn, eax
	.endif

	invoke RegCloseKey, hKey
exit:
	invoke LocalFree,lpszSubKey

	invoke LocalFree,lpszValueName

	return dwReturn

GetDataText2@CPidlMgr ENDP


GetPidlPath@CPidlMgr PROC public pidl:LPITEMIDLIST , lpszOut:LPSTR , dwOutSize:DWORD 

local lpszTemp:LPSTR
local hKey:HANDLE

	.if (!lpszOut)
		return 0
	.endif

	mov	eax, lpszOut
	mov	BYTE PTR [eax], 0

	mov	ecx, lpszOut
	mov	lpszTemp, ecx

;---------------- add the root key text if necessary
	invoke IsRootKey_Pidl, pidl
	.if (eax)

		invoke GetRootKey@CPidlMgr, pidl, addr hKey

		invoke GetRootKeyText, hKey, lpszOut, dwOutSize
		sub	dwOutSize, eax
	.endif

;--------------- add a backslash if necessary
	invoke AddBackslash, lpszOut

	invoke	lstrlen,lpszOut
	mov	edx, lpszOut
	add	edx, eax
	mov	lpszTemp, edx

;--------------- add the subkey string
	invoke GetSubKeyText@CPidlMgr, pidl, lpszTemp, dwOutSize
	sub	dwOutSize, eax

;--------------- add a backslash if necessary
	invoke AddBackslash, lpszOut

	invoke lstrlen, lpszOut
	mov	ecx, lpszOut
	add	ecx, eax
	mov	lpszTemp, ecx

;--------------- add the value string
	invoke GetValueText@CPidlMgr, pidl, lpszTemp, dwOutSize

;--------------- remove the last backslash if necessary
	invoke lstrlen, lpszOut
	mov	ecx, lpszOut
	mov dl,[ecx+eax-1]
	.if (dl == '\')
		invoke lstrlen,lpszOut
		mov	ecx, lpszOut
		mov	BYTE PTR [ecx+eax-1], 0
	.endif

	invoke lstrlen,lpszOut
	ret

GetPidlPath@CPidlMgr ENDP



Concatenate_Pidl PROC public pidl1:LPITEMIDLIST , pidl2:LPITEMIDLIST 

local pidlNew:LPITEMIDLIST
local cb1:dword
local cb2:dword

	mov	cb1, 0
	mov	cb2, 0

;----------------- are both of these NULL?
	.if (!pidl1 && !pidl2)
		return NULL
	.endif

;----------------- if pidl1 is NULL, just return a copy of pidl2
	.if (!pidl1)
		invoke	Copy_Pidl, pidl2
		mov	pidlNew, eax
		return pidlNew
	.endif

;----------------- if pidl2 is NULL, just return a copy of pidl1
	.if (!pidl2)
		invoke	Copy_Pidl, pidl1
		mov	pidlNew, eax
		return pidlNew
	.endif

	invoke GetSize_Pidl, pidl1
	sub eax, sizeof ITEMIDLIST
	mov	cb1, eax

	invoke GetSize_Pidl, pidl2
	mov	cb2, eax

;---------------- create the new PIDL
	mov eax,cb2
	add eax,cb1
	invoke vf(g_pMalloc,IMalloc,Alloc), eax
	mov	pidlNew, eax

	.if (eax)

ifdef _DEBUG
		inc g_cntPidl
endif

;---------------- copy the first PIDL
		invoke CopyMemory, pidlNew, pidl1, cb1

;---------------- copy the second PIDL
		mov	ecx, pidlNew
		add	ecx, cb1
		invoke CopyMemory, ecx, pidl2, cb2
	.endif

	return pidlNew

Concatenate_Pidl ENDP



SeparateKeyAndValue PROC pidlFQ:LPITEMIDLIST ,ppidlKey:ptr LPITEMIDLIST,ppidlValue:ptr LPITEMIDLIST

	.if (!pidlFQ)
		return FALSE
	.endif

	invoke GetLastItem_Pidl, pidlFQ
	mov	ecx, ppidlValue
	mov	[ecx], eax
	invoke IsValue_Pidl, eax
	.if (eax == 0)
		return FALSE
	.endif

;------------ make a copy of the value pidl

	mov	edx, ppidlValue
	invoke	Copy_Pidl, [edx]
	mov	ecx, ppidlValue
	mov	[ecx], eax

;------------ make a copy of the fully qualified PIDL

	invoke	Copy_Pidl, pidlFQ
	mov	ecx, ppidlKey
	mov	[ecx], eax

;------------ but truncate the last item of it

	invoke	GetLastItem_Pidl, eax
	mov	[eax].ITEMIDLIST.mkid.cb, 0
;;	mov	[eax].ITEMIDLIST.mkid.abID, 0

	return TRUE

SeparateKeyAndValue ENDP

	END

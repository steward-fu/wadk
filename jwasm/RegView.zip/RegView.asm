
;--- the main source, handles COM things

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include unknwn.inc
	include objidl.inc
	include olectl.inc
	include shlobj.inc
	.list
	.cref

	includelib kernel32.lib
	includelib advapi32.lib
	includelib user32.lib
	includelib gdi32.lib
	includelib comctl32.lib
	includelib ole32.lib
	includelib shell32.lib
	includelib uuid.lib

	include RegView.inc

?DESKTOP equ 0	;1 = register extension on desktop level

	.data

g_nColumn1		DD 0
g_nColumn2		DD 0
g_bViewKeys		DD 0
g_bShowIDW		DD 0
g_hInstance		HINSTANCE 0
g_DllRefCount	DD 0
g_himlLarge		DD 0
g_himlSmall		DD 0

	.const

CLSID_RegView GUID <2535cb20H, 0f867H, 011d5H, < 0bbH, 098H, 00H, 040H, 095H, 01aH, 0c3H, 02aH>>

ifdef _DEBUG
DEBUGPREFIX LPSTR CStr("RegView:")
endif

	.code

DllMain PROC hInstance:HINSTANCE,dwReason:dword,lpReserved:dword

	mov	eax, dwReason
	.if (eax == DLL_PROCESS_ATTACH)
		mov		ecx, hInstance
		mov		g_hInstance, ecx
		invoke	GetGlobalSettings
		invoke	CreateImageLists
	.elseif (eax == DLL_PROCESS_DETACH)
		call	SaveGlobalSettings
		call	DestroyImageLists
	.endif
	mov	eax, 1
	ret
DllMain ENDP

_DllMainCRTStartup proc public a1:HINSTANCE,a2:dword,a3:dword
	invoke DllMain,a1,a2,a3
	ret
_DllMainCRTStartup endp

DllCanUnloadNow PROC public

	xor		eax, eax
	cmp		g_DllRefCount, eax
	setne	al
	ret
DllCanUnloadNow ENDP


DllGetClassObject PROC public rclsid:ptr CLSID,riid:ptr IID,ppReturn:ptr

local pClassFactory:ptr IClassFactory
local hResult:dword

	mov	eax, ppReturn
	mov	DWORD PTR [eax], 0

	invoke	IsEqualGUID,rclsid,addr CLSID_RegView
	.if (eax == 0)
		return CLASS_E_CLASSNOTAVAILABLE
	.endif

	invoke	Create@CClassFactory
	.if (eax == NULL)
		return E_OUTOFMEMORY
	.endif
	mov pClassFactory,eax

	invoke vf(pClassFactory,IClassFactory,QueryInterface),riid,ppReturn
	mov	hResult, eax

	invoke vf(pClassFactory,IClassFactory,Release)

	return hResult

DllGetClassObject ENDP

	.data

REGSTRUCT struct
lpszSubKey		LPSTR  ? ;
lpszValueName   LPSTR  ? ;
lpszData		LPSTR  ? ;
REGSTRUCT ends

LPREGSTRUCT typedef ptr REGSTRUCT


ClsidEntries label REGSTRUCT
	REGSTRUCT <-1, 0, CStr("CLSID\%s")>
	REGSTRUCT <0,0,CStr("Registry")>
	REGSTRUCT <CStr("InprocServer32"), 0, CStr("%s")>
	REGSTRUCT <CStr("InprocServer32"), CStr("ThreadingModel"), CStr("Both")>
	REGSTRUCT <CStr("DefaultIcon"), 0, CStr("%s,0")>
	REGSTRUCT <-1,0,0>

	.code


RegisterNameSpace proc uses esi pszCLSID:LPSTR, bRegister:BOOL

local	hKey:HANDLE
local	dwDisp:dword
local	szKey[256]:byte

if ?DESKTOP
	mov ecx, CStr("Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace")
else
	mov ecx, CStr("Software\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace")
endif

	invoke wsprintf, addr szKey, CStr("%s\%s"), ecx, pszCLSID
	.if (bRegister)
		invoke RegCreateKeyEx, HKEY_LOCAL_MACHINE, addr szKey,\
			0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, addr hKey, addr dwDisp
		.if (eax == NOERROR)
;------------------------------ Create the value string.
			mov esi, CStr("RegViewASM")
			invoke lstrlen, esi
			mov edx,eax
			inc edx
			invoke RegSetValueEx, hKey, NULL, 0, REG_SZ, esi, edx
			invoke RegCloseKey, hKey
			mov eax, S_OK
		.else
			mov eax, SELFREG_E_CLASS
		.endif
	.else
		invoke RegDeleteKey, HKEY_LOCAL_MACHINE, addr szKey
	.endif
	ret
RegisterNameSpace endp

DllRegisterServer PROC public uses ebx

local	i:dword
local	hKey:HANDLE
local	lResult:dword
local	dwDisp:dword
local	szCLSID[40]:byte
local	wszCLSID[40]:word
local	pwsz:LPWSTR
local	dwData:dword
local	osvi:OSVERSIONINFO
local	szData[MAX_PATH]:byte
local	szSubKey[MAX_PATH]:byte
local	szModule[MAX_PATH]:byte
local	szKeyPrefix[64]:byte

;------------------------------------ get the CLSID in string form
	invoke StringFromGUID2, addr CLSID_RegView, addr wszCLSID,40
	invoke WideCharToLocal, addr szCLSID, addr wszCLSID, sizeof szCLSID

;------------------------------ get this DLL's path and file name
	invoke GetModuleFileName, g_hInstance, addr szModule, sizeof szModule

;------------------------------ register the CLSID entries

	mov ebx,offset ClsidEntries
	assume ebx:ptr REGSTRUCT

	.while (1)

		.if ([ebx].lpszSubKey == -1)
			.break .if ([ebx].lpszData == 0)
			invoke wsprintf, addr szKeyPrefix, [ebx].lpszData, addr szCLSID
			add ebx, sizeof REGSTRUCT
			.continue
		.endif
;------------------------------ Create the sub key string.
		invoke lstrcpy, addr szSubKey, addr szKeyPrefix
		.if ([ebx].lpszSubKey)
			invoke lstrlen, addr szSubKey
			lea ecx, szSubKey
			add ecx, eax
			mov byte ptr [ecx],'\'
			inc ecx
			invoke lstrcpy, ecx, [ebx].lpszSubKey
		.endif

		invoke RegCreateKeyEx, HKEY_CLASSES_ROOT,\
					addr szSubKey,0,NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, \
					NULL, addr hKey, addr dwDisp
		.if (eax == NOERROR)
;------------------------------ if necessary, create the value string
			invoke wsprintf, addr szData, [ebx].lpszData, addr szModule
;;			invoke lstrlen,addr szData // wsprintf returned string size already
			mov edx,eax
			inc edx
			invoke RegSetValueEx, hKey, [ebx].lpszValueName,\
						0, REG_SZ, addr szData, edx
			invoke	RegCloseKey, hKey

		.else
			return SELFREG_E_CLASS
		.endif

		add ebx,sizeof REGSTRUCT
	.endw
	assume ebx:nothing

;------------------------------ Register the default flags for the folder.
	invoke wsprintf, addr szSubKey,CStr("CLSID\%s\ShellFolder"),addr szCLSID

	invoke RegCreateKeyEx, HKEY_CLASSES_ROOT, addr szSubKey, 0, NULL, REG_OPTION_NON_VOLATILE,\
				KEY_WRITE, NULL, addr hKey, addr dwDisp
	.if (eax == NOERROR)
		mov dwData, SFGAO_FOLDER or SFGAO_HASSUBFOLDER or SFGAO_BROWSABLE
		invoke RegSetValueEx, hKey, CStr("Attributes"), 0, REG_BINARY, addr dwData, sizeof dwData
		invoke RegCloseKey, hKey
	.else
		return SELFREG_E_CLASS
	.endif

;------------------------------ Register the name space extension
	invoke RegisterNameSpace, addr szCLSID, TRUE

;------------------------------ If running on NT, register the extension as approved.
	mov osvi.dwOSVersionInfoSize,sizeof osvi
	invoke GetVersionEx, addr osvi

	.if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)

		invoke lstrcpy,addr szSubKey,\
			CStr("Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved")

		invoke RegCreateKeyEx, HKEY_LOCAL_MACHINE, addr szSubKey, 0, NULL, REG_OPTION_NON_VOLATILE,\
				KEY_WRITE, NULL, addr hKey, addr dwDisp
		.if (eax == NOERROR)
			invoke lstrcpy, addr szData, CStr("RegViewASM")
			invoke lstrlen, addr szData
			mov edx,eax
			inc eax
			invoke RegSetValueEx, hKey, addr szCLSID, 0, REG_SZ, addr szData, edx
			invoke RegCloseKey, hKey
		.else
			return SELFREG_E_CLASS
		.endif
	.endif
	return S_OK

DllRegisterServer ENDP

DeleteKeyWithSubKeys proc uses ebx hKey:HANDLE,pszKey:ptr byte

local	szKey[MAX_PATH]:byte
local	hSubKey:HANDLE
local	filetime:FILETIME
local	dwSize:dword

		invoke RegOpenKeyEx,hKey,pszKey,NULL,KEY_ALL_ACCESS,addr hSubKey
		.if (eax == ERROR_SUCCESS)
			mov ebx,0
			.while (1)
				mov dwSize,sizeof szKey
				invoke RegEnumKeyEx,hSubKey,ebx,addr szKey,addr dwSize,NULL,NULL,NULL,addr filetime
				.break .if (eax != ERROR_SUCCESS)
				invoke DeleteKeyWithSubKeys,hSubKey,addr szKey
			.endw							
			invoke RegCloseKey,hSubKey
		.endif
		invoke RegDeleteKey,hKey,pszKey		;and delete subkey
		ret
DeleteKeyWithSubKeys endp

DllUnregisterServer PROC public uses ebx esi edi

local	osvi:OSVERSIONINFO
local	hKey:HANDLE
local	szCLSID[40]:byte
local	wszGUID[40]:word
local	szSubKey[MAX_PATH]:byte

;------------------------------ get the CLSID in string form
		invoke StringFromGUID2, addr CLSID_RegView, addr wszGUID,40
		invoke WideCharToLocal, addr szCLSID, addr wszGUID, sizeof szCLSID

;------------------------------ Unregister CLSID
		mov esi, offset ClsidEntries
		.while (1)
			.if ([esi].REGSTRUCT.lpszSubKey == -1)
				.break .if ([esi].REGSTRUCT.lpszData == 0)
				invoke wsprintf, addr szSubKey, [esi].REGSTRUCT.lpszData, addr szCLSID
				invoke DeleteKeyWithSubKeys, HKEY_CLASSES_ROOT, addr szSubKey
			.endif
			add esi, sizeof REGSTRUCT
		.endw

;------------------------------ Unregister name space extension
		invoke RegisterNameSpace, addr szCLSID, FALSE

;------------------------------ If running on NT, unregister the extension as approved.
		mov osvi.dwOSVersionInfoSize,sizeof osvi
		invoke GetVersionEx, addr osvi

		.if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
			invoke lstrcpy, addr szSubKey,\
				CStr("Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved")
			invoke RegOpenKeyEx, HKEY_LOCAL_MACHINE, addr szSubKey, NULL,KEY_ALL_ACCESS, addr hKey
			.if (eax == ERROR_SUCCESS)
				invoke RegDeleteValue, hKey, addr szCLSID
				invoke RegCloseKey, hKey
			.endif
		.endif

		return S_OK

DllUnregisterServer endp


	END

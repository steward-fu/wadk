
;--- implements CExtractIcon class, based on IExtractIcon

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CEXTRACTICON equ 1
	include RegView.inc

CExtractIcon struct
vtblIExtractIcon dd ?

ObjRefCount DWORD ?

pidl		LPITEMIDLIST ?
;pPidlMgr	LPPIDLMGR ?
CExtractIcon ends

ICON_INDEX_BINARY     equ 0
ICON_INDEX_STRING     equ 1
ICON_INDEX_FOLDER     equ 2
ICON_INDEX_FOLDEROPEN equ 3

; private methods
Destroy@CExtractIcon proto :ptr CExtractIcon

	.const

CExtractIconVtbl IExtractIconVtbl {QueryInterface, AddRef, Release,\
		GetIconLocation, Extract}

	.code

__this	textequ <ebx>
_this	textequ <[__this].CExtractIcon>

	MEMBER vtblIExtractIcon, ObjRefCount, pidl

;*** constructor CExtractIcon

Create@CExtractIcon PROC public uses __this pidl:LPITEMIDLIST

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CExtractIcon
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m_vtblIExtractIcon, OFFSET CExtractIconVtbl

	inc g_DllRefCount

;	invoke Create@CPidlMgr
;	mov	m_pPidlMgr,eax
;	.if (!eax)
;		invoke Destroy@CExtractIcon, __this
;		return 0
;	.endif

	invoke Copy_Pidl, pidl
	mov m_pidl,eax

	mov m_ObjRefCount,1

	return __this

Create@CExtractIcon ENDP

;*** destructor CExtractIcon

Destroy@CExtractIcon PROC uses __this pThis:ptr CExtractIcon

	mov __this,pThis

	.if (m_pidl)
		invoke Delete_Pidl, m_pidl
	.endif

;	.if (m_pPidlMgr)
;		invoke Destroy@CPidlMgr
;	.endif

	invoke LocalFree, __this

	dec g_DllRefCount

	ret

Destroy@CExtractIcon ENDP

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IExtractIcon,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)


QueryInterface PROC pThis:ptr CExtractIcon,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP



AddRef PROC pThis:ptr CExtractIcon

	mov eax,pThis
	inc [eax].CExtractIcon.ObjRefCount
	mov	eax, [eax].CExtractIcon.ObjRefCount
	ret
AddRef ENDP



Release PROC pThis:ptr CExtractIcon

	mov eax,pThis
	dec [eax].CExtractIcon.ObjRefCount
	mov eax,[eax].CExtractIcon.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CExtractIcon,pThis
		xor eax,eax
	.endif
	ret

Release ENDP



GetIconLocation PROC uses __this pThis:ptr CExtractIcon, uFlags:UINT, szIconFile:LPSTR, cchMax:dword, piIndex:ptr dword, puFlags:ptr dword

local dwType:dword

	mov __this,pThis

;--------------- tell the shell to always call Extract

	mov	eax, puFlags
	mov	DWORD PTR [eax], GIL_NOTFILENAME

;--------------- the pidl is either a value or a folder, so find out which it is

	invoke	GetLastItem_Pidl, m_pidl
	invoke	IsValue_Pidl, eax
	.if (eax)
;--------------- its a value
;--------------- get the data type to determine which icon to get
		invoke	GetValueType@CPidlMgr, m_pidl, addr dwType

		mov eax,dwType
		mov	ecx, piIndex
		.if ((eax == REG_BINARY) || (eax == REG_DWORD) || (eax == REG_DWORD_BIG_ENDIAN))
			mov	DWORD PTR [ecx], ICON_INDEX_BINARY
		.else
			mov	DWORD PTR [ecx], ICON_INDEX_STRING
		.endif
	.else
;--------------- its a key
		mov	ecx, piIndex
		.if (uFlags & GIL_OPENICON)
			mov	DWORD PTR [ecx], ICON_INDEX_FOLDEROPEN	;tell Extract to return the open icon
		.else
			mov	DWORD PTR [ecx], ICON_INDEX_FOLDER	;tell Extract to return the open icon
		.endif
	.endif
	return S_OK

GetIconLocation ENDP	; CExtractIcon::GetIconLocation


Extract PROC pThis:ptr CExtractIcon, pszFile:LPSTR,nIconIndex:dword, phiconLarge:ptr HICON, phiconSmall:ptr HICON, nIconSize;dword


	invoke ImageList_GetIcon, g_himlLarge, nIconIndex, ILD_TRANSPARENT
	mov	edx, phiconLarge
	mov	[edx], eax

	invoke ImageList_GetIcon, g_himlSmall, nIconIndex, ILD_TRANSPARENT
	mov	edx, phiconSmall
	mov	[edx], eax

if 0
;	if(nIconIndex)
;	{
;		*phiconLarge = ImageList_GetIcon(g_himlLarge, ICON_INDEX_FOLDEROPEN, ILD_TRANSPARENT);
;		*phiconSmall = ImageList_GetIcon(g_himlSmall, ICON_INDEX_FOLDEROPEN, ILD_TRANSPARENT);
;	}
;	else
;	{
;		*phiconLarge = ImageList_GetIcon(g_himlLarge, ICON_INDEX_FOLDER, ILD_TRANSPARENT);
;		*phiconSmall = ImageList_GetIcon(g_himlSmall, ICON_INDEX_FOLDER, ILD_TRANSPARENT);
;	}
endif

	return S_OK

Extract ENDP	; CExtractIcon::Extract


	END

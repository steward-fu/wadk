
;--- implements CEnumIDList, based on IEnumIDList
;--- this is a standard COM enumerator

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CENUMIDLIST equ 1

	include RegView.inc

LPENUMLIST typedef ptr ENUMLIST

ENUMLIST struct 
pNext   LPENUMLIST	?
pidl	LPITEMIDLIST ?
ENUMLIST ends 

CEnumIDList struct
vtblIEnumIDList	dd ?
ObjRefCount	DWORD ?

pMalloc		LPMALLOC ?
pFirst		LPENUMLIST ?
pLast		LPENUMLIST ?
pCurrent	LPENUMLIST ?
;;pPidlMgr	LPPIDLMGR  ?

CEnumIDList ends


;private methods
Destroy@CEnumIDList	proto :ptr CEnumIDList
CreateEnumList		proto :ptr CEnumIDList, :HANDLE, :LPSTR, :DWORD
AddToEnumList		proto :ptr CEnumIDList, :LPITEMIDLIST
DeleteEnumList		proto :ptr CEnumIDList

	.const

CEnumIDListVtbl IEnumIDListVtbl {QueryInterface,\
	AddRef,Release,Next, Skip, Reset, Clone}

	.code

__this	textequ <ebx>
_this	textequ <[__this].CEnumIDList>

	MEMBER vtblIEnumIDList, ObjRefCount, pMalloc
	MEMBER pFirst, pLast, pCurrent

Create@CEnumIDList PROC public uses __this hKeyRoot:HANDLE, lpszSubKey:LPSTR, dwFlags:DWORD, pResult:ptr dword


	DebugOut "Create@CEnumIDList"

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CEnumIDList
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m_vtblIEnumIDList, OFFSET CEnumIDListVtbl

	inc g_DllRefCount

	.if (pResult)
		mov	ecx, pResult
		mov	DWORD PTR [ecx], 0
	.endif

	mov	m_pFirst,NULL
	mov	m_pLast,NULL
	mov	m_pCurrent,NULL

;	invoke Create@CPidlMgr
;	mov	m_pPidlMgr,eax

;	.if (!eax)
;		.if (pResult)
;			mov	eax,pResult
;			mov	DWORD PTR [eax], E_OUTOFMEMORY
;		.endif
;		invoke Destroy@CEnumIDList, __this
;		return 0
;	.endif

;------------ get the shell's IMalloc pointer
;------------ we'll keep this until we get destroyed
	invoke	SHGetMalloc, addr m_pMalloc
	.if (FAILED(eax))
		.if (pResult)
			mov	eax,pResult
			mov	DWORD PTR [eax], E_OUTOFMEMORY
		.endif
		invoke Destroy@CEnumIDList, __this
		return 0
	.endif

	invoke CreateEnumList, __this, hKeyRoot, lpszSubKey, dwFlags
	.if (eax == 0)
		.if (pResult)
			mov	eax,pResult
			mov	DWORD PTR [eax], E_OUTOFMEMORY
		.endif
		invoke Destroy@CEnumIDList, __this
		return 0
	.endif

	mov m_ObjRefCount,1

	DebugOut "Create@CEnumIDList exit"

	return __this

Create@CEnumIDList ENDP



Destroy@CEnumIDList PROC uses __this pThis:ptr CEnumIDList

	DebugOut "Destroy@CEnumIDList"

	mov __this,pThis

	invoke DeleteEnumList, __this

	.if (m_pMalloc)
		invoke vf(m_pMalloc,IMalloc,Release)
	.endif

;	.if (m_pPidlMgr)
;		invoke Destroy@CPidlMgr
;	.endif

	invoke LocalFree, __this

	dec g_DllRefCount

	DebugOut "Destroy@CEnumIDList exit"

	ret

Destroy@CEnumIDList ENDP

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IEnumIDList,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface PROC pThis:ptr CEnumIDList,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP	



AddRef PROC pThis:ptr CEnumIDList

	mov eax,pThis
	inc [eax].CEnumIDList.ObjRefCount
	mov	eax, [eax].CEnumIDList.ObjRefCount
	ret
AddRef ENDP			


Release PROC pThis:ptr CEnumIDList

	mov eax,pThis
	dec [eax].CEnumIDList. ObjRefCount
	mov eax,[eax].CEnumIDList. ObjRefCount
	.if (eax == 0)
		invoke Destroy@CEnumIDList,pThis
		xor eax,eax
	.endif
	ret
Release ENDP



Next PROC uses __this esi edi pThis:ptr CEnumIDList, dwElements:DWORD , apidl: ptr LPITEMIDLIST, pdwFetched:ptr DWORD

local hr:dword

	mov __this,pThis

	mov	hr, S_OK

	.if (dwElements > 1 && !pdwFetched)
		return E_INVALIDARG
	.endif

	mov edi, m_pCurrent
	assume edi:ptr ENUMLIST

	mov esi,0
	.while (esi < dwElements)
;----------------- is this the last item in the list?
		.if (!edi)
			mov hr,S_FALSE
			.break
		.endif

		invoke	Copy_Pidl, [edi].pidl
		mov	edx, apidl
		mov	[edx+esi*4], eax
		mov edi, [edi].pNext

		inc esi
	.endw
	mov m_pCurrent,edi

	.if (pdwFetched)
		mov	ecx, pdwFetched
		mov	[ecx], esi
	.endif
	return hr
	assume edi:nothing

Next ENDP


Skip PROC uses __this esi edi pThis:ptr CEnumIDList, dwSkip:DWORD 

local hr:dword

	mov __this,pThis

	mov	hr, S_OK

	mov esi,0
	mov edi, m_pCurrent
	assume edi:ptr ENUMLIST

	.while (esi < dwSkip)

		.if(!edi)				; is this the last item in the list?
			mov hr,S_FALSE
			.break
		.endif

		mov edi, [edi].pNext
		inc esi
	.endw
	mov m_pCurrent,edi

	return hr
	assume edi:nothing

Skip ENDP


Reset PROC uses __this pThis:ptr CEnumIDList

	mov __this,pThis

	mov	eax, m_pFirst
	mov	m_pCurrent,eax

	return S_OK

Reset ENDP


Clone PROC pThis:ptr CEnumIDList, ppEnum:ptr LPENUMIDLIST

	return E_NOTIMPL

Clone ENDP


ahKey HANDLE HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE,\
		HKEY_USERS, HKEY_PERFORMANCE_DATA, HKEY_CURRENT_CONFIG, HKEY_DYN_DATA, -1


CreateEnumList PROC uses __this esi pThis:ptr CEnumIDList, hKeyRoot:HANDLE , lpszSubKey:LPSTR , dwFlags:DWORD 

local pidl:LPITEMIDLIST
local szKey[REGSTR_MAX_VALUE_LENGTH]:byte
local szValue[REGSTR_MAX_VALUE_LENGTH]:byte

	mov __this,pThis

;----------------- enumerate the folders (keys)
	.if (dwFlags & SHCONTF_FOLDERS)

;----------- special case - we can't enumerate the root level keys (HKEY_CLASSES_ROOT, etc.), 
;----------- so if both of these are NULL, then we need to fake an enumeration of those.
		.if ((!hKeyRoot) && (!lpszSubKey))

			mov esi,offset ahKey
			.while (dword ptr [esi] != -1)

;------------- only add the root keys that actually exists on this system
				invoke RootKeyExists,[esi]
				.if (eax)
;------------- create the pidl for this item
					invoke	CreateRootKey@CPidlMgr, [esi]
					mov	pidl, eax
					.if (eax)
						invoke AddToEnumList, __this, pidl
						.if (eax == 0)
							return FALSE
						.endif
					.else
						return FALSE
					.endif
				.endif
				add esi,sizeof HANDLE
			.endw
		.else
			mov esi,0
			.while (1)
;-------------------- get the next item
				invoke GetKeyName, hKeyRoot, lpszSubKey, esi, addr szKey, sizeof szKey
				.break .if (eax == 0)

;-------------------- create the pidl for this item
				invoke	CreateSubKey@CPidlMgr, addr szKey
				mov	pidl, eax
				.if (eax)
					invoke	AddToEnumList, __this, pidl
					.if (eax == 0)
						return FALSE
					.endif
				.else
					return FALSE
				.endif
				inc esi
			.endw
		.endif
	.endif

;----------- enumerate the non-folder items (values)

	.if (dwFlags & SHCONTF_NONFOLDERS)

		mov	esi, 0

;---------- There is a special case here. All keys have a default value, but if the 
;---------- default value is empty, then it won't be enumerated. If it has data, then 
;---------- it will be enumerated but the name will be NULL. 
;---------- To work around this, we will add a default item here and then not add it 
;---------- if it shows up in the enumeration in the loop below.

;---------- create the default item

		invoke	CreateValue@CPidlMgr, CStr("")
		mov	pidl, eax
		.if (eax)
			invoke AddToEnumList, __this, pidl
			.if (eax == 0)
				return FALSE
			.endif
		.else
			return FALSE
		.endif

;----------- get the items
		.while (1)
			invoke GetValueName, hKeyRoot, lpszSubKey, esi, addr szValue, sizeof szValue
			.break .if (eax == 0)

;------------- don't add a default value that may have shown up in the enumeration
			movsx	eax, BYTE PTR szValue
			.if (al == 0)
				inc esi
				.continue
			.endif

;------------- create the pidl for this item
			invoke	CreateValue@CPidlMgr, addr szValue
			mov	pidl, eax
			.if (eax)
				invoke AddToEnumList, __this, pidl
				.if (eax == 0)
					return FALSE
				.endif
			.else
				return FALSE
			.endif
			inc esi
		.endw
	.endif

	return TRUE

CreateEnumList ENDP



AddToEnumList PROC uses __this pThis:ptr CEnumIDList, pidl:LPITEMIDLIST 

local pNew:LPENUMLIST

	mov __this,pThis

	invoke vf(m_pMalloc,IMalloc,Alloc), sizeof ENUMLIST
	mov	pNew, eax
	.if (eax)
;--------------- set the next pointer
		mov [eax].ENUMLIST.pNext,NULL
		mov ecx,pidl
		mov [eax].ENUMLIST.pidl,ecx

;--------------- is this the first item in the list?
		.if (!m_pFirst)
			mov	m_pFirst, eax
			mov m_pCurrent, eax
		.endif

		.if (m_pLast)
;--------------- add the new item to the end of the list
			mov ecx, m_pLast
			mov	[ecx].ENUMLIST.pNext, eax
		.endif

		mov	m_pLast, eax

		mov eax,TRUE
	.else

		mov eax,FALSE
	.endif
	ret

AddToEnumList ENDP	; CEnumIDList::AddToEnumList



DeleteEnumList PROC uses __this edi pThis:ptr CEnumIDList

;local pDelete:LPENUMLIST == esi

	mov __this,pThis

	mov edi, m_pFirst
	assume edi:ptr ENUMLIST

	.while (edi)

		push [edi].pNext

;-------------- free the pidl
;-------------- //m_pMalloc->Free(pDelete->pidl);

		invoke Delete_Pidl, [edi].pidl 

;-------------- free the list item
		invoke vf(m_pMalloc,IMalloc,Free), edi

		pop edi

	.endw

	mov	m_pFirst,NULL
	mov	m_pLast,NULL
	mov	m_pCurrent,NULL

	return TRUE
	assume edi:nothing

DeleteEnumList ENDP


	END

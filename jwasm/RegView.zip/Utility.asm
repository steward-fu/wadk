
;--- some helper functions

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

	include RegView.inc

INITIAL_COLUMN_SIZE   equ 100

	.code

;*** scan interface tab and see if requested iface is in there
;*** return valid ptr or NULL

IsInterfaceSupported proc public uses ebx esi edi pReqIF:ptr IID, pIFTab:ptr ptr IID, dwEntries:dword, pThis:ptr, ppReturn:ptr LPUNKNOWN
	
	mov ecx,dwEntries
	mov esi,pIFTab
	mov ebx,0
	.while (ecx)
		lodsd
		mov edi,eax
		lodsd
		mov edx,eax
		mov eax,esi
		mov esi,pReqIF
		push ecx
		mov ecx,4
		repz cmpsd
		pop ecx
		.if (ZERO?)
			mov ebx,edx
			add ebx,pThis
			.break
		.endif
		mov esi,eax
		dec ecx
	.endw
	mov ecx,ppReturn
	mov [ecx],ebx

	.if (ebx)
		invoke vf(ebx,IUnknown,AddRef)
		mov eax,S_OK
	.else
		mov eax,E_NOINTERFACE
	.endif
	ret

IsInterfaceSupported endp

GetKeyName PROC public hKeyRoot:HKEY, pszSubKey:LPSTR, dwIndex:DWORD, pszOut:LPSTR, dwSize:DWORD

local hKey:HKEY
local lResult:dword
local ft:FILETIME

	.if (!pszOut)
		return 0
	.endif

	.if (!pszSubKey)
		mov pszSubKey,CStr("")
	.endif

	invoke RegOpenKeyEx,hKeyRoot, pszSubKey, 0, KEY_ENUMERATE_SUB_KEYS, addr hKey
	.if (eax != ERROR_SUCCESS)
		return 0
	.endif

	invoke RegEnumKeyEx, hKey, dwIndex, pszOut, addr dwSize, NULL, NULL, NULL, addr ft
	mov	lResult, eax

	invoke RegCloseKey, hKey

	.if (lResult == ERROR_SUCCESS)
		return dwSize
	.endif

	return 0

GetKeyName ENDP		; GetKeyName


GetValueName PROC public hKeyRoot:HKEY, pszSubKey:LPSTR, dwIndex:DWORD, pszOut:LPSTR, dwSize:DWORD

local hKey:HKEY
local lResult:dword
local dwType:dword

	.if (!pszOut)
		return FALSE
	.endif

	.if (!pszSubKey)
		mov pszSubKey,CStr("")
	.endif


	invoke RegOpenKeyEx, hKeyRoot, pszSubKey, 0, KEY_QUERY_VALUE, addr hKey
	.if (eax != ERROR_SUCCESS)
		return FALSE
	.endif

	invoke RegEnumValue, hKey, dwIndex, pszOut, addr dwSize, NULL,addr dwType, NULL, NULL
	mov	lResult, eax

	invoke RegCloseKey, hKey

	xor	eax, eax
	cmp	lResult, ERROR_SUCCESS
	sete	al

	ret
GetValueName ENDP



GetRootKeyText PROC public hKeyRoot:HKEY, lpszOut:LPSTR, dwOutSize:DWORD

	xor ecx,ecx
	mov eax,hKeyRoot
	.if		(eax == HKEY_CLASSES_ROOT)
		mov ecx, CStr("HKEY_CLASSES_ROOT")
	.elseif (eax == HKEY_CURRENT_USER)
		mov ecx, CStr("HKEY_CURRENT_USER")
	.elseif (eax == HKEY_LOCAL_MACHINE)
		mov ecx, CStr("HKEY_LOCAL_MACHINE")
	.elseif (eax == HKEY_USERS)
		mov ecx, CStr("HKEY_USERS")
	.elseif (eax == HKEY_PERFORMANCE_DATA)
		mov ecx, CStr("HKEY_PERFORMANCE_DATA")
	.elseif (eax == HKEY_CURRENT_CONFIG)
		mov ecx, CStr("HKEY_CURRENT_CONFIG")
	.elseif (eax == HKEY_DYN_DATA)
		mov ecx, CStr("HKEY_DYN_DATA")
	.endif

	.if (ecx)
		invoke lstrcpyn, lpszOut, ecx, dwOutSize
	.else
		mov	eax, lpszOut
		mov	BYTE PTR [eax], 0
	.endif

	invoke lstrlen, lpszOut
	inc eax
	ret
GetRootKeyText ENDP



RootKeyExists PROC public hKeyRoot:HKEY

local lResult:dword
local hKey:HKEY

;------------ open the specified key
	invoke RegOpenKeyEx, hKeyRoot, NULL, 0, KEY_ENUMERATE_SUB_KEYS, addr hKey
	mov	lResult, eax

	.if (eax != ERROR_SUCCESS)
		return FALSE
	.endif

	invoke RegCloseKey, hKey

	return TRUE

RootKeyExists ENDP


MAIN_KEY_STRING	textequ	<CStr("Software\Japheth\RegView")>
VALUE_STRING	textequ <CStr("Display Settings")>

SaveGlobalSettings PROC public

local hKey:HKEY
local lResult:dword
local dwDisp:dword
local dwArray[4]:dword


	invoke RegCreateKeyEx, HKEY_CURRENT_USER, MAIN_KEY_STRING, 0,\
				NULL, REG_OPTION_NON_VOLATILE,  KEY_ALL_ACCESS, NULL,  addr hKey, addr dwDisp

	mov lResult,eax
	.if (eax != ERROR_SUCCESS)
		return FALSE
	.endif

	mov	edx, g_nColumn1
	mov	dwArray[0*sizeof dword], edx
	mov	eax, g_nColumn2
	mov	dwArray[1*sizeof dword], eax
	mov	ecx, g_bViewKeys
	mov	dwArray[2*sizeof dword], ecx
	mov	edx, g_bShowIDW
	mov	dwArray[3*sizeof dword], edx

;----------------- save the last printer selected
	invoke	RegSetValueEx, hKey, VALUE_STRING, 0, REG_BINARY, addr dwArray, sizeof dwArray
	mov	lResult, eax

	invoke RegCloseKey, hKey

	.if (lResult != ERROR_SUCCESS)
		return FALSE
	.endif

	return TRUE

SaveGlobalSettings ENDP				; SaveGlobalSettings


GetGlobalSettings PROC public

local hKey:HKEY
local lResult:dword
local dwArray[4]:dword
local dwType:dword
local dwSize:dword


;------------- set up the default data
	mov g_nColumn1,INITIAL_COLUMN_SIZE

	mov g_nColumn2,INITIAL_COLUMN_SIZE

	mov g_bViewKeys,TRUE

	mov g_bShowIDW,FALSE

	invoke RegOpenKeyEx, HKEY_CURRENT_USER, MAIN_KEY_STRING, 0, KEY_ALL_ACCESS, addr hKey
	mov	lResult, eax

	.if (eax != ERROR_SUCCESS)
		return FALSE
	.endif

	mov	dwSize, sizeof dwArray

;-------------- save the last printer selected
	invoke RegQueryValueEx, hKey, VALUE_STRING, NULL, addr dwType, addr dwArray, addr dwSize
	mov	lResult, eax

	invoke RegCloseKey, hKey

	.if (lResult != ERROR_SUCCESS)
		return FALSE
	.endif

	mov	eax, dwArray[0 * sizeof dword]
	mov	g_nColumn1, eax

	mov	ecx, dwArray[1 * sizeof dword]
	mov	g_nColumn2, ecx

	mov	edx, dwArray[2 * sizeof dword]
	mov	g_bViewKeys, edx

	mov	eax, dwArray[3 * sizeof dword]
	mov	g_bShowIDW, eax

	return TRUE

GetGlobalSettings ENDP



CompareItems PROC public lParam1:LPARAM, lParam2:LPARAM, lpData:LPARAM

	mov	eax, lpData

	.if (eax)
		invoke vf(eax, IShellFolder,CompareIDs), 0, lParam1, lParam2
	.else
		return 0
	.endif

	ret
CompareItems ENDP


CreateImageLists PROC public

local	_cx:dword
local	_cy:dword
local	hIcon:HICON

	invoke GetSystemMetrics, SM_CXSMICON
	mov	_cx, eax

	invoke GetSystemMetrics, SM_CYSMICON
	mov	_cy, eax

	mov	_cx, 16
	mov	_cy, 16

	.if (g_himlSmall)
		invoke ImageList_Destroy, g_himlSmall
	.endif

;------------ set the small image list
	invoke ImageList_Create, _cx, _cy, ILC_COLORDDB or ILC_MASK, 4, 0
	mov	g_himlSmall, eax

	.if (eax)

		invoke LoadImage, g_hInstance, IDI_BINARY, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlSmall, eax)

		invoke LoadImage, g_hInstance, IDI_STRING, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlSmall, eax)

		invoke LoadImage, g_hInstance, IDI_FOLDER, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlSmall, eax)

		invoke LoadImage, g_hInstance, IDI_FOLDEROPEN, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlSmall, eax)

	.endif

	.if (g_himlLarge)
		invoke ImageList_Destroy,g_himlLarge
	.endif

	invoke GetSystemMetrics, SM_CXICON
	mov	_cx, eax

	invoke GetSystemMetrics, SM_CYICON
	mov	_cy, eax

	mov	_cx, 32
	mov	_cy, 32

;------------ set the large image list
	invoke ImageList_Create, _cx, _cy, ILC_COLORDDB or ILC_MASK, 4, 0
	mov	g_himlLarge, eax

	.if (eax)

		invoke LoadImage, g_hInstance, IDI_BINARY, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlLarge, eax)

		invoke LoadImage, g_hInstance, IDI_STRING, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlLarge, eax)


		invoke LoadImage, g_hInstance, IDI_FOLDER, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlLarge, eax)

		invoke LoadImage, g_hInstance, IDI_FOLDEROPEN, IMAGE_ICON, _cx, _cy, LR_DEFAULTCOLOR
		invoke ImageList_AddIcon( g_himlLarge, eax)

	.endif
	ret

CreateImageLists ENDP


DestroyImageLists PROC public

	.if (g_himlSmall)
		invoke ImageList_Destroy, g_himlSmall
	.endif

	.if (g_himlLarge)
		invoke ImageList_Destroy, g_himlLarge
	.endif
	ret

DestroyImageLists ENDP



WideCharToLocal PROC public pLocal:LPSTR, pWide:LPWSTR, dwChars:DWORD

	mov	eax, pLocal
	mov	BYTE PTR [eax], 0

ifdef UNICODE
	invoke lstrcpyn, pLocal, pWide, dwChars
else
	invoke WideCharToMultiByte, CP_ACP, 0, pWide, -1, pLocal, dwChars, NULL, NULL
endif

	invoke lstrlen, pLocal

	ret
WideCharToLocal ENDP



LocalToWideChar PROC public pWide:LPWSTR, pLocal:LPSTR,  dwChars:DWORD

	mov	eax, pWide
	mov	WORD PTR [eax], 0

ifdef UNICODE
	invoke lstrcpyn, pWide, pLocal, dwChars
else
	invoke MultiByteToWideChar, CP_ACP, 0, pLocal, -1, pWide, dwChars
endif

	invoke lstrlenW, pWide

	ret
LocalToWideChar ENDP

;***

GetNextRegElement PROC public uses esi pszNext:LPSTR, pszOut:LPSTR,  dwOut:DWORD

	mov esi,pszNext
	.if (!esi || !byte ptr [esi])
		return NULL
	.endif

	.repeat				;search next backslash
		lodsb
	.until ((al == 0) || (al == '\'))

	mov	eax, esi
	sub	eax, pszNext
	.if (eax > dwOut)
		mov eax,dwOut
	.endif

	invoke lstrcpyn, pszOut, pszNext, eax

	.if (byte ptr [esi])
		inc esi
	.endif

	return esi

GetNextRegElement ENDP


AddBackslash PROC public lpszString:LPSTR 

	mov	eax, lpszString
	mov	cl, [eax]
	.if (cl)
		invoke	lstrlen,eax
		mov	ecx,lpszString
		mov	dl, [ecx+eax-1]
		.if (dl != '\')
			mov word ptr [ecx+eax],'\'
			return TRUE
		.endif
	.endif
	return FALSE

AddBackslash ENDP

	END

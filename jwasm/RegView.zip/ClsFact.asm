
;--- implements CClassFactory, based on IClassFactory

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

	include RegView.inc

CClassFactory struct
vtbl		dd ?
ObjRefCount dd ?
CClassFactory ends

	.const

CClassFactoryVtbl IClassFactoryVtbl {QueryInterface,\
	AddRef,Release,CreateInstance,LockServer}

	.code

Create@CClassFactory PROC public		; constructor ClassFactory

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CClassFactory
	.if (eax == NULL)
		ret
	.endif
				
	mov	[eax].CClassFactory.vtbl,OFFSET CClassFactoryVtbl

	inc g_DllRefCount

	mov	[eax].CClassFactory.ObjRefCount, 1

	ret
Create@CClassFactory ENDP


Destroy@CClassFactory PROC pThis:ptr CClassFactory

	invoke LocalFree,pThis

	dec g_DllRefCount

	ret
Destroy@CClassFactory ENDP		

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IClassFactory,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface PROC pThis:ptr CClassFactory,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP


AddRef PROC pThis:ptr CClassFactory

	mov	eax, pThis
	inc	[eax].CClassFactory.ObjRefCount
	mov	eax, [eax].CClassFactory.ObjRefCount
	ret

AddRef ENDP


Release PROC pThis:ptr CClassFactory

	mov	eax, pThis
	dec	[eax].CClassFactory.ObjRefCount

	mov eax,[eax].CClassFactory.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CClassFactory,pThis
		xor eax,eax
	.endif
	ret

Release ENDP


CreateInstance PROC pThis:ptr CClassFactory, pUnknown:ptr,riid:ptr IID,ppObject:ptr ptr

local	pShellFolder:ptr
local	hResult:dword

	mov	eax, ppObject
	mov	DWORD PTR [eax], 0

	.if (pUnknown != NULL)
		return CLASS_E_NOAGGREGATION
	.endif

	invoke Create@CShellFolder, NULL, NULL, addr pShellFolder
	.if (eax != S_OK)
		ret
	.endif


	invoke vf(pShellFolder,IShellFolder,QueryInterface),riid,ppObject
	mov	hResult, eax

	invoke vf(pShellFolder,IShellFolder,Release)

	return hResult

CreateInstance ENDP


LockServer PROC pThis:ptr CClassFactory

	return E_NOTIMPL

LockServer ENDP

END

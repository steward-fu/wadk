
;--- implements CQueryInfo, based on IQueryInfo

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CQUERYINFO equ 1
	include RegView.inc

CQueryInfo struct
_IQueryInfo	IQueryInfo <>
ObjRefCount	DWORD ?
pidl		LPITEMIDLIST ?
pMalloc		LPMALLOC ?
pPidlMgr	LPPIDLMGR ?
CQueryInfo ends

Destroy@CQueryInfo PROTO pThis:ptr CQueryInfo

	.const

CQueryInfoVtbl	IExtractIconVtbl { QueryInterface, AddRef, Release,\
	GetInfoTip,	GetInfoFlags}

	.code

__this	textequ <ebx>
_this	textequ <[__this].CQueryInfo>

	MEMBER _IQueryInfo, ObjRefCount, pidl, pMalloc, pPidlMgr

Create@CQueryInfo PROC public uses __this pidl:LPITEMIDLIST

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CQueryInfo
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m__IQueryInfo.lpVtbl, OFFSET CQueryInfoVtbl

	inc g_DllRefCount

	invoke Create@CPidlMgr
	mov	m_pPidlMgr,eax

	.if (!eax)
		invoke Destroy@CQueryInfo, __this
		return 0
	.endif

;--------- get the shell's IMalloc pointer
;--------- we'll keep this until we get destroyed

	invoke	SHGetMalloc,addr m_pMalloc
	.if (FAILED(eax))
		invoke Destroy@CQueryInfo, __this
		return 0
	.endif

	invoke Copy_Pidl, pidl
	mov m_pidl,eax

	mov m_ObjRefCount, 1

	return __this

Create@CQueryInfo ENDP		; CQueryInfo::CQueryInfo



Destroy@CQueryInfo PROC uses __this pThis:ptr CQueryInfo

	mov __this,pThis

	.if (m_pidl)
		invoke Delete_Pidl, m_pidl
		mov m_pidl,0
	.endif

	.if (m_pMalloc)
		invoke vf( m_pMalloc, IMalloc, Release)
	.endif

	.if (m_pPidlMgr)
		invoke Destroy@CPidlMgr
	.endif

	invoke LocalFree, __this

	dec g_DllRefCount

	ret

Destroy@CQueryInfo ENDP

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IQueryInfo,0
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)


QueryInterface PROC pThis:ptr CExtractIcon,riid:ptr IID,ppReturn:ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP


AddRef PROC pThis:ptr CQueryInfo

	mov eax,pThis
	inc [eax].CQueryInfo.ObjRefCount
	mov	eax, [eax].CQueryInfo.ObjRefCount
	ret

AddRef ENDP			; CQueryInfo::AddRef



Release PROC pThis:ptr CQueryInfo

	mov eax,pThis
	dec [eax].CQueryInfo.ObjRefCount
	mov eax,[eax].CQueryInfo.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CQueryInfo, pThis
		xor eax,eax
	.endif
	ret

Release ENDP			; CQueryInfo::Release



GetInfoTip PROC uses __this pThis:ptr CQueryInfo, dwFlags:dword,ppwszTip: ptr ptr WORD

local szTipText[MAX_PATH]:byte
local cchOleStr:dword

	mov __this, pThis
	mov	eax, ppwszTip
	mov	DWORD PTR [eax], 0

;---------- get the entire text for the item
	invoke	GetPidlPath@CPidlMgr, m_pidl, addr szTipText, sizeof szTipText

;---------- get the number of characters required
	invoke	lstrlen,addr szTipText
	inc	eax
	mov	cchOleStr, eax

;---------- allocate the wide character string
	mov eax,cchOleStr
	shl eax,1
	invoke vf( m_pMalloc, IMalloc, Alloc),eax
	mov	ecx, ppwszTip
	mov [ecx], eax

	.if (!eax)
		return E_OUTOFMEMORY
	.endif

	mov ecx,eax
	invoke LocalToWideChar, ecx, addr szTipText, cchOleStr

	return S_OK

GetInfoTip ENDP		; CQueryInfo::GetInfoTip



GetInfoFlags PROC pThis:ptr CQueryInfo, pdwFlags:ptr DWORD

	return E_NOTIMPL

GetInfoFlags ENDP		; CQueryInfo::GetInfoFlags


	END

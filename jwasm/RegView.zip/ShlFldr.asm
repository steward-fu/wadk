
;--- implements CShellFolder, based on IShellFolder interface

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include unknwn.inc
	include objidl.inc
	include shlobj.inc
	.list
	.cref

INSIDE_CSHELLFOLDER equ 1
	include RegView.inc

RETWSTR	equ 1			;0 doesnt work

LPQUERYINFO typedef ptr IQueryInfo

CShellFolder struct
vtblIShellFolder	dd ?
vtblIPersistFolder	dd ?
ObjRefCount			dd ?
pidl				LPITEMIDLIST ?
pidlNSRoot			LPITEMIDLIST ?
hKeyRoot			HANDLE ?
lpszSubKey			LPSTR ?
pSFParent			LPSHELLFOLDER ?
pMalloc				LPMALLOC ?
pPidlMgr			LPPIDLMGR ?
CShellFolder ends

PUBLIC	g_ahKey			; g_ahKey

	.data

g_ahKey HANDLE	HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE,\
				HKEY_USERS, HKEY_PERFORMANCE_DATA, HKEY_CURRENT_CONFIG, HKEY_DYN_DATA, -1
      

	.const

CShellFolder@IShellFolder@Vtbl IShellFolderVtbl { QueryInterface,AddRef,Release,\
	ParseDisplayName,EnumObjects_,BindToObject,\
	BindToStorage,CompareIDs,CreateViewObject,GetAttributesOf,\
	GetUIObjectOf,GetDisplayNameOf,SetNameOf }

CShellFolder@IPersistFolder@Vtbl IPersistFolderVtbl {QueryInterface_,AddRef_,Release_,\
	GetClassID_, Initialize_ }

;*** "private" member functions 

Destroy@CShellFolder	proto :ptr CShellFolder	;destructor
GetRootKey				proto :ptr CShellFolder 

	.code

__this	textequ <ebx>
_this	textequ <[__this].CShellFolder>

	MEMBER vtblIShellFolder, vtblIPersistFolder, ObjRefCount, pidl
	MEMBER pidlNSRoot, hKeyRoot, lpszSubKey, pSFParent, pMalloc
	MEMBER pPidlMgr

;*** constructor CShellFolder

Create@CShellFolder PROC public uses __this pParent:ptr CShellFolder,pidl:LPITEMIDLIST, ppShellFolder:ptr LPSHELLFOLDER

local	bIsRoot:BOOL
local	dwSize:dword

	DebugOut "Create@CShellFolder"

	mov eax, ppShellFolder
	mov dword ptr [eax], NULL

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CShellFolder
	.if (eax == NULL)
		return E_OUTOFMEMORY
	.endif
	mov __this,eax

	mov	m_vtblIShellFolder,OFFSET CShellFolder@IShellFolder@Vtbl
	mov	m_vtblIPersistFolder,OFFSET CShellFolder@IPersistFolder@Vtbl

	inc	g_DllRefCount

	mov	m_hKeyRoot,NULL
	mov	m_lpszSubKey,NULL
	mov eax,pParent
	mov	m_pSFParent,eax

	.if (eax)
		invoke vf(pParent, IShellFolder, AddRef)
	.endif

	invoke Create@CPidlMgr
	mov m_pPidlMgr,eax
	.if (eax == NULL)
		invoke Destroy@CShellFolder, __this
		return E_OUTOFMEMORY
	.endif

;----------------- get the shell's IMalloc pointer
;----------------- we'll keep this until we get destroyed
	invoke SHGetMalloc, addr m_pMalloc
	.if (FAILED(eax))
		invoke Destroy@CShellFolder, __this
		return E_OUTOFMEMORY
	.endif

	invoke Copy_Pidl, pidl
	mov m_pidl, eax

	mov m_pidlNSRoot, NULL

	.if (m_pidl)

		invoke	IsRootKey_Pidl, m_pidl
		mov bIsRoot, eax
		.if (eax)
			invoke	GetRootKey@CPidlMgr, m_pidl, addr m_hKeyRoot
		.endif

		mov	dwSize, 0

		mov eax, m_pSFParent
		.if (eax && [eax].CShellFolder.lpszSubKey)
			invoke	lstrlen,[eax].CShellFolder.lpszSubKey
			inc eax
			add dwSize,eax
		.endif

		invoke	GetSubKeyText@CPidlMgr, m_pidl, NULL, 0
		add dwSize,eax

		invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, dwSize
		mov m_lpszSubKey,eax

		.if (eax)
			mov byte ptr [eax],0
			mov ecx, m_pSFParent
			.if ([ecx].CShellFolder.lpszSubKey)
				invoke	lstrcpy, m_lpszSubKey,[ecx].CShellFolder.lpszSubKey
				invoke	AddBackslash, m_lpszSubKey
			.endif

			invoke	lstrlen, m_lpszSubKey
			mov ecx,dwSize
			sub ecx,eax
			mov edx, m_lpszSubKey
			add edx,eax
			invoke	GetSubKeyText@CPidlMgr, m_pidl,edx,ecx
;-------------------------------- new: 17.2.2003
			.if ((!eax) && (!bIsRoot))
				invoke Destroy@CShellFolder, __this
				return E_NOINTERFACE
			.endif
			DebugOut "Create@CShellFolder, lpszSubKey=%s", m_lpszSubKey
;-------------------------------- end new
		.endif
	.endif

	mov m_ObjRefCount,1
	mov eax, ppShellFolder
	mov [eax], __this

	DebugOut "Create@CShellFolder exit"

	return S_OK

Create@CShellFolder ENDP

;*** destructor CShellFolder

Destroy@CShellFolder PROC uses __this pThis:ptr CShellFolder

	mov __this,pThis

	DebugOut "Destroy@CShellFolder"

	.if (m_pidl)
		invoke	Delete_Pidl, m_pidl
		mov m_pidl,NULL
	.endif

	.if (m_pidlNSRoot)
		invoke	Delete_Pidl, m_pidlNSRoot
		mov m_pidlNSRoot,NULL
	.endif

	.if (m_lpszSubKey)
		invoke LocalFree, m_lpszSubKey
	.endif

	.if (m_pSFParent)
		invoke vf(m_pSFParent, IShellFolder, Release)
	.endif

	.if (m_pMalloc)
		invoke vf(m_pMalloc,IMalloc,Release)
	.endif

	.if(m_pPidlMgr)
		invoke Destroy@CPidlMgr
	.endif

	invoke LocalFree, __this

	dec	g_DllRefCount

	DebugOut "Destroy@CShellFolder exit, DllRefCount=%u", g_DllRefCount

	ret

Destroy@CShellFolder ENDP

;*** table of supported interfaces

supInterfaces label dword
	dd offset IID_IUnknown,0
	dd offset IID_IShellFolder,0
	dd offset IID_IPersistFolder,offset CShellFolder.vtblIPersistFolder
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

;*** IUnknown::QueryInterface

QueryInterface PROC pThis:ptr CShellFolder,riid:ptr IID,ppReturn:ptr ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP

;*** IUnknown::AddRef

AddRef PROC pThis:ptr CShellFolder

	mov eax,pThis
	inc [eax].CShellFolder.ObjRefCount
	mov	eax, [eax].CShellFolder.ObjRefCount
	ret
AddRef ENDP

;*** IUnknown::Release

Release PROC pThis:ptr CShellFolder

	mov eax,pThis
	dec [eax].CShellFolder.ObjRefCount
	mov eax,[eax].CShellFolder.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CShellFolder,pThis
		xor eax,eax
	.endif
	ret
Release ENDP

;*** IPersist:GetClassID

GetClassID PROC uses esi edi pThis:ptr CShellFolder, lpClassID:ptr CLSID

	mov	edi, lpClassID
	mov esi, offset CLSID_RegView
	movsd
	movsd
	movsd
	movsd
	return S_OK

GetClassID ENDP


;*** IPersistFolder:Initialize

Initialize PROC uses __this pThis:ptr CShellFolder, pidl: ptr LPITEMIDLIST

	DebugOut "Initialize"

	mov	__this,pThis

	.if (m_pidlNSRoot)
		invoke	Delete_Pidl, m_pidlNSRoot
		mov		m_pidlNSRoot, NULL
	.endif
	invoke	Copy_Pidl, pidl
	mov		m_pidlNSRoot,eax

	return S_OK

Initialize ENDP

;*** IShellFolder::BindToObject

BindToObject PROC uses __this pThis:ptr CShellFolder, pidl: LPITEMIDLIST, res:dword,riid:ptr IID, ppvOut:ptr LPSHELLFOLDER

local	pShellFolder:LPSHELLFOLDER
local	hr:dword

ifdef _DEBUG
	mov eax, pidl
	mov ecx, 0
	.while ([eax].SHITEMID.cb)
		movzx edx,[eax].SHITEMID.cb
		add eax, edx
		inc ecx
	.endw
	DebugOut "BindToObject pidls=%u", ecx
endif

	mov __this,pThis

	mov eax,ppvOut
	mov	DWORD PTR [eax], NULL

	invoke Create@CShellFolder, pThis, pidl, addr pShellFolder
	.if (eax != S_OK)
		ret
	.endif
	
	invoke Initialize, pShellFolder, m_pidlNSRoot

	invoke QueryInterface, pShellFolder, riid, ppvOut
	mov	hr, eax

	invoke Release, pShellFolder

	return hr

BindToObject ENDP

;*** IShellFolder::BindToStorage

BindToStorage PROC pThis:ptr CShellFolder, pidl: ptr LPITEMIDLIST,res:dword,riid:ptr IID,ppvOut:ptr

	DebugOut "BindToStorage"

	mov eax,ppvOut
	mov	DWORD PTR [eax], 0

	return E_NOTIMPL

BindToStorage ENDP

;*** IShellFolder::CompareIDs

CompareIDs PROC uses __this pThis:ptr CShellFolder,lParam:LPARAM, pidl1: ptr LPITEMIDLIST, pidl2: ptr LPITEMIDLIST

local	pidlTemp1:LPITEMIDLIST
local	pidlTemp2:LPITEMIDLIST
local	hkey1:HANDLE
local	hkey2:HANDLE
local	szString1[MAX_PATH]:byte
local	szString2[MAX_PATH]:byte

;	DebugOut "CompareIDs: pidl1=%X, pidl2=%X",pidl1,pidl2

	mov __this,pThis

;----------------------------- get the last item in each list
	invoke GetLastItem_Pidl, pidl1
	mov pidlTemp1,eax
	invoke GetLastItem_Pidl, pidl2
	mov pidlTemp2,eax

;-------------- now both pidlTemp1 and pidlTemp2 point to the last item in the list

	invoke	IsValue_Pidl, pidlTemp1
	push	eax

	invoke	IsValue_Pidl, pidlTemp2
	pop		ecx

	.if (eax != ecx)
		.if (ecx)		;is first pidl a value?
			mov eax,1
		.else
			mov eax,-1
		.endif
		ret
	.endif

;---------------------------- get the numeric value of the root key

	mov	hkey1, 0
	mov	hkey2, 0
	invoke	GetRootKey@CPidlMgr, pidl1, addr hkey1
	invoke	GetRootKey@CPidlMgr, pidl2, addr hkey2

;---------------------------- compare the root keys

	mov ecx,hkey1
	.if (ecx != hkey2)
		mov	eax, hkey1
		sub	eax, hkey2
		ret
	.endif

;---------------------------- now compare the subkey strings

	xor eax,eax
	mov szString1,al
	mov szString2,al

	invoke	GetSubKeyText@CPidlMgr, pidl1, addr szString1, sizeof szString1
	invoke	GetSubKeyText@CPidlMgr, pidl2, addr szString2, sizeof szString2

	invoke	lstrcmpi,addr szString1,addr szString2

	.if (eax)
		ret
	.endif

;---------------------------- now compare the value strings

	invoke	GetValueText@CPidlMgr, pidl1, addr szString1, sizeof szString1
	invoke	GetValueText@CPidlMgr, pidl2, addr szString2, sizeof szString2

	invoke	lstrcmpi,addr szString1, addr szString2

	ret

CompareIDs ENDP

;*** IShellFolder::CreateViewObjects

CreateViewObject PROC uses __this pThis:ptr CShellFolder,hwndOwner:HWND,riid:ptr IID,ppvOut:ptr

local hr:dword
local pShellView:LPSHELLVIEW

	DebugOut "CreateViewObject"

	mov __this,pThis

	mov eax,ppvOut
	mov	DWORD PTR [eax], 0

	invoke Create@CShellView, __this, m_pidl
	mov	pShellView, eax

	.if(!eax)
		return E_OUTOFMEMORY
	.endif

	invoke vf(pShellView,IShellView,QueryInterface), riid, ppvOut
	mov	hr, eax

	invoke vf(pShellView,IShellView,Release)

	DebugOut "CreateViewObject exit"

	return hr

CreateViewObject ENDP

;*** IShellFolder::EnumObjects

EnumObjects_ PROC uses __this pThis:ptr CShellFolder,hwndOwner:HWND,dwFlags:dword,ppEnumIDList:ptr LPENUMIDLIST

local	hr:dword

	DebugOut "EnumObjects start"

	mov __this,pThis

	mov	eax, ppEnumIDList
	mov	DWORD PTR [eax], 0

	invoke	GetRootKey, __this
	mov		ecx,eax
	invoke	Create@CEnumIDList, ecx, m_lpszSubKey, dwFlags, addr hr
	mov	ecx, ppEnumIDList
	mov	[ecx], eax

	.if (!eax)
		return hr
	.endif

	return S_OK

EnumObjects_ ENDP

;*** IShellFolder::GetAttributesOf

GetAttributesOf PROC uses __this esi pThis:ptr CShellFolder,uCount:dword,aPidls:LPITEMIDLIST,pdwAttribs:ptr dword

local	pidl:LPITEMIDLIST
local	dwAttribs:dword

	DebugOut "GetAttributesOf"

	mov __this,pThis

	.if (uCount == 0)
		mov	eax, pdwAttribs
		and	dword ptr [eax], SFGAO_FOLDER or SFGAO_HASSUBFOLDER
	.endif

	mov esi,0
	.while (esi < uCount)

;----------------- flags common to all items

		mov	dwAttribs, 0

;----------------- is this item a key?

		mov	ecx, aPidls
		invoke	GetLastItem_Pidl, [ecx+esi*4]
		mov pidl, eax
		invoke	IsValue_Pidl, eax
		.if (eax == 0)
			invoke IsRootKey_Pidl, pidl
			.if (eax)
				or	dwAttribs, SFGAO_FOLDER
			.else
				or	dwAttribs, SFGAO_FOLDER or SFGAO_CANRENAME
			.endif

			invoke	GetRootKey, __this
			mov	ecx, aPidls
			invoke	HasSubKeys@CPidlMgr, eax, m_lpszSubKey,[ecx+esi*4]
			.if (eax)
				or dwAttribs,SFGAO_HASSUBFOLDER
			.endif
		.endif

		mov	ecx, pdwAttribs
		mov	edx, [ecx]
		and	edx, dwAttribs
		mov	[ecx], edx

		inc esi
	.endw

	return S_OK

GetAttributesOf ENDP

;*** IShellFolder::GetUIObjectOf

GetUIObjectOf PROC uses __this pThis:ptr CShellFolder,hwndOwner:HWND,uCount:dword,pPidl:ptr LPITEMIDLIST,riid:ptr IID,puReserved:ptr dword,ppvReturn:ptr dword

local	pcm:LPCONTEXTMENU
local	pExtractIcon:LPEXTRACTICON
local	pidl:LPITEMIDLIST
if _WIN32_IE ge 0400h
local	pQueryInfo:LPQUERYINFO
endif


	mov __this,pThis

	mov	eax, ppvReturn
	mov	DWORD PTR [eax], 0

	invoke	IsEqualGUID,riid, addr IID_IContextMenu
	.if (eax)
		DebugOut "GetUIObjectOf(IContextMenu)"

		invoke Create@CContextMenu,pThis,pPidl,uCount
		mov	pcm, eax
		.if (eax)
			mov	ecx, ppvReturn
			mov	[ecx], eax
			return S_OK
		.endif
	.endif

	.if	(uCount != 1)
		DebugOut "GetUIObjectOf failed"
		return E_FAIL
	.endif

	invoke	IsEqualGUID,riid,addr IID_IExtractIcon
	.if (eax)
;;		DebugOut "GetUIObjectOf(IExtractIcon)"
		mov ecx,pPidl
		invoke	Concatenate_Pidl, m_pidl,[ecx]
		mov	pidl, eax
		invoke	Create@CExtractIcon,pidl
		mov	pExtractIcon, eax
	
;---------------- The temp PIDL can be deleted because the new CExtractIcon either failed or 
;---------------- made its own copy of it.
		invoke	Delete_Pidl, pidl
		.if (pExtractIcon)
			mov	edx, ppvReturn
			mov	eax, pExtractIcon
			mov	[edx], eax
			return S_OK
		.else
			return E_OUTOFMEMORY
		.endif
	.endif

if _WIN32_IE ge 0400h

	invoke	IsEqualGUID,riid,addr IID_IQueryInfo
	.if (eax)
		DebugOut "GetUIObjectOf(IQueryInfo)"
		mov	ecx,pPidl
		invoke	Concatenate_Pidl, m_pidl,[ecx]
		mov	pidl, eax
		invoke	Create@CQueryInfo,pidl
		mov	pQueryInfo, eax

;----------------- The temp PIDL can be deleted because the new CQueryInfo either failed or 
;----------------- made its own copy of it.
		invoke	Delete_Pidl, pidl

		.if (pQueryInfo)
			mov	eax, ppvReturn
			mov	ecx, pQueryInfo
			mov	[eax], ecx
			return S_OK
		.else
			return E_OUTOFMEMORY
		.endif

	.endif

endif   ;if (_WIN32_IE GE 0400h)

	DebugOut "GetUIObjectOf failed"

	return E_NOINTERFACE

GetUIObjectOf ENDP

;*** IShellFolder::GetDisplayNameOf

GetDisplayNameOf PROC uses __this pThis:ptr CShellFolder, pidl:LPITEMIDLIST,dwFlags:dword,lpName:ptr STRRET

local szText[MAX_PATH]:byte
local cchOleStr:dword
local pidlTemp:LPITEMIDLIST

;;	DebugOut "GetDisplayNameOf(%X)", pidl

	mov __this,pThis
	
	mov	eax, dwFlags
	and	eax, 0FFh
	.if (eax == SHGDN_NORMAL)
;------------------------- get the full name

		invoke	GetPidlPath@CPidlMgr, pidl,addr szText,sizeof szText

;------------------------ If the text is NULL and this is a value, get the default item name.
		mov		al,szText
		.if (!al)
			invoke	GetLastItem_Pidl, pidl
			invoke	IsValue_Pidl, eax
			.if (eax)
				invoke	LoadString,g_hInstance,IDS_DEFAULT,addr szText,sizeof szText
			.endif
		.endif
	.elseif (eax == SHGDN_INFOLDER)
		invoke	GetLastItem_Pidl, pidl
		mov	pidlTemp, eax

;----------------------- get the relative name
		invoke	GetItemText@CPidlMgr, pidlTemp,addr szText,sizeof szText

;----------------------- If the text is NULL and this is a value, get the default item name.
		mov		al,szText
		.if (!al)
			invoke	IsValue_Pidl, pidlTemp
			.if (eax)
				invoke	LoadString,g_hInstance,IDS_DEFAULT,addr szText,sizeof szText
			.endif
		.endif
	.else
		return E_INVALIDARG
	.endif

;------------------ get the number of characters required
if RETWSTR
	invoke	lstrlen,addr szText
	inc eax
	mov	cchOleStr, eax

;------------------ allocate the wide character string
	mov	eax, cchOleStr
	shl	eax, 1
	invoke	vf(m_pMalloc,IMalloc,Alloc),eax
	mov	ecx, lpName
	mov	[ecx].STRRET.pOleStr,eax
	.if (!eax)
		return E_OUTOFMEMORY
	.endif

	mov	ecx, lpName
	mov	[ecx].STRRET.uType, STRRET_WSTR
	invoke	LocalToWideChar,[ecx].STRRET.pOleStr,addr szText,cchOleStr
else
	mov ecx,lpName
	mov [ecx].STRRET.uType, STRRET_CSTR
	invoke lstrcpy,addr [ecx].STRRET.cStr, addr szText
endif
	return S_OK

GetDisplayNameOf ENDP

;*** IShellFolder::ParseDisplayName

ParseDisplayName PROC uses __this esi pThis:ptr CShellFolder,hwndOwner:HWND,pbcReserved:dword,lpDisplayName:ptr WORD,pdwEaten:ptr dword,pPidlNew:ptr LPITEMIDLIST,pdwAttributes:ptr DWORD

local	hr:dword
local	pidlFull:LPITEMIDLIST
local	dwChars:dword
local	pszTemp:LPSTR
local	pszNext:LPSTR
local	szElement[MAX_PATH]:byte
local	fValue:dword
local	szKeyText[MAX_PATH]:byte
local	pidlTemp:LPITEMIDLIST
local	pidlOld:LPITEMIDLIST
local	hKey:HANDLE

	DebugOut "ParseDisplayName"

	mov __this,pThis

	mov	hr,E_OUTOFMEMORY
	mov	pidlFull, NULL

	invoke	lstrlenW,lpDisplayName
	inc	eax
	mov	dwChars, eax
	invoke	LocalAlloc,LPTR,dwChars
	mov	pszTemp, eax

	.if (pszTemp)

		mov	hr, E_FAIL

		invoke	WideCharToLocal,pszTemp,lpDisplayName,dwChars
		mov	edx, pszTemp
		mov	al,[edx]
		.if (al)

;------------------ get the root key

			invoke	GetNextRegElement,pszTemp,addr szElement, sizeof szElement
			mov	pszNext, eax


			mov	esi, 0
			.while (1)

				.break .if	(DWORD PTR g_ahKey[esi*4] == -1)
				.break .if	(pidlFull != 0)

				mov	ecx, g_ahKey[esi*4]
				invoke	GetRootKeyText, ecx, addr szKeyText, sizeof szKeyText

				invoke	lstrcmpi,addr szElement,addr szKeyText
				.if (eax == 0)
					mov	ecx, g_ahKey[esi*4]
					invoke	CreateRootKey@CPidlMgr, ecx
					mov	pidlFull, eax
				.endif
				inc esi
			.endw

			.if	(pidlFull)

				mov	pidlTemp, 0
				mov	pidlOld, 0

				mov	ecx, g_ahKey[esi*4]
				invoke	RegOpenKeyEx,ecx,pszNext,0,KEY_READ,addr hKey
				.if (eax == NOERROR)
					mov	fValue, FALSE
					invoke	RegCloseKey,hKey
				.else
					mov	fValue, TRUE
				.endif

;--------------------- get the remaining keys

				.while (1)
					invoke	GetNextRegElement,pszNext,addr szElement, sizeof szElement
					mov	pszNext, eax
					.break .if (eax == 0)

;---------------------- if this is the last element, check to see if it is a value or a key

					mov	al, [eax]
					.if (al == 0 && fValue)
						invoke	CreateValue@CPidlMgr, addr szElement
						mov	pidlTemp, eax
					.else
						invoke	CreateSubKey@CPidlMgr, addr szElement
						mov	pidlTemp, eax
					.endif

					mov	edx, pidlFull
					mov	pidlOld, edx

					invoke	Concatenate_Pidl, pidlFull,pidlTemp
					mov	pidlFull, eax
					invoke	Delete_Pidl, pidlOld
				.endw
				mov	hr, S_OK
			.endif
		.endif

		invoke	LocalFree,pszTemp

	.endif

	mov	eax, pPidlNew
	mov	ecx, pidlFull
	mov	[eax], ecx

	return hr

ParseDisplayName ENDP

;*** IShellFolder::SetNameOf

SetNameOf PROC pThis:ptr CShellFolder, hwndOwner:HWND, pidl:LPITEMIDLIST, lpName:ptr, _dw:dword, pPidlOut:ptr LPITEMIDLIST

	return E_NOTIMPL

SetNameOf ENDP

;*** public function called by CShellView

GetFolderPath@CShellFolder PROC public uses __this pThis:ptr CShellFolder, lpszOut:LPSTR, dwOutSize:dword

local	szTemp[MAX_PATH]:byte
local	dwSize:dword

	DebugOut "GetFolderPath"

	mov __this,pThis

	mov	BYTE PTR szTemp, 0

	.if (!lpszOut)
		xor eax,eax
		ret
	.endif

	mov	ecx, lpszOut
	mov	BYTE PTR [ecx], 0

;-------------------- get the text for the root key

	invoke	GetRootKeyText, m_hKeyRoot, addr szTemp, sizeof szTemp

	invoke	lstrlen,addr szTemp
	mov	dwSize, eax

	.if (m_lpszSubKey)

		invoke	lstrlen, m_lpszSubKey

		mov	ecx, dwSize
		lea	edx, [ecx+eax+1]
		mov	dwSize, edx
	.endif

;-------------- is the output buffer big enough?

	mov	eax, dwSize
	.if (eax > dwOutSize)
		mov eax,FALSE
		ret
	.endif

;--------------- add the text we already have

	invoke	lstrcpy,lpszOut,addr szTemp

;--------------- add this folder's text if present

	mov eax, m_lpszSubKey
	.if (eax)
		mov al,[eax]
		 .if (al)
			invoke	lstrcat,lpszOut,CStr("\")
			invoke	lstrcat,lpszOut, m_lpszSubKey
		.endif
	.endif

	mov	eax, TRUE
	ret

GetFolderPath@CShellFolder ENDP

;*** currently not used

GetFolderText PROC uses __this pThis:ptr CShellFolder, lpszOut:LPSTR, dwOutSize:dword


	DebugOut "GetFolderText"

	mov __this,pThis

	.if (!lpszOut)
		xor	eax, eax
		ret
	.endif

	mov	eax, lpszOut
	mov	BYTE PTR [eax], 0

;--------------- add this folder's text if present

	mov eax, m_lpszSubKey
	.if (eax)
		mov al,[eax]
		.if (al)
			invoke	lstrcpyn, lpszOut, m_lpszSubKey,dwOutSize
		.endif
	.endif
	mov	eax, 1
	ret

GetFolderText ENDP

;***

GetRootKey PROC uses __this pThis:ptr CShellFolder

local hkReturn:dword

	DebugOut "GetRootKey"

	mov __this,pThis

	mov	hkReturn, 0
	mov	eax, __this

	.while (eax)
		.if ([eax].CShellFolder.hKeyRoot)
			mov	ecx, [eax].CShellFolder.hKeyRoot
			mov	hkReturn, ecx
			.break
		.endif
		mov	eax, [eax].CShellFolder.pSFParent
	.endw

	mov	eax, hkReturn

	ret
GetRootKey ENDP

GetPidl@CShellFolder proc public pThis:ptr CShellFolder
	mov eax, pThis
	mov eax, [eax].CShellFolder.pidl
	ret
GetPidl@CShellFolder endp

GetPidlRoot@CShellFolder proc public pThis:ptr CShellFolder
	mov eax, pThis
	mov eax, [eax].CShellFolder.pidlNSRoot
	ret
GetPidlRoot@CShellFolder endp

;*** method instances for IPersistFolder
;*** adjust pThis (== [esp+4]) first

QueryInterface_:
	sub	DWORD PTR [esp+4], CShellFolder.vtblIPersistFolder
	jmp	QueryInterface
AddRef_:
	sub	DWORD PTR [esp+4], CShellFolder.vtblIPersistFolder
	jmp	AddRef
Release_:
	sub	DWORD PTR [esp+4], CShellFolder.vtblIPersistFolder
	jmp	Release

GetClassID_:
	sub DWORD PTR [esp+4], CShellFolder.vtblIPersistFolder
	jmp GetClassID
Initialize_:
	sub DWORD PTR [esp+4], CShellFolder.vtblIPersistFolder
	jmp Initialize


	END

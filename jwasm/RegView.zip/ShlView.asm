
;--- implements CShellView, based on IShellView

	.386
	.model flat,stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
	include windows.inc
	include macros.inc
	include windowsx.inc
	include unknwn.inc
	include objidl.inc
	include oleidl.inc
	include docobj.inc
	include shlobj.inc
	include servprov.inc
	.list
	.cref

INSIDE_CSHELLVIEW equ 1
	include RegView.inc

?OLECOMMANDTARGET	equ 1
?ACTIVATEAPP		equ 0	;1=old mode
?COMBINEMENU		equ 1
?TESTBROWSER		equ 1

LPDOCKINGWINDOW typedef ptr IDockingWindow
LPDOCKINGWINDOWFRAME typedef ptr IDockingWindowFrame

IDM_VIEW_KEYS   equ (FCIDM_SHVIEWFIRST + 0500h)
IDM_VIEW_IDW    equ (FCIDM_SHVIEWFIRST + 0501h)
IDM_MYFILEITEM  equ (FCIDM_SHVIEWFIRST + 0502h)
ID_LISTVIEW     equ 2000


CShellView struct
vtblIShellView			dd ?
if ?OLECOMMANDTARGET
vtblIOleCommandTarget	dd ?
endif
ObjRefCount			dd ?
uState				dword ?
hKeyRoot			HANDLE ?
pidl				LPITEMIDLIST ?		;
FolderSettings		FOLDERSETTINGS <>
pShellBrowser		LPSHELLBROWSER ?	;shell browser object
pShellFolder		LPSHELLFOLDER ?		;current shell folder
hwndParent			HWND ?				;HWND shell browser
hWnd				HWND ?				;handle our view class
hwndList			HWND ?				;handle listview
hMenu				HMENU ?				;composite menu
pMalloc				LPMALLOC ?			;shell's allocator
;pPidlMgr			LPPIDLMGR ?
if (_WIN32_IE ge 0400h)
pDockingWindow		LPDOCKINGWINDOW ?
endif
CShellView ends

COPYPIDL	equ 0		;0 is faster

MYTOOLINFO struct
idCommand		dword ?
iImage			dword ?
idButtonString  dword ?
idMenuString	dword ?
nStringOffset	dword ?
bState			BYTE  ?
bStyle			BYTE  ?
MYTOOLINFO ends

LPMYTOOLINFO typedef ptr MYTOOLINFO

TOOLBAR_ID   textequ <L("RegView")>

;*** these 2 functions MUST be public (called from IDockingWindow)

OnActivate		textequ <OnActivate@CShellView>
OnDeactivate	textequ <OnDeactivate@CShellView>

;*** CShellView private methods

Destroy@CShellView	proto :ptr CShellView	;destructor
WndProc				proto :HWND, :UINT, :WPARAM, :LPARAM
UpdateMenu			proto :ptr CShellView, :HMENU
BuildRegistryMenu	proto :ptr CShellView
MergeFileMenu		proto :ptr CShellView, :HMENU
MergeViewMenu		proto :ptr CShellView, :HMENU
OnCommand			proto :ptr CShellView, :DWORD, :DWORD, :HWND
OnActivate			proto :ptr CShellView, :DWORD
OnDeactivate		proto :ptr CShellView
OnSetFocus			proto
OnKillFocus			proto
OnNotify			proto :dword,:ptr NMHDR
OnSize				proto :ptr CShellView, :DWORD, :DWORD
OnCreate			proto :ptr CShellView
CreateList			proto :ptr CShellView
InitList			proto :ptr CShellView
FillList			proto :ptr CShellView
CanDoIDockingWindow	proto :ptr CShellView
AddRemoveDockingWindow	proto :ptr CShellView, :dword
OnSettingChange		proto :ptr CShellView, :LPSTR
UpdateShellSettings	proto :ptr CShellView
DoContextMenu		proto :ptr CShellView, :DWORD, :DWORD, :DWORD



	.data

PUBLIC	g_Tools
g_Tools label MYTOOLINFO
   MYTOOLINFO {IDM_VIEW_KEYS, 0, IDS_TB_VIEW_KEYS, IDS_MI_VIEW_KEYS, 0, TBSTATE_ENABLED,  TBSTYLE_BUTTON}
   MYTOOLINFO {IDM_VIEW_IDW,  0, IDS_TB_VIEW_IDW,  IDS_MI_VIEW_IDW,  0, TBSTATE_ENABLED,  TBSTYLE_BUTTON}
   MYTOOLINFO {-1, 0, 0, 0, 0}

s_szNoData		db 32 dup (0)
s_szKey			db 32 dup (0)
g_szTitle		db 64 dup (0)
g_szRegistry	db 64 dup (0)

	.const

CShellView@IShellView@Vtbl IShellViewVtbl {QueryInterface, AddRef, Release,\
	GetWindow_, ContextSensitiveHelp, TranslateAccelerator_, EnableModeless,\
	UIActivate, Refresh, CreateViewWindow, DestroyViewWindow, GetCurrentInfo, \
	AddPropertySheetPages, SaveViewState, SelectItem, GetItemObject}

if ?OLECOMMANDTARGET
CShellView@IOleCommandTarget@Vtbl IOleCommandTargetVtbl {\
	QueryInterface_, AddRef_, Release_,	QueryStatus_, Exec_}
endif

	.code

__this	textequ <ebx>
_this	textequ <[__this].CShellView>

	MEMBER vtblIShellView
if ?OLECOMMANDTARGET
	MEMBER vtblIOleCommandTarget
endif
	MEMBER ObjRefCount, uState
	MEMBER hKeyRoot, pidl, FolderSettings, pShellBrowser, hwndParent
	MEMBER hWnd, hwndList, hMenu, pShellFolder, pMalloc, pDockingWindow

Create@CShellView PROC public uses __this pFolder:LPSHELLFOLDER, pidl:LPITEMIDLIST

local	iccex:INITCOMMONCONTROLSEX

	DebugOut "Create@CShellView, DllCount=%u", g_DllRefCount

	invoke	LocalAlloc,LMEM_FIXED or LMEM_ZEROINIT,sizeof CShellView
	.if (eax == NULL)
		ret
	.endif

	mov __this,eax

	mov	m_vtblIShellView, OFFSET CShellView@IShellView@Vtbl
if ?OLECOMMANDTARGET
	mov	m_vtblIOleCommandTarget, OFFSET CShellView@IOleCommandTarget@Vtbl
endif
	inc g_DllRefCount

	mov		iccex.dwSize,sizeof INITCOMMONCONTROLSEX
	mov		iccex.dwICC, ICC_LISTVIEW_CLASSES
	invoke	InitCommonControlsEx,addr iccex

	mov m_hMenu,NULL
if (_WIN32_IE ge 0400h)
	mov m_pDockingWindow,NULL
endif

;	invoke Create@CPidlMgr
;	mov m_pPidlMgr,eax
;	.if (!eax)
;		jmp error
;	.endif

	mov	edx, pFolder
	mov	m_pShellFolder, edx

	.if (edx)
		invoke vf(m_pShellFolder, IShellFolder, AddRef)
	.endif

;----------------- get the shell's IMalloc pointer
;----------------- we'll keep this until we get destroyed

	invoke	SHGetMalloc,addr m_pMalloc
	.if (FAILED(eax))
		jmp error
	.endif

	invoke	Copy_Pidl, pidl
	mov m_pidl, eax

	mov m_uState,SVUIA_DEACTIVATE

	mov m_ObjRefCount,1

	.if (!s_szNoData)
		invoke LoadString, g_hInstance, IDS_NODATA, addr s_szNoData, sizeof s_szNoData
		invoke LoadString, g_hInstance, IDS_KEY, addr s_szKey, sizeof s_szKey
		invoke LoadString, g_hInstance, IDS_REGISTRY_TITLE, addr g_szTitle, sizeof g_szTitle
		invoke LoadString, g_hInstance, IDS_MI_REGISTRY, addr g_szRegistry, sizeof g_szRegistry
	.endif

	DebugOut "Create@CShellView exit"

	return __this
error:
	invoke Destroy@CShellView, __this
	return 0

Create@CShellView ENDP


Destroy@CShellView PROC uses __this pThis:ptr CShellView

	DebugOut "Destroy@CShellView"

	mov __this,pThis

	.if (m_pidl)
		invoke	Delete_Pidl, m_pidl
		mov m_pidl,NULL
	.endif

	.if (m_pShellFolder)
		invoke vf(m_pShellFolder, IShellFolder, Release)
	.endif

	.if (m_pMalloc)
		invoke vf(m_pMalloc, IMalloc, Release)
	.endif

;	.if (m_pPidlMgr)
;		invoke Destroy@CPidlMgr
;	.endif

	invoke LocalFree, __this

	dec g_DllRefCount

	DebugOut "Destroy@CShellView exit, DllRefCount=%u", g_DllRefCount

	ret

Destroy@CShellView ENDP

supInterfaces label dword
	dd offset IID_IUnknown, 0
	dd offset IID_IOleWindow, CShellView.vtblIShellView
	dd offset IID_IShellView, CShellView.vtblIShellView
if ?OLECOMMANDTARGET
	dd offset IID_IOleCommandTarget, CShellView.vtblIOleCommandTarget
endif
IFTABSIZE equ ($ - supInterfaces)/ (2 * sizeof dword)

QueryInterface PROC pThis:ptr CShellView,riid:ptr IID,ppReturn:ptr ptr

	invoke IsInterfaceSupported, riid, offset supInterfaces, IFTABSIZE,  pThis, ppReturn
	ret

QueryInterface ENDP



AddRef PROC pThis:ptr CShellView

	mov eax,pThis
	inc [eax].CShellView.ObjRefCount
	mov	eax, [eax].CShellView.ObjRefCount
	ret
AddRef ENDP	



Release PROC pThis:ptr CShellView

	mov eax,pThis
	dec [eax].CShellView.ObjRefCount
	mov eax,[eax].CShellView.ObjRefCount
	.if (eax == 0)
		invoke Destroy@CShellView, pThis
		xor eax,eax
	.endif
	ret

Release ENDP


GetWindow_ PROC pThis:ptr CShellView, phWnd:ptr HWND

	mov	eax, phWnd
	mov	ecx, pThis
	mov	edx, [ecx].CShellView.hWnd
	mov	[eax], edx
	return S_OK

GetWindow_ ENDP


ContextSensitiveHelp proc pThis:ptr CShellView, fEnterMode:dword

	return E_NOTIMPL

ContextSensitiveHelp ENDP

if ?OLECOMMANDTARGET

;*** IOleCommandTarget::QueryStatus

QueryStatus PROC uses __this esi pThis:ptr CShellView,pguidCmdGroup:ptr GUID,cCmds:dword,prgCmds:ptr OLECMD,pCmdText:ptr OLECMDTEXT

	DebugOut "QueryStatus"

	mov __this,pThis

	.if (!prgCmds)
		return E_POINTER
	.endif

	.if (pguidCmdGroup)
		invoke IsEqualGUID,pguidCmdGroup,addr CLSID_RegView
		.if (eax == 0)
			return OLECMDERR_E_UNKNOWNGROUP
		.endif
	.endif

	xor esi,esi
	.while (esi < cCmds)
		mov	ecx, prgCmds
		mov	[ecx+esi*sizeof OLECMD].OLECMD.cmdf, OLECMDF_SUPPORTED or OLECMDF_ENABLED
		mov eax,[ecx+esi*sizeof OLECMD].OLECMD.cmdID
		.if (eax == OLECMDID_COPY)
			mov	[ecx+esi*sizeof OLECMD].OLECMD.cmdf, OLECMDF_SUPPORTED or OLECMDF_ENABLED
		.endif
		inc esi
	.endw

	return S_OK

QueryStatus ENDP


;*** IOleCommandTarget::Exec

Exec PROC uses __this pThis:ptr CShellView, pguidCmdGroup:ptr GUID, nCmdID:dword, nCmdExecOpt:dword,pvaIn:ptr VARIANTARG,pvaOut:ptr VARIANTARG

ifdef _DEBUG
local szGUID[40]:byte
local wszGUID[40]:word

	.if (pguidCmdGroup)
		invoke StringFromGUID2, pguidCmdGroup, addr wszGUID, 40
		invoke WideCharToLocal, addr szGUID, addr wszGUID, 40
	.else
		invoke lstrcpy, addr szGUID, CStr("NULL")
	.endif
	DebugOut "Exec(%s, %X, %X)", addr szGUID, nCmdID, nCmdExecOpt
endif

	mov __this,pThis		

	.if (pguidCmdGroup)
		invoke IsEqualGUID,pguidCmdGroup,addr CLSID_RegView
		.if (eax == 0)
			return OLECMDERR_E_UNKNOWNGROUP
		.endif
	.endif

	invoke	OnCommand, __this, nCmdID, 0, NULL

	return S_OK

Exec ENDP

endif

TranslateAccelerator_ PROC uses __this pThis:ptr CShellView, pMsg:ptr MSG

	mov eax, S_FALSE
	ret

TranslateAccelerator_ ENDP



EnableModeless PROC pThis:ptr CShellView,bEnable:dword

	return E_NOTIMPL

EnableModeless ENDP

;*** called from WndProc (WM_ACTIVATE) and IShellView:UIActivate

OnActivate PROC public uses __this pThis:ptr CShellView, uState:dword

local omw:OLEMENUGROUPWIDTHS
local mii:MENUITEMINFO
local szText[MAX_PATH]:byte

	DebugOut "OnActivate(%X) enter", uState

;------------------- don't do anything if the state isn't really changing

	mov __this,pThis
	
	mov eax, m_uState
	.if (eax == uState)
		xor	eax, eax
		ret
	.endif

	invoke	OnDeactivate, __this

if ?COMBINEMENU

;------------------- only do this if we are active
	.if (uState != SVUIA_DEACTIVATE)

;------------------- merge the menus
		invoke	CreateMenu
		mov	m_hMenu,eax

		.if (eax)

			mov	omw.width_[0*sizeof DWORD], 0
			mov	omw.width_[1*sizeof DWORD], 0
			mov	omw.width_[2*sizeof DWORD], 0
			mov	omw.width_[3*sizeof DWORD], 0
			mov	omw.width_[4*sizeof DWORD], 0
			mov	omw.width_[5*sizeof DWORD], 0

			invoke vf(m_pShellBrowser, IShellBrowser, InsertMenusSB), m_hMenu, addr omw

;------------------- build the top level menu
;------------------- the menu item's text
if 0
			invoke LoadString,g_hInstance, IDS_MI_REGISTRY, addr szText, sizeof szText
else
			invoke lstrcpy, addr szText, addr g_szRegistry
endif
			invoke ZeroMemory,addr mii,sizeof MENUITEMINFO

			mov mii.cbSize, sizeof mii
			mov mii.fMask, MIIM_SUBMENU or MIIM_TYPE or MIIM_STATE
			mov mii.fType, MFT_STRING
			mov mii.fState, MFS_ENABLED
			lea eax,szText
			mov mii.dwTypeData, eax
			invoke	BuildRegistryMenu,ebx
			mov mii.hSubMenu,eax

;------------------- insert our menu into the menu bar
			.if (mii.hSubMenu)
				invoke InsertMenuItem, m_hMenu, FCIDM_MENU_HELP, FALSE, addr mii
			.endif

;------------------- get the view menu so we can merge with it
			invoke ZeroMemory, addr mii, sizeof MENUITEMINFO

			mov mii.cbSize, sizeof MENUITEMINFO
			mov mii.fMask,MIIM_SUBMENU

			invoke GetMenuItemInfo, m_hMenu, FCIDM_MENU_VIEW, FALSE, addr mii
			.if (eax)
				invoke MergeViewMenu, __this , mii.hSubMenu
			.endif

;------------------- add the items that should only be added if we have the focus
			.if (uState == SVUIA_ACTIVATE_FOCUS)

;------------------- get the file menu so we can merge with it
				invoke ZeroMemory, addr mii, sizeof MENUITEMINFO

				mov mii.cbSize, sizeof MENUITEMINFO
				mov mii.fMask, MIIM_SUBMENU

				invoke GetMenuItemInfo, m_hMenu, FCIDM_MENU_FILE, FALSE, addr mii
				.if (eax)
					invoke MergeFileMenu, __this, mii.hSubMenu
				.endif
			.endif
			
			invoke vf(m_pShellBrowser,IShellBrowser,SetMenuSB), m_hMenu, NULL, m_hWnd

			invoke vf(m_pShellBrowser,IShellBrowser,SetToolbarItems), 0, 0, FCT_MERGE

		.endif
	.endif

endif

	mov eax,uState
	mov m_uState,eax

	DebugOut "OnActivate exit"

	xor	eax, eax
	ret

OnActivate ENDP


OnDeactivate PROC public uses __this pThis:ptr CShellView

	DebugOut "OnDeactivate"

	mov __this,pThis

	.if (m_uState != SVUIA_DEACTIVATE)

if ?COMBINEMENU
		.if (m_hMenu)

			invoke vf(m_pShellBrowser, IShellBrowser, SetMenuSB), NULL, NULL, NULL
			invoke vf(m_pShellBrowser, IShellBrowser, RemoveMenusSB), m_hMenu
			invoke DestroyMenu, m_hMenu
			mov m_hMenu,NULL
		.endif
endif

		mov m_uState,SVUIA_DEACTIVATE
	.endif
	ret

OnDeactivate ENDP


UIActivate PROC uses __this pThis:ptr CShellView, uState:dword

local szName[MAX_PATH]:byte
local lResult:dword
local nPartArray:sdword

	DebugOut "UIActivate(%X)", uState

	mov __this,pThis

;---------------- don't do anything if the state isn't really changing
	mov eax, uState
	.if (m_uState == eax)
		return S_OK
	.endif

;---------------- OnActivate handles the menu merging and internal state

	invoke	OnActivate, __this, uState

;---------------- remove the docking window
	.if (g_bShowIDW)
		invoke AddRemoveDockingWindow, __this, FALSE
	.endif

;---------------- only do this if we are active
	.if (uState != SVUIA_DEACTIVATE)

;---------------- update the status bar
if 0		
		invoke LoadString, g_hInstance, IDS_REGISTRY_TITLE, addr szName, sizeof szName
else
		invoke lstrcpy, addr szName, addr g_szTitle
endif
		invoke	lstrlen, addr szName
		lea	ecx, [szName + eax]
		mov edx, sizeof szName
		sub	edx, eax
		invoke	GetFolderPath@CShellFolder, m_pShellFolder, ecx, edx

;---------------- set the number of parts
		mov	nPartArray, -1
		invoke vf(m_pShellBrowser, IShellBrowser, SendControlMsg),FCW_STATUS, SB_SETPARTS, 1,  addr nPartArray, addr lResult

;---------------- set the text for the parts
		invoke vf(m_pShellBrowser, IShellBrowser, SendControlMsg),FCW_STATUS, SB_SETTEXT, 0, addr szName, addr lResult

;---------------- add the docking window if necessary
		.if (g_bShowIDW)
			invoke AddRemoveDockingWindow, __this, TRUE
		.endif
	.endif

	DebugOut "UIActivate exit"

	return S_OK

UIActivate ENDP			; CShellView::UIActivate

if ?COMBINEMENU

BuildRegistryMenu PROC uses esi pThis:ptr CShellView

local hSubMenu:HMENU
local szText[MAX_PATH]:byte
local mii:MENUITEMINFO
local nTools:dword

	DebugOut "BuildRegistryMenu"

	invoke CreatePopupMenu
	mov	hSubMenu, eax

	.if (hSubMenu)

;---------------- get the number of items in our global array

		mov	esi, 0
		.while (1)
			mov	ecx, esi
			imul	ecx, sizeof MYTOOLINFO
			.break .if (g_Tools[ecx].idCommand  == -1)
			inc esi
		.endw
		mov nTools,esi

;---------------- add the menu items

		mov esi,0
		.while (esi < nTools)

			mov edx,esi
			imul edx,sizeof MYTOOLINFO
			invoke LoadString, g_hInstance, g_Tools[edx].idMenuString, addr szText, sizeof szText

			invoke ZeroMemory, addr mii, sizeof MENUITEMINFO

			mov mii.cbSize, sizeof MENUITEMINFO
			mov mii.fMask, MIIM_TYPE or MIIM_ID or MIIM_STATE

			mov	eax, esi
			imul	eax, sizeof MYTOOLINFO
			.if (g_Tools[eax].bStyle != TBSTYLE_SEP)

				mov mii.fType, MFT_STRING
				mov mii.fState, MFS_ENABLED
				lea eax,szText
				mov mii.dwTypeData, eax

				mov	eax, esi
				imul	eax, sizeof MYTOOLINFO
				mov ecx, g_Tools[eax].idCommand;
				mov mii.wID, ecx
			.else
				mov mii.fType, MFT_SEPARATOR
			.endif

;---------------- tack this item onto the end of the menu
			invoke InsertMenuItem, hSubMenu, -1, TRUE,  addr mii

			inc esi
		.endw
	.endif

	mov	eax, hSubMenu
	ret

BuildRegistryMenu ENDP


MergeFileMenu PROC pThis:ptr CShellView, hSubMenu:HMENU

local	mii:MENUITEMINFO
local	szText[MAX_PATH]:byte

	DebugOut "MergeFileMenu"

	.if (hSubMenu)

		invoke ZeroMemory,addr mii, sizeof mii

;----------------- add a separator at the beginning of the menu

		mov mii.cbSize, sizeof MENUITEMINFO
		mov mii.fMask, MIIM_TYPE
		mov mii.fType, MFT_SEPARATOR
		invoke	InsertMenuItem,hSubMenu, 0, TRUE, addr mii

;----------------- add the file menu items
		invoke LoadString, g_hInstance, IDS_MI_FILEITEM, addr szText, sizeof szText

		mov mii.cbSize, sizeof MENUITEMINFO
		mov mii.fMask, MIIM_TYPE or MIIM_ID or MIIM_STATE
		mov mii.fType, MFT_STRING
		mov mii.fState, MFS_ENABLED
		lea eax,szText
		mov mii.dwTypeData,eax
		mov mii.wID, IDM_MYFILEITEM
;------------------ insert this item at the beginning of the menu
		invoke InsertMenuItem, hSubMenu, 0, TRUE, addr mii

	.endif
	ret
MergeFileMenu ENDP	; CShellView::MergeFileMenu


MergeViewMenu PROC pThis:ptr CShellView, hSubMenu:HMENU

local	mii:MENUITEMINFO
local	szText[MAX_PATH]:byte

	DebugOut "MergeViewMenu"

	.if (hSubMenu)

		invoke ZeroMemory,addr mii, sizeof mii

;---------------- add a separator at the correct position in the menu
		mov mii.cbSize, sizeof MENUITEMINFO
		mov mii.fMask, MIIM_TYPE
		mov mii.fType, MFT_SEPARATOR
		invoke	InsertMenuItem, hSubMenu, FCIDM_MENU_VIEW_SEP_OPTIONS, FALSE, addr mii

;---------------- add the view menu items at the correct position in the menu

		invoke	LoadString, g_hInstance, IDS_MI_VIEW_KEYS, addr szText, sizeof szText

		mov mii.cbSize, sizeof MENUITEMINFO
		mov mii.fMask, MIIM_TYPE or MIIM_ID or MIIM_STATE
		mov mii.fType, MFT_STRING
		mov mii.fState, MFS_ENABLED
		lea eax,szText
		mov mii.dwTypeData, eax
		mov mii.wID, IDM_VIEW_KEYS
		invoke	InsertMenuItem,hSubMenu, FCIDM_MENU_VIEW_SEP_OPTIONS, FALSE, addr mii

	.endif

	ret
MergeViewMenu ENDP

endif

Refresh PROC pThis:ptr CShellView

	DebugOut "Refresh"

	invoke	FillList,pThis

	return S_OK

Refresh ENDP

if ?TESTBROWSER

SID_Notknown GUID {0D7D1D00h, 6FC0h, 11D0h, {0A9h,74h,00h,0C0h,4Fh,0D7h,05h,0A2h}}

TestBrowser proc

local pServiceProvider:LPSERVICEPROVIDER
local pNotknown:LPUNKNOWN

	invoke vf(m_pShellBrowser, IUnknown, QueryInterface), addr IID_IServiceProvider, addr pServiceProvider
	.if (eax != S_OK)
		jmp exit
	.endif
	invoke vf(pServiceProvider, IServiceProvider, QueryService), addr SID_Notknown, addr SID_Notknown, addr pNotknown
	.if (eax == S_OK)
		invoke vf(pNotknown, IUnknown, Release)
	.endif
	invoke vf(pServiceProvider, IServiceProvider, Release)
exit:
	ret
TestBrowser endp
endif

NS_CLASS_NAME db "RegViewClass", 00H


CreateViewWindow PROC uses __this pThis:ptr CShellView, pPrevView:LPSHELLVIEW, lpfs:ptr FOLDERSETTINGS, psb:LPSHELLBROWSER, prcView:ptr RECT, phWnd:ptr HWND

local	wc:WNDCLASS

	DebugOut "CreateViewWindow, DllCount=%u", g_DllRefCount

	mov	__this, pThis

	mov	eax, phWnd
;	mov	HWND PTR [eax], 0
	mov	DWORD PTR [eax], 0

;------------- if our window class has not been registered, then do so

	invoke	GetClassInfo,g_hInstance,addr NS_CLASS_NAME,addr wc
	.if (eax == 0)

		invoke ZeroMemory,addr wc, sizeof WNDCLASS

		mov	wc.style, 0; CS_HREDRAW or CS_VREDRAW
		mov wc.lpfnWndProc, WndProc
		mov wc.cbClsExtra,0
		mov wc.cbWndExtra,0
		mov eax,g_hInstance
		mov wc.hInstance,eax
		mov wc.hIcon,0

		invoke	LoadCursor,NULL,IDC_ARROW
		mov wc.hCursor,eax
		mov wc.hbrBackground,(COLOR_WINDOW + 1)
		mov wc.lpszMenuName,0
		mov wc.lpszClassName,offset NS_CLASS_NAME

		invoke	RegisterClass, addr wc
		.if (ax == 0)
			return E_FAIL
		.endif
	.endif

;---------------- set up the member variables
	mov	eax, psb
	mov m_pShellBrowser, eax

	mov	edx, lpfs
	mov	eax, [edx].FOLDERSETTINGS.ViewMode
	mov	ecx, [edx].FOLDERSETTINGS.fFlags
	mov	m_FolderSettings.ViewMode, eax
	mov	m_FolderSettings.fFlags, ecx

;---------------- get our parent window

	invoke	vf(m_pShellBrowser, IShellBrowser, GetWindow),addr m_hwndParent

	mov		edx,prcView
	mov		eax,[edx].RECT.right
	sub		eax,[edx].RECT.left
	mov		ecx,[edx].RECT.bottom
	sub		ecx,[edx].RECT.top

	invoke	CreateWindowEx, 0, addr NS_CLASS_NAME, NULL,\
					WS_CHILD or WS_VISIBLE or WS_CLIPSIBLINGS or WS_TABSTOP,\
					[edx].RECT.left,[edx].RECT.top, eax, ecx, \
					m_hwndParent, NULL, g_hInstance, __this

	mov	ecx, phWnd
	mov	[ecx], eax

	.if (eax == 0)
		return E_FAIL
	.endif

	invoke	vf(m_pShellBrowser, IShellBrowser, AddRef)

if 0
	invoke	vf(m_pShellBrowser, IShellBrowser, GetViewStateStream), STGM_READ, addr pStream
	.if (eax == S_OK)
		invoke vf(pStream, IUnknown, Release)
	.endif
endif
if ?TESTBROWSER
	invoke TestBrowser
endif		


	DebugOut "CreateViewWindow exit"

	return S_OK

CreateViewWindow ENDP


DestroyViewWindow PROC uses __this pThis:ptr CShellView

	mov	__this, pThis

;--------------- Make absolutely sure all our UI is cleaned up.

	invoke	UIActivate, __this, SVUIA_DEACTIVATE

	.if (m_hMenu)
		invoke	DestroyMenu, m_hMenu
	.endif

	invoke	DestroyWindow, m_hWnd

;---------------- release the shell browser object

	invoke	vf(m_pShellBrowser, IShellBrowser, Release)

	return S_OK

DestroyViewWindow ENDP


GetCurrentInfo PROC pThis:ptr CShellView, lpfs:ptr FOLDERSETTINGS

	DebugOut "GetCurrentInfo"

	mov	eax, pThis
	mov	ecx, [eax].CShellView.FolderSettings.ViewMode
	mov	edx, [eax].CShellView.FolderSettings.fFlags
	mov	eax, lpfs
	mov	[eax].FOLDERSETTINGS.ViewMode, ecx
	mov	[eax].FOLDERSETTINGS.fFlags, edx
	return S_OK

GetCurrentInfo ENDP ; CShellView::GetCurrentInfo




AddPropertySheetPages PROC pThis:ptr CShellView, dwReserved:DWORD , lpfn:ptr FNADDPROPSHEETPAGE, lParam:LPARAM  

	return E_NOTIMPL

AddPropertySheetPages ENDP


SaveViewState PROC uses __this pThis:ptr CShellView

	mov __this,pThis
if 0
	invoke	vf(m_pShellBrowser, IShellBrowser, GetViewStateStream), STGM_WRITE, addr pStream
	.if (eax == S_OK)
		invoke vf(pStream, IUnknown, Release)
	.endif
endif

	return S_OK

SaveViewState ENDP


SelectItem PROC pThis:ptr CShellView, pidlItem:LPITEMIDLIST , uFlags:dword

	return E_NOTIMPL

SelectItem ENDP


GetItemObject PROC pThis:ptr CShellView, uItem:dword , riid:ptr IID , ppvOut:ptr

	mov	eax, ppvOut
	mov	DWORD PTR [eax], 0

	return E_NOTIMPL

GetItemObject ENDP


WndProc PROC uses __this hWnd:HWND, uMessage:dword, wParam:WPARAM, lParam:LPARAM

if 0;def _DEBUG
	.if (uMessage == WM_NCHITTEST)
	.elseif (uMessage == WM_NOTIFY)
	.else
	DebugOut "WndProc, msg=%X",uMessage
	.endif
endif

	invoke	GetWindowLong, hWnd, GWL_USERDATA
	mov	__this, eax

	mov eax,uMessage
	.if (eax == WM_NCCREATE)

		mov	eax, lParam
		mov	__this, [eax].CREATESTRUCT.lpCreateParams

		invoke	SetWindowLong, hWnd, GWL_USERDATA, __this

		mov	edx, hWnd
		mov	m_hWnd,edx
		jmp default

	.elseif (eax == WM_CREATE)

		invoke	OnCreate, __this

	.elseif (eax == WM_SIZE)

		mov	eax, lParam
		movzx ecx,ax
		shr eax,16
		invoke	OnSize, __this, ecx, eax

if ?ACTIVATEAPP
	.elseif (eax == WM_SETFOCUS)

		invoke	OnSetFocus

	.elseif (eax == WM_KILLFOCUS)

		invoke	OnKillFocus

	.elseif (eax == WM_ACTIVATE)

		invoke	OnActivate, __this, SVUIA_ACTIVATE_FOCUS
else
	.elseif (eax == WM_SETFOCUS)
		
		.if (m_hwndList)
			invoke SetFocus, m_hwndList
		.endif
		xor eax, eax
endif
	.elseif (eax == WM_COMMAND)

		movzx ecx, GET_WM_COMMAND_ID(wParam, lParam)
		movzx eax, GET_WM_COMMAND_CMD(wParam, lParam)
		invoke	OnCommand, __this, ecx, eax, GET_WM_COMMAND_HWND(wParam, lParam)

	.elseif (eax == WM_NOTIFY)

		invoke	OnNotify, wParam, lParam

	.elseif (eax == WM_INITMENUPOPUP)

		DebugOut "WM_INITMENUPOPUP"
		invoke	UpdateMenu, __this, wParam

	.elseif (eax == WM_SETTINGCHANGE)

		invoke	OnSettingChange, __this, lParam

	.else
default:
		invoke	DefWindowProc, hWnd, uMessage, wParam, lParam
	.endif
exit:
	ret
WndProc ENDP

;*** WM_SETFOCUS handler

OnSetFocus PROC

;------ Tell the browser one of our windows has received the focus. This should always 
;------ be done before merging menus (OnActivate merges the menus) if one of our 
;------ windows has the focus.

	DebugOut "OnSetFocus"
	invoke	vf(m_pShellBrowser, IShellBrowser, OnViewWindowActive), __this

	invoke	OnActivate, __this, SVUIA_ACTIVATE_FOCUS

	xor	eax, eax
	ret

OnSetFocus ENDP

;*** WM_KILLFOCUS handler

OnKillFocus PROC

	DebugOut "OnKillFocus"
	invoke	OnActivate, __this, SVUIA_ACTIVATE_NOFOCUS
	xor	eax, eax
	ret
OnKillFocus ENDP


;*** WM_COMMAND handler


OnCommand PROC uses __this pThis:ptr CShellView, dwCmdID:DWORD , dwCmd:DWORD , hwndCmd:HWND


;;	DebugOut "OnCommand(%X)", dwCmdID

	mov	__this, pThis

	mov	eax, dwCmdID
	.if (eax == IDM_VIEW_KEYS)

		xor	byte ptr g_bViewKeys, 1
		invoke	Refresh, __this

	.elseif (eax == IDM_VIEW_IDW)

		xor byte ptr g_bShowIDW, 1
		invoke	AddRemoveDockingWindow, __this, g_bShowIDW

	.elseif (eax == IDM_MYFILEITEM)

		invoke	MessageBeep, MB_OK

	.elseif (eax == OLECMDID_REFRESH)

		invoke	Refresh, __this

	.endif

;;	DebugOut "OnCommand Exit"

	xor	eax, eax
	ret

OnCommand ENDP


;*** WM_INITMENUPOPUP handler


UpdateMenu PROC uses __this pThis:ptr CShellView, hMenu:HMENU

	DebugOut "UpdateMenu"

	mov	__this, pThis

	.if (g_bViewKeys)
		mov ecx,MF_BYCOMMAND or MF_CHECKED
	.else
		mov ecx,MF_BYCOMMAND or MF_UNCHECKED
	.endif

	invoke CheckMenuItem, hMenu, IDM_VIEW_KEYS, ecx

	invoke CanDoIDockingWindow, __this
	.if (eax)

		invoke EnableMenuItem, hMenu, IDM_VIEW_IDW, MF_BYCOMMAND or MF_ENABLED

		.if (g_bShowIDW)
			mov ecx,MF_BYCOMMAND or MF_CHECKED 
		.else
			mov ecx,MF_BYCOMMAND or MF_UNCHECKED
		.endif

		invoke CheckMenuItem, hMenu, IDM_VIEW_IDW, ecx

	.else

		invoke EnableMenuItem, hMenu, IDM_VIEW_IDW, MF_BYCOMMAND or MF_DISABLED or MF_GRAYED

		invoke CheckMenuItem, hMenu, IDM_VIEW_IDW, MF_BYCOMMAND or MF_UNCHECKED

	.endif

	DebugOut "UpdateMenu exit"

	xor	eax, eax
	ret

UpdateMenu ENDP		; CShellView::UpdateMenu


;--- WM_NOTIFY, LVN_GETDISPINFO


OnGetDispInfo proc uses esi lpdi:ptr LV_DISPINFO

local pidl:LPITEMIDLIST
local pExtractIcon:LPEXTRACTICON
local uFlags:dword
local _str:STRRET

		mov	esi, lpdi
		assume esi:ptr LV_DISPINFO

		mov eax,[esi].item.lParam
		mov	pidl, eax

;--------------------- is the sub-item information being requested?
		.if ([esi].item.iSubItem)


;--------------------- is the text being requested?
			.if ([esi].item.mask_ & LVIF_TEXT)


;--------------------- is this a value or a key?
				invoke	IsValue_Pidl, pidl
				.if (eax)

;--------------------- get the item's value text
					invoke	GetDataText2@CPidlMgr, m_pidl, pidl, [esi].item.pszText, [esi].item.cchTextMax

;--------------------- if the data text is NULL, get the no value string
					mov eax,[esi].item.pszText
					mov al,[eax]
					.if (al == 0)
						invoke lstrcpyn, [esi].item.pszText, addr s_szNoData, [esi].item.cchTextMax
					.endif
				.else
;-------------------- its a key
if 0
					invoke lstrcpyn, [esi].item.pszText, addr s_szKey, [esi].item.cchTextMax
else					
					invoke	Concatenate_Pidl, m_pidl, pidl
					push eax
					invoke	GetDataText2@CPidlMgr, eax, NULL, [esi].item.pszText, [esi].item.cchTextMax
					pop eax
					invoke Delete_Pidl, eax
endif
				.endif
			.endif
		.else			;([esi].item.iSubItem)

;-------------------- the item text is being requested

;-------------------- is the text being requested?
			.if ([esi].item.mask_ & LVIF_TEXT)

				invoke vf(m_pShellFolder, IShellFolder, GetDisplayNameOf),pidl, SHGDN_NORMAL or SHGDN_INFOLDER, addr _str
				.if (SUCCEEDED(eax))
					.if (_str.uType == STRRET_WSTR)
						invoke WideCharToLocal,[esi].item.pszText, _str.pOleStr, [esi].item.cchTextMax
;-------------------- delete the string buffer
						invoke vf(m_pMalloc,IMalloc,Free),_str.pOleStr
					.endif
				.endif
			.endif	
;-------------------- is the image being requested?
			.if ([esi].item.mask_ & LVIF_IMAGE)

				invoke vf(m_pShellFolder, IShellFolder, GetUIObjectOf), m_hWnd, 1, addr pidl, addr IID_IExtractIcon, NULL, addr pExtractIcon
				.if (SUCCEEDED(eax))
;-------------------- GetIconLoaction will give us the index into our image list
					invoke vf(pExtractIcon,IExtractIcon,GetIconLocation),GIL_FORSHELL, NULL, 0, addr [esi].item.iImage, addr uFlags
					invoke vf(pExtractIcon,IExtractIcon,Release)
				.endif
			.endif
		.endif
		ret
	assume esi:nothing

OnGetDispInfo endp


MENU_OFFSET  equ 1
MENU_MAX     equ 100


;*** WM_NOTIFY handler

OnNotify PROC uses esi CtlID:dword , lpnmh:ptr NMHDR 

	mov ecx,lpnmh
	mov edx,[ecx].NMHDR.code

	DebugOut "OnNotify, code=%d", edx

	.if (edx == NM_SETFOCUS)

		invoke	OnSetFocus			;returns 0

	.elseif (edx == NM_KILLFOCUS)

if ?ACTIVATEAPP
		invoke	OnDeactivate, __this
else
		invoke	OnKillFocus			;returns 0
endif

	.elseif (edx == NM_RCLICK)

		invoke	GetMessagePos
		movzx ecx,ax
		shr	eax,16
		invoke DoContextMenu, __this, ecx, eax, FALSE
		xor eax, eax

	.elseif (edx == HDN_ENDTRACK)

		invoke ListView_GetColumnWidth(m_hwndList, 0)
		mov	g_nColumn1, eax

		invoke ListView_GetColumnWidth(m_hwndList, 1)
		mov	g_nColumn2, eax
		xor eax, eax

	.elseif (edx == LVN_DELETEITEM)

;--------------------- delete the pidl because we made a copy of it

		invoke	Delete_Pidl, [ecx].NM_LISTVIEW.lParam
		xor eax, eax

	.elseif (edx == LVN_ITEMACTIVATE)

		invoke DoContextMenu, __this, 0, 0, TRUE
		xor eax, eax

	.elseif (edx == LVN_GETDISPINFO)

		invoke OnGetDispInfo, lpnmh

	.else

		xor eax, eax

	.endif

	ret

OnNotify ENDP


;*** WM_SIZE handler


OnSize PROC uses __this pThis:ptr CShellView, wWidth:dword, wHeight:dword


	mov	__this, pThis

;----------------- resize the ListView to fit our window
	.if (m_hwndList)

		invoke	MoveWindow, m_hwndList, 0, 0, wWidth, wHeight, TRUE

	.endif

	xor	eax, eax
	ret

OnSize ENDP


;*** WM_CREATE handler


OnCreate PROC pThis:ptr CShellView


;---------------- create the ListView
	invoke	CreateList, pThis
	.if (eax)
		invoke	InitList, pThis
		.if (eax)
			invoke	FillList, pThis
		.endif
	.endif
	xor	eax, eax
	ret
OnCreate ENDP			; CShellView::OnCreate

;WC_LISTVIEW DB	'SysListView32', 00H

CreateList PROC uses __this pThis:ptr CShellView

local dwStyle:dword

	mov	__this, pThis

	mov dwStyle,WS_TABSTOP or WS_VISIBLE or WS_CHILD or WS_BORDER or LVS_REPORT or LVS_NOSORTHEADER or LVS_SHAREIMAGELISTS

	invoke CreateWindowEx, WS_EX_CLIENTEDGE, CStr(WC_LISTVIEW), NULL, dwStyle,\
					0, 0, 0, 0, m_hWnd, ID_LISTVIEW, g_hInstance, NULL

	mov	m_hwndList, eax

	.if (!eax)
		jmp exit
	.endif


	invoke	UpdateShellSettings, __this

	mov	eax,TRUE
exit:
	ret

CreateList ENDP


InitList PROC uses __this pThis:ptr CShellView

local lvColumn:LV_COLUMN
local rc:RECT
local szString[MAX_PATH]:byte

	mov	__this, pThis

;----------------- empty the list
	invoke ListView_DeleteAllItems( m_hwndList)

;----------------- initialize the columns
	mov lvColumn.mask_,LVCF_FMT or LVCF_WIDTH or LVCF_TEXT or LVCF_SUBITEM

	mov lvColumn.fmt,LVCFMT_LEFT

	lea eax,szString
	mov lvColumn.pszText,eax

	mov eax,g_nColumn1
	mov lvColumn.cx_,eax


	invoke LoadString, g_hInstance, IDS_COLUMN1, addr szString, sizeof szString

	invoke ListView_InsertColumn( m_hwndList, 0, addr lvColumn)

	invoke GetClientRect, m_hWnd, addr rc

	mov	eax, g_nColumn2
	mov lvColumn.cx_,eax

	invoke LoadString, g_hInstance, IDS_COLUMN2, addr szString, sizeof szString

	invoke ListView_InsertColumn( m_hwndList, 1, addr lvColumn)

	invoke ListView_SetImageList( m_hwndList, g_himlSmall, LVSIL_SMALL)

	mov	eax, 1
	ret

InitList ENDP			; CShellView::InitList


FillList PROC uses __this pThis:ptr CShellView

local	pEnumIDList:ptr CEnumIDList
local	pidl:LPITEMIDLIST
local	dwFetched:dword
local	lvItem:LV_ITEM
local	hCursorPrev:HCURSOR

	DebugOut "FillList"

	mov	__this, pThis

	.if (g_bViewKeys)
		mov ecx,SHCONTF_NONFOLDERS or SHCONTF_FOLDERS
	.else
		mov ecx,SHCONTF_NONFOLDERS
	.endif
	invoke vf(m_pShellFolder,IShellFolder,EnumObjects_), m_hWnd, ecx, addr pEnumIDList
	.if (SUCCEEDED(eax))

		invoke LoadCursor, NULL, IDC_WAIT
		invoke SetCursor, eax
		mov hCursorPrev,eax

;----------------- turn the listview's redrawing off

		invoke SetWindowRedraw( m_hwndList,FALSE)

;----------------- delete old items

		invoke ListView_DeleteAllItems( m_hwndList)

;----------------- refill the list

		invoke ZeroMemory, addr lvItem, sizeof lvItem
;----------------- init item index
		mov lvItem.iItem,0
;----------------- set the mask (is constant)
		mov lvItem.mask_,LVIF_TEXT or LVIF_IMAGE or LVIF_PARAM
;----------------- get text on a callback basis (is constant)
		mov lvItem.pszText,LPSTR_TEXTCALLBACK
;----------------- get the image on a callback basis (is constant)
		mov lvItem.iImage,I_IMAGECALLBACK

		.while (1)

			invoke vf(pEnumIDList,IEnumIDList,Next),1, addr pidl, addr dwFetched
			.break .if (eax != S_OK)
			.break .if (dwFetched == 0)

;----------------- copy the pidl
if COPYPIDL
			invoke Copy_Pidl, m_pPidlMgr, pidl
else
			mov eax,pidl
endif
;----------------- use the copy as item data
			mov lvItem.lParam,eax
if COPYPIDL
;----------------- and free the source pidl
			invoke vf(m_pMalloc,IMalloc,Free),pidl
endif
;----------------- add the item
			invoke ListView_InsertItem( m_hwndList, addr lvItem)

			inc lvItem.iItem
		.endw

;----------------- sort the items
		invoke ListView_SortItems( m_hwndList, CompareItems, m_pShellFolder)

;----------------- turn the listview's redrawing back on and force it to draw
		invoke SetWindowRedraw( m_hwndList,TRUE)

		invoke InvalidateRect, m_hwndList, NULL, TRUE

		invoke UpdateWindow, m_hwndList
	
		ListView_SetItemState m_hwndList, 0, LVIS_FOCUSED, LVIS_FOCUSED

		invoke SetCursor, hCursorPrev

		invoke vf(pEnumIDList,IEnumIDList,Release)

	.endif

	DebugOut "FillList exit"

	ret

FillList ENDP			; CShellView::FillList


CanDoIDockingWindow PROC uses __this pThis:ptr CShellView

local	bReturn:dword
local	hr:sdword
local	pServiceProvider:LPSERVICEPROVIDER
local	pFrame:LPDOCKINGWINDOWFRAME

if (_WIN32_IE LT 0400h)
	xor eax,eax
else
	mov	__this, pThis

	mov	bReturn, FALSE

;-------------------- get the browser's IServiceProvider
	invoke vf(m_pShellBrowser,IUnknown,QueryInterface),addr IID_IServiceProvider, addr pServiceProvider
	mov	hr, eax

	.if (SUCCEEDED(eax))

;-------------------- get the IDockingWindowFrame
		invoke vf(pServiceProvider,IServiceProvider,QueryService),addr IID_IShellBrowser, addr IID_IDockingWindowFrame, addr pFrame
		mov	hr, eax

		.if (SUCCEEDED(eax))

			mov	bReturn, TRUE

			invoke vf(pFrame,IDockingWindowFrame,Release)
		.endif

		invoke vf(pServiceProvider,IServiceProvider,Release)
	.endif

	mov	eax, bReturn
endif

	ret

CanDoIDockingWindow ENDP		; CShellView::CanDoIDockingWindow


AddRemoveDockingWindow PROC uses __this pThis:ptr CShellView, bAdd:dword

local bReturn:dword
local hr:dword
local pServiceProvider:LPSERVICEPROVIDER
local pFrame:LPDOCKINGWINDOWFRAME

if (_WIN32_IE LT 0400h)

	xor eax,eax

else
	mov	__this, pThis

;------------------- get the browser's IServiceProvider
	invoke vf(m_pShellBrowser,IShellBrowser,QueryInterface),addr IID_IServiceProvider, addr pServiceProvider
	mov	hr, eax

	.if (SUCCEEDED(eax))


;------------------- get the IDockingWindowFrame pointer
		invoke vf(pServiceProvider,IServiceProvider,QueryService), addr SID_SShellBrowser, addr IID_IDockingWindowFrame, addr pFrame
		mov	hr, eax

		.if (SUCCEEDED(eax))

			.if (bAdd)

				mov	hr, S_OK

				.if (!m_pDockingWindow)
;-------------------- create the toolbar object
					invoke Create@CDockingWindow, __this, m_hWnd
					mov m_pDockingWindow,eax
				.endif

				.if (m_pDockingWindow)

;-------------------- add the toolbar object
					invoke vf(pFrame,IDockingWindowFrame,AddToolbar), m_pDockingWindow, TOOLBAR_ID, 0
					mov	hr, eax
					.if (SUCCEEDED(eax))
						mov	bReturn, TRUE
					.endif
				.endif
			.else


				.if (m_pDockingWindow)

					invoke vf(pFrame,IDockingWindowFrame,RemoveToolbar), m_pDockingWindow, DWFRF_NORMAL
					mov	hr, eax

					.if (SUCCEEDED(eax))

;------------------- RemoveToolbar should release the toolbar object which will cause 
;------------------- it to destroy itself. Our toolbar object is no longer valid at 
;------------------- this point.
						mov m_pDockingWindow,NULL
						mov bReturn,TRUE
					.endif
				.endif
			.endif

			invoke vf(pFrame,IDockingWindowFrame,Release)

		.endif

		invoke vf(pServiceProvider,IServiceProvider,Release)

	.endif

	mov	eax, bReturn
endif

	ret

AddRemoveDockingWindow ENDP	; CShellView::AddRemoveDockingWindow

if 0
SHELLFLAGSTATE record fRestFlags:3,fHideIcons:1,fShowInfoTip:1,fMapNetDrvBtn:1,\
	fShowAttribCol:1,fDontPrettyPath:1,fWin95Classic:1,fDesktopHTML:1,\
	fDoubleClickInWebView:1,fShowCompColor:1,fShowSysFiles:1,\
	fNoConfirmRecycle:1,fShowExtensions:1,fShowAllObjects:1
endif

pSHGetSettings typedef proto  :ptr SHELLFLAGSTATE,:DWORD
PFNSHGETSETTINGSPROC typedef ptr pSHGetSettings

UpdateShellSettings PROC uses __this pThis:ptr CShellView

local dummy: dword			;probably sfs is located with wrong size (actually WORD!)
							;so this dummy var is added to avoid severe problems
local sfs: SHELLFLAGSTATE
local dwExStyles:dword
local hinstShell32:HINSTANCE
local pfnSHGetSettings:PFNSHGETSETTINGSPROC

if (_WIN32_IE LT 0400h)
	ret
else
	mov	__this, pThis

;---------- Since SHGetSettings is not implemented in all versions of the shell, get the 
;---------- function address manually at run time. This allows the extension to run on all 
;---------- platforms.

	mov sfs, 0

;---------- The default, in case any of the following steps fails, is classic Windows 95 
;---------- style.

	or sfs, MASK fWin95Classic

	invoke LoadLibrary,CStr("shell32.dll")
	mov	hinstShell32, eax

	.if (eax)
		invoke GetProcAddress,hinstShell32, CStr("SHGetSettings")
		mov	pfnSHGetSettings, eax
		.if (eax)
			invoke pfnSHGetSettings,addr sfs, SSF_DOUBLECLICKINWEBVIEW or SSF_WIN95CLASSIC
		.endif
		invoke FreeLibrary,hinstShell32
	.endif

	mov dwExStyles,LVS_EX_INFOTIP

	.if (!sfs)
		or dwExStyles, LVS_EX_ONECLICKACTIVATE or LVS_EX_TRACKSELECT or LVS_EX_UNDERLINEHOT
	.endif

	invoke ListView_SetExtendedListViewStyle( m_hwndList, dwExStyles)

	ret
endif

UpdateShellSettings ENDP		; CShellView::UpdateShellSettings

;*** WM_SETTINGCHANGE handler

OnSettingChange PROC pThis:ptr CShellView, lpszSection:LPSTR

	invoke UpdateShellSettings, pThis
	xor	eax, eax
	ret

OnSettingChange ENDP		; CShellView::OnSettingChange


DoContextMenu PROC uses __this esi pThis:ptr CShellView,x:dword,y:dword,fDefault:dword

local uSelected:dword
local aSelectedItems:ptr LPITEMIDLIST
local pContextMenu:LPCONTEXTMENU
local lvItem:LV_ITEM
local hMenu:HMENU
local fExplore:dword
local hwndTree:HWND
local uCommand:dword
local mii:MENUITEMINFO
local nMenuIndex:dword
local cmi:CMINVOKECOMMANDINFO

	mov	__this, pThis

	invoke ListView_GetSelectedCount( m_hwndList)
	mov	uSelected, eax
	imul eax,sizeof LPITEMIDLIST
	invoke vf(m_pMalloc, IMalloc, Alloc), eax
	mov	aSelectedItems, eax

	.if (eax)

		mov	pContextMenu, 0

		invoke ZeroMemory, addr lvItem, sizeof LV_ITEM

		mov lvItem.mask_,LVIF_PARAM
		mov lvItem.iItem,-1

		mov	esi, 0

		.while (esi < uSelected)

			invoke ListView_GetNextItem( m_hwndList, lvItem.iItem, LVNI_SELECTED)
			.break .if (eax == -1)

			mov lvItem.iItem,eax
			invoke ListView_GetItem( m_hwndList, addr lvItem)
			mov	edx, lvItem.lParam
			mov	ecx, aSelectedItems
			mov	DWORD PTR [ecx+esi*4], edx

			inc esi

		.endw

		invoke vf( m_pShellFolder, IShellFolder, GetUIObjectOf), m_hwndParent,\
			uSelected, aSelectedItems,addr IID_IContextMenu, NULL, addr pContextMenu

		.if (pContextMenu)

			invoke CreatePopupMenu
			mov	hMenu, eax
	
;-------------- See if we are in Explore or Open mode. If the browser's tree is present, 
;-------------- then we are in Explore mode.

			mov	fExplore, FALSE
			mov	hwndTree, 0

			invoke vf( m_pShellBrowser,IShellBrowser,GetControlWindow),FCW_TREE, addr hwndTree
			.if (SUCCEEDED(eax) && hwndTree)
				mov fExplore,TRUE
			.endif

			.if (hMenu)
				mov ecx,CMF_NORMAL
				.if (uSelected != 1)
					or ecx,CMF_CANRENAME
				.endif
				.if (fExplore)
					or ecx,CMF_EXPLORE
				.endif
				invoke vf(pContextMenu,IContextMenu,QueryContextMenu),hMenu,\
						 0, MENU_OFFSET, MENU_MAX, ecx
				.if (SUCCEEDED(eax))
					.if (fDefault)
						mov	uCommand, 0
						invoke ZeroMemory, addr mii, sizeof MENUITEMINFO

						mov mii.cbSize,sizeof MENUITEMINFO
						mov mii.fMask,MIIM_STATE or MIIM_ID
						mov	nMenuIndex, 0
;--------------------- find the default item in the menu
						.while (1)
							invoke GetMenuItemInfo,hMenu, nMenuIndex, TRUE, addr mii
							.break .if (eax == 0)

							.if (mii.fState & MFS_DEFAULT)
								mov	ecx, mii.wID
								mov	uCommand, ecx
								.break
							.endif
							inc nMenuIndex
						.endw
					.else
						invoke TrackPopupMenu, hMenu, TPM_LEFTALIGN or TPM_RETURNCMD,\
										x, y, 0, m_hWnd, NULL
						mov	uCommand, eax
					.endif

					.if (uCommand > 0)

						invoke ZeroMemory, addr cmi, sizeof CMINVOKECOMMANDINFO
						mov cmi.cbSize,sizeof CMINVOKECOMMANDINFO

						mov eax, m_hwndParent
						mov cmi.hwnd,eax

						mov	edx, uCommand
						sub	edx, MENU_OFFSET
						movzx edx,dx
						mov	cmi.lpVerb, edx

						invoke vf(pContextMenu,IContextMenu,InvokeCommand), addr cmi
					.endif

					invoke DestroyMenu, hMenu

				.endif	;(SUCCEEDED)
			.endif		;(hMenu)
			invoke vf(pContextMenu,IContextMenu,Release)
		.endif			;(pContextMenu)
		invoke vf(m_pMalloc,IMalloc,Free),aSelectedItems
	.endif				;(eax)

	ret

DoContextMenu ENDP		; CShellView::DoContextMenu

if ?OLECOMMANDTARGET

QueryInterface_:
	sub	DWORD PTR [esp+4], offset CShellView.vtblIOleCommandTarget
	jmp	QueryInterface
AddRef_:
	sub	DWORD PTR [esp+4], offset CShellView.vtblIOleCommandTarget
	jmp	AddRef
Release_:
	sub	DWORD PTR [esp+4], offset CShellView.vtblIOleCommandTarget
	jmp	Release
QueryStatus_:
	sub	DWORD PTR [esp+4], offset CShellView.vtblIOleCommandTarget
	jmp	QueryStatus
Exec_:
	sub	DWORD PTR [esp+4], offset CShellView.vtblIOleCommandTarget
	jmp	Exec
endif

	END

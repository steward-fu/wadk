
This sample demonstrates how to access ring 0 in win9x from a Win32 user app.
That's done by temporarily manipulating IDT. This works only for Windows 9x!

While in ring 0, interrupts are disabled and shouldn't be enabled. Calling 
nontrivial VMM functions may be a problem, since CS, DS and ES contain ring 3
LDT selectors. So for more sophisticated work to be done in ring 0 you will
have to get flat ring 0 GDT selectors. Thats no problem for DS and ES,
these can be loaded with SS, but to get a valid CS you may need to scan GDT.

japheth


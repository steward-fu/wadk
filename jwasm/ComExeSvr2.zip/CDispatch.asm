
;-----------------------------------------------------------------------
;--- dual interface implementation
;-----------------------------------------------------------------------

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32    
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include objidl.inc
	include ocidl.inc
	include disphlp.inc
	include debugout.inc
	.list
	.cref

	include ComExeSvr2.inc		;COMView generated
	include ComExeSvr2c.inc		;COMView generated (needed for event fireing)
	include CComExeSvr2.inc

DISPID_PROPERTY1	equ 1

	DEFINE_FIREEVENTHELPER

;-----------------------------------------------------------------------
;--- definitions to allow member variable access by
;--- "m_VarName" instead of "[ebx].CComExeSvr2.VarName"
;-----------------------------------------------------------------------

__this	textequ <ebx>
_this	textequ <[__this].CComExeSvr2>

	MEMBER _IDispatch, dwRefCount, pTypeInfo, dwProperty1, pConnectionPoint


	.const

;-----------------------------------------------------------------------
;--- vtable of dual interface
;--- order of methods must match those in .IDL file
;-----------------------------------------------------------------------

CComExeSvr2Vtbl label IComExeSvr2Vtbl
	IDispatchVtbl {QueryInterface@CComExeSvr2, AddRef@CComExeSvr2, Release@CComExeSvr2,\
		GetTypeInfoCount, GetTypeInfo, GetIDsOfNames, Invoke_}
	dd get_Property1, put_Property1

	.code

;-----------------------------------------------------------------------
;--- IDispatch methods
;-----------------------------------------------------------------------

GetTypeInfoCount proc this_:ptr CComExeSvr2, pCntinfo:ptr SDWORD

	DebugOut "IDispatch::GetTypeInfoCount"
	mov ecx, pCntinfo
	mov dword ptr [ecx], 1		;provide 1 typeinfo
	return S_OK

GetTypeInfoCount endp

;------------------------------------------------------------------------

GetTypeInfo proc uses __this this_:ptr CComExeSvr2, iTypeInfo:DWORD, lcid:LCID, ppTInfo:ptr LPTYPEINFO
             
	DebugOut "IDispatch::GetTypeInfo(Index=%u, LCID=%X)", iTypeInfo, lcid

	mov __this, this_

	mov ecx, ppTInfo
	mov dword ptr [ecx],NULL

	.if (iTypeInfo != 0)
		return DISP_E_BADINDEX
	.endif

    mov eax, m_pTypeInfo
	mov ecx, ppTInfo
	mov [ecx], eax
	.if (eax)
		invoke vf(eax, IUnknown, AddRef)
		mov eax, S_OK
	.else
		mov eax, E_FAIL
	.endif
	ret

GetTypeInfo endp

;------------------------------------------------------------------------
;--- IDispatch::GetIDsOfNames: since we have a typeinfo available
;--- the real work is done by ITypeInfo::GetIDsOfNames
;------------------------------------------------------------------------

GetIDsOfNames proc uses __this this_:ptr CComExeSvr2, rrid:ptr IID, rgszNames:DWORD, cNames:DWORD, lcid:LCID, rgDispID:DWORD
			 
	DebugOut "IDispatch::GetIDsOfNames"

	mov __this, this_

    mov eax, m_pTypeInfo
	.if (eax)
		invoke vf( m_pTypeInfo, ITypeInfo, GetIDsOfNames), rgszNames, cNames, rgDispID
	.else
		mov eax, E_FAIL
	.endif
	ret

GetIDsOfNames endp

;-----------------------------------------------------------------------
;--- IDispatch::Invoke. Containers may call this function
;--- to set/get properties or call members in "late binding" mode.
;--- The real work inhere is done by ITypeInfo:Invoke.
;-----------------------------------------------------------------------

Invoke_ proc uses __this this_:ptr CComExeSvr2, dispIdMember:DISPID, riid:ptr IID, lcid:LCID, wFlags:DWORD, 
            pDispParams:ptr DISPPARAMS, pVarResult:ptr VARIANT, pExcepInfo:ptr EXCEPINFO, puArgErr:ptr DWORD

	mov __this, this_

    .if (!m_pTypeInfo)     
		return DISP_E_MEMBERNOTFOUND
    .endif
	invoke SetErrorInfo, NULL, NULL

	invoke vf(m_pTypeInfo, ITypeInfo, Invoke_), __this, dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr
ifdef _DEBUG
	.if (eax != S_OK)
		DebugOut "IDispatch::Invoke DispID=%X returned %X", dispIdMember, eax
	.endif
endif
	ret

Invoke_ endp

;------------------------------------------------------------
;--- custom interface methods/properties
;------------------------------------------------------------

get_Property1 proc this_:ptr CComExeSvr2, pValue:ptr DWORD
	mov ecx, pValue
	mov eax, this_
	mov eax, [eax].CComExeSvr2.dwProperty1
	mov [ecx], eax
	return S_OK
get_Property1 endp

put_Property1 proc uses __this this_:ptr CComExeSvr2, dwNewValue:DWORD

	mov __this, this_
	mov ecx, dwNewValue
	mov m_dwProperty1, ecx
	invoke FIREEVENT(m_pConnectionPoint, _ComExeSvr2Event, OnPropertyChange), DISPID_PROPERTY1
	return S_OK

put_Property1 endp

	end

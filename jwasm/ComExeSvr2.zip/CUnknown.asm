
;-----------------------------------------------------------------------
;--- IUnknown implementation
;-----------------------------------------------------------------------

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32    
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include objidl.inc
	include ocidl.inc
	include debugout.inc
	.list
	.cref

	include ComExeSvr2.inc		;COMView generated include
	include CComExeSvr2.inc

	.const

;-----------------------------------------------------------------------
;--- define the table of exposed interfaces by this object
;-----------------------------------------------------------------------

iftab	label dword
	dd offset IID_IUnknown, 0
	dd offset IID_IDispatch, CComExeSvr2._IDispatch
	dd offset IID_IComExeSvr2, CComExeSvr2._IDispatch
	dd offset IID_IConnectionPointContainer, CComExeSvr2._IConnectionPointContainer
;--------------------- insert new exposed interfaces here
IFTABSIZE equ ($ - offset iftab) / 8

	.code

;*** scan interface tab and see if requested interface is in there

IsInterfaceSupported proc public uses ebx esi edi pReqIF:ptr IID, pIFTab:ptr ptr IID, dwEntries:dword, pThis:ptr, ppReturn:ptr LPUNKNOWN
	
	mov ecx,dwEntries
	mov esi,pIFTab
	mov ebx,0
	.while (ecx)
		lodsd
		mov edi,eax
		lodsd
		mov edx,eax
		mov eax,esi
		mov esi,pReqIF
		push ecx
		mov ecx,4
		repz cmpsd
		pop ecx
		.if (ZERO?)
			mov ebx,edx
			add ebx,pThis
			.break
		.endif
		mov esi,eax
		dec ecx
	.endw
	mov ecx,ppReturn
	mov [ecx],ebx

	.if (ebx)
		invoke vf(ebx,IUnknown,AddRef)
		mov eax,S_OK
	.else
		mov eax,E_NOINTERFACE
	.endif
	ret

IsInterfaceSupported endp


;*** IUnknown::QueryInterface - the real, nondelegated QueryInterface

QueryInterface@CComExeSvr2 PROC public this_:ptr CComExeSvr2,riid:ptr IID,ppReturn:ptr LPUNKNOWN

ifdef _DEBUG
local	szIID[40]:byte
local	wszIID[40]:word
local	szKey[128]:byte
local	dwSize:DWORD
local	hKey:HANDLE
endif

	invoke IsInterfaceSupported, riid, offset iftab, IFTABSIZE,  this_, ppReturn
ifdef _DEBUG
    push eax
	invoke StringFromGUID2,riid, addr wszIID,40
	invoke WideCharToMultiByte, CP_ACP, 0, addr wszIID, -1, addr szIID, 40, NULL, NULL
	invoke wsprintf, addr szKey, CStr("Interface\%s"),addr szIID
	invoke RegOpenKeyEx, HKEY_CLASSES_ROOT, addr szKey, 0, KEY_READ, addr hKey 
	.if (eax == ERROR_SUCCESS)
		mov dwSize, sizeof szKey
		invoke RegQueryValueEx,hKey,CStr(""),NULL,NULL,addr szKey,addr dwSize
		invoke RegCloseKey, hKey
	.else
		mov szKey,0
	.endif
    pop eax
	DebugOut "IUnknown::QueryInterface(%s[%s])=%X", addr szIID, addr szKey, eax
endif
	ret

QueryInterface@CComExeSvr2 ENDP

;*** IUnknown::AddRef

AddRef@CComExeSvr2 PROC public this_:ptr CComExeSvr2

	mov eax,this_
	inc [eax].CComExeSvr2.dwRefCount
	mov	eax, [eax].CComExeSvr2.dwRefCount
	ret
AddRef@CComExeSvr2 ENDP		

;*** IUnknown::Release

Release@CComExeSvr2 PROC public this_:ptr CComExeSvr2

	mov eax,this_
	dec [eax].CComExeSvr2.dwRefCount
	mov eax,[eax].CComExeSvr2.dwRefCount
	.if (eax == 0)
		invoke Destroy@CComExeSvr2, this_
		xor eax,eax
	.endif
	ret

Release@CComExeSvr2 ENDP	

	end


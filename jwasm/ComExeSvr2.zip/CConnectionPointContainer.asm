
;*** implements interfaces
;*** IConnectionPointContainer, IEnumConnectionPoints
;*** IConnectionPoint, IEnumConnections

;*** IConnectionPointContainer interface is exposed by CComExeSvr2 object,
;*** the other three interfaces are implemented as objects

	.386
	.model flat, stdcall
	option casemap:none
	option proc:private

	.nolist
	.nocref
ifdef ?MASM32    
	include \masm32\include\windows.inc
	include \masm32\include\kernel32.inc
	include \masm32\include\advapi32.inc
	include \masm32\include\user32.inc
	include \masm32\include\gdi32.inc
	include \masm32\include\ole32.inc
	include \masm32\include\oleaut32.inc
else
	include windows.inc
endif
	include macros.inc
	include unknwn.inc
	include oaidl.inc
	include objidl.inc
	include ocidl.inc
	include olectl.inc
	include debugout.inc
	.list
	.cref

	include ComExeSvr2.inc
	include CComExeSvr2.inc
	include utility.inc


Create@CEnumConnectionPoints proto :LPUNKNOWN, :ptr LPCONNECTIONPOINTS, :DWORD
Create@CConnectionPoint proto :LPUNKNOWN, :ptr IID

	.const

;--- vtable of IConnectionPointContainer

CConnectionPointContainerVtbl label IConnectionPointContainerVtbl
	dd QueryInterface_, AddRef_, Release_
	dd EnumConnectionPoints_, FindConnectionPoint_
	
IID__ComExeSvr2Event sIID__ComExeSvr2Event

;--- table of outgoing interface IIDs. # of items here must match ?NUMCP
;--- in ATL such a table is defined with BEGIN_CONNECTION_POINT_MAP macros

EventIID_CComExeSvr2 label REFIID
	dd offset IID__ComExeSvr2Event
;--- include further outgoing interfaces here

	.code

__this	textequ <ebx>
_this	textequ <[__this].CComExeSvr2>

	MEMBER pConnectionPoint

;--------------------------------------------------------------------------
;IConnectionPointContainer interface
;--------------------------------------------------------------------------

;--- IConnectionPointContainer vtable is not located at offset 0
;--- so this_ (=[esp+4]) has to be adjusted if method is called thru vtable

Create@CConnectionPoint proto :LPUNKNOWN, :ptr IID

QueryInterface_:
	sub dword ptr [esp+4], CComExeSvr2._IConnectionPointContainer
	jmp QueryInterface@CComExeSvr2
AddRef_:
	sub dword ptr [esp+4], CComExeSvr2._IConnectionPointContainer
	jmp AddRef@CComExeSvr2
Release_:
	sub dword ptr [esp+4], CComExeSvr2._IConnectionPointContainer
	jmp Release@CComExeSvr2

;--- initialize table of ConnectionPoint(s) if not done already
;--- each outgoing interface requires a connectionpoint

InitCP proc uses esi edi

	mov ecx, ?NUMCP
	mov esi, offset EventIID_CComExeSvr2
	lea edi, m_pConnectionPoint
	.while (ecx)
		push ecx
		lodsd
		.if (!(dword ptr [edi]))
			invoke Create@CConnectionPoint, __this, eax
			mov [edi], eax
		.endif
		add edi, 4
		pop ecx
		dec ecx
	.endw
	ret
InitCP endp


EnumConnectionPoints_:
	sub dword ptr [esp+4], CComExeSvr2._IConnectionPointContainer

EnumConnectionPoints PROC uses __this this_:ptr CComExeSvr2, ppEnumConnectionPoints:ptr LPENUMCONNECTIONPOINTS

	DebugOut "IConnectionPointContainer::EnumConnectionPoints"

	mov __this, this_
	.if (ppEnumConnectionPoints == NULL)
		return E_POINTER
	.endif

	invoke InitCP

	invoke Create@CEnumConnectionPoints, __this, addr m_pConnectionPoint, ?NUMCP

	mov ecx,ppEnumConnectionPoints
	mov [ecx],eax
	.if (eax)
		mov eax, S_OK
	.else
		mov eax, E_OUTOFMEMORY
	.endif
	ret

EnumConnectionPoints endp

;--------------------------------------------------------------------------

FindConnectionPoint_:
	sub dword ptr [esp+4], CComExeSvr2._IConnectionPointContainer

FindConnectionPoint PROC uses __this esi edi this_:ptr CComExeSvr2, refIID: ptr IID, ppConnectionPoint:ptr LPCONNECTIONPOINT

local	dwNumCPs:DWORD
local	iid:IID

	mov __this,this_

	DebugOut "IConnectionPointContainer::FindConnectionPoint"

	mov eax,ppConnectionPoint
	.if (eax == NULL)
		return E_POINTER
	.endif
	mov dword ptr [eax],NULL

	invoke InitCP

;--- scan table of connectionpoints if requested iid is there

	lea esi,m_pConnectionPoint
	mov dwNumCPs, ?NUMCP
	.while (dwNumCPs)
		lodsd
		mov edi, eax
		invoke vf(edi, IConnectionPoint, GetConnectionInterface), addr iid
		.if (eax == S_OK)
			invoke IsEqualGUID, addr iid, refIID
			.if (eax)
				mov ecx, ppConnectionPoint
				mov [ecx], edi
				invoke vf(edi, IUnknown, AddRef)
				return S_OK
			.endif
		.endif
		dec dwNumCPs
	.endw
	
	return CONNECT_E_NOCONNECTION

FindConnectionPoint endp


;--------------------------------------------------------------------------
;IEnumConnectionPoints interface
;--------------------------------------------------------------------------


CEnumConnectionPoints struct
_IEnumConnectionPoints	IEnumConnectionPoints <>
dwRefCount		DWORD	?
pObject			LPUNKNOWN ?
dwIndex			DWORD	?
pCPTab			LPVOID	?
dwSize			DWORD	?
CEnumConnectionPoints ends

__this	textequ <ebx>
_this	textequ <[__this].CEnumConnectionPoints>

	MEMBER _IEnumConnectionPoints, dwRefCount, pObject, dwIndex, pCPTab, dwSize

	.const

CEnumConnectionPointsVtbl label IEnumConnectionPointsVtbl
	dd QueryInterface@CEnumConnectionPoints, AddRef@CEnumConnectionPoints, Release@CEnumConnectionPoints
	dd Next@CEnumConnectionPoints, Skip@CEnumConnectionPoints, Reset@CEnumConnectionPoints, Clone@CEnumConnectionPoints

	.code

Create@CEnumConnectionPoints proc uses __this pObject:LPUNKNOWN, pCPs:ptr LPCONNECTIONPOINTS, dwSize:DWORD

	DebugOut "Create@CEnumConnectionPoints"

	invoke LocalAlloc,LMEM_FIXED,sizeof CEnumConnectionPoints
	.if (eax == NULL)
		ret
	.endif
	mov __this, eax

	mov m__IEnumConnectionPoints, offset CEnumConnectionPointsVtbl
	mov m_dwRefCount,1
	mov eax,pObject
	mov m_pObject,eax
	invoke vf(eax, IUnknown, AddRef)
	mov m_dwIndex,0
	mov eax, dwSize
	mov m_dwSize, eax
	mov eax, pCPs
	mov m_pCPTab, eax

	return __this

Create@CEnumConnectionPoints endp


Destroy@CEnumConnectionPoints PROC uses __this this_:ptr CEnumConnectionPoints

	DebugOut "Destroy@CEnumConnectionPoints"

	mov __this,this_
	invoke vf(m_pObject, IUnknown, Release)
	invoke LocalFree, __this
	ret

Destroy@CEnumConnectionPoints ENDP

	.const

iftab@CEnumConnectionPoints label dword
	dd offset IID_IUnknown,0
	dd offset IID_IEnumConnectionPoints,0
IFTABSIZE1 equ ($ - iftab@CEnumConnectionPoints)/ (2 * sizeof dword)

	.code

QueryInterface@CEnumConnectionPoints PROC this_:ptr CEnumConnectionPoints,riid:ptr IID,ppReturn:ptr
	invoke IsInterfaceSupported, riid, offset iftab@CEnumConnectionPoints, IFTABSIZE1,  this_, ppReturn
	ret
QueryInterface@CEnumConnectionPoints ENDP	


AddRef@CEnumConnectionPoints PROC uses __this this_:ptr CEnumConnectionPoints

	mov __this,this_
	inc m_dwRefCount
	mov	eax, m_dwRefCount
	ret

AddRef@CEnumConnectionPoints ENDP			


Release@CEnumConnectionPoints PROC uses __this this_:ptr CEnumConnectionPoints
	
	mov __this,this_

	dec m_dwRefCount
	mov eax, m_dwRefCount
	.if (eax == 0)
		invoke Destroy@CEnumConnectionPoints, __this
		xor eax,eax
	.endif
	ret

Release@CEnumConnectionPoints ENDP


Next@CEnumConnectionPoints PROC uses __this esi edi this_:ptr CEnumConnectionPoints, dwElements:dword, ppConnectionPoint:ptr LPCONNECTIONPOINT, pdwFetched:ptr dword

local	dwReturn:dword

	DebugOut "IEnumConnectionPoints::Next"

	mov __this,this_

	.if (dwElements > 1 && !pdwFetched)
		return E_INVALIDARG
	.endif

	mov edi, ppConnectionPoint
	.if (!edi)
		return E_POINTER
	.endif

	mov dwReturn,0

	mov ecx, m_dwIndex
	mov esi,m_pCPTab
	lea esi,[esi+ecx*4]

	.while (dwElements && (ecx < m_dwSize))
		push ecx
		lodsd
		stosd
		invoke vf(eax, IUnknown, AddRef)
		pop ecx
		inc ecx
		dec dwElements
		inc m_dwIndex
		inc dwReturn
	.endw

	mov eax,pdwFetched
	.if (eax)
		mov ecx,dwReturn
		mov [eax],ecx
	.endif

	.if (dwElements == 0)
		mov eax,S_OK
	.else
		mov eax,S_FALSE
	.endif
	ret

Next@CEnumConnectionPoints endp

;--------------------------------------------------------------------------

Skip@CEnumConnectionPoints PROC uses __this this_:ptr CEnumConnectionPoints,cConn:dword

	DebugOut "IEnumConnectionPoints::Skip(%u)", cConn
	mov __this,this_
	mov ecx, cConn
	add ecx, m_dwIndex
	.if (ecx < m_dwSize)
		mov m_dwIndex, ecx
		mov eax, S_OK
	.else
		mov ecx, m_dwSize
		dec ecx
		mov m_dwIndex, ecx
		mov eax, S_FALSE
	.endif
	ret

Skip@CEnumConnectionPoints endp

;--------------------------------------------------------------------------

Reset@CEnumConnectionPoints PROC this_:ptr CEnumConnectionPoints
	
	DebugOut "IEnumConnectionPoints::Reset"
	mov ecx,this_
	mov [ecx].CEnumConnectionPoints.dwIndex,0
	return S_OK
Reset@CEnumConnectionPoints endp

;--------------------------------------------------------------------------

Clone@CEnumConnectionPoints PROC uses __this this_:ptr CEnumConnectionPoints, ppEnumConnectionPoints:ptr LPENUMCONNECTIONPOINTS

	mov __this,this_
	invoke Create@CEnumConnectionPoints, m_pObject, m_pCPTab, m_dwSize
	.if (!eax)
		mov eax, E_OUTOFMEMORY
		jmp done
	.endif
	mov edx, m_dwIndex
	mov ecx, ppEnumConnectionPoints
	mov [eax].CEnumConnectionPoints.dwIndex, edx
	mov [ecx], eax
	mov eax, S_OK
done:
	ret

Clone@CEnumConnectionPoints endp


;--------------------------------------------------------------------------
;--- IConnectionPoint interface
;--------------------------------------------------------------------------


;*** definition of CConnectionPoint class

;*** helper struct CEventSink (linked list of connected sinks)

LPEVENTSINK typedef ptr CEventSink

CEventSink struct
m_pNext		LPEVENTSINK ?
m_pSink		LPUNKNOWN	?
CEventSink ends


CConnectionPoint struct
_IConnectionPoint	IConnectionPoint <>
dwRefCount			DWORD	?
iid					IID	<>
pFirstSink			LPEVENTSINK	?	;pointer to list of connected sinks
pObject				LPUNKNOWN ?		;pointer to object (CComExeSvr2)
CConnectionPoint ends

__this	textequ <ebx>
_this	textequ <[__this].CConnectionPoint>

	MEMBER _IConnectionPoint, dwRefCount, iid, pFirstSink, pObject

Create@CEnumConnections proto :LPUNKNOWN, :LPEVENTSINK

	.const

CConnectionPointVtbl label IConnectionPointVtbl 
	dd QueryInterface@CConnectionPoint, AddRef@CConnectionPoint, Release@CConnectionPoint
	dd GetConnectionInterface, GetConnectionPointContainer
	dd Advise, Unadvise, EnumConnections

	.code

Create@CConnectionPoint proc uses __this pObject:LPUNKNOWN, riid:ptr IID

	DebugOut "Create@CConnectionPoint"

	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CConnectionPoint
	.if (!eax)
		ret
	.endif
	mov __this, eax

	mov m__IConnectionPoint,offset CConnectionPointVtbl
	mov m_dwRefCount,1
	mov eax,pObject
	mov m_pObject,eax
;------------------- do NOT call AddRef for pObject
	pushad
	mov esi, riid
	lea edi, m_iid
	movsd
	movsd
	movsd
	movsd
	popad
	mov m_pFirstSink,NULL

	return __this

Create@CConnectionPoint endp

Destroy@CConnectionPoint PROC uses __this this_:ptr CConnectionPoint

	DebugOut "Destroy@CConnectionPoint"

	mov __this,this_

	xor eax, eax
	xchg eax, m_pFirstSink

;--- delete remaining items from sink list. Shouldnt be necessary

	.while (eax)
		push [eax].CEventSink.m_pNext
		invoke LocalFree, eax
		pop eax
	.endw
	invoke LocalFree, __this
	ret

Destroy@CConnectionPoint ENDP

	.const

iftab@CConnectionPoint label dword
	dd offset IID_IUnknown,0
	dd offset IID_IConnectionPoint,0
IFTABSIZE2 equ ($ - iftab@CConnectionPoint)/ (2 * sizeof dword)

	.code

QueryInterface@CConnectionPoint PROC this_:ptr CConnectionPoint,riid:ptr IID,ppReturn:ptr
	invoke IsInterfaceSupported, riid, offset iftab@CConnectionPoint, IFTABSIZE2,  this_, ppReturn
	ret
QueryInterface@CConnectionPoint ENDP	


AddRef@CConnectionPoint PROC uses __this this_:ptr CConnectionPoint

	mov __this,this_
	inc m_dwRefCount
	DebugOut "IConnectionPoint::AddRef %u", m_dwRefCount
	mov	eax, m_dwRefCount
	ret

AddRef@CConnectionPoint ENDP			


Release@CConnectionPoint PROC uses __this this_:ptr CConnectionPoint

	mov __this,this_

	dec m_dwRefCount

	DebugOut "IConnectionPoint::Release %u", m_dwRefCount

	mov eax, m_dwRefCount
	.if (eax == 0)
		invoke Destroy@CConnectionPoint, __this
		xor eax,eax
	.endif
	ret

Release@CConnectionPoint ENDP


GetConnectionInterface PROC uses esi edi __this this_:ptr CConnectionPoint,ppIID:ptr ptr IID

	DebugOut "IConnectionPoint::GetConnectionInterface"

	mov __this, this_
	mov edi,ppIID
	.if (edi == NULL)
		return E_POINTER
	.endif
	lea esi,m_iid
	movsd
	movsd
	movsd
	movsd
	return S_OK

GetConnectionInterface endp

;--------------------------------------------------------------------------

GetConnectionPointContainer PROC uses __this this_:ptr CConnectionPoint, ppCPContainer:ptr LPCONNECTIONPOINTCONTAINER

	DebugOut "IConnectionPoint::GetConnectionPointContainer"

	mov __this,this_
	invoke vf(m_pObject, IUnknown, QueryInterface), addr IID_IConnectionPointContainer, ppCPContainer
	ret

GetConnectionPointContainer endp

;--------------------------------------------------------------------------


Advise PROC uses __this esi this_:ptr CConnectionPoint, pUnknown:LPUNKNOWN, pdwCookie:ptr dword

	DebugOut "IConnectionPoint::Advise"

	mov __this,this_

	mov eax,pdwCookie
	.if (eax == 0)
		return E_POINTER
	.endif
	mov dword ptr [eax],0

	invoke LocalAlloc, LMEM_FIXED or LMEM_ZEROINIT, sizeof CEventSink
	.if (eax == NULL)
		return E_OUTOFMEMORY
	.endif
	mov esi,eax
	invoke vf(pUnknown, IUnknown, QueryInterface), addr m_iid, addr [esi].CEventSink.m_pSink

	.if (eax != S_OK)
		invoke LocalFree, esi
		DebugOut "IConnectionPoint::Advise failed with CONNECT_E_CANNOTCONNECT"
		return CONNECT_E_CANNOTCONNECT
	.endif
;--------------------------- add sink to list of connected clients
	lea eax, m_pFirstSink
	.while ([eax].CEventSink.m_pNext)
		mov eax, [eax].CEventSink.m_pNext
	.endw
	mov [eax].CEventSink.m_pNext, esi
	mov eax,pdwCookie
	mov [eax],esi
	return S_OK

Advise endp

;--------------------------------------------------------------------------

Unadvise PROC uses __this esi this_:ptr CConnectionPoint, dwCookie:dword

	DebugOut "IConnectionPoint::Unadvise"

	mov __this,this_

	lea esi, m_pFirstSink

	.while ([esi].CEventSink.m_pNext)
		mov eax,[esi].CEventSink.m_pNext
		.if (eax == dwCookie)
		    invoke vf([eax].CEventSink.m_pSink, IUnknown, Release)
;--------------------------------- delete item from list of connected clients
			mov eax,[esi].CEventSink.m_pNext
			push [eax].CEventSink.m_pNext
			invoke LocalFree, eax
			pop [esi].CEventSink.m_pNext
			return S_OK
		.endif
		mov esi,[esi].CEventSink.m_pNext
	.endw

	return CONNECT_E_NOCONNECTION

Unadvise endp

;--------------------------------------------------------------------------

EnumConnections PROC this_:ptr CConnectionPoint, ppIEnumConnections:ptr LPENUMCONNECTIONS

	DebugOut "IConnectionPoint::EnumConnections"
	mov eax, this_
	invoke Create@CEnumConnections, eax, [eax].CConnectionPoint.pFirstSink
	mov ecx, ppIEnumConnections
	mov [ecx], eax
	.if (eax)
		mov eax, S_OK
	.else
		mov eax, E_FAIL
	.endif
	ret

EnumConnections endp


;--------------------------------------------------------------------------
;--- interface IEnumConnections
;--------------------------------------------------------------------------


CEnumConnections struct
_IEnumConnections	IEnumConnections <>
dwRefCount			DWORD	?
pObject				LPUNKNOWN ?		;connection point object
pEventSink			LPEVENTSINK	?	;list of connected event sinks
dwIndex				DWORD	?		;current index
CEnumConnections ends

__this	textequ <ebx>
_this	textequ <[__this].CEnumConnections>

	MEMBER _IEnumConnections, dwRefCount, pObject, pEventSink, dwIndex

	.const

CEnumConnectionsVtbl label IEnumConnectionsVtbl
	dd QueryInterface@CEnumConnections, AddRef@CEnumConnections, Release@CEnumConnections
	dd Next@CEnumConnections, Skip@CEnumConnections, Reset@CEnumConnections, Clone@CEnumConnections

	.code

Create@CEnumConnections proc uses __this pObject:LPUNKNOWN, pEventSink:LPEVENTSINK

	DebugOut "Create@CEnumConnections"

	invoke LocalAlloc,LMEM_FIXED,sizeof CEnumConnections
	.if (eax == NULL)
		ret
	.endif
	mov __this, eax

	mov m__IEnumConnections,offset CEnumConnectionsVtbl
	mov m_dwRefCount,1
	mov eax, pObject
	mov m_pObject, eax
	invoke vf(eax, IUnknown, AddRef)
	mov eax, pEventSink
	mov m_pEventSink,eax
	mov m_dwIndex,0

	return __this

Create@CEnumConnections endp


Destroy@CEnumConnections PROC this_:ptr CEnumConnections

	DebugOut "Destroy@CEnumConnections"

	mov eax,this_
	invoke vf([eax].CEnumConnections.pObject, IUnknown, Release)
	invoke LocalFree,this_
	ret

Destroy@CEnumConnections ENDP


	.const

iftab@CEnumConnections label dword
	dd offset IID_IUnknown,0
	dd offset IID_IEnumConnections,0
IFTABSIZE3 equ ($ - iftab@CEnumConnections)/ (2 * sizeof dword)

	.code


QueryInterface@CEnumConnections PROC this_:ptr CEnumConnections,riid:ptr IID,ppReturn:ptr
	invoke IsInterfaceSupported, riid, offset iftab@CEnumConnections, IFTABSIZE3,  this_, ppReturn
	ret
QueryInterface@CEnumConnections ENDP	


AddRef@CEnumConnections PROC uses __this this_:ptr CEnumConnections

	mov __this,this_
	inc m_dwRefCount
	DebugOut "IEnumConnections::AddRef %u", m_dwRefCount
	mov	eax, m_dwRefCount
	ret

AddRef@CEnumConnections ENDP			


Release@CEnumConnections PROC uses __this this_:ptr CEnumConnections

	mov __this,this_

	dec m_dwRefCount

	DebugOut "IEnumConnections::Release %u", m_dwRefCount

	mov eax, m_dwRefCount
	.if (eax == 0)
		invoke Destroy@CEnumConnections, __this
		xor eax,eax
	.endif
	ret

Release@CEnumConnections ENDP

Next@CEnumConnections PROC uses __this esi edi this_:ptr CEnumConnections, dwElements:dword, ppICP:ptr LPCONNECTIONPOINT, pdwFetched:ptr dword

local	dwReturn:dword

;	DebugOut "IEnumConnections::Next"

	mov __this,this_

	.if (dwElements > 1 && !pdwFetched)
		return E_INVALIDARG
	.endif

	mov edi,ppICP
	.if (!edi)
		return E_POINTER
	.endif

	mov dwReturn,0

	mov esi, m_pEventSink
	assume esi:ptr CEventSink
	mov ecx, m_dwIndex
	.while (ecx && esi)
		mov esi, [esi].m_pNext
		dec ecx
	.endw

	.while (dwElements && esi)
		push ecx
		mov eax, [esi].m_pSink
		stosd
		invoke vf(eax, IUnknown, AddRef)
		pop ecx
		mov esi, [esi].m_pNext
		inc ecx
		dec dwElements
		inc m_dwIndex
		inc dwReturn
	.endw

	mov eax,pdwFetched
	.if (eax)
		mov ecx,dwReturn
		mov [eax],ecx
	.endif

	.if (dwElements == 0)
		mov eax,S_OK
	.else
		mov eax,S_FALSE
	.endif
	ret
	assume esi:nothing

Next@CEnumConnections endp


;--------------------------------------------------------------------------

Skip@CEnumConnections PROC uses __this esi this_:ptr CEnumConnections,cConn:dword
	
	mov __this,this_
	mov esi, m_pEventSink
	assume esi:ptr CEventSink
	mov ecx, m_dwIndex
	add ecx, cConn
	xor edx, edx
	.while (ecx && esi)
		mov esi, [esi].m_pNext
		dec ecx
		inc edx
	.endw
	sub edx, m_dwIndex
	add m_dwIndex, edx
	.if (edx == cConn)
		mov eax, S_OK
	.else
		mov eax, S_FALSE
	.endif
	ret
	assume esi:nothing

Skip@CEnumConnections endp

;--------------------------------------------------------------------------

Reset@CEnumConnections PROC this_:ptr CEnumConnections
	
	DebugOut "IEnumConnections::Reset"
	mov ecx,this_
	mov [ecx].CEnumConnections.dwIndex,0
	return S_OK

Reset@CEnumConnections endp

;--------------------------------------------------------------------------

Clone@CEnumConnections PROC uses __this this_:ptr CEnumConnections, ppEnumConnections:ptr LPENUMCONNECTIONS

	mov __this,this_
	invoke Create@CEnumConnections, m_pObject, m_pEventSink
	.if (!eax)
		mov eax, E_OUTOFMEMORY
		jmp done
	.endif
	mov edx, m_dwIndex
	mov ecx, ppEnumConnections
	mov [eax].CEnumConnections.dwIndex, edx
	mov [ecx], eax
	mov eax, S_OK
done:
	ret
Clone@CEnumConnections endp


	end

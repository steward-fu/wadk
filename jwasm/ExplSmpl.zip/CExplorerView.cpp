
#define STRICT

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <stdio.h>
#include "explsmpl.h"
#include "resource.h"

// methods of class CExplorerView which is the base class of the main view
// these class does all the "standard" handling

// Constructor of the explorer view
// all child windows are created here

CExplorerView::CExplorerView(HWND hWnd)
{
	HINSTANCE hInstance	= g_hInstance;
	
	m_hWndTreeView = CreateWindowEx( WS_EX_CLIENTEDGE,
					WC_TREEVIEW,
					NULL,
					WS_CHILD | WS_VISIBLE | WS_TABSTOP | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | TVS_SHOWSELALWAYS,
					0,0,0,0,
					hWnd,
					(HMENU)IDC_TREEVIEW,
					hInstance,
					NULL);

	m_hWndListView = CreateWindowEx( WS_EX_CLIENTEDGE,
					WC_LISTVIEW,
					NULL,
					WS_CHILD | WS_VISIBLE | WS_TABSTOP | LVS_REPORT | LVS_SHOWSELALWAYS,
					0,0,0,0,
					hWnd,
					(HMENU)IDC_LISTVIEW,
					hInstance,
					NULL);
		
	m_hWndToolbar = CreateToolbarEx ( hWnd,
					WS_CHILD | WS_VISIBLE | TBSTYLE_TOOLTIPS | TBSTYLE_FLAT,
					IDC_TOOLBAR,
					2,				// number of button images in IDB_BITMAP
					hInstance,
					IDB_BITMAP1,
					g_tbbutton,
					g_iNumButtons,	// number of buttons in toolbar
					16,16,			// x y for buttons
					16,15,			// x y for bitmaps
					sizeof(TBBUTTON));

	m_hWndStatusBar = CreateWindowEx ( 0,
					STATUSCLASSNAME,
					NULL,
					WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP | CCS_BOTTOM,
					0,0,0,0,
					hWnd,
					(HMENU)IDC_STATUSBAR,
					hInstance,
					NULL);

	m_hHalftoneBrush = 0;

	if (m_hWndTreeView && m_hWndListView && m_hWndStatusBar) {
		SetWindowLong(hWnd,0,(LONG)this);
	} else
		m_hWndTreeView = NULL;
}

CExplorerView::~CExplorerView()
{
	if (m_hHalftoneBrush)
		DeleteObject(m_hHalftoneBrush);
}

// user resizes TreeView/ListView. This is the only function with GDI stuff

void CExplorerView::DrawResizeLine(HWND hwnd, int xPos)
{
        
	HBRUSH hBrushOld;
	HDC hdc; 
	RECT rc;
	
	if (!m_hHalftoneBrush) {
		int i;
		HBITMAP hBitmap;
		WORD pattern[8];

		for (i=0;i<8;i++) 
			pattern[i] = 0x5555 << (i & 1);
										// Create a pattern halftone brush
		hBitmap = CreateBitmap(8,8,1,1,pattern);
		m_hHalftoneBrush = CreatePatternBrush(hBitmap);
		DeleteObject(hBitmap);				// bitmap no longer needed
	}
	GetClientRect(m_hWndTreeView, &rc);

	hdc = GetDC(hwnd);
	hBrushOld = (HBRUSH)SelectObject(hdc, m_hHalftoneBrush); 
	PatBlt(hdc,xPos, m_iToolbarHeight + 2, 4, rc.bottom, PATINVERT);

	SelectObject(hdc, hBrushOld);		// clean up 
	ReleaseDC(hwnd, hdc);

	m_iOldResizeLine = xPos;
}



BOOL CALLBACK aboutproc(HWND hWnd,UINT message,WPARAM wparam,LPARAM lparam)
{
	BOOL rc = FALSE;
	switch (message) {
	case WM_CLOSE:
		EndDialog(hWnd,0);
		break;
	case WM_COMMAND:
		SendMessage(hWnd,WM_CLOSE,0,0);
		break;
	}
	return rc;
}


// rearrange clients in response to WM_SIZE

int CExplorerView::ResizeClients(HWND hWnd)
{
	RECT rect;
	RECT rectTV;
	RECT rectSB;
	RECT rectTB;
	HDWP hdwp;

	GetClientRect(hWnd,&rect);
	
	GetWindowRect(m_hWndToolbar,&rectTB);
	rectTB.bottom = rectTB.bottom - rectTB.top;
	
	GetWindowRect(m_hWndStatusBar,&rectSB);
	rectSB.bottom = rectSB.bottom - rectSB.top;

	GetWindowRect(m_hWndTreeView,&rectTV);
	rectTV.right = rectTV.right - rectTV.left;

	if (rectTV.right == 0) { 
		int aWidths[2];
		rectTV.right = MulDiv(rect.right,1,3) - 2;
		aWidths[0] = rect.right / 3;
		aWidths[1] = -1;
		SendMessage (m_hWndStatusBar, SB_SETPARTS, 2, (LPARAM)aWidths);
	}

	m_iToolbarHeight = rectTB.bottom;

	hdwp = BeginDeferWindowPos(4);

// set the status bar
	
	DeferWindowPos(hdwp, m_hWndStatusBar, NULL,
				0,rect.bottom - rectSB.bottom,
				rect.right,rectSB.bottom,
				SWP_NOZORDER | SWP_NOACTIVATE);

// set the toolbar control	
	
	DeferWindowPos(hdwp, m_hWndToolbar, NULL,
				0,0,rect.right,rectTB.bottom,
				SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

// set the tree view control	
	
	DeferWindowPos(hdwp, m_hWndTreeView, NULL,
				0, rectTB.bottom,	rectTV.right,
				rect.bottom - rectSB.bottom - rectTB.bottom,
				SWP_NOZORDER | SWP_NOACTIVATE);

// set the list view control	

	DeferWindowPos(hdwp, m_hWndListView, NULL, 
				rectTV.right + 4, rectTB.bottom,
				rect.right - rectTV.right - 4,
				rect.bottom - rectSB.bottom - rectTB.bottom,
				SWP_NOZORDER | SWP_NOACTIVATE);

	return EndDeferWindowPos(hdwp);
}

// adjust treeview & listview only

int CExplorerView::AdjustTreeAndList(HWND hWnd,int iWidth)
{
	RECT rect;
	RECT rectTV;
	HDWP hdwp;

	GetClientRect(hWnd,&rect);
	if (iWidth > 0 && iWidth < rect.right) {
		GetWindowRect(m_hWndTreeView,&rectTV);
		rectTV.right = iWidth - rect.left;
		hdwp = BeginDeferWindowPos(2);
		DeferWindowPos(hdwp, m_hWndTreeView, NULL,
				0,0,
				rectTV.right,
				rectTV.bottom - rectTV.top,
				SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
		DeferWindowPos(hdwp, m_hWndListView, NULL,
				rectTV.right + 4,  m_iToolbarHeight,
				rect.right - rectTV.right - 4,
				rectTV.bottom - rectTV.top,
				SWP_NOZORDER | SWP_NOACTIVATE);
		EndDeferWindowPos(hdwp);
	}
	return 1;
}

// WM_PAINT main window
// the only painting required from the main window is the splitter bar

void CExplorerView::DoPaint(HWND hWnd)
{
	PAINTSTRUCT ps;
	HDC hDC;
	RECT rect;
	HBRUSH hBrush;

	hDC = BeginPaint(hWnd,&ps);
	hBrush = CreateSolidBrush(GetSysColor(COLOR_ACTIVEBORDER));
	GetWindowRect(m_hWndTreeView,&rect);
	rect.left = rect.right - rect.left;
	rect.bottom = rect.bottom - rect.top + m_iToolbarHeight; 
	rect.right = rect.left + 4;
	rect.top = m_iToolbarHeight;
	FillRect(hDC,&rect,hBrush);
	DeleteObject(hBrush);
	EndPaint(hWnd,&ps);

	return;
}

// handle WM_NOTIFY

LRESULT CExplorerView::OnNotify(HWND hWnd,WPARAM wParam,LPNMHDR pNMHdr)
{
	LPTOOLTIPTEXT pTTT;
	LRESULT rc = 0;

	switch (pNMHdr->code) {
	case TTN_NEEDTEXT:	
						// help string ID = command ID!
		pTTT = (LPTOOLTIPTEXT)pNMHdr;
		pTTT->hinst = g_hInstance;
		pTTT->lpszText = (LPSTR)pTTT->hdr.idFrom;
		break;
	}
	return rc;
}

// handle WM_COMMAND

LRESULT CExplorerView::OnCommand(HWND hWnd,WPARAM wparam,LPARAM lparam)
{
	LRESULT rc = 0;

	switch (LOWORD(wparam)) {
	case IDM_ABOUT:
		DialogBox(g_hInstance,
			MAKEINTRESOURCE(IDD_DIALOG1),
			hWnd,
			aboutproc);
		break;
	case IDM_EXIT:
		DestroyWindow(hWnd);
		break;
	}
	return rc;
}

LRESULT CExplorerView::OnMessage(HWND hWnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	static HWND hWndActive = NULL;
	LRESULT rc = 0;
	char szText[80];

	switch (message) {
	case WM_ACTIVATE:							// save currently active
		if (LOWORD(wparam) == WA_INACTIVE) {	// child
			hWndActive = GetFocus();
		} else
			if (hWndActive)						// and restore it if we
				SetFocus(hWndActive);			// become active again
		break;
	case WM_SIZE:
		if (wparam != SIZE_MINIMIZED)
			ResizeClients(hWnd);
		break;
	case WM_LBUTTONDOWN:
		RECT rect;
		RECT rect2;
		GetWindowRect(m_hWndTreeView, &rect);
		GetWindowRect(m_hWndListView, &rect2);
		UnionRect(&rect, &rect, &rect2);
		ClipCursor(&rect);
		SetCapture(hWnd);
		m_iOldResizeLine = -1;
		DrawResizeLine(hWnd,LOWORD(lparam));
		break;
	case WM_LBUTTONUP:
		if (GetCapture() == hWnd) {
			ClipCursor(NULL);
			ReleaseCapture();
			DrawResizeLine(hWnd, m_iOldResizeLine);
			AdjustTreeAndList(hWnd,(int)LOWORD(lparam));
		}
		break;
	case WM_MOUSEMOVE:	
		if (GetCapture() == hWnd) { 	// 
			DrawResizeLine(hWnd, m_iOldResizeLine);
			DrawResizeLine(hWnd, LOWORD(lparam));
		}
		break;
	case WM_ENTERMENULOOP:
		SendMessage( m_hWndStatusBar,SB_SIMPLE,1,0);	// simple mode on		
		break;
	case WM_EXITMENULOOP:
		SendMessage( m_hWndStatusBar,SB_SIMPLE,0,0);	// simple mode off	
		break;
	case WM_MENUSELECT:
		szText[0] = 0;
		LoadString( g_hInstance, LOWORD(wparam), szText, sizeof(szText));
		SendMessage( m_hWndStatusBar, SB_SETTEXT, 255, (LPARAM)szText);		
		break;
	case WM_PAINT:
		DoPaint(hWnd);
		break;
	default:
		rc = DefWindowProc(hWnd,message,wparam,lparam);
	}
	return rc;
}
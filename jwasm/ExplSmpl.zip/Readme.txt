
sample written in C++ of how to implement an explorer-like app.

Use this code as you wish.

An VC project file is supplied for easy compilation (.dsp + .dsw).
Or you may just use the makefile as well.

japeth 1999

